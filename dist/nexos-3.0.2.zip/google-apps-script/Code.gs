/**
 * NEXOS TORRE - Google Apps Script Backend
 * Este script recebe dados da extensão e escreve no Google Sheets
 * 
 * INSTRUÇÕES DE CONFIGURAÇÃO:
 * 1. Abra sua planilha do Google Sheets
 * 2. Vá em Extensões > Apps Script
 * 3. Cole este código no editor
 * 4. Clique em "Implantar" > "Nova implantação"
 * 5. Tipo: "Aplicativo da web"
 * 6. Execute como: "Eu"
 * 7. Quem tem acesso: "Qualquer pessoa"
 * 8. Clique em "Implantar"
 * 9. Copie a URL do aplicativo da web
 * 10. Cole a URL em sheets-logger.js > SHEETS_CONFIG.webAppUrl
 */

// ID da planilha (será substituído pelos dados recebidos)
const SPREADSHEET_ID = '1w36aYfJaDJcYRTMV_Lh1duCqDTEBE31iGDXb_lrSfbI';

/**
 * Função que recebe requisições POST
 */
function doPost(e) {
  try {
    Logger.log('📥 Recebendo dados da extensão Nexos...');
    
    // Parse do corpo da requisição
    const data = JSON.parse(e.postData.contents);
    
    Logger.log('📦 Dados recebidos:', data);
    
    // Extrair configurações
    const spreadsheetId = data.spreadsheetId || SPREADSHEET_ID;
    const sheetName = data.sheetName || 'Solicitações';
    const values = data.values || [];
    
    if (values.length === 0) {
      return ContentService.createTextOutput(JSON.stringify({
        success: false,
        message: 'Nenhum dado para inserir'
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    // Abrir planilha
    const spreadsheet = SpreadsheetApp.openById(spreadsheetId);
    let sheet = spreadsheet.getSheetByName(sheetName);
    
    // Se a aba não existir, criar
    if (!sheet) {
      Logger.log(`⚠️ Aba "${sheetName}" não encontrada. Criando...`);
      sheet = spreadsheet.insertSheet(sheetName);
      
      // Adicionar cabeçalhos
      const headers = [
        'Data/Hora',
        'Loja',
        'Pedido',
        'Status',
        'Plataforma',
        'Cliente',
        'Telefone',
        'Endereço',
        'Complemento',
        'Bairro',
        'CEP',
        'Valor',
        'Tracking Link',
        'Usuário'
      ];
      sheet.appendRow(headers);
      
      // Formatar cabeçalhos
      const headerRange = sheet.getRange(1, 1, 1, headers.length);
      headerRange.setFontWeight('bold');
      headerRange.setBackground('#4A5568');
      headerRange.setFontColor('#FFFFFF');
    }
    
    // Adicionar linha
    sheet.appendRow(values);
    
    Logger.log('✅ Dados inseridos com sucesso!');
    
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      message: 'Dados inseridos com sucesso',
      row: sheet.getLastRow()
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    Logger.log('❌ Erro:', error.toString());
    
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      message: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Função de teste (opcional)
 */
function testInsert() {
  const testData = {
    spreadsheetId: SPREADSHEET_ID,
    sheetName: 'Solicitações',
    values: [
      new Date().toLocaleString('pt-BR'),
      '1685',
      '40939786',
      'SOLICITADO',
      'UBER',
      'João da Silva',
      '(11) 98765-4321',
      'Rua Teste, 123',
      'Apto 45',
      'Centro',
      '01234-567',
      'R$ 125,50',
      'https://tracking.uber.com/123',
      'usuario@example.com'
    ]
  };
  
  const e = {
    postData: {
      contents: JSON.stringify(testData)
    }
  };
  
  const result = doPost(e);
  Logger.log(result.getContent());
}
