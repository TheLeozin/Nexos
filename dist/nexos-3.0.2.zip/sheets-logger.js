// ============================================
// NEXOS TORRE - Google Sheets Logger
// Registra todas as solicitações em Google Sheets
// ============================================

// CONFIGURAÇÃO - Preencha com suas credenciais
const SHEETS_CONFIG = {
  // ATENÇÃO: Habilitar sincronização apenas quando o backend estiver disponível
  enabled: false, // Mude para true quando tiver backend configurado
  
  // ID da planilha (pegue na URL do Google Sheets)
  // Ex: https://docs.google.com/spreadsheets/d/1ABC123XYZ/edit
  // O ID é: 1ABC123XYZ
  spreadsheetId: '1w36aYfJaDJcYRTMV_Lh1duCqDTEBE31iGDXb_lrSfbI',
  
  // URL do seu backend que faz a escrita no Sheets
  // Recomendado: Cloud Function, Node.js, etc.
  // IMPORTANTE: Substitua localhost por URL real de produção
  backendUrl: '', // Ex: 'https://seu-backend.com/api/log-solicitacao'
  
  // API Key do Google (alternativa mais simples, mas menos segura)
  // Deixe vazio se usar backend
  apiKey: ''
};

// ============================================
// Função para adicionar linha no Google Sheets via Backend
// ============================================
async function addRowToSheets(rowData) {
  // Verificar se sincronização está habilitada
  if (!SHEETS_CONFIG.enabled) {
    console.log('ℹ️ Sincronização Google Sheets desabilitada (SHEETS_CONFIG.enabled = false)');
    return true; // Retorna true para não marcar como erro
  }

  if (!SHEETS_CONFIG.backendUrl || SHEETS_CONFIG.backendUrl.trim() === '') {
    console.warn('⚠️ BackendUrl não configurado no SHEETS_CONFIG - sincronização ignorada');
    return true; // Retorna true para não marcar como erro
  }

  console.log('📤 Enviando para Google Sheets...', {
    url: SHEETS_CONFIG.backendUrl,
    spreadsheetId: SHEETS_CONFIG.spreadsheetId,
    rowData
  });

  try {
    const response = await fetch(SHEETS_CONFIG.backendUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        spreadsheetId: SHEETS_CONFIG.spreadsheetId,
        values: rowData
      })
    });

    console.log('📥 Resposta do backend:', {
      status: response.status,
      statusText: response.statusText,
      ok: response.ok
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('❌ Erro ao adicionar linha:', error);
      return false;
    }

    const result = await response.json();
    console.log('✅ Solicitação registrada no Google Sheets com sucesso!', result);
    return true;
  } catch (error) {
    // Falha silenciosa se backend não estiver disponível
    console.warn('⚠️ Não foi possível conectar ao backend do Google Sheets:', error.message);
    console.log('💡 Dica: Configure SHEETS_CONFIG.enabled e backendUrl no sheets-logger.js');
    // Retorna true para não marcar como erro e não incomodar o usuário
    return true;
  }
}

// ============================================
// Alternativa: usando API Key diretamente (menos seguro)
// ============================================
async function addRowToSheetsDirect(rowData) {
  if (!SHEETS_CONFIG.apiKey || !SHEETS_CONFIG.spreadsheetId) {
    console.error('❌ Configure apiKey e spreadsheetId no SHEETS_CONFIG');
    return false;
  }

  const range = 'A:M'; // Colunas A até M
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${SHEETS_CONFIG.spreadsheetId}/values/${range}:append?valueInputOption=USER_ENTERED&key=${SHEETS_CONFIG.apiKey}`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        values: [rowData]
      })
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('❌ Erro ao adicionar linha:', error);
      return false;
    }

    console.log('✅ Solicitação registrada no Google Sheets com sucesso!');
    return true;
  } catch (error) {
    console.error('❌ Erro ao enviar dados para Google Sheets:', error);
    return false;
  }
}

// ============================================
// Função de notificação
// ============================================
function showSheetsNotification(message, type = 'success') {
  try {
    // Tentar usar a função showAlert se estiver disponível
    if (typeof showAlert === 'function') {
      showAlert(message, type, 4000);
      return;
    }
    
    // Fallback: criar notificação custom
    const toast = document.createElement('div');
    toast.style.cssText = `
      position: fixed;
      bottom: 1.5rem;
      right: 1.5rem;
      max-width: 380px;
      padding: 1rem 1.25rem;
      background: ${type === 'success' ? 'linear-gradient(135deg, #059669, #10B981)' : 'linear-gradient(135deg, #DC2626, #EF4444)'};
      border: 1px solid ${type === 'success' ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'};
      border-radius: 0.75rem;
      box-shadow: 0 8px 16px -4px rgba(0, 0, 0, 0.15), 0 12px 24px -4px rgba(0, 0, 0, 0.2);
      color: #F0F6FC;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
      font-size: 0.875rem;
      font-weight: 500;
      line-height: 1.5;
      z-index: 10001;
      opacity: 0;
      transform: translateX(100%);
      transition: all 200ms ease-out;
      display: flex;
      align-items: center;
      gap: 0.75rem;
    `;
    
    const icon = type === 'success' 
      ? '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>'
      : '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>';
    
    toast.innerHTML = `
      <div style="flex-shrink: 0;">${icon}</div>
      <div style="flex: 1;">${message}</div>
    `;
    
    document.body.appendChild(toast);
    
    // Mostrar
    setTimeout(() => {
      toast.style.opacity = '1';
      toast.style.transform = 'translateX(0)';
    }, 10);
    
    // Esconder e remover
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      setTimeout(() => toast.remove(), 200);
    }, 4000);
    
  } catch (err) {
    console.warn('[NEXOS] Erro ao mostrar notificação:', err);
  }
}

// ============================================
// Função principal: registrar solicitação
// ============================================
async function logSolicitacao(loja, pedido, data) {
  // Normalizadores de plataforma e horário
  const normalizePlataforma = (p) => {
    try {
      const s = (p == null ? '' : String(p)).trim().toLowerCase();
      if (!s) return '-';
      if (s.includes('uber')) return 'Uber';
      if (s.includes('lalamove')) return 'Lalamove';
      if (s === '99' || s.includes('99')) return '99';
      return s.charAt(0).toUpperCase() + s.slice(1);
    } catch {
      return (p == null ? '-' : String(p));
    }
  };

  const normalizeHorarioBR = (v) => {
    try {
      if (v instanceof Date) {
        return v.toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
      }
      const str = (v == null ? '' : String(v)).trim();
      if (!str) {
        return new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
      }
      // Somente hora (ex.: 14:32 ou 14:32:10) -> prefixar data de hoje
      if (/^\d{1,2}:\d{2}(?::\d{2})?$/.test(str)) {
        const today = new Date();
        const date = today.toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' });
        return `${date} ${str}`;
      }
      // ISO/Date parseável -> formatar para pt-BR
      if (/T|Z|-/.test(str)) {
        const ts = Date.parse(str);
        if (!Number.isNaN(ts)) {
          return new Date(ts).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
        }
      }
      return str;
    } catch {
      return new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
    }
  };

  // Obter informações do usuário (nome cadastrado)
  const usuario = await getUsuarioInfo();
  // Reforçar captura de UUID se ausente
  let uuidFinal = data.uuid || '-';
  if (!uuidFinal || uuidFinal === '-') {
    try {
      const uuidRegex = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
      const sources = [data.tracking_link, data.observacoes, JSON.stringify(data || {})];
      for (const src of sources) {
        if (typeof src === 'string') {
          const m = src.match(uuidRegex);
          if (m) { uuidFinal = m[0]; break; }
        }
      }
      if (!uuidFinal || uuidFinal === '-') {
        // Buscar no picking-data
        const storage = await chrome.storage.local.get(['nexos-picking-data']);
        const pickingData = storage['nexos-picking-data'] || {};
        if (pickingData[loja] && pickingData[loja][pedido]) {
          const pd = pickingData[loja][pedido];
          uuidFinal = pd.order_uuid || pd.uuid || pd.uuid_solicitacao || uuidFinal;
        }
      }
    } catch (heuErr) {
      console.warn('[NEXOS][SHEETS] Heurística UUID fallback falhou:', heuErr);
    }
  }
  if (!uuidFinal || uuidFinal === '') uuidFinal = '-';
  data.uuid = uuidFinal; // garantir consistência
  const plataformaFinal = normalizePlataforma(data.plataforma || '-');
  const horarioFinal = normalizeHorarioBR(data.horario_solicitacao || '-');
  
  // Preparar dados da linha (incluindo UUID)
  const rowData = [
    new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }), // Timestamp formatado
    usuario, // Usuário
    String(loja), // Loja
    String(pedido), // Pedido
    data.status || 'Aguardando Transporte', // Status
    plataformaFinal, // Plataforma normalizada
    uuidFinal, // UUID (PRINCIPAL!) - após plataforma
    data.valor_solicitacao || '-', // Valor Solicitação
    horarioFinal, // Horário Solicitação (sempre com data)
    data.nome_cliente || '-', // Nome Cliente
    data.endereco_completo || '-', // Endereço
    data.telefone_cliente || '-', // Telefone
    data.tracking_link || '-', // Tracking Link
    data.observacoes || '-' // Observações
  ];

  // Enviar para Google Sheets
  // Tenta backend primeiro, se falhar tenta direto (se configurado)
  let success = await addRowToSheets(rowData);
  
  if (!success && SHEETS_CONFIG.apiKey) {
    console.warn('⚠️ Backend falhou, tentando API Key direta...');
    success = await addRowToSheetsDirect(rowData);
  }
  
  if (success) {
    console.log('📊 Registro salvo:', { loja, pedido, uuid: data.uuid, usuario });
    
    // Marcar pedido como sincronizado no storage do Picking
    await markPedidoAsSynced(loja, pedido);
    
    showSheetsNotification(
      `✅ Solicitação registrada!\nLoja: ${loja} | Pedido: ${pedido} | Plataforma: ${data.plataforma || '-'}`,
      'success'
    );
  } else {
    console.warn('⚠️ Não foi possível salvar no Google Sheets, tentando fallback local...');
    await saveFallbackLocal(loja, pedido, data, rowData);
    showSheetsNotification(
      `⚠️ Salvo localmente (será sincronizado)\nLoja: ${loja} | Pedido: ${pedido}`,
      'warning'
    );
  }
  
  return success;
}

// ============================================
// Fallback: salvar localmente se API falhar
// ============================================
async function saveFallbackLocal(loja, pedido, data, rowData) {
  try {
    // Salvar no chrome.storage como backup
    const key = `nexos-log-${Date.now()}-${loja}-${pedido}`;
    const logData = {
      timestamp: new Date().toISOString(),
      loja,
      pedido,
      data,
      rowData,
      synced: false
    };
    
    await safeChromeStorageSet({ [key]: logData });
    console.log('💾 Salvo localmente como backup:', key);
    
    // Tentar sincronizar depois
    setTimeout(() => retrySyncPendingLogs(), 60000); // Tenta em 1 minuto
  } catch (error) {
    console.error('❌ Erro ao salvar fallback local:', error);
  }
}

// ============================================
// Retry: tentar enviar logs pendentes
// ============================================
async function retrySyncPendingLogs() {
  try {
    const storage = await chrome.storage.local.get(null);
    const pendingLogs = Object.entries(storage)
      .filter(([key]) => key.startsWith('nexos-log-'))
      .filter(([, value]) => !value.synced);

    console.log(`🔄 Tentando sincronizar ${pendingLogs.length} logs pendentes...`);

    for (const [key, logData] of pendingLogs) {
      let success = await addRowToSheets(logData.rowData);
      
      if (!success && SHEETS_CONFIG.apiKey) {
        success = await addRowToSheetsDirect(logData.rowData);
      }
      
      if (success) {
        // Marcar como sincronizado
        logData.synced = true;
        await safeChromeStorageSet({ [key]: logData });
        console.log('✅ Log sincronizado:', key);
      }
    }
  } catch (error) {
    console.error('❌ Erro ao sincronizar logs pendentes:', error);
  }
}

// ============================================
// Marcar pedido como sincronizado
// ============================================
async function markPedidoAsSynced(loja, pedido) {
  try {
    const storage = await chrome.storage.local.get(['nexos-picking-data']);
    const pickingData = storage['nexos-picking-data'] || {};
    
    if (pickingData[loja] && pickingData[loja][pedido]) {
      pickingData[loja][pedido].sheets_synced = true;
      pickingData[loja][pedido].sheets_synced_at = new Date().toISOString();
      await safeChromeStorageSet({ 'nexos-picking-data': pickingData });
      console.log('✅ Pedido marcado como sincronizado:', { loja, pedido });
    }
  } catch (error) {
    console.error('❌ Erro ao marcar pedido como sincronizado:', error);
  }
}

// ============================================
// Sincronizar pedidos antigos (solicitados mas não sincronizados)
// ============================================
// Sincronizar pedidos antigos; se force=true ignora flag sheets_synced
async function syncPedidosAntigos(force = false) {
  try {
    console.log('🔄 Iniciando sincronização de pedidos antigos...');
    const storage = await chrome.storage.local.get(['nexos-picking-data']);
    const pickingData = storage['nexos-picking-data'] || {};
    
    let sincronizados = 0;
    let erros = 0;
    
    for (const loja in pickingData) {
      for (const pedido in pickingData[loja]) {
        const pedidoData = pickingData[loja][pedido];
        
        // Verificar se é status "solicitado" ou "solicitado_cancelado" e NÃO está sincronizado
        const status = (pedidoData.status || '').toLowerCase().replace(/_/g, ' ');
  const jaSync = pedidoData.sheets_synced === true;
        
        if ((status === 'solicitado' || status === 'cancelado') && (force || !jaSync)) {
          console.log(`📤 Sincronizando pedido antigo: Loja ${loja}, Pedido ${pedido}`);
          
          // Extrair dados do pedido
          const dados = {
            status: status === 'solicitado' ? 'Aguardando Transporte' : 'Cancelado',
            plataforma: pedidoData.plataforma || '-',
            uuid: pedidoData.order_uuid || '-',
            valor_solicitacao: pedidoData.valor_solicitacao || pedidoData.valor || pedidoData.value || '-',
            horario_solicitacao: pedidoData.horario_solicitacao || pedidoData.horario || pedidoData.time || '-',
            nome_cliente: pedidoData.nome_cliente || '-',
            endereco_completo: pedidoData.endereco_completo || pedidoData.endereco || '-',
            telefone_cliente: pedidoData.celular_cliente || pedidoData.telefone_cliente || '-',
            tracking_link: pedidoData.link_rastreio || pedidoData.tracking_link || '-',
            observacoes: `${force ? 'Forçado' : 'Retroativo'} - ${pedidoData.mode || 'modo desconhecido'}`
          };
          
          try {
            const success = await logSolicitacao(loja, pedido, dados);
            if (success) {
              sincronizados++;
            } else {
              erros++;
            }
          } catch (err) {
            console.error(`❌ Erro ao sincronizar pedido ${pedido}:`, err);
            erros++;
          }
          
          // Aguardar 500ms entre cada sincronização para não sobrecarregar
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
    }
    
    console.log(`✅ Sincronização concluída: ${sincronizados} sincronizados, ${erros} erros`);
    
    if (sincronizados > 0) {
      showSheetsNotification(
        `✅ ${sincronizados} pedido(s) antigo(s) sincronizado(s)!`,
        'success'
      );
    }
    
    return { sincronizados, erros };
  } catch (error) {
    console.error('❌ Erro ao sincronizar pedidos antigos:', error);
    return { sincronizados: 0, erros: 0 };
  }
}

// ============================================
// Obter informação do usuário LOGADO (Microsoft)
// ============================================
async function getUsuarioInfo() {
  try {
    // Pegar nome do usuário logado via NexosAuth (API atual)
    if (window.NexosAuth) {
      // Tentar getCurrentUser() (API atual)
      if (typeof window.NexosAuth.getCurrentUser === 'function') {
        const user = window.NexosAuth.getCurrentUser();
        if (user) return user.displayName || user.name || user.email || 'USUARIO-NAO-IDENTIFICADO';
      }
      // Fallback: authManager.getSession() (API antiga — pode não existir)
      if (window.NexosAuth.authManager && typeof window.NexosAuth.authManager.getSession === 'function') {
        const session = window.NexosAuth.authManager.getSession();
        if (session && session.account) {
          return session.account.name || session.account.username || 'USUARIO-NAO-IDENTIFICADO';
        }
      }
    }
    
    // Fallback: tentar storage local (compatibilidade)
    let userData = await chrome.storage.local.get(['nexos-user-full-name']);
    if (userData['nexos-user-full-name']) {
      return userData['nexos-user-full-name'];
    }
    
    return 'USUARIO-NAO-IDENTIFICADO';
  } catch (error) {
    console.error('Erro ao obter informação do usuário:', error);
    return 'USUARIO-DESCONHECIDO';
  }
}

// ============================================
// FUNÇÕES DEPRECATED - Mantidas para compatibilidade
// Sistema agora usa login Microsoft via NexosAuth
// ============================================
async function promptUserName() {
  console.warn('⚠️ promptUserName() deprecated - usando login Microsoft');
  return await getUsuarioInfo();
}

async function changeUserName() {
  console.warn('⚠️ changeUserName() deprecated - nome vem do Microsoft');
  const usuarioAtual = await getUsuarioInfo();
  alert(`📝 INFORMAÇÃO DO USUÁRIO\n\nNome atual: ${usuarioAtual}\n\n⚠️ O nome vem do login Microsoft e não pode ser alterado pela extensão.\n\nPara alterar, acesse seu perfil Microsoft.`);
  return usuarioAtual;
}

async function initializeUser() {
  console.info('ℹ️ initializeUser() deprecated - usando autenticação Microsoft');
  return true;
}

// ============================================
// Utility: Safe Chrome Storage Set
// ============================================
async function safeChromeStorageSet(data) {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await chrome.storage.local.set(data);
      return true;
    }
    return false;
  } catch (error) {
    console.error('Erro ao salvar no chrome.storage:', error);
    return false;
  }
}

// ============================================
// Exportar funções
// ============================================
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    logSolicitacao,
    promptUserName,
    changeUserName,
    initializeUser,
    retrySyncPendingLogs
  };
}
