// ═══════════════════════════════════════════════════════════════════════════
// EXTRAÇÃO DE STATUS DO PICKING - EXEMPLO DE IMPLEMENTAÇÃO
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Extrai o status do picking exatamente como aparece na tela
 * ⚠️ IMPORTANTE: Não normalizar ou mapear valores - capturar texto exato!
 * 
 * @returns {string|null} Status exato da UI ou null se não encontrar
 */
function extrairStatusPickingDaTela() {
  console.log('[Picking] Iniciando extração de status...');
  
  // ═══════════════════════════════════════════════════════════════════════
  // ESTRATÉGIA 1: Seletor específico do status
  // ═══════════════════════════════════════════════════════════════════════
  
  // Exemplo: <span class="status-pedido">Aguardando Transporte</span>
  const seletorStatus = '.status-pedido, .picking-status, [data-status], .status-text';
  const elementoStatus = document.querySelector(seletorStatus);
  
  if (elementoStatus) {
    const status = elementoStatus.textContent.trim();
    console.log('[Picking] ✅ Status extraído (seletor direto):', status);
    return status;
  }
  
  // ═══════════════════════════════════════════════════════════════════════
  // ESTRATÉGIA 2: Badge ou label de status
  // ═══════════════════════════════════════════════════════════════════════
  
  // Exemplo: <div class="badge badge-warning">Em Separação</div>
  const badge = document.querySelector('.badge-status, .status-badge, .label-status');
  
  if (badge) {
    const status = badge.innerText.trim();
    console.log('[Picking] ✅ Status extraído (badge):', status);
    return status;
  }
  
  // ═══════════════════════════════════════════════════════════════════════
  // ESTRATÉGIA 3: Atributo data-* do container
  // ═══════════════════════════════════════════════════════════════════════
  
  // Exemplo: <div data-status="Entregue" data-pedido-id="123">
  const containerComData = document.querySelector('[data-status-picking]') || 
                           document.querySelector('[data-status]');
  
  if (containerComData) {
    const status = containerComData.dataset.statusPicking || 
                   containerComData.dataset.status;
    if (status) {
      console.log('[Picking] ✅ Status extraído (data attribute):', status);
      return status;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════
  // ESTRATÉGIA 4: Buscar em tabela de detalhes
  // ═══════════════════════════════════════════════════════════════════════
  
  // Exemplo: <tr><td>Status:</td><td>Aguardando Coleta</td></tr>
  const linhasTabela = document.querySelectorAll('tr');
  
  for (const linha of linhasTabela) {
    const celulas = linha.querySelectorAll('td, th');
    if (celulas.length >= 2) {
      const label = celulas[0].textContent.trim().toLowerCase();
      if (label.includes('status') || label.includes('situação')) {
        const status = celulas[1].textContent.trim();
        console.log('[Picking] ✅ Status extraído (tabela):', status);
        return status;
      }
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════
  // ESTRATÉGIA 5: Buscar em texto do modal/overlay
  // ═══════════════════════════════════════════════════════════════════════
  
  // Exemplo: <p>Status atual: <strong>Em Separação</strong></p>
  const modalContent = document.querySelector('.modal-body, .overlay-content, .pedido-detalhes');
  
  if (modalContent) {
    const textoCompleto = modalContent.textContent;
    const regexStatus = /Status\s*:?\s*([^\n\r]+)/i;
    const match = textoCompleto.match(regexStatus);
    
    if (match && match[1]) {
      const status = match[1].trim();
      console.log('[Picking] ✅ Status extraído (regex no modal):', status);
      return status;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════
  // ESTRATÉGIA 6: Buscar por padrões visuais comuns
  // ═══════════════════════════════════════════════════════════════════════
  
  // Buscar elementos que PARECEM ser status (bootstrap, tailwind, etc)
  const possiveisStatus = document.querySelectorAll(`
    .text-success, .text-warning, .text-danger, .text-info,
    .bg-success, .bg-warning, .bg-danger, .bg-info,
    .alert-success, .alert-warning, .alert-danger, .alert-info
  `);
  
  for (const elemento of possiveisStatus) {
    const texto = elemento.textContent.trim();
    // Se tem entre 5 e 50 caracteres, pode ser um status
    if (texto.length >= 5 && texto.length <= 50 && !texto.includes('\n')) {
      console.log('[Picking] ⚠️ Status extraído (padrão visual - validar):', texto);
      return texto;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════
  // NÃO ENCONTRADO
  // ═══════════════════════════════════════════════════════════════════════
  
  console.warn('[Picking] ⚠️ Status do picking não encontrado na tela');
  return null;
}

// ═══════════════════════════════════════════════════════════════════════════
// EXEMPLO DE USO NO FLUXO DE EXTRAÇÃO
// ═══════════════════════════════════════════════════════════════════════════

async function extrairDadosPedidoPicking(pedidoElement) {
  try {
    console.log('[Picking] Extraindo dados do pedido...');
    
    // Extrair campos básicos (já existentes)
    const pedidoID = extrairPedidoID(pedidoElement);
    const loja = extrairLoja(pedidoElement);
    const custo = extrairCusto(pedidoElement);
    // ... outros campos
    
    // ⭐ NOVO: Extrair status do picking
    const statusPicking = extrairStatusPickingDaTela();
    
    // Montar objeto
    const dadosPedido = {
      PedidoID: pedidoID,
      Plataforma: 'Picking',
      Loja: loja,
      CustoEntrega: custo,
      DataSolicitacao: new Date().toISOString(),
      DataConclusao: new Date().toISOString(),
      OperadorEmail: window.currentUserEmail || 'desconhecido@gpabr.com',
      OperadorNome: window.currentUserName || 'Operador',
      StatusFinal: 'Concluído',
      
      // ⭐ Status do picking no momento da extração
      StatusPicking: statusPicking,  // Pode ser null se não encontrar
      
      // ... outros campos
    };
    
    console.log('[Picking] ✅ Dados extraídos:', dadosPedido);
    
    // Salvar no SharePoint
    if (window.graphClient) {
      await window.graphClient.addListItem('Nexos_PedidosConcluidos', dadosPedido);
      console.log('[Picking] ✅ Pedido salvo no SharePoint');
    }
    
    return dadosPedido;
    
  } catch (error) {
    console.error('[Picking] ❌ Erro ao extrair dados:', error);
    throw error;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// DEBUGGING: Ajuda para encontrar o seletor correto
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Execute no console do DevTools para encontrar onde está o status
 * Cole isso no console da página do picking e veja os resultados
 */
function debugEncontrarStatusPicking() {
  console.log('═══════════════════════════════════════════════════════');
  console.log('🔍 DEBUG: Procurando status do picking na página...');
  console.log('═══════════════════════════════════════════════════════');
  
  // Procurar em todos elementos visíveis
  const elementosVisiveis = Array.from(document.querySelectorAll('*'))
    .filter(el => {
      const style = window.getComputedStyle(el);
      return style.display !== 'none' && style.visibility !== 'hidden';
    });
  
  // Procurar elementos que contenham "status" no texto
  const candidatos = elementosVisiveis.filter(el => {
    const texto = el.textContent.toLowerCase();
    return texto.includes('status') || 
           texto.includes('situação') ||
           texto.includes('aguardando') ||
           texto.includes('separação') ||
           texto.includes('entregue');
  });
  
  console.log(`📊 Encontrados ${candidatos.length} elementos candidatos:`);
  
  candidatos.slice(0, 10).forEach((el, index) => {
    console.log(`\n${index + 1}. Tag: <${el.tagName.toLowerCase()}>`);
    console.log(`   Classes: ${el.className}`);
    console.log(`   ID: ${el.id}`);
    console.log(`   Texto: "${el.textContent.trim().substring(0, 100)}"`);
    console.log(`   Seletor: ${getSelectorPath(el)}`);
  });
  
  console.log('\n💡 Dica: Inspecione os elementos acima e encontre o que contém o status');
  console.log('═══════════════════════════════════════════════════════');
}

function getSelectorPath(el) {
  if (el.id) return `#${el.id}`;
  if (el.className) {
    const classes = el.className.split(' ').filter(c => c).join('.');
    return `.${classes}`;
  }
  return el.tagName.toLowerCase();
}

// Para usar: cole no console e execute
// debugEncontrarStatusPicking();
