/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - PICKING OVERLAY (REFATORADO)
 * Exemplo de refatoração usando o novo design system
 * Versão: 2.2.2
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * ESTE É UM EXEMPLO - NÃO SUBSTITUIR content.js AINDA!
 * Use este arquivo como referência para refatorar buildExtractionOverlay()
 * 
 */

/**
 * Constrói overlay de extração do Picking (VERSÃO REFATORADA)
 */
async function buildExtractionOverlayRefactored() {
  console.log('[Picking] Iniciando construção do overlay refatorado...');

  // 1. Criar overlay base com autenticação
  const overlay = await window.NexosOverlay.create({
    title: 'Picking - Extração de Pedidos',
    subtitle: 'Mapa James Delivery',
    platform: 'picking',
    requireAuth: true,
    showSidebar: true,
    showFooter: true
  });

  // Se não conseguiu autenticar, retorna
  if (!overlay) {
    console.error('[Picking] Overlay não criado (autenticação falhou?)');
    return;
  }

  // 2. Estado local
  const state = {
    extractedData: [], // Dados extraídos do mapa
    filteredData: [],  // Dados após filtros
    currentTab: 'pendentes', // Tab ativa
    selectedStore: 'all',
    searchTerm: ''
  };

  /* ═══════════════════════════════════════════════════════════════════════════
     EXTRAÇÃO DE DADOS (mantém lógica original)
     ══════════════════════════════════════════════════════════════════════════ */

  function extractDataFromMap() {
    const data = [];
    
    // Lógica original de extração do DOM
    const markers = document.querySelectorAll('.leaflet-marker-icon');
    
    markers.forEach((marker) => {
      try {
        // Extrai dados do marcador (exemplo simplificado)
        const pedido = {
          id: Math.random().toString(36).substr(2, 9),
          loja: extractStoreFromMarker(marker),
          endereco: extractAddressFromMarker(marker),
          status: extractStatusFromMarker(marker),
          timestamp: new Date().toISOString()
        };
        
        data.push(pedido);
      } catch (error) {
        console.error('[Picking] Erro ao extrair pedido:', error);
      }
    });

    console.log(`[Picking] ✅ Extraídos ${data.length} pedidos`);
    return data;
  }

  function extractStoreFromMarker(marker) {
    // Lógica original
    return 'Loja 123';
  }

  function extractAddressFromMarker(marker) {
    // Lógica original
    return 'Rua Exemplo, 123';
  }

  function extractStatusFromMarker(marker) {
    // Lógica original
    return 'Pendente';
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     SIDEBAR - FILTROS
     ══════════════════════════════════════════════════════════════════════════ */

  function buildSidebar() {
    // Seção 1: Tabs de Status
    const tabsHTML = `
      <div style="display: flex; flex-direction: column; gap: 8px;">
        <button class="nexos-btn nexos-btn-secondary" data-tab="pendentes" style="justify-content: flex-start;">
          📦 Pendentes
          <span class="nexos-badge nexos-badge-warning" style="margin-left: auto;">0</span>
        </button>
        <button class="nexos-btn nexos-btn-ghost" data-tab="solicitado" style="justify-content: flex-start;">
          🚚 Solicitados
          <span class="nexos-badge nexos-badge-info" style="margin-left: auto;">0</span>
        </button>
        <button class="nexos-btn nexos-btn-ghost" data-tab="cancelado" style="justify-content: flex-start;">
          ❌ Cancelados
          <span class="nexos-badge nexos-badge-error" style="margin-left: auto;">0</span>
        </button>
      </div>
    `;
    
    const tabsContainer = document.createElement('div');
    tabsContainer.innerHTML = tabsHTML;
    
    // Event listeners para tabs
    tabsContainer.querySelectorAll('[data-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        state.currentTab = btn.dataset.tab;
        updateTabUI(btn);
        applyFilters();
      });
    });
    
    overlay.addSidebarSection('Status', tabsContainer);

    // Seção 2: Filtro de Loja
    const storeSelect = document.createElement('select');
    storeSelect.className = 'nexos-input';
    storeSelect.innerHTML = `
      <option value="all">Todas as Lojas</option>
      <option value="loja-123">Loja 123</option>
      <option value="loja-456">Loja 456</option>
    `;
    storeSelect.addEventListener('change', (e) => {
      state.selectedStore = e.target.value;
      applyFilters();
    });
    
    overlay.addSidebarSection('Filtro de Loja', storeSelect);

    // Seção 3: Busca
    const searchInput = window.NexosUI.createInput({
      type: 'text',
      placeholder: '🔍 Buscar pedido...',
      onChange: window.NexosUI.utils.debounce((value) => {
        state.searchTerm = value.toLowerCase();
        applyFilters();
      }, 300)
    });
    
    overlay.addSidebarSection('Busca', searchInput);

    // Seção 4: Ações
    const actionsHTML = `
      <div style="display: flex; flex-direction: column; gap: 8px;">
        ${window.NexosUI.createButton({
          text: '🔄 Atualizar Dados',
          variant: 'primary',
          onClick: () => refreshData()
        }).outerHTML}
        ${window.NexosUI.createButton({
          text: '📋 Copiar Todos',
          variant: 'secondary',
          onClick: () => copyAllToClipboard()
        }).outerHTML}
      </div>
    `;
    
    const actionsContainer = document.createElement('div');
    actionsContainer.innerHTML = actionsHTML;
    
    // Re-attach event listeners (necessário após innerHTML)
    actionsContainer.querySelectorAll('button').forEach((btn, index) => {
      if (index === 0) btn.addEventListener('click', refreshData);
      if (index === 1) btn.addEventListener('click', copyAllToClipboard);
    });
    
    overlay.addSidebarSection('Ações', actionsContainer);
  }

  function updateTabUI(activeBtn) {
    // Atualiza estilos dos botões
    overlay.sidebar.querySelectorAll('[data-tab]').forEach(btn => {
      if (btn === activeBtn) {
        btn.className = 'nexos-btn nexos-btn-secondary';
      } else {
        btn.className = 'nexos-btn nexos-btn-ghost';
      }
      btn.style.justifyContent = 'flex-start';
    });
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     CONTENT - LISTA DE PEDIDOS
     ══════════════════════════════════════════════════════════════════════════ */

  function renderPedidos() {
    // Limpa conteúdo
    overlay.content.innerHTML = '';

    if (state.filteredData.length === 0) {
      const emptyState = document.createElement('div');
      emptyState.style.cssText = `
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100%;
        gap: 16px;
        color: var(--nexos-text-secondary);
      `;
      emptyState.innerHTML = `
        <div style="font-size: 48px;">📦</div>
        <div style="font-size: 18px; font-weight: 500;">Nenhum pedido encontrado</div>
        <div style="font-size: 14px;">Tente ajustar os filtros ou atualizar os dados</div>
      `;
      overlay.content.appendChild(emptyState);
      return;
    }

    // Agrupa por loja
    const groupedByStore = groupByStore(state.filteredData);

    Object.entries(groupedByStore).forEach(([storeName, pedidos]) => {
      // Card da loja
      const storeCard = window.NexosUI.createCard({
        title: `${storeName} (${pedidos.length} pedidos)`,
        body: createPedidosList(pedidos)
      });
      
      storeCard.style.marginBottom = '16px';
      overlay.content.appendChild(storeCard);
    });

    // Atualiza footer
    overlay.updateFooterStatus(
      `${state.filteredData.length} pedidos carregados`,
      'success'
    );
  }

  function createPedidosList(pedidos) {
    const list = document.createElement('div');
    list.style.cssText = `
      display: flex;
      flex-direction: column;
      gap: 12px;
    `;

    pedidos.forEach(pedido => {
      const item = document.createElement('div');
      item.style.cssText = `
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px;
        background: var(--nexos-bg-secondary);
        border-radius: var(--nexos-radius-md);
        cursor: pointer;
        transition: all var(--nexos-transition-fast);
      `;
      
      item.addEventListener('mouseenter', () => {
        item.style.background = 'var(--nexos-bg-tertiary)';
      });
      item.addEventListener('mouseleave', () => {
        item.style.background = 'var(--nexos-bg-secondary)';
      });
      
      item.innerHTML = `
        <div style="flex: 1;">
          <div style="font-weight: 500; margin-bottom: 4px;">${pedido.endereco}</div>
          <div style="font-size: 12px; color: var(--nexos-text-secondary);">
            ID: ${pedido.id} • ${new Date(pedido.timestamp).toLocaleString()}
          </div>
        </div>
        <div style="display: flex; align-items: center; gap: 8px;">
          ${window.NexosUI.createBadge(pedido.status, getBadgeVariant(pedido.status)).outerHTML}
          <button class="nexos-btn nexos-btn-sm nexos-btn-ghost">👁️ Ver</button>
        </div>
      `;

      // Event listener para ver detalhes
      const viewBtn = item.querySelector('button');
      viewBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        showPedidoDetails(pedido);
      });

      list.appendChild(item);
    });

    return list;
  }

  function getBadgeVariant(status) {
    const map = {
      'Pendente': 'warning',
      'Solicitado': 'info',
      'Cancelado': 'error',
      'Entregue': 'success'
    };
    return map[status] || 'primary';
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     MODAL - DETALHES DO PEDIDO
     ══════════════════════════════════════════════════════════════════════════ */

  function showPedidoDetails(pedido) {
    const detailsHTML = `
      <div style="display: flex; flex-direction: column; gap: 16px;">
        <div>
          <label style="font-weight: 500; color: var(--nexos-text-secondary); display: block; margin-bottom: 4px;">
            ID do Pedido
          </label>
          <div style="font-size: 18px; font-weight: 600;">${pedido.id}</div>
        </div>
        <div>
          <label style="font-weight: 500; color: var(--nexos-text-secondary); display: block; margin-bottom: 4px;">
            Loja
          </label>
          <div>${pedido.loja}</div>
        </div>
        <div>
          <label style="font-weight: 500; color: var(--nexos-text-secondary); display: block; margin-bottom: 4px;">
            Endereço
          </label>
          <div>${pedido.endereco}</div>
        </div>
        <div>
          <label style="font-weight: 500; color: var(--nexos-text-secondary); display: block; margin-bottom: 4px;">
            Status
          </label>
          <div>${window.NexosUI.createBadge(pedido.status, getBadgeVariant(pedido.status)).outerHTML}</div>
        </div>
        <div>
          <label style="font-weight: 500; color: var(--nexos-text-secondary); display: block; margin-bottom: 4px;">
            Data/Hora
          </label>
          <div>${new Date(pedido.timestamp).toLocaleString()}</div>
        </div>
      </div>
    `;

    const detailsContainer = document.createElement('div');
    detailsContainer.innerHTML = detailsHTML;

    const copyBtn = window.NexosUI.createButton({
      text: '📋 Copiar Dados',
      variant: 'primary',
      onClick: () => {
        copyToClipboard(pedido);
        window.NexosUI.showToast('Dados copiados!', 'success');
      }
    });

    const closeBtn = window.NexosUI.createButton({
      text: 'Fechar',
      variant: 'ghost',
      onClick: () => {
        modal.backdrop.remove();
      }
    });

    const modal = window.NexosUI.createModal({
      title: `📦 Detalhes do Pedido`,
      body: detailsContainer,
      footer: [closeBtn, copyBtn],
      size: 'md'
    });
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     FUNÇÕES DE DADOS
     ══════════════════════════════════════════════════════════════════════════ */

  function applyFilters() {
    let filtered = state.extractedData;

    // Filtro de tab (status)
    if (state.currentTab !== 'all') {
      const statusMap = {
        'pendentes': 'Pendente',
        'solicitado': 'Solicitado',
        'cancelado': 'Cancelado'
      };
      filtered = filtered.filter(p => p.status === statusMap[state.currentTab]);
    }

    // Filtro de loja
    if (state.selectedStore !== 'all') {
      filtered = filtered.filter(p => p.loja === state.selectedStore);
    }

    // Filtro de busca
    if (state.searchTerm) {
      filtered = filtered.filter(p => 
        p.id.toLowerCase().includes(state.searchTerm) ||
        p.endereco.toLowerCase().includes(state.searchTerm) ||
        p.loja.toLowerCase().includes(state.searchTerm)
      );
    }

    state.filteredData = filtered;
    renderPedidos();
    updateCounts();
  }

  function updateCounts() {
    const counts = {
      pendentes: state.extractedData.filter(p => p.status === 'Pendente').length,
      solicitado: state.extractedData.filter(p => p.status === 'Solicitado').length,
      cancelado: state.extractedData.filter(p => p.status === 'Cancelado').length
    };

    overlay.sidebar.querySelectorAll('[data-tab]').forEach(btn => {
      const badge = btn.querySelector('.nexos-badge');
      const tab = btn.dataset.tab;
      if (badge && counts[tab] !== undefined) {
        badge.textContent = counts[tab];
      }
    });
  }

  function groupByStore(pedidos) {
    return pedidos.reduce((groups, pedido) => {
      const store = pedido.loja;
      if (!groups[store]) groups[store] = [];
      groups[store].push(pedido);
      return groups;
    }, {});
  }

  function refreshData() {
    window.NexosUI.showToast('Atualizando dados...', 'info');
    
    // Re-extrai dados
    state.extractedData = extractDataFromMap();
    applyFilters();
    
    window.NexosUI.showToast('Dados atualizados!', 'success');
  }

  function copyToClipboard(pedido) {
    const text = `ID: ${pedido.id}\nLoja: ${pedido.loja}\nEndereço: ${pedido.endereco}\nStatus: ${pedido.status}`;
    navigator.clipboard.writeText(text);
  }

  function copyAllToClipboard() {
    const text = state.filteredData.map(p => 
      `ID: ${p.id} | Loja: ${p.loja} | Endereço: ${p.endereco} | Status: ${p.status}`
    ).join('\n');
    
    navigator.clipboard.writeText(text);
    window.NexosUI.showToast(`${state.filteredData.length} pedidos copiados!`, 'success');
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     INICIALIZAÇÃO
     ══════════════════════════════════════════════════════════════════════════ */

  // Extrai dados iniciais
  state.extractedData = extractDataFromMap();
  applyFilters();

  // Constrói sidebar
  buildSidebar();

  // Renderiza pedidos
  renderPedidos();

  // Adiciona botão de exportação no footer
  const exportBtn = window.NexosUI.createButton({
    text: '📊 Exportar Excel',
    variant: 'secondary',
    onClick: () => {
      window.NexosUI.showToast('Exportação em desenvolvimento', 'info');
    }
  });
  overlay.addFooterButton(exportBtn);

  console.log('[Picking] ✅ Overlay refatorado construído com sucesso!');
  
  return overlay;
}

/* ═══════════════════════════════════════════════════════════════════════════
   NOTAS DE REFATORAÇÃO
   ══════════════════════════════════════════════════════════════════════════
   
   VANTAGENS:
   
   1. ✅ Código muito mais limpo e organizado
   2. ✅ Componentes reutilizáveis (botões, cards, badges)
   3. ✅ Autenticação automática
   4. ✅ Dark mode funcional
   5. ✅ Avatar do usuário no header
   6. ✅ Toasts para feedback
   7. ✅ Modais padronizados
   8. ✅ Fácil manutenção e extensão
   
   LÓGICA MANTIDA:
   
   - ✅ Extração de dados do mapa (extractDataFromMap)
   - ✅ Filtros por status, loja e busca
   - ✅ Agrupamento por loja
   - ✅ Modal de detalhes
   - ✅ Copiar para clipboard
   
   PRÓXIMOS PASSOS:
   
   1. Testar este exemplo em ambiente de desenvolvimento
   2. Adaptar lógica de extração real do content.js
   3. Substituir buildExtractionOverlay() original
   4. Testar exaustivamente
   5. Aplicar mesma refatoração em outros overlays
   
   ══════════════════════════════════════════════════════════════════════════ */
