// ===================================================================
// NEXOS - Gerenciador de Cargos de Usuários
// Interface de administração para atribuir roles aos usuários
// ===================================================================

/**
 * Gerenciador de Cargos de Usuários
 * Permite que Admin Master atribua roles para outros usuários
 */
class UserRoleManager {
  constructor() {
    this.storageKey = '__nexos_user_roles';
    this.pendingUsersKey = '__nexos_pending_users';
    this.userRoles = {}; // { email: roleId }
    this.pendingUsers = []; // [{ email, name, department, requestedAt }]
    this.initialized = false;
  }

  /**
   * Verifica se window.ROLES está carregado (agora via <script> no HTML)
   * @private
   */
  async _ensureRolesLoaded() {
    if (window.ROLES && window.PERMISSIONS && Object.keys(window.ROLES).length > 0) {
      return; // Já está carregado
    }

    // ROLES deve ser carregado via <script src="../core/permissions/roles.js"> no HTML
    // Se não estiver disponível, é um erro de configuração
    console.error('[UserRoleManager] ❌ window.ROLES não disponível!');
    console.error('[UserRoleManager] ❌ Verifique se roles.js está sendo carregado no HTML antes de admin.js');
    throw new Error('ROLES não foi carregado via HTML');
  }

  /**
   * Inicializa o gerenciador carregando dados do storage
   */
  async init() {
    if (this.initialized) {
      console.log('[UserRoleManager] Já inicializado');
      return;
    }

    try {
      // Garantir que ROLES está disponível
      await this._ensureRolesLoaded();
      
      await this.loadUserRoles();
      await this.loadPendingUsers();
      
      // Garantir que o Admin Master padrão sempre esteja registrado
      const defaultAdminEmail = 'leonardo.miguel@gpabr.com';
      if (!this.userRoles[defaultAdminEmail]) {
        console.log('[UserRoleManager] ⚠️ Admin Master não encontrado. Registrando...');
        await this.setUserRole(defaultAdminEmail, 'admin_master');
        console.log('[UserRoleManager] ✅ Admin Master registrado:', defaultAdminEmail);
      }
      
      this.initialized = true;
      console.log('[UserRoleManager] ✅ Inicializado com', Object.keys(this.userRoles).length, 'usuários');
    } catch (error) {
      console.error('[UserRoleManager] ❌ Erro ao inicializar:', error);
      throw error;
    }
  }

  /**
   * Carrega roles dos usuários do storage
   */
  async loadUserRoles() {
    try {
      const data = await chrome.storage.local.get(this.storageKey);
      this.userRoles = data[this.storageKey] || {};
      
      console.log('[UserRoleManager] Roles carregados:', this.userRoles);
      return this.userRoles;
    } catch (error) {
      console.error('[UserRoleManager] Erro ao carregar roles:', error);
      this.userRoles = {};
      return {};
    }
  }

  /**
   * Salva roles dos usuários no storage
   */
  async saveUserRoles() {
    try {
      await chrome.storage.local.set({
        [this.storageKey]: this.userRoles
      });
      console.log('[UserRoleManager] ✅ Roles salvos:', this.userRoles);
      return true;
    } catch (error) {
      console.error('[UserRoleManager] ❌ Erro ao salvar roles:', error);
      return false;
    }
  }

  /**
   * Define o cargo de um usuário
   * @param {string} email - Email do usuário
   * @param {string} roleId - ID do cargo (ex: 'admin_master', 'torre_assistente_i')
   */
  async setUserRole(email, roleId) {
    if (!email || !email.includes('@')) {
      throw new Error('Email inválido');
    }

    // Garantir que ROLES está carregado
    await this._ensureRolesLoaded();

    // Validar se o role existe
    if (!window.ROLES || !Object.values(window.ROLES).find(r => r.id === roleId)) {
      throw new Error(`Role '${roleId}' não existe`);
    }

    this.userRoles[email.toLowerCase()] = roleId;
    await this.saveUserRoles();

    console.log(`[UserRoleManager] ✅ Role '${roleId}' atribuído para ${email}`);
    return true;
  }

  /**
   * Remove o cargo de um usuário
   * @param {string} email - Email do usuário
   */
  async removeUserRole(email) {
    if (!email) return false;

    delete this.userRoles[email.toLowerCase()];
    await this.saveUserRoles();

    console.log(`[UserRoleManager] ✅ Role removido para ${email}`);
    return true;
  }

  /**
   * Obtém o cargo de um usuário
   * @param {string} email - Email do usuário
   * @returns {string|null} ID do cargo ou null se não definido
   */
  getUserRole(email) {
    if (!email) return null;
    return this.userRoles[email.toLowerCase()] || null;
  }

  /**
   * Carrega usuários pendentes de aprovação do storage
   */
  async loadPendingUsers() {
    try {
      const data = await chrome.storage.local.get(this.pendingUsersKey);
      this.pendingUsers = data[this.pendingUsersKey] || [];
      
      console.log('[UserRoleManager] Usuários pendentes carregados:', this.pendingUsers.length);
      return this.pendingUsers;
    } catch (error) {
      console.error('[UserRoleManager] Erro ao carregar pendentes:', error);
      this.pendingUsers = [];
      return [];
    }
  }

  /**
   * Salva usuários pendentes no storage
   */
  async savePendingUsers() {
    try {
      await chrome.storage.local.set({
        [this.pendingUsersKey]: this.pendingUsers
      });
      console.log('[UserRoleManager] ✅ Pendentes salvos:', this.pendingUsers.length);
      return true;
    } catch (error) {
      console.error('[UserRoleManager] ❌ Erro ao salvar pendentes:', error);
      return false;
    }
  }

  /**
   * Adiciona usuário à lista de aprovações pendentes
   * @param {Object} userData - { email, name, department, requestedAt }
   */
  async addPendingUser(userData) {
    if (!userData.email || !userData.email.includes('@')) {
      throw new Error('Email inválido');
    }

    const email = userData.email.toLowerCase();

    // Verificar se já está pendente
    const existing = this.pendingUsers.find(u => u.email === email);
    if (existing) {
      console.log('[UserRoleManager] ℹ️ Usuário já está na lista de pendentes:', email);
      return false;
    }

    // Adicionar à lista
    this.pendingUsers.push({
      email: email,
      name: userData.name || email.split('@')[0],
      department: userData.department || 'Não informado',
      requestedAt: userData.requestedAt || Date.now(),
      microsoft365: userData.microsoft365 || false,
      photo: userData.photo || null,
      suggestedRole: userData.suggestedRole || null
    });

    await this.savePendingUsers();

    console.log('[UserRoleManager] ✅ Usuário adicionado aos pendentes:', email);
    return true;
  }

  /**
   * Aprova usuário pendente e atribui role
   * @param {string} email - Email do usuário
   * @param {string} roleId - ID do cargo a atribuir
   */
  async approvePendingUser(email, roleId) {
    if (!email || !roleId) {
      throw new Error('Email e roleId são obrigatórios');
    }

    email = email.toLowerCase();

    // Remover da lista de pendentes
    this.pendingUsers = this.pendingUsers.filter(u => u.email !== email);
    await this.savePendingUsers();

    // Atribuir role
    await this.setUserRole(email, roleId);

    console.log('[UserRoleManager] ✅ Usuário aprovado:', email, '| Role:', roleId);
    return true;
  }

  /**
   * Rejeita usuário pendente
   * @param {string} email - Email do usuário
   */
  async rejectPendingUser(email) {
    if (!email) return false;

    email = email.toLowerCase();

    // Remover da lista de pendentes
    const before = this.pendingUsers.length;
    this.pendingUsers = this.pendingUsers.filter(u => u.email !== email);
    const after = this.pendingUsers.length;

    if (before === after) {
      console.log('[UserRoleManager] ⚠️ Usuário não encontrado nos pendentes:', email);
      return false;
    }

    await this.savePendingUsers();

    console.log('[UserRoleManager] ✅ Usuário rejeitado:', email);
    return true;
  }

  /**
   * Obtém lista de usuários pendentes
   * @returns {Array} Lista de usuários pendentes
   */
  getPendingUsers() {
    return [...this.pendingUsers]; // Retornar cópia
  }

  /**
   * Verifica se há usuários pendentes
   * @returns {boolean}
   */
  hasPendingUsers() {
    return this.pendingUsers.length > 0;
  }

  /**
   * Conta quantos usuários pendentes
   * @returns {number}
   */
  getPendingCount() {
    return this.pendingUsers.length;
  }

  /**
   * Lista todos os usuários com seus cargos
   * @returns {Array} Array de objetos { email, roleId, roleName, roleColor }
   */
  listAllUsers() {
    return Object.entries(this.userRoles).map(([email, roleId]) => {
      const role = Object.values(window.ROLES || {}).find(r => r.id === roleId);
      return {
        email,
        roleId,
        roleName: role?.name || 'Cargo Desconhecido',
        roleColor: role?.color || '#666',
        roleHierarchy: role?.hierarchy || 0
      };
    }).sort((a, b) => b.roleHierarchy - a.roleHierarchy); // Maior hierarquia primeiro
  }

  /**
   * Importa múltiplos usuários de uma vez
   * @param {Array} users - Array de objetos { email, roleId }
   */
  async bulkImportUsers(users) {
    let imported = 0;
    let errors = [];

    for (const user of users) {
      try {
        await this.setUserRole(user.email, user.roleId);
        imported++;
      } catch (error) {
        errors.push({ email: user.email, error: error.message });
      }
    }

    console.log(`[UserRoleManager] ✅ Importação: ${imported} OK, ${errors.length} erros`);
    return { imported, errors };
  }

  /**
   * Exporta todos os usuários para JSON
   */
  exportUsersToJSON() {
    const users = this.listAllUsers();
    const json = JSON.stringify(users, null, 2);
    
    // Download automático
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexos-users-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);

    console.log('[UserRoleManager] ✅ Usuários exportados para JSON');
    return users;
  }

  /**
   * Obtém estatísticas dos usuários
   */
  getStatistics() {
    const users = this.listAllUsers();
    const stats = {
      total: users.length,
      byRole: {}
    };

    users.forEach(user => {
      if (!stats.byRole[user.roleName]) {
        stats.byRole[user.roleName] = {
          count: 0,
          color: user.roleColor
        };
      }
      stats.byRole[user.roleName].count++;
    });

    return stats;
  }
}

// ===================================================================
// UTILITY - Busca em Tempo Real
// ===================================================================

/**
 * Inicializa busca em tempo real de usuários
 */
function initializeUserSearch(users, currentUserEmail) {
  const searchInput = document.getElementById('user-search-input');
  const tableBody = document.getElementById('users-table-body');
  const counter = document.getElementById('user-search-counter');
  
  if (!searchInput || !tableBody || !counter) return;
  
  // Função para renderizar linha de usuário
  const renderUserRow = (user) => {
    const supervisor = window.supervisionManager ? 
      window.supervisionManager.getSupervisor(user.email) : null;
    
    return `
      <tr>
        <td>
          <strong>${user.email}</strong>
          ${user.email === currentUserEmail ? '<span class="badge" style="background: #0078D4; margin-left: 0.5rem;">Você</span>' : ''}
        </td>
        <td>
          <span class="role-badge" style="
            background: ${user.roleColor}15;
            color: ${user.roleColor};
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-weight: 500;
            font-size: 0.9rem;
          ">
            ${user.roleName}
          </span>
        </td>
        <td>
          <span style="color: #666;">${user.roleHierarchy}</span>
        </td>
        <td>
          ${supervisor ? `
            <div style="display: flex; align-items: center; gap: 0.5rem;">
              <span style="color: #10b981;">✓</span>
              <span style="font-size: 0.875rem;">${supervisor}</span>
              <button 
                class="btn btn-small" 
                data-action="showAssignSupervisorModal"
                data-param="${user.email}"
                style="padding: 0.125rem 0.5rem; font-size: 0.75rem;"
              >
                Alterar
              </button>
            </div>
          ` : `
            <button 
              class="btn btn-small btn-success" 
              data-action="showAssignSupervisorModal"
              data-param="${user.email}"
              style="padding: 0.25rem 0.75rem; font-size: 0.8rem;"
            >
              + Atribuir
            </button>
          `}
        </td>
        <td style="text-align: center;">
          <button 
            class="btn btn-small" 
            data-action="showEditUserModal"
            data-param="${user.email}"
            style="margin-right: 0.5rem;"
          >
            ✏️ Editar
          </button>
          <button 
            class="btn btn-small btn-danger" 
            data-action="removeUserRole"
            data-param="${user.email}"
          >
            🗑️ Remover
          </button>
        </td>
      </tr>
    `;
  };
  
  // Função de busca
  const performSearch = () => {
    const searchTerm = searchInput.value.toLowerCase().trim();
    
    if (!searchTerm) {
      // Sem busca, mostrar todos
      tableBody.innerHTML = users.map(renderUserRow).join('');
      counter.textContent = `${users.length} usuários`;
      counter.style.color = 'var(--gray-600)';
      return;
    }
    
    // Filtrar usuários
    const filtered = users.filter(user => {
      return user.email.toLowerCase().includes(searchTerm) ||
             user.roleName.toLowerCase().includes(searchTerm);
    });
    
    // Renderizar com highlight
    if (filtered.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="5" style="text-align: center; padding: 2rem; color: #999;">
            ⚠️ Nenhum usuário encontrado para "${searchInput.value}"
          </td>
        </tr>
      `;
      counter.textContent = '0 resultados';
      counter.style.color = 'var(--warning)';
    } else {
      tableBody.innerHTML = filtered.map(user => {
        // Criar cópia com highlight
        const highlightedUser = {
          ...user,
          email: highlightText(user.email, searchTerm),
          roleName: highlightText(user.roleName, searchTerm)
        };
        return renderUserRow(highlightedUser);
      }).join('');
      
      counter.textContent = `${filtered.length} de ${users.length} usuários`;
      counter.style.color = 'var(--success)';
    }
  };
  
  // Helper para highlight (reutilizar do admin.js se disponível)
  const highlightText = (text, search) => {
    if (!search || !text) return text;
    const escapedSearch = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escapedSearch})`, 'gi');
    return text.replace(regex, '<mark>$1</mark>');
  };
  
  // Debounce helper
  const debounce = (func, delay = 300) => {
    let timeoutId;
    return function(...args) {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
  };
  
  // Adicionar listener com debounce
  searchInput.addEventListener('input', debounce(performSearch, 300));
  
  // Renderização inicial
  tableBody.innerHTML = users.map(renderUserRow).join('');
}

/**
 * Inicializa busca em tempo real de usuários pendentes
 */
function initializePendingSearch(pendingUsers) {
  const searchInput = document.getElementById('pending-search-input');
  const container = document.getElementById('pending-users-container');
  const counter = document.getElementById('pending-search-counter');
  
  if (!searchInput || !container || !counter) return;
  
  // Função para renderizar card de pendente
  const renderPendingCard = (user) => {
    const timeAgo = Math.floor((Date.now() - user.requestedAt) / 1000 / 60);
    const timeLabel = timeAgo < 60 ? `${timeAgo} minutos` : `${Math.floor(timeAgo / 60)} horas`;
    
    return `
      <div class="pending-user-card">
        <div class="pending-user-grid">
          <div class="pending-user-info">
            <div class="pending-user-header">
              ${user.photo ? `<img src="${user.photo}" alt="${user.name}" class="pending-user-avatar">` : `<span class="pending-user-avatar-placeholder">👤</span>`}
              <div class="pending-user-name-container">
                <strong class="pending-user-name">${user.name}</strong>
                ${user.microsoft365 ? '<span class="pending-user-badge-m365">Microsoft 365</span>' : ''}
              </div>
            </div>
            <div class="pending-user-email">
              📧 <span class="pending-user-email-value">${user.email}</span>
            </div>
            <div class="pending-user-department">
              🏢 ${user.department}
            </div>
            <div class="pending-user-role">
              🎭 <strong class="pending-user-role-value">${user.suggestedRole || '—'}</strong>
            </div>
            <div class="pending-user-time">
              ⏱️ Solicitado há ${timeLabel}
            </div>
          </div>

          <div class="pending-user-actions">
            <select 
              class="pending-role-select" 
              data-email="${user.email}"
            >
              <option value="">-- Selecionar Cargo --</option>
              ${Object.values(window.ROLES || {})
                .sort((a, b) => b.hierarchy - a.hierarchy)
                .map(role => {
                  const isSuggested = user.suggestedRole && (role.id === user.suggestedRole || role.name === user.suggestedRole);
                  return `<option value="${role.id}" ${isSuggested ? 'selected' : ''}>${role.name}</option>`;
                }).join('')}
            </select>
            <button 
              class="btn-pending-approve" 
              data-action="approvePendingUser"
              data-email="${user.email}"
            >
              ✅ Aprovar
            </button>
            <button 
              class="btn-pending-reject" 
              data-action="rejectPendingUser"
              data-email="${user.email}"
            >
              ❌ Rejeitar
            </button>
          </div>
        </div>
      </div>
    `;
  };
  
  // Função de busca
  const performSearch = () => {
    const searchTerm = searchInput.value.toLowerCase().trim();
    
    if (!searchTerm) {
      // Sem busca, mostrar todos
      container.innerHTML = pendingUsers.map(renderPendingCard).join('');
      counter.textContent = `${pendingUsers.length} usuário${pendingUsers.length !== 1 ? 's' : ''} pendente${pendingUsers.length !== 1 ? 's' : ''}`;
      counter.style.color = 'var(--gray-600)';
      return;
    }
    
    // Filtrar pendentes
    const filtered = pendingUsers.filter(user => {
      return user.name.toLowerCase().includes(searchTerm) ||
             user.email.toLowerCase().includes(searchTerm) ||
             (user.department && user.department.toLowerCase().includes(searchTerm));
    });
    
    // Renderizar com highlight
    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="pending-user-card" style="text-align: center; padding: 2rem;">
          <p style="color: var(--gray-500);">⚠️ Nenhum usuário pendente encontrado para "${searchInput.value}"</p>
        </div>
      `;
      counter.textContent = '0 resultados';
      counter.style.color = 'var(--warning)';
    } else {
      container.innerHTML = filtered.map(user => {
        // Criar cópia com highlight
        const highlightedUser = {
          ...user,
          name: highlightText(user.name, searchTerm),
          email: highlightText(user.email, searchTerm)
        };
        return renderPendingCard(highlightedUser);
      }).join('');
      
      counter.textContent = `${filtered.length} de ${pendingUsers.length} pendentes`;
      counter.style.color = 'var(--success)';
    }
  };
  
  // Helper para highlight
  const highlightText = (text, search) => {
    if (!search || !text) return text;
    const escapedSearch = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escapedSearch})`, 'gi');
    return text.replace(regex, '<mark>$1</mark>');
  };
  
  // Debounce helper
  const debounce = (func, delay = 300) => {
    let timeoutId;
    return function(...args) {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
  };
  
  // Adicionar listener com debounce
  searchInput.addEventListener('input', debounce(performSearch, 300));
  
  // Renderização inicial
  container.innerHTML = pendingUsers.map(renderPendingCard).join('');
}

// ===================================================================
// UI - Painel de Gerenciamento de Usuários
// ===================================================================

// ===================================================================
// Helpers de acesso ao SharePoint — Nexos_Usuarios
// Usa raw fetch igual ao NexosUserManager para máxima compatibilidade
// ===================================================================

const _SP_GRAPH = 'https://graph.microsoft.com/v1.0';
const _SP_SITE  = 'gpabr.sharepoint.com:/sites/nexos';

/** Obtém token de acesso: tenta todas as fontes disponíveis no contexto admin */
async function _adminGetSPToken() {
  // 1. msalAuth exposto globalmente (ExtensionOAuthAdapter — admin page)
  if (window.msalAuth && typeof window.msalAuth.getAccessToken === 'function') {
    try { const t = await window.msalAuth.getAccessToken(); if (t) return t; } catch {}
  }

  // 2. SP GraphClient (tem authHelper com getAccessToken)
  const gc = window.graphClient;
  if (gc) {
    const helper = gc.authHelper || gc.msalAuth;
    if (helper && typeof helper.getAccessToken === 'function') {
      try { const t = await helper.getAccessToken(); if (t) return t; } catch {}
    }
  }

  // 3. unifiedAuth (disponível em content scripts e às vezes no admin)
  if (window.unifiedAuth && typeof window.unifiedAuth.getMSALToken === 'function') {
    try { const t = await window.unifiedAuth.getMSALToken(); if (t) return t; } catch {}
  }

  // 4. NexosAuth (sistema legado)
  if (window.NexosAuth) {
    const user = window.NexosAuth.getCurrentUser?.();
    if (user?.accessToken) return user.accessToken;
  }

  // 5. chrome.storage — tokens salvos por qualquer parte do sistema
  try {
    const keys = ['nexos-access-token', 'nexos-sp-token', 'ms-access-token',
                  'nexos_sp_token', 'msal_access_token'];
    const data = await chrome.storage.local.get(keys);
    for (const k of keys) { if (data[k]) return data[k]; }
  } catch {}

  console.warn('[UserRoleManager] ❌ _adminGetSPToken: nenhuma fonte retornou token. msalAuth:', !!window.msalAuth, '| graphClient:', !!window.graphClient);
  throw new Error('Token de acesso não disponível. Certifique-se de estar logado na conta Microsoft do GPA.');
}

/** Estado compartilhado: siteId e listId cacheados para evitar round-trips */
const _spCache = { siteId: null, listId: null };

/** Resolve siteId e listId, cacheando em memória */
async function _spResolveIds(token) {
  if (_spCache.siteId && _spCache.listId) return _spCache;

  const siteRes = await fetch(`${_SP_GRAPH}/sites/${_SP_SITE}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!siteRes.ok) throw new Error(`Erro ao obter site SharePoint: ${siteRes.status}`);
  _spCache.siteId = (await siteRes.json()).id;

  const listRes = await fetch(
    `${_SP_GRAPH}/sites/${_spCache.siteId}/lists?$filter=displayName eq 'Nexos_Usuarios'`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!listRes.ok) throw new Error(`Erro ao obter lista: ${listRes.status}`);
  const listData = await listRes.json();
  if (!listData.value?.length) throw new Error("Lista 'Nexos_Usuarios' não encontrada no SharePoint.");
  _spCache.listId = listData.value[0].id;

  return _spCache;
}

/** Busca todos os itens de Nexos_Usuarios */
async function _fetchNexosUsuarios() {
  const token = await _adminGetSPToken();
  const { siteId, listId } = await _spResolveIds(token);

  const res = await fetch(
    `${_SP_GRAPH}/sites/${siteId}/lists/${listId}/items?$expand=fields&$top=500`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!res.ok) throw new Error(`Erro ao buscar usuários: ${res.status}`);
  const data = await res.json();

  return {
    users: (data.value || []).map(i => ({ _itemId: i.id, ...i.fields }))
  };
}

/** Atualiza Status do usuário em Nexos_Usuarios */
async function _updateNexosUsuarioStatus(itemId, newStatus) {
  const token = await _adminGetSPToken();
  const { siteId, listId } = await _spResolveIds(token);

  const res = await fetch(
    `${_SP_GRAPH}/sites/${siteId}/lists/${listId}/items/${itemId}`,
    {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ fields: { Status: newStatus, UltimaAtualizacao: new Date().toISOString() } })
    }
  );
  if (!res.ok) throw new Error(`Erro ao atualizar status: ${res.status}`);
}

/** Atualiza campo Departamento de um usuário pelo email */
async function _updateNexosDepartamento(email, departamento) {
  const token = await _adminGetSPToken();
  const { siteId, listId } = await _spResolveIds(token);

  // Buscar itemId pelo email
  const busca = await fetch(
    `${_SP_GRAPH}/sites/${siteId}/lists/${listId}/items?$expand=fields&$filter=fields/Email eq '${encodeURIComponent(email)}'&$top=1`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!busca.ok) throw new Error(`Erro ao buscar usuário: ${busca.status}`);
  const { value } = await busca.json();
  if (!value || !value.length) throw new Error(`Usuário não encontrado: ${email}`);
  const itemId = value[0].id;

  const patch = await fetch(
    `${_SP_GRAPH}/sites/${siteId}/lists/${listId}/items/${itemId}`,
    {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ fields: { Departamento: departamento || null, UltimaAtualizacao: new Date().toISOString() } })
    }
  );
  if (!patch.ok) throw new Error(`Erro ao atualizar departamento: ${patch.status}`);
}

/** Exclui item da lista Nexos_Usuarios */
async function _deleteNexosUsuario(itemId) {
  const token = await _adminGetSPToken();
  const { siteId, listId } = await _spResolveIds(token);

  const res = await fetch(
    `${_SP_GRAPH}/sites/${siteId}/lists/${listId}/items/${itemId}`,
    { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } }
  );
  if (!res.ok && res.status !== 204) throw new Error(`Erro ao excluir: ${res.status}`);
}

/**
 * Gera HTML de avatar para um usuário do Nexos_Usuarios.
 * - URL direta (CDN/blob): usa <img src> com fallback de iniciais.
 * - URL Graph API (contém 'graph.microsoft.com' ou '$value'):
 *   exibe iniciais + coloca data-nexos-photo no <img> para lazy-load com token.
 * Após inserir o HTML no DOM, chame _adminLoadAvatarsWithToken(rootEl) para
 * buscar as fotos autenticadas.
 * @param {object} u   - item de Nexos_Usuarios
 * @param {number} size - tamanho em px (default 36)
 */
function _adminAvatarHtml(u, size = 36) {
  const name = (u.NomeExibicao || u.NomeCompleto || u.Title || '?').trim();
  const initials = name.split(/\s+/).map(w => w[0]).filter(Boolean).slice(0, 2).join('').toUpperCase() || '?';
  const fs = Math.round(size * 0.38);

  const wrapStyle  = `position:relative;width:${size}px;height:${size}px;flex-shrink:0;display:inline-block;`;
  const imgStyle   = `width:${size}px;height:${size}px;border-radius:50%;object-fit:cover;position:absolute;top:0;left:0;`;
  const fallStyle  = `width:${size}px;height:${size}px;border-radius:50%;background:#6366F1;color:#fff;
    display:flex;align-items:center;justify-content:center;font-size:${fs}px;font-weight:700;
    position:absolute;top:0;left:0;`;

  const url = (u.FotoURL || '').trim();

  if (!url) {
    return `<div style="${wrapStyle}"><div style="${fallStyle}">${initials}</div></div>`;
  }

  const needsAuth = url.includes('graph.microsoft.com') || url.includes('$value');

  if (needsAuth) {
    // Lazy-load: inicialmente só fallback; _adminLoadAvatarsWithToken buscará com token
    return `<div style="${wrapStyle}">
      <div class="nxav-fb" style="${fallStyle}">${initials}</div>
      <img class="nxav-img" data-nexos-photo="${url}" alt="${name}"
           style="${imgStyle}display:none;">
    </div>`;
  }

  // URL direta — carregamento normal com fallback em caso de erro
  return `<div style="${wrapStyle}">
    <div class="nxav-fb" style="${fallStyle}">${initials}</div>
    <img src="${url}" alt="${name}" style="${imgStyle}"
         onload="this.style.display='';this.previousElementSibling.style.display='none';"
         onerror="this.style.display='none';">
  </div>`;
}

/**
 * Após inserir HTML com _adminAvatarHtml no DOM, chame esta função
 * passando o elemento raiz (ou document) para buscar e exibir as fotos
 * que requerem autenticação (data-nexos-photo).
 * @param {Element|Document} root
 */
async function _adminLoadAvatarsWithToken(root) {
  const el = root || document;
  const imgs = el.querySelectorAll('img[data-nexos-photo]');
  if (!imgs.length) return;

  let token = null;
  try { token = await _adminGetSPToken(); } catch { return; }
  if (!token) return;

  for (const img of imgs) {
    const url = img.dataset.nexosPhoto;
    if (!url) continue;
    try {
      const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) continue;
      const blob = await res.blob();
      const dataUrl = await new Promise(r => {
        const reader = new FileReader();
        reader.onloadend = () => r(reader.result);
        reader.readAsDataURL(blob);
      });
      img.src = dataUrl;
      img.style.display = '';
      const fb = img.previousElementSibling;
      if (fb && fb.classList.contains('nxav-fb')) fb.style.display = 'none';
    } catch { /* foto indisponível — manter fallback */ }
  }
}

/**
 * Renderiza o painel de gerenciamento de usuários lendo diretamente de Nexos_Usuarios no SharePoint.
 */
async function renderUserManagementPanel() {
  const container = document.getElementById('content-area');
  if (!container) return;

  const loadingId = window.globalLoading?.show('user-management-panel');

  // Verificar permissão
  if (!window.permissionManager?.hasPermission('manage_users')) {
    window.globalLoading?.hide(loadingId);
    container.innerHTML = `<div class="error-panel"><h2>❌ Acesso Negado</h2>
      <p>Permissão necessária: <code>manage_users</code></p></div>`;
    return;
  }

  // Estado do filtro ativo (persiste entre reloads)
  const activeFilter = window._usuariosFilter || 'todos';

  // ── Renderizar esqueleto da página primeiro ──────────────────────────────
  container.innerHTML = `
    <div class="panel-header" style="display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap;">
      <div>
        <h2 style="margin:0;font-size:1.25rem;">👥 Gerenciamento de Usuários</h2>
        <p class="subtitle" style="margin:0;color:#666;">Todos os registros da lista <strong>Nexos_Usuarios</strong> no SharePoint</p>
      </div>
      <div style="display:flex;gap:8px;align-items:center;">
        <button class="btn btn-secondary" data-action="refreshUserManagement" title="Atualizar">
          🔄 Atualizar
        </button>
      </div>
    </div>

    <!-- Filtros -->
    <div id="usuarios-filter-bar" style="display:flex;align-items:center;gap:8px;margin:16px 0 12px 0;flex-wrap:wrap;">
      <span style="font-size:12px;color:#6B7280;font-weight:600;">Filtrar:</span>
      ${[
        { key:'todos',     label:'Todos',      bg:'#F9FAFB', border:'#D1D5DB', color:'#374151' },
        { key:'pendente',  label:'⏳ Pendentes', bg:'#FFFBEB', border:'#FDE68A', color:'#92400E' },
        { key:'aprovado',  label:'✅ Aprovados', bg:'#ECFDF5', border:'#A7F3D0', color:'#065F46' },
        { key:'rejeitado', label:'🚫 Rejeitados',bg:'#FEF2F2', border:'#FECACA', color:'#B91C1C' }
      ].map(f => `
        <button data-action="filterUsuarios" data-param="${f.key}"
          style="font-size:12px;padding:5px 14px;border-radius:8px;cursor:pointer;font-weight:600;
          border:1.5px solid ${f.border};background:${f.bg};color:${f.color};
          ${activeFilter === f.key ? 'box-shadow:0 0 0 2px #6366F1;' : ''}">
          ${f.label}
        </button>
      `).join('')}
      <span id="usuarios-count" style="margin-left:auto;font-size:12px;color:#9CA3AF;"></span>
    </div>

    <!-- Tabela / Grid de cards -->
    <div class="card" style="overflow-x:auto;background:transparent;box-shadow:none;border:none;padding:0;">
      <table id="nexos-usuarios-table" style="width:100%;border-collapse:separate;border-spacing:0;table-layout:fixed;">
        <colgroup><col style="width:50%"><col style="width:50%"></colgroup>
        <tbody id="nexos-usuarios-tbody">
          <tr><td colspan="2" style="text-align:center;padding:60px;color:#9CA3AF;">
            <div style="font-size:28px;margin-bottom:8px;">⏳</div>
            <div style="font-weight:600;font-size:14px;">Buscando usuários no SharePoint…</div>
          </td></tr>
        </tbody>
      </table>
    </div>

    <!-- Modal de confirmação remoção -->
    <div id="rm-user-modal" style="display:none;position:fixed;inset:0;z-index:9999;
      background:rgba(15,23,42,0.75);align-items:center;justify-content:center;">
      <div style="background:#fff;border-radius:14px;padding:32px 36px;max-width:400px;width:90%;
        box-shadow:0 20px 60px rgba(0,0,0,0.3);text-align:center;">
        <div style="font-size:40px;margin-bottom:12px;">🗑️</div>
        <div style="font-size:17px;font-weight:700;color:#111827;margin-bottom:8px;">Remover Acesso</div>
        <div id="rm-user-msg" style="font-size:14px;color:#6B7280;margin-bottom:24px;line-height:1.5;"></div>
        <div style="display:flex;gap:10px;justify-content:center;">
          <button id="rm-user-confirm" style="background:#EF4444;color:#fff;border:none;border-radius:8px;
            padding:10px 24px;font-size:14px;font-weight:600;cursor:pointer;">Sim, remover</button>
          <button data-action="closeRmUserModal"
            style="background:transparent;color:#6B7280;border:1.5px solid #D1D5DB;border-radius:8px;
            padding:10px 18px;font-size:14px;cursor:pointer;">Cancelar</button>
        </div>
      </div>
    </div>

    <div id="usuarios-action-result" style="margin-top:12px;"></div>
  `;

  window.globalLoading?.hide(loadingId);

  // ── Buscar dados do SharePoint ────────────────────────────────────────────
  let spCtx = null;
  try {
    spCtx = await _fetchNexosUsuarios();
  } catch (e) {
    document.getElementById('nexos-usuarios-tbody').innerHTML =
      `<tr><td colspan="2" style="text-align:center;padding:32px;color:#EF4444;">
        ❌ ${e.message}</td></tr>`;
    return;
  }

  const { users } = spCtx;
  window._spCtxUsuarios = {}; // contexto simplificado — graphClient gerencia auth

  // Contagens por status
  const _counts = {
    todos:     users.length,
    pendente:  users.filter(u => (u.Status||'').toLowerCase() === 'pendente').length,
    aprovado:  users.filter(u => (u.Status||'').toLowerCase() === 'aprovado').length,
    rejeitado: users.filter(u => (u.Status||'').toLowerCase() === 'rejeitado').length,
  };

  // Atualizar labels dos filtros com contagens reais
  const filterBar = document.getElementById('usuarios-filter-bar');
  if (filterBar) {
    const counts = _counts;
    const defs = [
      { key:'todos',     label:'Todos',        bg:'#F9FAFB', border:'#D1D5DB', color:'#374151' },
      { key:'pendente',  label:'⏳ Pendentes',  bg:'#FFFBEB', border:'#FDE68A', color:'#92400E' },
      { key:'aprovado',  label:'✅ Aprovados',  bg:'#ECFDF5', border:'#A7F3D0', color:'#065F46' },
      { key:'rejeitado', label:'🚫 Rejeitados', bg:'#FEF2F2', border:'#FECACA', color:'#B91C1C' }
    ];
    filterBar.innerHTML = defs.map(f => `
      <button data-action="filterUsuarios" data-param="${f.key}"
        style="font-size:12px;padding:5px 14px;border-radius:8px;cursor:pointer;font-weight:600;
        border:1.5px solid ${f.border};background:${f.bg};color:${f.color};
        ${activeFilter === f.key ? 'box-shadow:0 0 0 2px #6366F1;' : ''}">
        ${f.label} <span style="background:${f.border};border-radius:99px;padding:1px 7px;font-size:11px;margin-left:4px;">${counts[f.key]}</span>
      </button>
    `).join('') + `<span id="usuarios-count" style="margin-left:auto;font-size:12px;color:#9CA3AF;"></span>`;
  }

  // ── Renderizar linhas ─────────────────────────────────────────────────────
  _renderUsuariosTable(users, activeFilter);
}

/** Renderiza as linhas da tabela com filtro aplicado */
function _renderUsuariosTable(users, filter) {
  const tbody = document.getElementById('nexos-usuarios-tbody');
  const countEl = document.getElementById('usuarios-count');
  if (!tbody) return;

  const currentEmail = window.currentUserEmail || '';

  const filtered = filter === 'todos'
    ? users
    : users.filter(u => (u.Status || '').toLowerCase() === filter);

  if (countEl) countEl.textContent = `${filtered.length} de ${users.length} usuário(s)`;

  if (!filtered.length) {
    tbody.innerHTML = `<tr><td colspan="2" style="text-align:center;padding:48px;color:#9CA3AF;">
      <div style="font-size:32px;margin-bottom:8px;">🔍</div>
      <div style="font-weight:600;font-size:14px;">Nenhum usuário encontrado</div>
      <div style="font-size:12px;margin-top:4px;">Tente outro filtro</div>
    </td></tr>`;
    return;
  }

  const fmtDate = iso => {
    if (!iso) return '—';
    try { return new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }); } catch { return iso; }
  };

  // Mapeamento de nível → cor de badge
  const deptoColor = d => ({
    'Auxiliar':    ['#F3F4F6','#374151','#D1D5DB'],
    'Assistente':  ['#EFF6FF','#1D4ED8','#BFDBFE'],
    'Assistente2': ['#F0F9FF','#0369A1','#BAE6FD'],
    'Especialista':['#F0FDF4','#15803D','#BBF7D0'],
    'Loja':        ['#FFF7ED','#C2410C','#FED7AA'],
    'Gestão':      ['#FAF5FF','#7E22CE','#E9D5FF'],
  }[d] || ['#F9FAFB','#6B7280','#E5E7EB']);

  const deptoBadge = d => {
    if (!d || d === '—') return `<span style="color:#9CA3AF;font-size:11px;font-style:italic;">Não definido</span>`;
    const [bg, c, br] = deptoColor(d);
    return `<span style="background:${bg};color:${c};border:1px solid ${br};border-radius:20px;
      padding:3px 10px;font-size:11px;font-weight:700;white-space:nowrap;">${d}</span>`;
  };

  const statusConfig = {
    aprovado:  { bg:'#ECFDF5', c:'#065F46', br:'#6EE7B7', icon:'✅', label:'Aprovado',  strip:'#10B981' },
    pendente:  { bg:'#FFFBEB', c:'#92400E', br:'#FDE68A', icon:'⏳', label:'Pendente',  strip:'#F59E0B' },
    rejeitado: { bg:'#FEF2F2', c:'#B91C1C', br:'#FECACA', icon:'🚫', label:'Rejeitado', strip:'#EF4444' },
  };

  // Renderizar como cards numa grid de 2 colunas
  const cardsHtml = filtered.map(u => {
    const status  = (u.Status || 'pendente').toLowerCase();
    const email   = u.Email || '';
    const nome    = u.NomeExibicao || u.NomeCompleto || u.Title || '—';
    const cargo   = u.Cargo || '';
    const depto   = u.Departamento || '—';
    const userId  = u.UserID || '';
    const isMe    = email === currentEmail;
    const ativo   = (u.Ativo === true || u.Ativo === 'true' || u.Ativo === 1);
    const sc      = statusConfig[status] || { bg:'#F9FAFB', c:'#374151', br:'#E5E7EB', icon:'❓', label: status, strip:'#9CA3AF' };
    const deptoRaw = depto === '—' ? '' : depto;

    // Botões de ação
    let btns = '';
    if (status === 'pendente') {
      btns += `<button data-action="usuarioAprovar" data-item-id="${u._itemId}" data-email="${email}"
        style="background:linear-gradient(135deg,#10B981,#059669);color:#fff;border:none;border-radius:8px;
        padding:7px 14px;font-size:12px;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:4px;
        box-shadow:0 2px 4px rgba(16,185,129,0.3);transition:opacity .15s;" onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'">
        ✅ Aprovar</button>`;
      btns += `<button data-action="usuarioRejeitar" data-item-id="${u._itemId}" data-email="${email}"
        style="background:linear-gradient(135deg,#F59E0B,#D97706);color:#fff;border:none;border-radius:8px;
        padding:7px 14px;font-size:12px;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:4px;
        box-shadow:0 2px 4px rgba(245,158,11,0.3);transition:opacity .15s;" onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'">
        🚫 Rejeitar</button>`;
    } else if (status === 'aprovado') {
      btns += `<button data-action="usuarioRejeitar" data-item-id="${u._itemId}" data-email="${email}"
        style="background:linear-gradient(135deg,#F59E0B,#D97706);color:#fff;border:none;border-radius:8px;
        padding:7px 14px;font-size:12px;font-weight:600;cursor:pointer;
        box-shadow:0 2px 4px rgba(245,158,11,0.3);transition:opacity .15s;" onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'">
        � Revogar</button>`;
    } else if (status === 'rejeitado') {
      btns += `<button data-action="usuarioAprovar" data-item-id="${u._itemId}" data-email="${email}"
        style="background:linear-gradient(135deg,#10B981,#059669);color:#fff;border:none;border-radius:8px;
        padding:7px 14px;font-size:12px;font-weight:600;cursor:pointer;
        box-shadow:0 2px 4px rgba(16,185,129,0.3);transition:opacity .15s;" onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'">
        ✅ Aprovar</button>`;
    }
    if (!isMe) {
      btns += `<button data-action="usuarioRemover" data-item-id="${u._itemId}"
        data-nome="${nome.replace(/"/g,'&quot;')}" data-email="${email}"
        style="background:transparent;color:#EF4444;border:1.5px solid #FECACA;border-radius:8px;
        padding:6px 12px;font-size:12px;font-weight:600;cursor:pointer;transition:all .15s;"
        onmouseover="this.style.background='#FEF2F2'" onmouseout="this.style.background='transparent'">
        🗑️ Remover</button>`;
    }

    return `
      <td style="padding:8px;">
        <div style="background:#fff;border-radius:14px;border:1.5px solid #E2E8F0;overflow:hidden;
          box-shadow:0 1px 4px rgba(0,0,0,0.06);position:relative;transition:box-shadow .2s;"
          onmouseover="this.style.boxShadow='0 4px 16px rgba(0,0,0,0.1)'" onmouseout="this.style.boxShadow='0 1px 4px rgba(0,0,0,0.06)'">
          <!-- Faixa colorida de status -->
          <div style="height:4px;background:${sc.strip};"></div>

          <div style="padding:16px 18px;">
            <!-- Topo: avatar + nome + status -->
            <div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:12px;">
              <div style="flex-shrink:0;">${_adminAvatarHtml(u, 44)}</div>
              <div style="flex:1;min-width:0;">
                <div style="font-weight:700;font-size:14px;color:#111827;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                  ${nome}${isMe ? ' <span style="background:#0078D4;color:#fff;font-size:9px;padding:1px 5px;border-radius:4px;vertical-align:middle;">VOCÊ</span>' : ''}
                </div>
                <div style="font-size:11px;color:#6B7280;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:1px;">${email}</div>
                ${cargo ? `<div style="font-size:11px;color:#9CA3AF;margin-top:2px;">🏷️ ${cargo}</div>` : ''}
              </div>
              <div style="flex-shrink:0;">
                <span style="background:${sc.bg};color:${sc.c};border:1px solid ${sc.br};border-radius:20px;
                  padding:3px 10px;font-size:11px;font-weight:700;white-space:nowrap;">
                  ${sc.icon} ${sc.label}
                </span>
              </div>
            </div>

            <!-- Linha de metadados -->
            <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:12px;">
              <!-- Nível editável -->
              <div style="display:flex;align-items:center;gap:6px;background:#F8FAFC;border-radius:8px;
                padding:5px 10px;border:1px solid #E2E8F0;">
                <span style="font-size:11px;color:#6B7280;font-weight:600;">NÍVEL</span>
                <select data-action="changeDepartamento" data-email="${email}" data-nivel-original="${deptoRaw}"
                  title="Alterar nível de acesso"
                  style="font-size:12px;font-weight:700;border:none;background:transparent;color:#374151;
                  cursor:pointer;outline:none;padding:0 2px;">
                  <option value="" ${!deptoRaw ? 'selected' : ''}>— Indefinido</option>
                  <option value="Auxiliar"    ${deptoRaw === 'Auxiliar'    ? 'selected' : ''}>Auxiliar</option>
                  <option value="Assistente"  ${deptoRaw === 'Assistente'  ? 'selected' : ''}>Assistente</option>
                  <option value="Assistente2" ${deptoRaw === 'Assistente2' ? 'selected' : ''}>Assistente2</option>
                  <option value="Especialista"${deptoRaw === 'Especialista'? 'selected' : ''}>Especialista</option>
                  <option value="Loja"        ${deptoRaw === 'Loja'        ? 'selected' : ''}>Loja</option>
                  <option value="Gestão"      ${deptoRaw === 'Gestão'      ? 'selected' : ''}>Gestão</option>
                </select>
              </div>

              <!-- Badge de nível atual -->
              ${deptoBadge(depto)}

              <!-- Ativo -->
              <span style="font-size:11px;${ativo ? 'color:#10B981;' : 'color:#9CA3AF;'};font-weight:600;">
                ${ativo ? '🟢 Ativo' : '⚪ Inativo'}
              </span>
            </div>

            <!-- Datas em linha discreta -->
            <div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:12px;padding-top:8px;border-top:1px solid #F1F5F9;">
              <div style="font-size:11px;color:#9CA3AF;">
                📅 <span style="color:#6B7280;">Criado:</span> ${fmtDate(u.DataCriacao)}
              </div>
              <div style="font-size:11px;color:#9CA3AF;">
                🕐 <span style="color:#6B7280;">Último acesso:</span> ${fmtDate(u.UltimaAtualizacao)}
              </div>
              ${userId ? `<div style="font-size:11px;color:#9CA3AF;" title="${userId}">
                🆔 <span style="color:#6B7280;">ID:</span> ${userId.length > 16 ? userId.substring(0,14)+'…' : userId}
              </div>` : ''}
            </div>

            <!-- Ações -->
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              ${btns}
            </div>
          </div>
        </div>
      </td>`;
  });

  // Montar em grid de 2 colunas
  let html = '';
  for (let i = 0; i < cardsHtml.length; i += 2) {
    html += `<tr>${cardsHtml[i]}${cardsHtml[i + 1] || '<td></td>'}</tr>`;
  }
  tbody.innerHTML = html;

  // Lazy-load de fotos que requerem autenticação Graph API
  _adminLoadAvatarsWithToken(tbody);
}

/** Aprovar / Rejeitar usuário direto no SharePoint */
async function _usuariosAction(action, itemId, email) {
  const newStatus = action === 'approve' ? 'aprovado' : 'rejeitado';
  const resultEl = document.getElementById('usuarios-action-result');

  // Ao aprovar, solicitar nível de acesso
  let departamento = null;
  if (action === 'approve') {
    const niveis = ['Auxiliar', 'Assistente', 'Assistente2', 'Especialista', 'Loja', 'Gestão'];
    const opcoes = niveis.map((n, i) => `${i + 1}. ${n}`).join('\n');
    const resp = prompt(`Aprovar ${email}\n\nEscolha o nível de acesso:\n${opcoes}\n\n(Digite o número ou deixe em branco para "Assistente")`);
    if (resp === null) return; // cancelou
    const idx = parseInt(resp) - 1;
    departamento = (idx >= 0 && idx < niveis.length) ? niveis[idx] : 'Assistente';
  }

  try {
    await _updateNexosUsuarioStatus(itemId, newStatus);

    // Atualizar Departamento se aprovado
    if (action === 'approve' && departamento) {
      try {
        await _updateNexosDepartamento(email, departamento);
      } catch (depErr) {
        console.warn('[Admin] Não foi possível atualizar Departamento:', depErr);
      }
    }

    const deptoMsg = action === 'approve' ? ` | Nível: <strong>${departamento}</strong>` : '';
    if (resultEl) resultEl.innerHTML = `<div style="background:#ECFDF5;border:1px solid #A7F3D0;border-radius:8px;
      padding:10px 16px;font-size:13px;color:#065F46;margin-top:8px;">
      ✅ Status de <strong>${email}</strong> atualizado para <strong>${newStatus}</strong>${deptoMsg}.</div>`;
    // Recarregar tabela
    renderUserManagementPanel();
  } catch (e) {
    if (resultEl) resultEl.innerHTML = `<div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:8px;
      padding:10px 16px;font-size:13px;color:#B91C1C;margin-top:8px;">❌ ${e.message}</div>`;
  }
}

/** Confirmação modal antes de remover */
function _usuariosConfirmRemove(itemId, nome, email) {
  const modal = document.getElementById('rm-user-modal');
  const msg   = document.getElementById('rm-user-msg');
  const btn   = document.getElementById('rm-user-confirm');
  if (!modal) return;
  msg.innerHTML = `Excluir permanentemente o registro de<br>
    <strong>${nome}</strong> (${email})?<br>
    <span style="color:#EF4444;font-size:12px;">Esta ação não pode ser desfeita.</span>`;
  modal.style.display = 'flex';
  btn.onclick = async () => {
    modal.style.display = 'none';
    const resultEl = document.getElementById('usuarios-action-result');
    try {
      await _deleteNexosUsuario(itemId);
      if (resultEl) resultEl.innerHTML = `<div style="background:#ECFDF5;border:1px solid #A7F3D0;border-radius:8px;
        padding:10px 16px;font-size:13px;color:#065F46;">🗑️ Registro de <strong>${email}</strong> removido.</div>`;
      renderUserManagementPanel();
    } catch (e) {
      if (resultEl) resultEl.innerHTML = `<div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:8px;
        padding:10px 16px;font-size:13px;color:#B91C1C;">❌ ${e.message}</div>`;
    }
  };
}

/**
 * Mostra modal para adicionar novo usuário
 */
function showAddUserModal_LEGACY_PLACEHOLDER() {
  // reservado — substituído pelo fluxo SP
  return;
}

// --- FIM DO CÓDIGO LEGADO (removido) ---

/**
 * Mostra modal para adicionar novo usuário
 */
function showAddUserModal() {
  const roles = Object.values(window.ROLES || {}).sort((a, b) => b.hierarchy - a.hierarchy);

  const overlay = document.createElement('div');
  overlay.className = 'nexos-overlay';
  overlay.innerHTML = `
    <div class="nexos-modal" style="max-width: 600px;">
      <div class="nexos-modal-header">
        <h3>➕ Adicionar Usuário</h3>
        <button class="nexos-modal-close" data-action="closeModal">✕</button>
      </div>
      <div class="nexos-modal-body">
        <div class="form-group">
          <label>Email do Usuário</label>
          <input 
            type="email" 
            id="newUserEmail" 
            class="form-control" 
            placeholder="usuario@gpa.com.br"
            style="width: 100%;"
          >
        </div>
        <div class="form-group" style="margin-top: 1rem;">
          <label>Cargo</label>
          <select id="newUserRole" class="form-control" style="width: 100%;">
            <option value="">Selecione um cargo...</option>
            ${roles.map(role => `
              <option value="${role.id}" data-role-id="${role.id}">
                ${role.name} - ${role.description}
              </option>
            `).join('')}
          </select>
        </div>
        
        <!-- Info do cargo selecionado -->
        <div id="roleInfoContainer" style="display: none;"></div>
      </div>
      <div class="nexos-modal-footer">
        <button class="btn btn-secondary" data-action="closeModal">
          Cancelar
        </button>
        <button class="btn btn-primary" data-action="saveNewUser">
          ✅ Adicionar
        </button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
  
  // Adicionar listener para mostrar permissões quando selecionar role
  const roleSelect = document.getElementById('newUserRole');
  roleSelect.addEventListener('change', function() {
    updateRoleInfo(this.value, 'roleInfoContainer');
  });
  
  document.getElementById('newUserEmail').focus();
}

/**
 * Salva novo usuário
 */
async function saveNewUser() {
  const email = document.getElementById('newUserEmail').value.trim();
  const roleId = document.getElementById('newUserRole').value;

  if (!email || !email.includes('@')) {
    alert('❌ Por favor, insira um email válido.');
    return;
  }

  if (!roleId) {
    alert('❌ Por favor, selecione um cargo.');
    return;
  }

  const opId = window.globalLoading?.show('add-user');
  
  try {
    await window.userRoleManager.setUserRole(email, roleId);
    
    // Fechar modal
    document.querySelector('.nexos-overlay')?.remove();
    
    // Recarregar painel
    await renderUserManagementPanel();
    
    // Toast de sucesso
    if (window.toastNotifications) {
      window.toastNotifications.success(`${email} foi adicionado com sucesso!`, {
        title: 'Usuário Adicionado'
      });
    }

    // Log
    if (window.logManager) {
      await window.logManager.info('admin', 'user_added', `Usuário ${email} adicionado com role ${roleId}`);
    }
  } catch (error) {
    console.error('[Admin] Erro ao adicionar usuário:', error);
    if (window.toastNotifications) {
      window.toastNotifications.error(error.message, {
        title: 'Erro ao Adicionar Usuário'
      });
    } else {
      alert('❌ Erro ao adicionar usuário: ' + error.message);
    }
  } finally {
    window.globalLoading?.hide(opId);
  }
}

/**
 * Mostra modal para editar usuário
 */
function showEditUserModal(email) {
  const currentRole = window.userRoleManager.getUserRole(email);
  const roles = Object.values(window.ROLES || {}).sort((a, b) => b.hierarchy - a.hierarchy);

  const overlay = document.createElement('div');
  overlay.className = 'nexos-overlay';
  overlay.innerHTML = `
    <div class="nexos-modal" style="max-width: 600px;">
      <div class="nexos-modal-header">
        <h3>✏️ Editar Usuário</h3>
        <button class="nexos-modal-close" data-action="closeModal">✕</button>
      </div>
      <div class="nexos-modal-body">
        <div class="form-group">
          <label>Email</label>
          <input 
            type="text" 
            class="form-control" 
            value="${email}"
            disabled
            style="width: 100%; background: #f5f5f5;"
          >
        </div>
        <div class="form-group" style="margin-top: 1rem;">
          <label>Cargo</label>
          <select id="editUserRole" class="form-control" style="width: 100%;">
            ${roles.map(role => `
              <option 
                value="${role.id}" 
                ${role.id === currentRole ? 'selected' : ''}
                data-role-id="${role.id}"
              >
                ${role.name} - ${role.description}
              </option>
            `).join('')}
          </select>
        </div>
        
        <!-- Info do cargo selecionado -->
        <div id="editRoleInfoContainer"></div>
      </div>
      <div class="nexos-modal-footer">
        <button class="btn btn-secondary" data-action="closeModal">
          Cancelar
        </button>
        <button class="btn btn-primary" data-action="saveEditedUser" data-param="${email}">
          ✅ Salvar
        </button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
  
  // Adicionar listener para mostrar permissões quando selecionar role
  const roleSelect = document.getElementById('editUserRole');
  roleSelect.addEventListener('change', function() {
    updateRoleInfo(this.value, 'editRoleInfoContainer');
  });
  
  // Mostrar info do cargo atual
  updateRoleInfo(currentRole, 'editRoleInfoContainer');
}

/**
 * Salva edição de usuário
 */
async function saveEditedUser(email) {
  const roleId = document.getElementById('editUserRole').value;
  const opId = window.globalLoading?.show('edit-user');

  try {
    await window.userRoleManager.setUserRole(email, roleId);
    
    // Fechar modal
    document.querySelector('.nexos-overlay')?.remove();
    
    // Recarregar painel
    await renderUserManagementPanel();
    
    // Notificar sucesso
    if (window.notificationManager) {
      await window.notificationManager.notifyInfo(
        'Usuário Atualizado',
        `Cargo de ${email} foi alterado.`
      );
    }

    // Log
    if (window.logManager) {
      await window.logManager.info('admin', 'user_updated', `Usuário ${email} alterado para role ${roleId}`);
    }
  } catch (error) {
    console.error('[Admin] Erro ao editar usuário:', error);
    alert('❌ Erro ao editar usuário: ' + error.message);
  } finally {
    window.globalLoading?.hide(opId);
  }
}

/**
 * Remove cargo de usuário
 */
async function removeUserRole(email) {
  if (!confirm(`❌ Tem certeza que deseja remover ${email}?\n\nEle perderá acesso ao painel Admin.`)) {
    return;
  }

  const opId = window.globalLoading?.show('remove-user');

  try {
    await window.userRoleManager.removeUserRole(email);
    
    // Recarregar painel
    await renderUserManagementPanel();
    
    // Notificar sucesso
    if (window.notificationManager) {
      await window.notificationManager.notifyWarning(
        'Usuário Removido',
        `${email} foi removido do sistema.`
      );
    }

    // Log
    if (window.logManager) {
      await window.logManager.info('admin', 'user_removed', `Usuário ${email} removido`);
    }
  } catch (error) {
    console.error('[Admin] Erro ao remover usuário:', error);
    alert('❌ Erro ao remover usuário: ' + error.message);
  } finally {
    window.globalLoading?.hide(opId);
  }
}

/**
 * Mostra modal para atribuir supervisor a um usuário
 */
async function showAssignSupervisorModal(userEmail) {
  if (!window.supervisionManager) {
    alert('❌ SupervisionManager não está disponível');
    return;
  }
  
  const userRole = window.userRoleManager.getUserRole(userEmail);
  const userRoleData = window.ROLES[userRole];
  const currentSupervisor = window.supervisionManager.getSupervisor(userEmail);
  
  // Buscar usuários elegíveis (hierarquia superior)
  const allUsers = window.userRoleManager.listAllUsers();
  const eligibleSupervisors = allUsers.filter(u => {
    if (u.email === userEmail) return false; // Não pode ser supervisor de si mesmo
    return u.roleHierarchy > (userRoleData?.hierarchy || 0);
  });
  
  const overlay = document.createElement('div');
  overlay.className = 'nexos-overlay';
  overlay.innerHTML = `
    <div class="nexos-modal" style="max-width: 600px;">
      <div class="nexos-modal-header">
        <h3>👤 Atribuir Supervisor</h3>
        <button class="nexos-modal-close" data-action="closeModal">✕</button>
      </div>
      <div class="nexos-modal-body">
        <div class="info-box" style="margin-bottom: 1.5rem;">
          <p style="margin: 0;"><strong>Usuário:</strong> ${userEmail}</p>
          <p style="margin: 0.5rem 0 0 0;"><strong>Cargo:</strong> ${userRoleData?.name || 'Não definido'} (Hierarquia ${userRoleData?.hierarchy || 0})</p>
          ${currentSupervisor ? `
            <p style="margin: 0.5rem 0 0 0; color: var(--success);">
              <strong>Supervisor atual:</strong> ${currentSupervisor}
            </p>
          ` : `
            <p style="margin: 0.5rem 0 0 0; color: var(--warning);">
              ⚠️ Nenhum supervisor atribuído
            </p>
          `}
        </div>
        
        ${eligibleSupervisors.length === 0 ? `
          <div class="error-panel">
            <h4 style="margin: 0 0 0.5rem 0;">❌ Nenhum Supervisor Elegível</h4>
            <p style="margin: 0;">
              Não há usuários com hierarquia superior a este usuário.
              Crie usuários com cargos superiores (Encarregado, Gestão, Admin) para atribuí-los como supervisores.
            </p>
          </div>
        ` : `
          <div class="form-group">
            <label>Selecione o Supervisor</label>
            <select id="supervisorSelect" class="form-control" style="width: 100%;">
              <option value="">-- Remover supervisor --</option>
              ${eligibleSupervisors.map(sup => `
                <option 
                  value="${sup.email}"
                  ${sup.email === currentSupervisor ? 'selected' : ''}
                >
                  ${sup.email} - ${sup.roleName} (Hierarquia ${sup.roleHierarchy})
                </option>
              `).join('')}
            </select>
          </div>
          
          <div class="info-box" style="margin-top: 1rem; background: var(--gray-50);">
            <p style="margin: 0; font-size: 0.875rem; color: var(--gray-700);">
              <strong>ℹ️ Sobre Supervisores:</strong><br>
              O supervisor designado pode:<br>
              • Aprovar ações do usuário supervisionado<br>
              • Visualizar histórico de atividades<br>
              • Receber notificações de solicitações
            </p>
          </div>
        `}
      </div>
      <div class="nexos-modal-footer">
        <button class="btn btn-secondary" data-action="closeModal">
          Cancelar
        </button>
        ${eligibleSupervisors.length > 0 ? `
          <button class="btn btn-primary" data-action="saveSupervisor" data-param="${userEmail}">
            ✅ Salvar
          </button>
        ` : ''}
      </div>
    </div>
  `;
  
  document.body.appendChild(overlay);
}

/**
 * Salva atribuição de supervisor
 */
async function saveSupervisor(userEmail) {
  const supervisorEmail = document.getElementById('supervisorSelect')?.value;
  
  if (!window.supervisionManager) {
    alert('❌ SupervisionManager não disponível');
    return;
  }
  
  try {
    if (supervisorEmail) {
      // Atribuir supervisor
      const success = await window.supervisionManager.assignSupervisor(userEmail, supervisorEmail);
      
      if (success) {
        // Fechar modal
        document.querySelector('.nexos-overlay')?.remove();
        
        // Recarregar painel
        await renderUserManagementPanel();
        
        // Notificar sucesso
        if (window.notificationManager) {
          await window.notificationManager.notifySuccess(
            'Supervisor Atribuído',
            `${supervisorEmail} foi designado como supervisor de ${userEmail}`
          );
        }
        
        // Log
        if (window.logManager) {
          await window.logManager.info('admin', 'supervisor_assigned', 
            `Supervisor ${supervisorEmail} atribuído a ${userEmail}`);
        }
      } else {
        alert('❌ Erro ao atribuir supervisor. Verifique a hierarquia.');
      }
    } else {
      // Remover supervisor
      await window.supervisionManager.removeSupervisor(userEmail);
      
      // Fechar modal
      document.querySelector('.nexos-overlay')?.remove();
      
      // Recarregar painel
      await renderUserManagementPanel();
      
      // Notificar
      if (window.notificationManager) {
        await window.notificationManager.notifyInfo(
          'Supervisor Removido',
          `Supervisor de ${userEmail} foi removido`
        );
      }
      
      // Log
      if (window.logManager) {
        await window.logManager.info('admin', 'supervisor_removed', 
          `Supervisor de ${userEmail} removido`);
      }
    }
  } catch (error) {
    console.error('[Admin] Erro ao salvar supervisor:', error);
    alert('❌ Erro ao salvar supervisor: ' + error.message);
  }
}

/**
 * Exporta usuários para JSON
 */
function exportUsersToJSON() {
  if (!window.userRoleManager) return;
  window.userRoleManager.exportUsersToJSON();
}

/**
 * Atualiza a exibição de informações do cargo selecionado
 * @param {string} roleId - ID do cargo
 * @param {string} containerId - ID do container onde exibir
 */
function updateRoleInfo(roleId, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  
  if (!roleId) {
    container.style.display = 'none';
    return;
  }
  
  const role = window.ROLES?.[roleId];
  if (!role) {
    container.style.display = 'none';
    return;
  }
  
  // Obter descrições das permissões
  const permissionDescriptions = {
    view_dashboard: 'Visualizar o dashboard administrativo',
    view_logs: 'Visualizar logs de operações',
    export_logs: 'Exportar logs para análise',
    view_users: 'Visualizar lista de usuários ativos',
    manage_users: 'Gerenciar cargos e permissões de usuários',
    view_statistics: 'Visualizar estatísticas e métricas',
    export_reports: 'Exportar relatórios em múltiplos formatos',
    view_storage: 'Visualizar informações de armazenamento',
    clear_storage: 'Limpar dados de armazenamento',
    view_alerts: 'Visualizar alertas e notificações',
    dismiss_alerts: 'Dispensar alertas',
    view_settings: 'Visualizar configurações do sistema',
    modify_settings: 'Modificar configurações do sistema',
    manage_notifications: 'Gerenciar sistema de notificações',
    access_picking: 'Acessar módulo de Picking',
    access_orkestra: 'Acessar módulo Orkestra',
    access_uber: 'Acessar módulo Uber',
    access_lalamove: 'Acessar módulo Lalamove',
    access_99: 'Acessar módulo 99',
    access_whatsapp: 'Acessar automações WhatsApp',
    auto_fill_forms: 'Preencher formulários automaticamente',
    send_comments: 'Enviar comentários nas plataformas',
    view_maps: 'Visualizar mapas e rotas',
    edit_trees: 'Editar árvores de decisão',
    manage_stores: 'Gerenciar lojas e configurações',
    supervise_users: 'Supervisionar atividades de outros usuários',
    approve_actions: 'Aprovar ações de usuários de nível inferior',
    emergency_override: 'Override de emergência (Admin Master)'
  };
  
  // Construir HTML das permissões
  const permissionsHTML = role.permissions.map(perm => {
    const desc = permissionDescriptions[perm] || perm;
    return `
      <div class="permission-item">
        <span class="permission-item-icon">✓</span>
        <span class="permission-item-name">${desc}</span>
      </div>
    `;
  }).join('');
  
  container.innerHTML = `
    <div class="role-info-box">
      <div class="role-info-header">
        <div class="role-color-badge" style="background-color: ${role.color};"></div>
        <div class="role-info-title">
          <p class="role-info-name">${role.name}</p>
          <p class="role-info-desc">${role.description}</p>
        </div>
        <span class="role-hierarchy">
          Nível ${role.hierarchy}
        </span>
      </div>
      <div style="margin-top: 0.75rem;">
        <strong style="font-size: 0.875rem; color: var(--gray-700); display: block; margin-bottom: 0.5rem;">
          Permissões (${role.permissions.length}):
        </strong>
        <div class="permissions-list">
          ${permissionsHTML}
        </div>
      </div>
    </div>
  `;
  
  container.style.display = 'block';
}

// Exportar para uso global
if (typeof window !== 'undefined') {
  window.UserRoleManager = UserRoleManager;
  window.renderUserManagementPanel = renderUserManagementPanel;
  window._adminAvatarHtml = _adminAvatarHtml;
  window._adminLoadAvatarsWithToken = _adminLoadAvatarsWithToken;
  window._fetchNexosUsuarios = _fetchNexosUsuarios;
  window._usuariosAction = _usuariosAction;
  window._usuariosConfirmRemove = _usuariosConfirmRemove;
  window.showAddUserModal = showAddUserModal;
  window.saveNewUser = saveNewUser;
  window.showEditUserModal = showEditUserModal;
  window.saveEditedUser = saveEditedUser;
  window.removeUserRole = removeUserRole;
  window.showAssignSupervisorModal = showAssignSupervisorModal;
  window.saveSupervisor = saveSupervisor;
  window.exportUsersToJSON = exportUsersToJSON;
  window.updateRoleInfo = updateRoleInfo;

  // ── Listener change: select de Departamento ────────────────────────────
  document.addEventListener('change', async (e) => {
    const sel = e.target.closest('select[data-action="changeDepartamento"]');
    if (!sel) return;

    const email         = sel.dataset.email || '';
    const novoNivel     = sel.value;
    const nivelOriginal = sel.dataset.nivelOriginal || '';
    if (novoNivel === nivelOriginal) return;

    const labelNovo  = novoNivel  || '— Não definido';
    const labelOrig  = nivelOriginal || '— Não definido';

    if (!confirm(`Alterar nível de "${labelOrig}" → "${labelNovo}" para ${email}?`)) {
      sel.value = nivelOriginal;
      return;
    }

    sel.disabled = true;
    const resultEl = document.getElementById('usuarios-action-result');
    try {
      await _updateNexosDepartamento(email, novoNivel);
      sel.dataset.nivelOriginal = novoNivel;
      if (resultEl) resultEl.innerHTML = `
        <div style="background:#ECFDF5;border:1px solid #A7F3D0;border-radius:8px;
          padding:10px 16px;font-size:13px;color:#065F46;margin-top:8px;">
          ✅ Nível de <strong>${email}</strong> atualizado para <strong>${labelNovo}</strong>.
        </div>`;
    } catch (err) {
      console.error('[Admin] Erro ao atualizar Departamento:', err);
      sel.value = nivelOriginal;
      if (resultEl) resultEl.innerHTML = `
        <div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:8px;
          padding:10px 16px;font-size:13px;color:#B91C1C;margin-top:8px;">
          ❌ Erro ao atualizar nível: ${err.message}
        </div>`;
    } finally {
      sel.disabled = false;
    }
  });
}
