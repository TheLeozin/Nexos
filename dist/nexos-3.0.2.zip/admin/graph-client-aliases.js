// ===================================================================
// Graph Client Aliases Setup
// Resolve conflito entre core/auth/graph-client.js e core/sharepoint/graph-client.js
// ===================================================================

/**
 * IMPORTANTE: Este arquivo deve ser carregado ENTRE os dois GraphClients
 * 
 * Ordem de carregamento em admin.html:
 * 1. core/auth/graph-client.js (define window.GraphClient)
 * 2. admin/graph-client-aliases-auth.js (salva como AuthGraphClient)
 * 3. core/sharepoint/graph-client.js (redefine window.GraphClient)
 * 4. admin/graph-client-aliases-final.js (renomeia SharePoint e restaura)
 */

// Este arquivo é carregado DEPOIS de core/auth/graph-client.js
// Salvar GraphClient de autenticação
if (typeof window.GraphClient === 'function') {
  window.AuthGraphClient = window.GraphClient;
  console.log('[Graph Aliases] ✅ AuthGraphClient salvo:', typeof window.AuthGraphClient);
} else {
  console.error('[Graph Aliases] ❌ window.GraphClient não encontrado!');
}
