// ===================================================================
// Graph Client Aliases - Final Setup
// Renomeia SharePoint GraphClient e restaura AuthGraphClient como padrão
// ===================================================================

// Este arquivo é carregado DEPOIS de core/sharepoint/graph-client.js
if (typeof window.GraphClient === 'function') {
  window.SharePointGraphClient = window.GraphClient;
  console.log('[Graph Aliases] ✅ SharePointGraphClient salvo:', typeof window.SharePointGraphClient);
} else {
  console.error('[Graph Aliases] ❌ window.GraphClient não encontrado para SharePoint!');
}

// Restaurar GraphClient de autenticação como padrão
if (typeof window.AuthGraphClient === 'function') {
  window.GraphClient = window.AuthGraphClient;
  console.log('[Graph Aliases] ✅ window.GraphClient restaurado para AuthGraphClient');
} else {
  console.error('[Graph Aliases] ❌ window.AuthGraphClient não encontrado!');
}

// Log final
console.log('[Graph Aliases] 📊 Status final:', {
  AuthGraphClient: typeof window.AuthGraphClient,
  SharePointGraphClient: typeof window.SharePointGraphClient,
  GraphClient: typeof window.GraphClient,
  GraphClientIsAuth: window.GraphClient === window.AuthGraphClient
});
