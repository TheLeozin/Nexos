// ===================================================================
// NEXOS ADMIN - Toast Notifications System
// Sistema de notificações toast para feedback visual não-intrusivo
// ===================================================================

/**
 * Sistema de notificações toast
 * Exibe mensagens elegantes e temporárias no canto da tela
 */
class ToastNotifications {
  constructor() {
    this.container = null;
    this.toasts = [];
    this.maxToasts = 5;
    this.defaultDuration = 4000;
    this.init();
  }

  /**
   * Inicializa o container de toasts
   */
  init() {
    // Criar container se não existir
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'toast-container';
      this.container.className = 'toast-container';
      
      // Garantir que document.body existe antes de appendChild
      if (document.body) {
        document.body.appendChild(this.container);
      } else {
        // Se body não existe ainda, aguardar DOMContentLoaded
        document.addEventListener('DOMContentLoaded', () => {
          if (document.body && !document.body.contains(this.container)) {
            document.body.appendChild(this.container);
          }
        });
      }
    }
  }

  /**
   * Exibe um toast
   * @param {string} message - Mensagem a exibir
   * @param {string} type - Tipo: 'success', 'error', 'warning', 'info'
   * @param {number} duration - Duração em ms (0 = permanente)
   * @param {object} options - Opções adicionais { title, action, icon }
   */
  show(message, type = 'info', duration = null, options = {}) {
    // Garantir que container existe
    if (!this.container || !document.body.contains(this.container)) {
      this.init();
      
      // Se ainda não existe após init, criar e adicionar imediatamente
      if (!this.container || !document.body.contains(this.container)) {
        console.warn('[Toast] Container não disponível, toast não será exibido:', message);
        return null;
      }
    }
    
    // Limitar número de toasts
    if (this.toasts.length >= this.maxToasts) {
      this.dismiss(this.toasts[0].id);
    }

    const toast = this.createToast(message, type, duration || this.defaultDuration, options);
    this.toasts.push(toast);
    this.container.appendChild(toast.element);

    // Animar entrada
    setTimeout(() => {
      toast.element.classList.add('toast-show');
    }, 10);

    // Auto-dismiss se tiver duração
    if (toast.duration > 0) {
      toast.timeout = setTimeout(() => {
        this.dismiss(toast.id);
      }, toast.duration);
    }

    return toast.id;
  }

  /**
   * Cria elemento toast
   */
  createToast(message, type, duration, options) {
    const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    
    const toast = document.createElement('div');
    toast.id = id;
    toast.className = `toast toast-${type}`;
    
    // Ícone
    const icon = options.icon || this.getDefaultIcon(type);
    
    // HTML do toast
    toast.innerHTML = `
      <div class="toast-icon">${icon}</div>
      <div class="toast-content">
        ${options.title ? `<div class="toast-title">${options.title}</div>` : ''}
        <div class="toast-message">${message}</div>
      </div>
      ${options.action ? `
        <button class="toast-action" data-toast-id="${id}">${options.action.label}</button>
      ` : ''}
      <button class="toast-close" data-toast-id="${id}">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
        </svg>
      </button>
    `;

    // Event listeners
    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => this.dismiss(id));

    if (options.action) {
      const actionBtn = toast.querySelector('.toast-action');
      actionBtn.addEventListener('click', () => {
        options.action.onClick();
        this.dismiss(id);
      });
    }

    return {
      id,
      element: toast,
      duration,
      timeout: null,
      type
    };
  }

  /**
   * Remove um toast
   */
  dismiss(id) {
    const toastIndex = this.toasts.findIndex(t => t.id === id);
    if (toastIndex === -1) return;

    const toast = this.toasts[toastIndex];
    
    // Limpar timeout se existir
    if (toast.timeout) {
      clearTimeout(toast.timeout);
    }

    // Animar saída
    toast.element.classList.remove('toast-show');
    toast.element.classList.add('toast-hide');

    // Remover do DOM após animação
    setTimeout(() => {
      if (toast.element.parentNode) {
        toast.element.parentNode.removeChild(toast.element);
      }
      this.toasts.splice(toastIndex, 1);
    }, 300);
  }

  /**
   * Remove todos os toasts
   */
  dismissAll() {
    const toastIds = this.toasts.map(t => t.id);
    toastIds.forEach(id => this.dismiss(id));
  }

  /**
   * Atalhos para tipos comuns
   */
  success(message, options = {}) {
    return this.show(message, 'success', null, options);
  }

  error(message, options = {}) {
    return this.show(message, 'error', 6000, options); // Erros ficam mais tempo
  }

  warning(message, options = {}) {
    return this.show(message, 'warning', null, options);
  }

  info(message, options = {}) {
    return this.show(message, 'info', null, options);
  }

  /**
   * Toast de carregamento (permanente até dismissar)
   */
  loading(message, options = {}) {
    return this.show(message, 'info', 0, {
      ...options,
      icon: '<div class="spinner-small"></div>'
    });
  }

  /**
   * Ícones padrão por tipo
   */
  getDefaultIcon(type) {
    const icons = {
      success: '✅',
      error: '❌',
      warning: '⚠️',
      info: 'ℹ️'
    };
    return icons[type] || icons.info;
  }
}

// Exportar para uso global
if (typeof window !== 'undefined') {
  window.ToastNotifications = ToastNotifications;
  
  // Criar instância global se não existir
  if (!window.toastNotifications) {
    window.toastNotifications = new ToastNotifications();
  }
}
