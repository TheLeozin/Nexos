/**
 * Controller para página de teste: Login SharePoint
 * Movido de inline para arquivo externo (CSP compliance)
 */

const statusDiv = document.getElementById('status');
const consoleOutput = document.getElementById('consoleOutput');
const btnRunTest = document.getElementById('btnRunTest');
const btnClearConsole = document.getElementById('btnClearConsole');

// Capturar logs do console
const originalConsole = {
  log: console.log,
  warn: console.warn,
  error: console.error,
  info: console.info
};

let logs = [];

function captureConsole() {
  ['log', 'warn', 'error', 'info'].forEach(method => {
    console[method] = function(...args) {
      originalConsole[method].apply(console, args);

      const message = args.map(arg => {
        if (typeof arg === 'object') {
          try {
            return JSON.stringify(arg, null, 2);
          } catch (e) {
            return String(arg);
          }
        }
        return String(arg);
      }).join(' ');

      logs.push({ method, message, timestamp: new Date().toLocaleTimeString() });
      updateConsoleOutput();
    };
  });
}

function updateConsoleOutput() {
  const html = logs.map(log => {
    let color = '#d4d4d4';
    let prefix = '';
    
    if (log.method === 'warn') {
      color = '#ffa500';
      prefix = '⚠️ ';
    } else if (log.method === 'error') {
      color = '#f44336';
      prefix = '❌ ';
    } else if (log.message.includes('✅')) {
      color = '#4caf50';
    } else if (log.message.includes('━━━')) {
      color = '#00bcd4';
    }

    return `<div style="color: ${color}; margin-bottom: 4px;">
      <span style="color: #888;">[${log.timestamp}]</span> ${prefix}${escapeHtml(log.message)}
    </div>`;
  }).join('');

  consoleOutput.innerHTML = html || 'Nenhum log ainda...';
  consoleOutput.scrollTop = consoleOutput.scrollHeight;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

btnRunTest.addEventListener('click', async () => {
  btnRunTest.disabled = true;
  statusDiv.style.display = 'block';
  statusDiv.className = 'status loading';
  statusDiv.textContent = '⏳ Executando teste...';

  logs = [];
  consoleOutput.innerHTML = '';
  
  // Marcar que o teste está rodando (para auto-continuar após redirect)
  sessionStorage.setItem('nexos-test-running', 'true');

  try {
    // Carregar e executar o script de teste (VERSÃO CHROME IDENTITY)
    const script = document.createElement('script');
    script.src = '../tests/test-login-chrome-identity.js';
    script.onload = () => {
      statusDiv.className = 'status success';
      statusDiv.textContent = '✅ Teste concluído! Verifique os logs abaixo.';
      // Limpar flag de teste rodando
      sessionStorage.removeItem('nexos-test-running');
    };
    script.onerror = () => {
      statusDiv.className = 'status error';
      statusDiv.textContent = '❌ Erro ao carregar script de teste';
      btnRunTest.disabled = false;
      sessionStorage.removeItem('nexos-test-running');
    };
    document.body.appendChild(script);

  } catch (error) {
    statusDiv.className = 'status error';
    statusDiv.textContent = `❌ Erro: ${error.message}`;
    console.error('Erro ao executar teste:', error);
    sessionStorage.removeItem('nexos-test-running');
  } finally {
    setTimeout(() => {
      btnRunTest.disabled = false;
    }, 5000);
  }
});

btnClearConsole.addEventListener('click', () => {
  logs = [];
  consoleOutput.innerHTML = 'Console limpo. Execute o teste novamente.';
});

// Inicializar captura de console
captureConsole();

console.log('✅ Página carregada dentro da extensão');
console.log('📍 Redirect URI (Chrome Identity):', chrome?.identity?.getRedirectURL?.() || 'Carregando...');
console.log('💡 Clique em "Executar Teste Completo" para começar.');
console.log('');
console.log('🔧 Versão do teste: Chrome Identity API (launchWebAuthFlow)');
console.log('   Este método é oficial e recomendado para extensões Chrome');

