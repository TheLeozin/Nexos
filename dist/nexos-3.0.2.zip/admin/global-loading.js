// ===================================================================
// NEXOS ADMIN - Global Loading Indicator
// Barra de progresso global para operações assíncronas
// ===================================================================

/**
 * Indicador de carregamento global
 * Exibe uma barra de progresso no topo da tela durante operações assíncronas
 */
class GlobalLoadingIndicator {
  constructor() {
    this.container = null;
    this.activeOperations = 0;
    this.progressBar = null;
    this.isVisible = false;
    this.animationFrame = null;
    this.progress = 0;
    this.init();
  }

  /**
   * Inicializa o indicador
   */
  init() {
    // Criar container se não existir
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'global-loading-indicator';
      this.container.className = 'global-loading-indicator';
      this.container.style.display = 'none';
      
      // Barra de progresso
      this.progressBar = document.createElement('div');
      this.progressBar.className = 'global-loading-bar';
      this.container.appendChild(this.progressBar);
      
      // Adicionar ao body quando disponível
      if (document.body) {
        document.body.appendChild(this.container);
      } else {
        document.addEventListener('DOMContentLoaded', () => {
          if (document.body && !document.body.contains(this.container)) {
            document.body.appendChild(this.container);
          }
        });
      }
    }
  }

  /**
   * Mostra o indicador
   * @param {string} operationId - ID único da operação (opcional)
   * @returns {string} ID da operação
   */
  show(operationId = null) {
    const id = operationId || 'op-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    
    this.activeOperations++;
    
    if (!this.isVisible) {
      this.isVisible = true;
      this.progress = 0;
      
      // Garantir que container existe
      if (!this.container || !document.body.contains(this.container)) {
        this.init();
      }
      
      // Mostrar container
      if (this.container) {
        this.container.style.display = 'block';
        
        // Resetar barra
        if (this.progressBar) {
          this.progressBar.style.width = '0%';
          this.progressBar.style.transition = 'none';
        }
        
        // Iniciar animação de progresso
        setTimeout(() => {
          this.startProgressAnimation();
        }, 10);
      }
    }
    
    return id;
  }

  /**
   * Oculta o indicador
   * @param {string} operationId - ID da operação (opcional)
   */
  hide(operationId = null) {
    this.activeOperations = Math.max(0, this.activeOperations - 1);
    
    // Só ocultar quando todas as operações terminarem
    if (this.activeOperations === 0 && this.isVisible) {
      this.isVisible = false;
      
      // Completar a barra rapidamente
      if (this.progressBar) {
        this.progressBar.style.transition = 'width 0.2s ease-out';
        this.progressBar.style.width = '100%';
      }
      
      // Parar animação
      if (this.animationFrame) {
        cancelAnimationFrame(this.animationFrame);
        this.animationFrame = null;
      }
      
      // Ocultar após completar
      setTimeout(() => {
        if (this.activeOperations === 0 && this.container) {
          this.container.style.display = 'none';
          this.progress = 0;
          if (this.progressBar) {
            this.progressBar.style.width = '0%';
          }
        }
      }, 300);
    }
  }

  /**
   * Anima o progresso da barra
   */
  startProgressAnimation() {
    if (!this.isVisible || !this.progressBar) return;
    
    // Progresso suave até 90% (nunca completa sozinho)
    const targetProgress = 90;
    const speed = 0.5; // Velocidade de incremento
    
    const animate = () => {
      if (!this.isVisible) {
        return;
      }
      
      if (this.progress < targetProgress) {
        // Aumentar progresso com desaceleração
        const remaining = targetProgress - this.progress;
        this.progress += remaining * 0.02;
        
        if (this.progressBar) {
          this.progressBar.style.transition = 'width 0.2s ease-out';
          this.progressBar.style.width = this.progress + '%';
        }
        
        this.animationFrame = requestAnimationFrame(animate);
      }
    };
    
    this.animationFrame = requestAnimationFrame(animate);
  }

  /**
   * Reseta o indicador (força ocultar)
   */
  reset() {
    this.activeOperations = 0;
    this.isVisible = false;
    this.progress = 0;
    
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame);
      this.animationFrame = null;
    }
    
    if (this.container) {
      this.container.style.display = 'none';
    }
    
    if (this.progressBar) {
      this.progressBar.style.width = '0%';
    }
  }

  /**
   * Wrapper para operações assíncronas
   * Mostra o indicador durante a operação e oculta ao finalizar
   * @param {Function} asyncFunction - Função assíncrona a executar
   * @param {string} operationId - ID da operação (opcional)
   * @returns {Promise} Resultado da função
   */
  async wrap(asyncFunction, operationId = null) {
    const id = this.show(operationId);
    
    try {
      const result = await asyncFunction();
      return result;
    } finally {
      this.hide(id);
    }
  }
}

// Exportar para uso global
if (typeof window !== 'undefined') {
  window.GlobalLoadingIndicator = GlobalLoadingIndicator;
  
  // Criar instância global se não existir
  if (!window.globalLoading) {
    window.globalLoading = new GlobalLoadingIndicator();
  }
}
