// ===================================================================
// NEXOS ADMIN DASHBOARD - PANELS (PART 2)
// Painéis: Statistics, Storage, Alerts, Settings
// ===================================================================

// ===================================================================
// PAINEL: ESTATÍSTICAS
// ===================================================================

async function renderStatisticsPanel() {
  const loadingId = window.globalLoading?.show('statistics-panel');
  
  const stats7d = await window.logManager.getStatistics(7);
  const stats30d = await window.logManager.getStatistics(30);
  
  const html = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Operações (7 dias)</div>
        <div class="stat-value">${stats7d.total.toLocaleString('pt-BR')}</div>
      </div>
      
      <div class="stat-card success">
        <div class="stat-label">Operações (30 dias)</div>
        <div class="stat-value">${stats30d.total.toLocaleString('pt-BR')}</div>
      </div>
      
      <div class="stat-card warning">
        <div class="stat-label">Taxa de Erro (7d)</div>
        <div class="stat-value">${stats7d.errorRate}%</div>
      </div>
      
      <div class="stat-card">
        <div class="stat-label">Tempo Médio</div>
        <div class="stat-value">${stats7d.avgDuration}ms</div>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Distribuição por Nível (7 dias)</div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Nível</th>
              <th>Quantidade</th>
              <th>Percentual</th>
            </tr>
          </thead>
          <tbody>
            ${Object.entries(stats7d.byLevel).map(([level, count]) => `
              <tr>
                <td><span class="badge badge-${getLevelBadge(level)}">${level}</span></td>
                <td>${count.toLocaleString('pt-BR')}</td>
                <td>${((count / stats7d.total) * 100).toFixed(1)}%</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Top 10 Ações Mais Executadas</div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Ação</th>
              <th>Quantidade</th>
              <th>Percentual</th>
            </tr>
          </thead>
          <tbody>
            ${stats7d.topActions.map(({ action, count }) => `
              <tr>
                <td>${formatAction(action)}</td>
                <td>${count.toLocaleString('pt-BR')}</td>
                <td>${((count / stats7d.total) * 100).toFixed(1)}%</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Distribuição por Módulo</div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Módulo</th>
              <th>Quantidade</th>
              <th>Percentual</th>
            </tr>
          </thead>
          <tbody>
            ${Object.entries(stats7d.byModule).map(([module, count]) => `
              <tr>
                <td><span class="badge badge-info">${module}</span></td>
                <td>${count.toLocaleString('pt-BR')}</td>
                <td>${((count / stats7d.total) * 100).toFixed(1)}%</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Distribuição por Plataforma</div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Plataforma</th>
              <th>Quantidade</th>
              <th>Percentual do Total</th>
            </tr>
          </thead>
          <tbody>
            ${Object.keys(stats7d.byPlatform).length > 0 
              ? Object.entries(stats7d.byPlatform).map(([platform, count]) => `
                <tr>
                  <td><span class="badge badge-success">${platform}</span></td>
                  <td>${count.toLocaleString('pt-BR')}</td>
                  <td>${((count / stats7d.total) * 100).toFixed(1)}%</td>
                </tr>
              `).join('')
              : '<tr><td colspan="3" class="empty-state">Nenhum dado de plataforma disponível</td></tr>'
            }
          </tbody>
        </table>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Horários de Pico (24h)</div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Hora</th>
              <th>Operações</th>
              <th>Gráfico</th>
            </tr>
          </thead>
          <tbody>
            ${stats7d.byHour.map((count, hour) => {
              const max = Math.max(...stats7d.byHour);
              const width = max > 0 ? (count / max) * 100 : 0;
              return `
                <tr>
                  <td>${hour.toString().padStart(2, '0')}:00</td>
                  <td>${count}</td>
                  <td>
                    <div style="background: var(--gray-200); height: 20px; border-radius: 4px; overflow: hidden;">
                      <div style="background: var(--primary); height: 100%; width: ${width}%; transition: width 0.3s;"></div>
                    </div>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
  
  document.getElementById('content-area').innerHTML = html;
  window.globalLoading?.hide(loadingId);
  updateConnectionStatus(true);
}

// ===================================================================
// PAINEL: STORAGE & SYNC
// ===================================================================

async function renderStoragePanel() {
  const loadingId = window.globalLoading?.show('storage-panel');
  
  // Obter uso do storage
  const bytesInUse = await chrome.storage.local.getBytesInUse();
  const quota = chrome.storage.local.QUOTA_BYTES || 10485760; // 10MB padrão
  const usagePercent = ((bytesInUse / quota) * 100).toFixed(2);
  
  // Obter todas as chaves
  const allData = await chrome.storage.local.get(null);
  const keys = Object.keys(allData);
  
  // Calcular tamanho por chave
  const keysSizes = keys.map(key => {
    const size = new Blob([JSON.stringify(allData[key])]).size;
    return { key, size };
  }).sort((a, b) => b.size - a.size);
  
  // Verificar status do StorageAdapter
  const adapterStatus = typeof storageAdapter !== 'undefined' ? 'Disponível' : 'Não carregado';
  
  const html = `
    <div class="stats-grid">
      <div class="stat-card ${usagePercent > 80 ? 'error' : usagePercent > 50 ? 'warning' : 'success'}">
        <div class="stat-label">Uso do Storage</div>
        <div class="stat-value">${usagePercent}%</div>
        <div class="stat-change">${formatBytes(bytesInUse)} / ${formatBytes(quota)}</div>
      </div>
      
      <div class="stat-card">
        <div class="stat-label">Total de Chaves</div>
        <div class="stat-value">${keys.length}</div>
        <div class="stat-change">Armazenadas localmente</div>
      </div>
      
      <div class="stat-card">
        <div class="stat-label">Maior Item</div>
        <div class="stat-value">${formatBytes(keysSizes[0]?.size || 0)}</div>
        <div class="stat-change">${keysSizes[0]?.key || 'N/A'}</div>
      </div>
      
      <div class="stat-card info">
        <div class="stat-label">StorageAdapter</div>
        <div class="stat-value" style="font-size: 1.5rem;">📦</div>
        <div class="stat-change">${adapterStatus}</div>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">Ações de Manutenção</div>
          <div class="card-subtitle">Operações de limpeza e backup</div>
        </div>
      </div>
      <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
        <button class="btn-primary" data-action="forceSync">
          🔄 Forçar Sync SharePoint
        </button>
        <button class="btn-secondary" data-action="cleanOldLogs">
          🗑️ Limpar Logs Antigos (>30d)
        </button>
        <button class="btn-success" data-action="backupData">
          💾 Backup Completo (JSON)
        </button>
        <button class="btn-secondary" data-action="clearCache">
          ⚠️ Limpar Cache Local
        </button>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Top 20 Maiores Itens</div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Chave</th>
              <th>Tamanho</th>
              <th>% do Total</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            ${keysSizes.slice(0, 20).map(({ key, size }) => `
              <tr>
                <td style="font-family: monospace; max-width: 300px; overflow: hidden; text-overflow: ellipsis;">${key}</td>
                <td>${formatBytes(size)}</td>
                <td>${((size / bytesInUse) * 100).toFixed(2)}%</td>
                <td>
                  <button class="btn-secondary" data-action="viewStorageValue" data-param="${key}">Ver</button>
                  <button class="btn-secondary" data-action="deleteStorageKey" data-param="${key}">Deletar</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Status do SharePoint Sync</div>
      </div>
      <div style="padding: 1rem; background: var(--gray-50); border-radius: var(--border-radius);">
        <p><strong>Backend:</strong> chrome-only (SharePoint desabilitado temporariamente)</p>
        <p><strong>Para habilitar:</strong> Descomentar código no background.js e configurar OAuth</p>
        <p style="margin-top: 1rem; color: var(--gray-600); font-size: 0.875rem;">
          ℹ️ O sync com SharePoint está preparado mas desabilitado até a configuração completa do Azure AD OAuth2
        </p>
      </div>
    </div>
  `;
  
  document.getElementById('content-area').innerHTML = html;
  window.globalLoading?.hide(loadingId);
  updateConnectionStatus(true);
}

window.forceSync = async function() {
  alert('Sync manual não disponível - backend chrome-only ativo.\n\nPara habilitar SharePoint sync, configure OAuth no background.js.');
  await window.logManager.info('admin', 'sync_attempt', 'Admin tentou forçar sync (não disponível)');
};

window.cleanOldLogs = async function() {
  if (!confirm('Remover logs com mais de 30 dias?')) return;
  
  const removed = await window.logManager.cleanOldLogs(30);
  alert(`${removed} logs removidos com sucesso!`);
  await window.logManager.info('admin', 'logs_cleanup', `Admin removeu ${removed} logs antigos`);
  window.loadPanel('storage');
};

window.backupData = async function() {
  const allData = await chrome.storage.local.get(null);
  const json = JSON.stringify(allData, null, 2);
  
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `nexos-backup-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
  
  await window.logManager.info('admin', 'backup_export', 'Admin exportou backup completo');
};

window.clearCache = async function() {
  if (!confirm('ATENÇÃO: Isso irá limpar TODOS os dados locais!\n\nDeseja continuar?')) return;
  
  await chrome.storage.local.clear();
  alert('Cache limpo! A página será recarregada.');
  await window.logManager.info('admin', 'cache_clear', 'Admin limpou todo o cache local');
  window.location.reload();
};

window.viewStorageValue = async function(key) {
  const data = await chrome.storage.local.get([key]);
  const json = JSON.stringify(data[key], null, 2);
  
  const width = Math.min(800, window.innerWidth - 100);
  const height = Math.min(600, window.innerHeight - 100);
  
  const win = window.open('', '_blank', `width=${width},height=${height}`);
  win.document.write(`
    <html>
      <head>
        <title>Storage: ${key}</title>
        <style>
          body { font-family: monospace; padding: 20px; background: #1e1e1e; color: #d4d4d4; }
          pre { white-space: pre-wrap; word-wrap: break-word; }
        </style>
      </head>
      <body>
        <h2>${key}</h2>
        <pre>${json}</pre>
      </body>
    </html>
  `);
};

window.deleteStorageKey = async function(key) {
  if (!confirm(`Deletar chave "${key}"?`)) return;
  
  await chrome.storage.local.remove([key]);
  alert('Chave deletada!');
  await window.logManager.info('admin', 'storage_key_delete', `Admin deletou chave: ${key}`);
  window.loadPanel('storage');
};

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// ===================================================================
// PAINEL: ALERTAS
// ===================================================================

async function renderAlertsPanel() {
  const loadingId = window.globalLoading?.show('alerts-panel');
  
  const alertsData = await chrome.storage.local.get(['__nexos_alerts']);
  const alerts = alertsData.__nexos_alerts || [];
  const unreadAlerts = alerts.filter(a => !a.read);
  
  // Atualizar badge
  document.getElementById('alerts-badge').textContent = unreadAlerts.length;
  
  const html = `
    <div class="stats-grid">
      <div class="stat-card error">
        <div class="stat-label">Alertas Não Lidos</div>
        <div class="stat-value">${unreadAlerts.length}</div>
      </div>
      
      <div class="stat-card">
        <div class="stat-label">Total de Alertas</div>
        <div class="stat-value">${alerts.length}</div>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">Alertas Recentes</div>
          <div class="card-subtitle">Últimos 50 alertas gerados</div>
        </div>
        <button class="btn-primary" data-action="markAllAlertsRead">
          ✓ Marcar Todos como Lidos
        </button>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Status</th>
              <th>Timestamp</th>
              <th>Tipo</th>
              <th>Mensagem</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            ${alerts.length === 0 
              ? '<tr><td colspan="5" class="empty-state"><div class="empty-state-icon">🔔</div><p>Nenhum alerta</p></td></tr>'
              : alerts.reverse().map(alert => `
                <tr style="background: ${alert.read ? 'transparent' : 'rgba(239, 68, 68, 0.05)'};">
                  <td>
                    ${alert.read 
                      ? '<span style="color: var(--gray-400);">✓</span>' 
                      : '<span style="color: var(--error);">●</span>'
                    }
                  </td>
                  <td style="white-space: nowrap;">${formatTimestamp(alert.timestamp)}</td>
                  <td><span class="badge badge-${alert.type === 'error' ? 'error' : 'warning'}">${alert.type.toUpperCase()}</span></td>
                  <td>${alert.message}</td>
                  <td>
                    ${!alert.read ? `<button class="btn-secondary" data-action="markAlertRead" data-param="${alert.id}">Marcar Lido</button>` : ''}
                    <button class="btn-secondary" data-action="viewAlertDetails" data-param="${alert.id}">Detalhes</button>
                  </td>
                </tr>
              `).join('')
            }
          </tbody>
        </table>
      </div>
    </div>
  `;
  
  document.getElementById('content-area').innerHTML = html;
  window.globalLoading?.hide(loadingId);
  updateConnectionStatus(true);
}

window.markAllAlertsRead = async function() {
  const alertsData = await chrome.storage.local.get(['__nexos_alerts']);
  const alerts = alertsData.__nexos_alerts || [];
  
  const alert = alerts.find(a => a.id === alertId);
  if (alert) {
    alert.read = true;
    await chrome.storage.local.set({ __nexos_alerts: alerts });
    await window.logManager.info('admin', 'alert_read', `Admin marcou alerta como lido: ${alertId}`);
    renderAlertsPanel();
  }
};

window.markAllAlertsRead = async function() {
  const alertsData = await chrome.storage.local.get(['__nexos_alerts']);
  const alerts = alertsData.__nexos_alerts || [];
  
  alerts.forEach(a => a.read = true);
  await chrome.storage.local.set({ __nexos_alerts: alerts });
  
  // Limpar badge
  if (chrome.action) {
    chrome.action.setBadgeText({ text: '' });
  }
  
  await window.logManager.info('admin', 'alerts_mark_all_read', 'Admin marcou todos os alertas como lidos');
  renderAlertsPanel();
};

window.viewAlertDetails = async function(alertId) {
  const alertsData = await chrome.storage.local.get(['__nexos_alerts']);
  const alerts = alertsData.__nexos_alerts || [];
  const alert = alerts.find(a => a.id === alertId);
  
  if (alert && alert.source) {
    alert(`Detalhes do Alerta:\n\n${JSON.stringify(alert.source, null, 2)}`);
  }
};

// ===================================================================
// PAINEL: CONFIGURAÇÕES
// ===================================================================

async function renderSettingsPanel() {
  const config = await chrome.storage.local.get(['__nexos_admin_config']) || {};
  const adminConfig = config.__nexos_admin_config || {
    debugMode: false,
    autoRefresh: true,
    refreshInterval: 10,
    sharepointSync: false,
    syncInterval: 60,
    authorizedAdmins: ADMIN_USERS
  };
  
  const html = `
    <div class="card">
      <div class="card-header">
        <div class="card-title">Configurações Gerais</div>
      </div>
      <form id="settings-form">
        <div class="form-group">
          <label>
            <input type="checkbox" id="debug-mode" ${adminConfig.debugMode ? 'checked' : ''}>
            Modo Debug (logs verbosos no console)
          </label>
        </div>
        
        <div class="form-group">
          <label>
            <input type="checkbox" id="auto-refresh" ${adminConfig.autoRefresh ? 'checked' : ''}>
            Auto-refresh do dashboard
          </label>
        </div>
        
        <div class="form-group">
          <label>Intervalo de Refresh (segundos)</label>
          <input type="number" id="refresh-interval" value="${adminConfig.refreshInterval || 10}" min="5" max="60">
        </div>
        
        <button type="submit" class="btn-primary">Salvar Configurações</button>
      </form>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">SharePoint Sync</div>
      </div>
      <div class="form-group">
        <label>
          <input type="checkbox" id="sharepoint-sync" ${adminConfig.sharepointSync ? 'checked' : ''} disabled>
          Habilitar sincronização com SharePoint (em desenvolvimento)
        </label>
      </div>
      <div class="form-group">
        <label>Intervalo de Sync (segundos)</label>
        <input type="number" id="sync-interval" value="${adminConfig.syncInterval || 60}" min="30" max="300" disabled>
      </div>
      <p style="color: var(--gray-600); font-size: 0.875rem; margin-top: 1rem;">
        ℹ️ A sincronização com SharePoint requer configuração adicional do OAuth2 no Azure AD
      </p>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Administradores Autorizados</div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Email</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody id="admins-tbody">
            ${adminConfig.authorizedAdmins.map(email => `
              <tr>
                <td>${email}</td>
                <td>
                  <button class="btn-secondary" data-action="removeAdmin" data-param="${email}">Remover</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
      <div style="margin-top: 1rem;">
        <input type="email" id="new-admin-email" placeholder="email@gpa.com.br" style="padding: 0.5rem; border: 1px solid var(--border-color); border-radius: var(--border-radius); margin-right: 0.5rem;">
        <button class="btn-primary" data-action="addAdmin">Adicionar Admin</button>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Informações do Sistema</div>
      </div>
      <table>
        <tr>
          <td><strong>Versão da Extensão:</strong></td>
          <td>${chrome.runtime.getManifest().version}</td>
        </tr>
        <tr>
          <td><strong>ID da Extensão:</strong></td>
          <td style="font-family: monospace;">${chrome.runtime.id}</td>
        </tr>
        <tr>
          <td><strong>Navegador:</strong></td>
          <td>${navigator.userAgent}</td>
        </tr>
        <tr>
          <td><strong>Admin Logado:</strong></td>
          <td>${currentUser}</td>
        </tr>
      </table>
    </div>
  `;
  
  document.getElementById('content-area').innerHTML = html;
  
  // Event listener para form
  const settingsForm = document.getElementById('settings-form');
  if (settingsForm) {
    settingsForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const debugModeEl = document.getElementById('debug-mode');
      const autoRefreshEl = document.getElementById('auto-refresh');
      const refreshIntervalEl = document.getElementById('refresh-interval');
      
      const newConfig = {
        ...adminConfig,
        debugMode: debugModeEl ? debugModeEl.checked : adminConfig.debugMode,
        autoRefresh: autoRefreshEl ? autoRefreshEl.checked : adminConfig.autoRefresh,
        refreshInterval: refreshIntervalEl ? parseInt(refreshIntervalEl.value) || 10 : adminConfig.refreshInterval
      };
      
      await chrome.storage.local.set({ __nexos_admin_config: newConfig });
      
      // Reiniciar timer de auto-refresh com novas configurações
      if (typeof window.startRefreshTimer === 'function') {
        await window.startRefreshTimer();
        console.log('[Admin] Timer de auto-refresh reiniciado com novas configurações');
      }
      
      alert('Configurações salvas! Auto-refresh ' + (newConfig.autoRefresh ? `habilitado (${newConfig.refreshInterval}s)` : 'desabilitado'));
      await window.logManager.info('admin', 'settings_update', 'Admin atualizou configurações');
    });
  } else {
    console.warn('[Admin] settings-form não encontrado');
  }
  
  updateConnectionStatus(true);
}

window.addAdmin = async function() {
  const email = document.getElementById('new-admin-email').value.trim();
  
  if (!email || !email.includes('@')) {
    alert('Email inválido');
    return;
  }
  
  const config = await chrome.storage.local.get(['__nexos_admin_config']);
  const adminConfig = config.__nexos_admin_config || { authorizedAdmins: ADMIN_USERS };
  
  if (adminConfig.authorizedAdmins.includes(email)) {
    alert('Este email já é um admin');
    return;
  }
  
  adminConfig.authorizedAdmins.push(email);
  ADMIN_USERS.push(email);
  
  await chrome.storage.local.set({ __nexos_admin_config: adminConfig });
  await window.logManager.info('admin', 'admin_added', `Admin ${email} adicionado por ${currentUser}`);
  
  renderSettingsPanel();
};

window.removeAdmin = async function(email) {
  if (email === currentUser) {
    alert('Você não pode remover a si mesmo!');
    return;
  }
  
  if (!confirm(`Remover ${email} dos administradores?`)) return;
  
  const config = await chrome.storage.local.get(['__nexos_admin_config']);
  const adminConfig = config.__nexos_admin_config || { authorizedAdmins: ADMIN_USERS };
  
  adminConfig.authorizedAdmins = adminConfig.authorizedAdmins.filter(e => e !== email);
  const index = ADMIN_USERS.indexOf(email);
  if (index > -1) ADMIN_USERS.splice(index, 1);
  
  await chrome.storage.local.set({ __nexos_admin_config: adminConfig });
  await window.logManager.info('admin', 'admin_removed', `Admin ${email} removido por ${currentUser}`);
  
  renderSettingsPanel();
};

// ===================================================================
// PAINEL: TESTAR EXTRAÇÃO
// ===================================================================

async function renderExtractionTestingPanel() {
  const loadingId = window.globalLoading?.show('extraction-testing-panel');
  
  const html = `
    <div class="card">
      <div class="card-header">
        <div class="card-title">🔍 Testar Extração de Dados</div>
      </div>
      <div class="card-body">
        <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">
          Teste a extração de campos em tempo real. Selecione um campo abaixo e clique em "Testar".
        </p>
        
        <div class="form-group" style="margin-bottom: 1rem;">
          <label for="extraction-field-select">Campo para Testar:</label>
          <select id="extraction-field-select">
            <option value="">-- Selecione um campo --</option>
            <option value="nome_cliente">👤 Nome do Cliente</option>
            <option value="telefone">📱 Telefone</option>
            <option value="endereco">📍 Endereço</option>
            <option value="numero">#️⃣ Número</option>
            <option value="bairro">🏘️ Bairro</option>
            <option value="cidade">🏙️ Cidade</option>
            <option value="uf">🗺️ UF</option>
            <option value="valor">💰 Valor</option>
            <option value="status">🏁 Status</option>
          </select>
        </div>
        
        <div style="display: flex; gap: 0.5rem; margin-bottom: 1.5rem;">
          <button id="btn-test-field" class="btn-primary" style="flex: 1;">
            🚀 Testar Campo
          </button>
          <button id="btn-test-all-fields" class="btn-secondary" style="flex: 1;">
            ⚡ Testar Todos
          </button>
        </div>
        
        <div id="extraction-result" style="display: none; margin-top: 1.5rem;">
          <div class="alert" id="extraction-alert">
            <!-- Resultado será inserido aqui -->
          </div>
        </div>
      </div>
    </div>
    
    <div class="card" style="margin-top: 1.5rem;">
      <div class="card-header">
        <div class="card-title">📊 Histórico de Testes</div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>Campo</th>
              <th>Status</th>
              <th>Confiança</th>
              <th>Valor Extraído</th>
            </tr>
          </thead>
          <tbody id="extraction-history-tbody">
            <tr>
              <td colspan="5" style="text-align: center; color: var(--text-secondary);">
                Nenhum teste realizado ainda
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `;
  
  const contentArea = document.getElementById('content-area');
  contentArea.innerHTML = html;
  
  // Setup de eventos
  const btnTestField = document.getElementById('btn-test-field');
  const btnTestAll = document.getElementById('btn-test-all-fields');
  const fieldSelect = document.getElementById('extraction-field-select');
  
  btnTestField.addEventListener('click', async () => {
    const field = fieldSelect.value;
    if (!field) {
      window.toast?.show('Selecione um campo para testar', 'warning');
      return;
    }
    
    const loadId = window.globalLoading?.show('extraction-test');
    try {
      // Simular teste de extração
      const result = await testExtractionField(field);
      showExtractionResult(result);
      
      // Adicionar ao histórico
      addExtractionHistoryEntry({
        timestamp: new Date().toLocaleString('pt-BR'),
        field,
        status: result.success ? '✅ Sucesso' : '❌ Falha',
        confidence: result.confidence ? (result.confidence * 100).toFixed(1) + '%' : 'N/A',
        value: result.value || '-'
      });
      
      // Log
      await window.logManager?.info('extraction', 'field_tested', \`Campo \${field} testado\`);
    } catch (e) {
      window.toast?.show(\`Erro ao testar: \${e.message}\`, 'error');
    } finally {
      window.globalLoading?.hide(loadId);
    }
  });
  
  btnTestAll.addEventListener('click', async () => {
    const loadId = window.globalLoading?.show('extraction-test-all');
    try {
      const fields = ['nome_cliente', 'telefone', 'endereco', 'numero', 'bairro', 'cidade', 'uf', 'valor', 'status'];
      let successCount = 0;
      
      for (const field of fields) {
        try {
          const result = await testExtractionField(field);
          if (result.success) successCount++;
          
          addExtractionHistoryEntry({
            timestamp: new Date().toLocaleString('pt-BR'),
            field,
            status: result.success ? '✅ Sucesso' : '❌ Falha',
            confidence: result.confidence ? (result.confidence * 100).toFixed(1) + '%' : 'N/A',
            value: result.value || '-'
          });
        } catch (e) {
          console.error(\`Erro ao testar \${field}:\`, e);
        }
      }
      
      window.toast?.show(\`Teste completo! \${successCount}/\${fields.length} campos extraídos com sucesso\`, 'success');
      await window.logManager?.info('extraction', 'all_fields_tested', \`Todos os campos testados: \${successCount}/\${fields.length} sucessos\`);
    } catch (e) {
      window.toast?.show(\`Erro ao testar campos: \${e.message}\`, 'error');
    } finally {
      window.globalLoading?.hide(loadId);
    }
  });
  
  window.globalLoading?.hide(loadingId);
}

// Helper: Testar extração de um campo
async function testExtractionField(fieldName) {
  // Chamar a função de extração do sistema
  if (typeof window.extractPickingDataResilient === 'function') {
    try {
      const result = await window.extractPickingDataResilient();
      const value = result[fieldName];
      const confidence = result._extraction_metadata?.averageConfidence || 0.5;
      
      return {
        success: !!value,
        value: value ? value.toString().substring(0, 50) : null,
        confidence,
        metadata: result._extraction_metadata
      };
    } catch (e) {
      return {
        success: false,
        value: null,
        confidence: 0,
        error: e.message
      };
    }
  }
  
  // Fallback: simular teste
  return {
    success: Math.random() > 0.3,
    value: \`Valor Teste (\${fieldName})\`,
    confidence: 0.85,
    metadata: {}
  };
}

// Helper: Mostrar resultado do teste
function showExtractionResult(result) {
  const resultDiv = document.getElementById('extraction-result');
  const alertDiv = document.getElementById('extraction-alert');
  
  if (result.success) {
    alertDiv.className = 'alert alert-success';
    alertDiv.innerHTML = \`
      <div style="display: flex; align-items: center; gap: 0.5rem;">
        <span>✅</span>
        <div>
          <strong>Sucesso!</strong><br>
          Valor: <code>\${result.value}</code><br>
          Confiança: \${(result.confidence * 100).toFixed(1)}%
        </div>
      </div>
    \`;
  } else {
    alertDiv.className = 'alert alert-error';
    alertDiv.innerHTML = \`
      <div style="display: flex; align-items: center; gap: 0.5rem;">
        <span>❌</span>
        <div>
          <strong>Falha na Extração</strong><br>
          Campo não foi extraído. Verifique as estratégias.
        </div>
      </div>
    \`;
  }
  
  resultDiv.style.display = 'block';
}

// Helper: Adicionar entrada ao histórico
function addExtractionHistoryEntry(entry) {
  const tbody = document.getElementById('extraction-history-tbody');
  
  // Se primeira linha for "nenhum teste", remover
  if (tbody.rows.length === 1 && tbody.rows[0].cells.length === 5 && 
      tbody.rows[0].cells[0].textContent.includes('Nenhum')) {
    tbody.innerHTML = '';
  }
  
  const row = document.createElement('tr');
  row.innerHTML = \`
    <td>\${entry.timestamp}</td>
    <td>\${entry.field}</td>
    <td>\${entry.status}</td>
    <td>\${entry.confidence}</td>
    <td>\${entry.value}</td>
  \`;
  
  tbody.insertBefore(row, tbody.firstChild);
  
  // Manter apenas últimas 20 entradas
  while (tbody.rows.length > 20) {
    tbody.removeChild(tbody.lastChild);
  }
}

// Export para admin.js
if (typeof window !== 'undefined') {
  window.renderStatisticsPanel = renderStatisticsPanel;
  window.renderStoragePanel = renderStoragePanel;
  window.renderAlertsPanel = renderAlertsPanel;
  window.renderSettingsPanel = renderSettingsPanel;
  window.renderExtractionTestingPanel = renderExtractionTestingPanel;
}
