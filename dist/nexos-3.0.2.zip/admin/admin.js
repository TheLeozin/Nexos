// ===================================================================
// NEXOS ADMIN DASHBOARD - MAIN SCRIPT
// ===================================================================

// Configuração
const ADMIN_USERS = [
  'leonardo.miguel@gpa.com.br',
  'admin@gpa.com.br',
  // 🔓 MODO DEBUG: Aceitar qualquer email (remover em produção)
  '*' // Wildcard que aceita qualquer usuário
];

const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutos
const REFRESH_INTERVAL = 10 * 1000; // 10 segundos

// Estado global
let currentUser = null;
let currentPanel = 'overview';
let refreshTimer = null;
let sessionTimer = null;

// Painéis que devem ser acessíveis apenas por administradores
const ADMIN_ONLY_PANELS = [
  'user-management',
  'approvals',
  'approval-history',
  'settings'
];

// Estado dos painéis (paginação, filtros)
let logsCurrentPage = 1;
let logsFilters = {
  level: '',
  module: '',
  search: ''
};

// Managers globais disponibilizados para admin-panels.js
window.logManager = null;
window.permissionManager = null;
window.notificationManager = null;
window.reportExporter = null;
window.liveDashboard = null;
window.userRoleManager = null;
window.supervisionManager = null;

// ===================================================================
// MANAGERS INITIALIZATION
// ===================================================================

/**
 * Verifica se roles.js foi carregado (agora via <script> no HTML)
 * @returns {boolean}
 */
function isRolesLoaded() {
  const isLoaded = window.ROLES && window.PERMISSIONS && Object.keys(window.ROLES).length > 0;
  if (!isLoaded) {
    console.error('[Admin] ❌ ROLES não foi carregado! Verifique se roles.js está no HTML');
  }
  return isLoaded;
}

async function initLogManager() {
  console.log('[Admin][InitLM] 1. Iniciando initLogManager...');
  
  if (window.logManager) {
    console.log('[Admin][InitLM] 2. LogManager já existe, retornando instância');
    return window.logManager;
  }
  
  try {
    console.log('[Admin][InitLM] 3. Verificando se window.LogManager existe...');
    console.log('[Admin][InitLM] 4. window.LogManager =', typeof window.LogManager);
    
    // Verificar se o script já foi carregado
    if (!window.LogManager) {
      console.log('[Admin][InitLM] 5. LogManager não carregado, carregando script...');
      
      const scriptUrl = chrome.runtime.getURL('core/logging/log-manager.js');
      console.log('[Admin][InitLM] 6. URL do script:', scriptUrl);
      
      // Carregar o script do LogManager apenas se não estiver carregado
      await new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = scriptUrl;
        script.onerror = (err) => {
          console.error('[Admin][InitLM] 7. ERRO ao carregar script:', err);
          reject(new Error('Falha ao carregar log-manager.js: ' + err.message));
        };
        script.onload = () => {
          console.log('[Admin][InitLM] 8. Script carregado! Aguardando 100ms...');
          // Aguardar para garantir que window.LogManager foi atribuído
          setTimeout(() => {
            console.log('[Admin][InitLM] 9. Verificando window.LogManager após timeout...');
            console.log('[Admin][InitLM] 10. window.LogManager =', typeof window.LogManager);
            
            if (window.LogManager) {
              console.log('[Admin][InitLM] 11. ✅ window.LogManager existe!');
              resolve();
            } else {
              console.error('[Admin][InitLM] 12. ❌ window.LogManager não existe!');
              console.error('[Admin][InitLM] 13. window keys com "Log":', Object.keys(window).filter(k => k.includes('Log')));
              reject(new Error('LogManager não foi exportado para window'));
            }
          }, 100);
        };
        document.head.appendChild(script);
        console.log('[Admin][InitLM] 14. Script tag adicionado ao DOM');
      });
    } else {
      console.log('[Admin][InitLM] 15. LogManager já estava carregado');
    }
    
    // Verificar se LogManager está disponível
    console.log('[Admin][InitLM] 16. Verificando tipo de window.LogManager...');
    if (typeof window.LogManager !== 'function') {
      throw new Error('LogManager não está disponível como função, tipo: ' + typeof window.LogManager);
    }
    
    // Instanciar e inicializar (disponibilizar globalmente)
    console.log('[Admin][InitLM] 17. Criando nova instância...');
    window.logManager = new window.LogManager();
    console.log('[Admin][InitLM] 18. Instância criada!');
    
    console.log('[Admin][InitLM] 19. Chamando initialize()...');
    await window.logManager.initialize();
    console.log('[Admin][InitLM] 20. Initialize() concluído!');
    
    console.log('[Admin] ✅ LogManager inicializado com sucesso');
    return window.logManager;
    
  } catch (err) {
    console.error('[Admin][InitLM] 21. ❌ ERRO CAPTURADO:', err);
    console.error('[Admin][InitLM] 22. Error message:', err.message);
    console.error('[Admin][InitLM] 23. Error stack:', err.stack);
    
    // Fallback: mock para não quebrar o dashboard
    console.warn('[Admin][InitLM] 24. Criando fallback mock...');
    window.logManager = {
      initialize: async () => { console.log('[FALLBACK] initialize()'); },
      log: async (...args) => console.log('[FALLBACK] log:', ...args),
      info: async (...args) => console.log('[FALLBACK] info:', ...args),
      warn: async (...args) => console.warn('[FALLBACK] warn:', ...args),
      error: async (...args) => console.error('[FALLBACK] error:', ...args),
      setCurrentUser: async () => { console.log('[FALLBACK] setCurrentUser()'); },
      clearCurrentUser: async () => { console.log('[FALLBACK] clearCurrentUser()'); },
      getStatistics: async () => {
        console.log('[FALLBACK] getStatistics()');
        return { total: 0, errorRate: 0, avgResponseTime: 0 };
      },
      getActiveSessions: async () => {
        console.log('[FALLBACK] getActiveSessions()');
        return [];
      },
      searchLogs: async () => {
        console.log('[FALLBACK] searchLogs()');
        return { logs: [], total: 0 };
      },
      getAlerts: async () => {
        console.log('[FALLBACK] getAlerts()');
        return [];
      },
      cleanOldLogs: async () => {
        console.log('[FALLBACK] cleanOldLogs()');
        return 0;
      }
    };
    
    console.warn('[Admin][InitLM] 25. Fallback mock criado, dashboard funcionará em modo limitado');
    return window.logManager;
  }
}

/**
 * Inicializa o PermissionManager
 */
async function initPermissionManager() {
  console.log('[Admin] Iniciando PermissionManager...');
  
  if (window.permissionManager) {
    return window.permissionManager;
  }
  
  try {
    // Verificar se ROLES foi carregado (via <script> no HTML)
    if (!isRolesLoaded()) {
      throw new Error('ROLES não foi carregado via HTML');
    }
    
    if (typeof window.PermissionManager !== 'function') {
      throw new Error('PermissionManager não foi exportado');
    }
    
    window.permissionManager = new window.PermissionManager();
    await window.permissionManager.initialize();
    
    console.log('[Admin] ✅ PermissionManager inicializado');
    return window.permissionManager;
  } catch (error) {
    console.error('[Admin] ❌ Erro ao inicializar PermissionManager:', error);
    // Mock básico
    window.permissionManager = {
      hasPermission: () => true,
      getCurrentRole: () => ({ name: 'Mock', permissions: [] }),
      showAccessDenied: (action) => alert(`Acesso negado: ${action}`)
    };
    return window.permissionManager;
  }
}

/**
 * Inicializa o NotificationManager
 */
async function initNotificationManager() {
  console.log('[Admin] Iniciando NotificationManager...');
  
  if (window.notificationManager) {
    return window.notificationManager;
  }
  
  try {
    await loadScript('core/notifications/notification-manager.js');
    
    if (typeof window.NotificationManager !== 'function') {
      throw new Error('NotificationManager não foi exportado');
    }
    
    window.notificationManager = new window.NotificationManager();
    await window.notificationManager.initialize(window.permissionManager, window.logManager);
    
    console.log('[Admin] ✅ NotificationManager inicializado');
    return window.notificationManager;
  } catch (error) {
    console.error('[Admin] ❌ Erro ao inicializar NotificationManager:', error);
    // Mock básico
    window.notificationManager = {
      notify: async () => console.log('[MOCK] notify'),
      notifyCriticalError: async () => console.log('[MOCK] notifyCriticalError')
    };
    return window.notificationManager;
  }
}

/**
 * Inicializa o ReportExporter
 */
async function initReportExporter() {
  console.log('[Admin] Iniciando ReportExporter...');
  
  if (window.reportExporter) {
    return window.reportExporter;
  }
  
  try {
    await loadScript('core/reports/report-exporter.js');
    
    if (typeof window.ReportExporter !== 'function') {
      throw new Error('ReportExporter não foi exportado');
    }
    
    window.reportExporter = new window.ReportExporter();
    await window.reportExporter.initialize(window.logManager, window.permissionManager);
    
    console.log('[Admin] ✅ ReportExporter inicializado');
    return window.reportExporter;
  } catch (error) {
    console.error('[Admin] ❌ Erro ao inicializar ReportExporter:', error);
    // Mock básico
    window.reportExporter = {
      exportLogsToCSV: async () => alert('Exportador não disponível'),
      exportLogsToJSON: async () => alert('Exportador não disponível')
    };
    return window.reportExporter;
  }
}

/**
 * Inicializa o LiveDashboard
 */
async function initLiveDashboard() {
  console.log('[Admin] Iniciando LiveDashboard...');
  
  if (window.liveDashboard) {
    return window.liveDashboard;
  }
  
  try {
    await loadScript('core/realtime/live-dashboard.js');
    
    if (typeof window.LiveDashboard !== 'function') {
      throw new Error('LiveDashboard não foi exportado');
    }
    
    window.liveDashboard = new window.LiveDashboard();
    
    // Carregar configuração de refresh
    const config = await chrome.storage.local.get('__nexos_admin_config');
    const adminConfig = config.__nexos_admin_config || { autoRefresh: true, refreshInterval: 10 };
    const refreshRate = adminConfig.refreshInterval * 1000; // Converter para ms
    
    await window.liveDashboard.initialize(window.logManager, refreshRate);
    
    console.log('[Admin] ✅ LiveDashboard inicializado com refresh rate:', refreshRate, 'ms');
    return window.liveDashboard;
  } catch (error) {
    console.error('[Admin] ❌ Erro ao inicializar LiveDashboard:', error);
    // Mock básico
    window.liveDashboard = {
      start: () => console.log('[MOCK] liveDashboard.start'),
      stop: () => console.log('[MOCK] liveDashboard.stop')
    };
    return window.liveDashboard;
  }
}

/**
 * Inicializa o UserRoleManager
 */
async function initUserRoleManager() {
  console.log('[Admin] Iniciando UserRoleManager...');
  
  if (window.userRoleManager) {
    return window.userRoleManager;
  }
  
  try {
    // Verificar se ROLES foi carregado (via <script> no HTML)
    if (!isRolesLoaded()) {
      throw new Error('ROLES não foi carregado via HTML');
    }
    
    await loadScript('admin/user-role-manager.js');
    
    if (typeof window.UserRoleManager !== 'function') {
      throw new Error('UserRoleManager não foi exportado');
    }
    
    window.userRoleManager = new window.UserRoleManager();
    await window.userRoleManager.init();
    
    console.log('[Admin] ✅ UserRoleManager inicializado');
    return window.userRoleManager;
  } catch (error) {
    console.error('[Admin] ❌ Erro ao inicializar UserRoleManager:', error);
    // Mock básico
    window.userRoleManager = {
      getUserRole: () => null,
      setUserRole: async () => false
    };
    return window.userRoleManager;
  }
}

/**
 * Inicializa o SupervisionManager
 */
async function initSupervisionManager() {
  console.log('[Admin] Iniciando SupervisionManager...');
  
  if (window.supervisionManager) {
    return window.supervisionManager;
  }
  
  try {
    await loadScript('core/supervision/supervision-manager.js');
    
    if (typeof window.SupervisionManager !== 'function') {
      throw new Error('SupervisionManager não foi exportado');
    }
    
    window.supervisionManager = new window.SupervisionManager();
    await window.supervisionManager.init();
    
    // Limpar solicitações expiradas
    await window.supervisionManager.cleanupExpiredRequests();
    
    console.log('[Admin] ✅ SupervisionManager inicializado');
    return window.supervisionManager;
  } catch (error) {
    console.error('[Admin] ❌ Erro ao inicializar SupervisionManager:', error);
    // Mock básico
    window.supervisionManager = {
      requiresApproval: () => false,
      requestApproval: async () => null,
      getPendingRequests: () => []
    };
    return window.supervisionManager;
  }
}

/**
 * Helper para carregar scripts dinamicamente
 */
async function loadScript(scriptPath) {
  return new Promise((resolve, reject) => {
    const scriptUrl = chrome.runtime.getURL(scriptPath);
    const script = document.createElement('script');
    script.src = scriptUrl;
    script.onerror = () => reject(new Error(`Falha ao carregar ${scriptPath}`));
    script.onload = () => {
      console.log(`[Admin] ✅ Script carregado: ${scriptPath}`);
      // Aguardar 50ms para garantir que exports foram atribuídos
      setTimeout(resolve, 50);
    };
    document.head.appendChild(script);
  });
}

// ===================================================================
// FUNÇÕES UTILITÁRIAS
// ===================================================================

// ===================================================================
// THEME MANAGEMENT
// ===================================================================

const THEME_STORAGE_KEY = '__nexos_theme';

/**
 * Inicializa tema (dark/light mode) e adiciona listeners
 */
async function initializeTheme() {
  // Carregar preferência salva
  const stored = await chrome.storage.local.get([THEME_STORAGE_KEY]);
  const savedTheme = stored[THEME_STORAGE_KEY] || 'light';
  
  console.log('[Admin] Tema salvo:', savedTheme);
  
  // Aplicar tema
  applyTheme(savedTheme);
  
  // Adicionar listener no botão de toggle
  const toggleBtn = document.getElementById('theme-toggle-btn');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', toggleTheme);
  }
}

/**
 * Aplica tema (adiciona/remove classe dark-mode no body)
 */
function applyTheme(theme) {
  const body = document.body;
  const icon = document.getElementById('theme-icon');
  const label = document.querySelector('.theme-label');
  
  if (theme === 'dark') {
    body.classList.add('dark-mode');
    if (icon) icon.textContent = '☀️';
    if (label) label.textContent = 'Modo Claro';
  } else {
    body.classList.remove('dark-mode');
    if (icon) icon.textContent = '🌙';
    if (label) label.textContent = 'Modo Escuro';
  }
  
  console.log('[Admin] Tema aplicado:', theme);
}

/**
 * Alterna entre dark e light mode
 */
async function toggleTheme() {
  const body = document.body;
  const isDark = body.classList.contains('dark-mode');
  const newTheme = isDark ? 'light' : 'dark';
  
  // Aplicar novo tema
  applyTheme(newTheme);
  
  // Salvar preferência
  await chrome.storage.local.set({ [THEME_STORAGE_KEY]: newTheme });
  
  console.log('[Admin] Tema alterado para:', newTheme);
  
  // Toast de feedback
  if (window.toastNotifications) {
    window.toastNotifications.success(
      `Tema ${newTheme === 'dark' ? 'escuro' : 'claro'} ativado`,
      { title: newTheme === 'dark' ? '🌙 Modo Escuro' : '☀️ Modo Claro', duration: 2000 }
    );
  }
}

// ===================================================================
// UTILITY FUNCTIONS
// ===================================================================

/**
 * Debounce - executa função após delay sem novas chamadas
 * @param {Function} func - Função a ser debounced
 * @param {number} delay - Delay em ms (padrão: 300ms)
 * @returns {Function}
 */
function debounce(func, delay = 300) {
  let timeoutId;
  return function(...args) {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func.apply(this, args), delay);
  };
}

/**
 * Highligh texto de busca em conteúdo
 * @param {string} text - Texto original
 * @param {string} search - Termo de busca
 * @returns {string} - HTML com <mark> nos matches
 */
function highlightText(text, search) {
  if (!search || !text) return text;
  
  const escapedSearch = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(${escapedSearch})`, 'gi');
  return text.replace(regex, '<mark>$1</mark>');
}

function formatTimestamp(timestamp) {
  return new Date(timestamp).toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}

function formatElapsed(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return days + 'd ' + (hours % 24) + 'h';
  if (hours > 0) return hours + 'h ' + (minutes % 60) + 'm';
  if (minutes > 0) return minutes + 'm ' + (seconds % 60) + 's';
  return seconds + 's';
}

function formatAction(action) {
  return action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
}

function getLevelBadge(level) {
  const map = {
    INFO: 'info',
    WARN: 'warning',
    ERROR: 'error',
    DEBUG: 'info'
  };
  return map[level] || 'info';
}

function updateConnectionStatus(online) {
  const dot = document.getElementById('status-dot');
  const text = document.getElementById('connection-text');
  
  if (online) {
    dot.className = 'status-dot online';
    text.textContent = 'Online';
  } else {
    dot.className = 'status-dot offline';
    text.textContent = 'Offline';
  }
}

/**
 * Atualiza o badge de usuários pendentes no menu lateral
 */
async function updatePendingUsersBadge() {
  try {
    const badge = document.getElementById('pending-users-badge');
    if (!badge) return;

    let count = 0;
    if (window.userRoleManager) {
      // garantir dados atualizados
      await window.userRoleManager.loadPendingUsers();
      count = window.userRoleManager.getPendingCount();
    } else {
      const data = await chrome.storage.local.get(['__nexos_pending_users']);
      const arr = data.__nexos_pending_users || [];
      count = arr.length;
    }

    if (count > 0) {
      badge.textContent = count;
      badge.style.display = 'inline-block';
    } else {
      badge.style.display = 'none';
    }
  } catch (err) {
    console.warn('[Admin] Erro ao atualizar pending-users-badge:', err);
  }
}

// ===================================================================
// INICIALIZAÇÃO
// ===================================================================

document.addEventListener('DOMContentLoaded', async () => {
  console.log('[Admin] ═══════════════════════════════════════════════════');
  console.log('[Admin] Inicializando dashboard...');
  console.log('[Admin] URL:', window.location.href);
  console.log('[Admin] ═══════════════════════════════════════════════════');
  
  try {
    // PASSO 1: Inicializar LogManager ANTES de qualquer coisa
    console.log('[Admin] PASSO 1: Inicializando LogManager...');
    await initLogManager();
    console.log('[Admin] PASSO 1: ✅ LogManager inicializado');
    
    // Carregar versão
    console.log('[Admin] PASSO 2: Carregando versão...');
    const manifest = chrome.runtime.getManifest();
    console.log('[Admin] PASSO 2: Versão =', manifest.version);
    document.querySelectorAll('#version-footer, #version-sidebar').forEach(el => {
      el.textContent = manifest.version;
    });
    console.log('[Admin] PASSO 2: ✅ Versão atualizada na UI');
    
    // Inicializar tema (dark/light mode)
    console.log('[Admin] PASSO 2.5: Inicializando tema...');
    await initializeTheme();
    console.log('[Admin] PASSO 2.5: ✅ Tema inicializado');
    
    // Verificar sessão existente
    console.log('[Admin] PASSO 3: Verificando sessão...');
    
    // ⚠️ AUTO-LOGIN DESABILITADO - sempre exigir login manual
    // Motivo: Problemas com listeners não anexados após reload da extensão
    const AUTO_LOGIN_ENABLED = false;
    
    if (AUTO_LOGIN_ENABLED) {
      const session = await chrome.storage.local.get(['__nexos_admin_session']);
      if (session.__nexos_admin_session) {
        const { user, timestamp } = session.__nexos_admin_session;
        const elapsed = Date.now() - timestamp;
        console.log('[Admin] PASSO 3: Sessão encontrada, elapsed =', elapsed);
        
        if (elapsed < SESSION_TIMEOUT) {
          // Sessão válida
          console.log('[Admin] PASSO 3: Sessão válida, fazendo login automático...');
          await login(user, true);
          return;
        } else {
          console.log('[Admin] PASSO 3: Sessão expirada');
        }
      } else {
        console.log('[Admin] PASSO 3: Nenhuma sessão encontrada');
      }
    } else {
      console.log('[Admin] PASSO 3: Auto-login desabilitado, exigindo login manual');
      // Limpar sessão antiga se existir
      await chrome.storage.local.remove(['__nexos_admin_session']);
    }
    
    // Mostrar tela de login
    console.log('[Admin] PASSO 4: Mostrando tela de login');
    showLoginScreen();
    console.log('[Admin] ═══════════════════════════════════════════════════');
    console.log('[Admin] ✅ Inicialização concluída com sucesso!');
    console.log('[Admin] ═══════════════════════════════════════════════════');
    
  } catch (err) {
    console.error('[Admin] ═══════════════════════════════════════════════════');
    console.error('[Admin] ❌ ERRO FATAL na inicialização:');
    console.error('[Admin] Error:', err);
    console.error('[Admin] Message:', err.message);
    console.error('[Admin] Stack:', err.stack);
    console.error('[Admin] ═══════════════════════════════════════════════════');
    
    // Tentar mostrar tela de login mesmo com erro
    try {
      showLoginScreen();
    } catch (e2) {
      console.error('[Admin] Não foi possível nem mostrar login:', e2);
    }
  }
  
  // ===================================================================
  // AUTENTICAÇÃO
  // ===================================================================
  
  // Variáveis globais para Microsoft Auth
  let msalAuth = null;
  let graphClient = null;
  let isTestMode = false;
  
  // Inicializar MSAL (tentar real, fallback para mock se falhar)
  async function initMicrosoftAuth() {
    try {
      // Tentar usar chrome.identity + OAuthClient quando disponível (mais confiável em extensões)
      if (typeof chrome !== 'undefined' && chrome.identity && chrome.identity.launchWebAuthFlow) {
        try {
          console.log('[Admin] ℹ️ chrome.identity.detectado - usando ExtensionOAuthAdapter (chrome.identity.launchWebAuthFlow)');

          // Garantir que os scripts necessários foram carregados
          if (typeof OAuthClient === 'undefined') {
            await loadScript('core/auth/oauth-client.js');
          }

          if (typeof ExtensionOAuthAdapter === 'undefined') {
            await loadScript('core/auth/extension-oauth-adapter.js');
          }

          // Instanciar adapter que delega ao OAuthClient
          msalAuth = new window.ExtensionOAuthAdapter(AZURE_AD_CONFIG);
          await msalAuth.init();
          window.msalAuth = msalAuth; // Expor globalmente para user-role-manager e outros módulos
          graphClient = new window.AuthGraphClient(msalAuth);
          
          // Inicializar SharePoint GraphClient se disponível
          if (typeof window.SharePointGraphClient !== 'undefined') {
            window.graphClient = new window.SharePointGraphClient({ authHelper: msalAuth });
            console.log('[Admin] ✅ SharePoint GraphClient inicializado');
          }
          
          console.log('[Admin] ✅ Microsoft Auth inicializado via chrome.identity (ExtensionOAuthAdapter)');
          isTestMode = false;
          return true;
        } catch (err) {
          console.warn('[Admin] ⚠️ Falha ao inicializar via chrome.identity:', err);
          // se falhar, seguir para tentativa com MsalAuth abaixo
        }
      }

      // Tentar configuração real com MsalAuth (fallback)
      if (typeof MsalAuth !== 'undefined' && typeof AZURE_AD_CONFIG !== 'undefined') {
        const configValid = validateAzureAdConfig(AZURE_AD_CONFIG);
        if (configValid.valid) {
          msalAuth = new MsalAuth(AZURE_AD_CONFIG);
          await msalAuth.init();
          graphClient = new window.AuthGraphClient(msalAuth);
          
          // Inicializar SharePoint GraphClient se disponível
          if (typeof window.SharePointGraphClient !== 'undefined') {
            window.graphClient = new window.SharePointGraphClient({ authHelper: msalAuth });
            console.log('[Admin] ✅ SharePoint GraphClient inicializado');
          }
          
          console.log('[Admin] ✅ Microsoft Auth inicializado (modo real - MsalAuth)');
          isTestMode = false;
          return true;
        }
      }
      
      // Fallback para mock
      console.warn('[Admin] ⚠️ Azure AD não configurado, usando modo de teste');
      return false;
    } catch (error) {
      console.error('[Admin] ❌ Erro ao inicializar MSAL:', error);
      return false;
    }
  }
  
  // Botão: Entrar com Microsoft (OAuth real)
  document.getElementById('btn-microsoft-login')?.addEventListener('click', async () => {
    try {
      const btn = document.getElementById('btn-microsoft-login');
      btn.disabled = true;
      btn.textContent = 'Conectando...';
      
      // Toast de loading
      let loadingToast = null;
      if (window.toastNotifications) {
        loadingToast = window.toastNotifications.loading('Aguardando autenticação Microsoft...', {
          title: 'Conectando'
        });
      }
      
      // Helper para resetar botão e dismiss loading
      const resetButton = () => {
        btn.disabled = false;
        btn.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 23 23" style="margin-right: 8px; vertical-align: middle;">
            <rect x="1" y="1" width="10" height="10" fill="#f25022"/>
            <rect x="12" y="1" width="10" height="10" fill="#00a4ef"/>
            <rect x="1" y="12" width="10" height="10" fill="#7fba00"/>
            <rect x="12" y="12" width="10" height="10" fill="#ffb900"/>
          </svg>
          Entrar com Microsoft
        `;
        
        // Dismiss loading toast
        if (loadingToast && window.toastNotifications) {
          window.toastNotifications.dismiss(loadingToast);
        }
      };
      
      // Inicializar se necessário
      if (!msalAuth) {
        const initialized = await initMicrosoftAuth();
        if (!initialized) {
          showLoginError('Azure AD não configurado. Use o modo de teste ou configure o Azure AD app registration.');
          resetButton();
          return;
        }
      }
      
      // Login com popup
      const result = await msalAuth.loginPopup();

      if (!result.success) {
        const errorMsg = result.error?.message || 'Erro ao fazer login';
        
        // Detectar se popup foi bloqueado ou usuário cancelou
        if (errorMsg.includes('Popup bloqueado') || errorMsg.includes('popup_window_error') || errorMsg.includes('user_cancelled') || errorMsg.includes('did not approve')) {
          
          if (window.toastNotifications) {
            window.toastNotifications.warning(
              'O navegador bloqueou o popup ou você cancelou a autenticação. Tente novamente e permita popups se necessário.',
              {
                title: 'Autenticação Cancelada',
                action: {
                  label: 'Tentar Novamente',
                  onClick: () => {
                    document.getElementById('btn-microsoft-login')?.click();
                  }
                }
              }
            );
          }
          
          showLoginError(
            '🚫 Popup Bloqueado ou Cancelado\n\n' +
            'O navegador bloqueou o popup de login da Microsoft ou você cancelou.\n\n' +
            'Para corrigir:\n' +
            '1. Clique no ícone 🚫 na barra de endereço\n' +
            '2. Selecione "Sempre permitir popups"\n' +
            '3. Tente fazer login novamente\n\n' +
            'Ou vá em Configurações → Privacidade → Pop-ups e adicione esta extensão.'
          );
        } else {
          if (window.toastNotifications) {
            window.toastNotifications.error(errorMsg, {
              title: 'Erro de Autenticação'
            });
          }
          showLoginError(errorMsg);
        }
        
        resetButton();
        return;
      }
      
      // Buscar perfil completo
      const profile = await graphClient.getUserFullProfile();

      // Fazer login com dados do Microsoft 365
      const loginResult = await loginWithMicrosoft365(profile);

      // Se entrou no fluxo de PENDENTE, resetar estado para permitir nova tentativa
      if (loginResult && loginResult.status === 'pending') {
        // Resetar msalAuth para não reusar o mock/adaptador do teste
        msalAuth = null;
        graphClient = null;
        isTestMode = false;

        // Resetar botão para estado original
        resetButton();
        return;
      }
      
    } catch (error) {
      console.error('[Admin] ❌ Erro no login Microsoft:', error);
      showLoginError(error.message || 'Erro ao fazer login com Microsoft');
      
      // Resetar botão em caso de erro
      resetButton();
      
      // Limpar estado em caso de erro
      msalAuth = null;
      graphClient = null;
      isTestMode = false;
    }
  });
  
  // Botão: Testar Sistema (Mock)
  document.getElementById('btn-test-auth')?.addEventListener('click', async () => {
    try {
      console.log('[Admin] 🧪 Iniciando modo de teste...');
      
      // Usar mocks
      if (typeof MockMsalAuth === 'undefined' || typeof MockGraphClient === 'undefined') {
        showLoginError('Erro: Arquivos de teste não carregados');
        return;
      }
      
      const btn = document.getElementById('btn-test-auth');
      btn.disabled = true;
      btn.textContent = 'Carregando usuários...';

      msalAuth = new MockMsalAuth();
      await msalAuth.init();

      graphClient = new MockGraphClient(msalAuth);
      isTestMode = true;

      // Login com mock (abre seletor de usuários)
      const result = await msalAuth.loginPopup();

      if (!result.success) {
        btn.disabled = false;
        btn.textContent = '🧪 Testar Sistema (Modo Debug)';
        // limpar estado de teste
        msalAuth = null;
        graphClient = null;
        isTestMode = false;
        return;
      }

      // Buscar perfil completo
      const profile = await graphClient.getUserFullProfile();

      // Fazer login com dados simulados
      const loginResult = await loginWithMicrosoft365(profile, true);

      // Se entrou no fluxo de PENDENTE, resetar estado para permitir nova tentativa
      if (loginResult && loginResult.status === 'pending') {
        btn.disabled = false;
        btn.textContent = '🧪 Testar Sistema (Modo Debug)';
        msalAuth = null;
        graphClient = null;
        isTestMode = false;
        return;
      }
      
    } catch (error) {
      console.error('[Admin] ❌ Erro no modo de teste:', error);
      showLoginError(error.message || 'Erro no modo de teste');
      
      const btn = document.getElementById('btn-test-auth');
      btn.disabled = false;
      btn.textContent = '🧪 Testar Sistema (Modo Debug)';
    }
  });
  
  // Botão: Toggle Modo Legado
  document.getElementById('btn-toggle-legacy')?.addEventListener('click', () => {
    const container = document.getElementById('legacy-mode-container');
    const btn = document.getElementById('btn-toggle-legacy');
    
    if (container.style.display === 'none') {
      container.style.display = 'block';
      btn.textContent = 'Ocultar modo legado';
    } else {
      container.style.display = 'none';
      btn.textContent = 'Modo desenvolvedor (legado)';
    }
  });
  
  // Login com Microsoft 365 (real ou mock)
  async function loginWithMicrosoft365(profile, isTest = false) {
    const email = profile.profile.email;
    const displayName = profile.profile.displayName;
    const photo = profile.photo;
    const roleData = profile.role;
    
    console.log('[Admin] 📧 Email:', email);
    console.log('[Admin] 👤 Nome:', displayName);
    console.log('[Admin] 🎭 Role:', roleData.roleName);
    console.log('[Admin] 🧪 Modo teste:', isTest);
    
    // Validar se o usuário está cadastrado
    try {
      if (!window.userRoleManager) {
        await loadScript('admin/user-role-manager.js');
        window.userRoleManager = new window.UserRoleManager();
        await window.userRoleManager.init();
      }
      
      let userRole = window.userRoleManager.getUserRole(email);
      
      // Se não estiver cadastrado, cadastrar como PENDENTE
      if (!userRole) {
        console.log('[Admin] ⚠️ Usuário novo detectado:', email);
        console.log('[Admin] 🔒 Usuário precisa de aprovação do Admin Master');
        
        // Cadastrar como "pendente" (sem role)
        await window.userRoleManager.addPendingUser({
          email: email,
          name: displayName,
          department: roleData.groups?.[0] || 'Não informado',
          requestedAt: Date.now(),
          microsoft365: true,
          // Incluir foto de perfil (se disponível) e role sugerido a partir do Azure
          photo: photo || null,
          suggestedRole: roleData?.roleName || null
        });
        
        console.log('[Admin] 📝 Usuário adicionado à lista de aprovações pendentes');
  // Atualizar badge lateral
  try { await updatePendingUsersBadge(); } catch (e) { console.warn('[Admin] Falha ao atualizar badge após addPendingUser:', e); }
        
        // Notificar Admin Master via toast (sendToAdminMasters será implementado futuramente)
        if (window.toastNotifications) {
          window.toastNotifications.info(
            `${displayName} (${email}) está aguardando aprovação de acesso.`,
            {
              title: '📩 Novo Usuário Pendente'
            }
          );
        }
        
        // Mostrar mensagem de acesso negado
        showLoginError(
          `🔒 Acesso Pendente de Aprovação\n\n` +
          `Olá ${displayName}!\n\n` +
          `Seu acesso foi detectado, mas você precisa ser aprovado pelo Admin Master antes de usar o sistema.\n\n` +
          `O administrador foi notificado e em breve você receberá suas permissões.\n\n` +
          `Por favor, aguarde a aprovação e tente novamente mais tarde.`
        );
        return { status: 'pending' };
      }
      
      // Se tem role, fazer login normal
      console.log('[Admin] ✅ Usuário aprovado, fazendo login...');
      await login(email, false, {
        displayName,
        photo,
        roleData: {
          ...roleData,
          roleId: userRole // Usar role aprovado, não o do Azure AD
        },
        microsoft365: true,
        isTestMode: isTest
      });
      return { status: 'ok' };
      
    } catch (error) {
      console.error('[Admin] ❌ Erro ao processar login Microsoft:', error);
      showLoginError('Erro ao processar credenciais. Tente novamente.');
    }
  }
  
  // Login Legacy (formulário tradicional)
  document.getElementById('login-form')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = document.getElementById('admin-email').value.trim();
  const password = document.getElementById('admin-password').value;
  
  // Senha hardcoded para demo (em produção, usar hash + backend)
  if (password !== 'nexos2024') {
    showLoginError('Senha incorreta');
    return;
  }
  
  // Validar se o usuário está cadastrado no UserRoleManager
  // Primeiro, inicializar o UserRoleManager temporariamente para verificar
  try {
    if (!window.userRoleManager) {
      await loadScript('admin/user-role-manager.js');
      window.userRoleManager = new window.UserRoleManager();
      await window.userRoleManager.init();
    }
    
    const userRole = window.userRoleManager.getUserRole(email);
    
    if (!userRole) {
      showLoginError('Usuário não cadastrado. Entre em contato com o administrador para receber acesso.');
      return;
    }
    
    console.log('[Admin] ✅ Usuário autorizado:', email, '| Role:', userRole);
  } catch (error) {
    console.error('[Admin] ❌ Erro ao verificar usuário:', error);
    showLoginError('Erro ao verificar credenciais. Tente novamente.');
    return;
  }
  
  await login(email);
});

async function login(email, isRestore = false, microsoft365Data = null) {
  currentUser = email;
  window.currentUserEmail = email; // Disponibilizar globalmente para outros módulos
  
  // Salvar sessão (incluindo dados M365 se disponível)
  const sessionData = {
    user: email,
    timestamp: Date.now()
  };
  
  if (microsoft365Data) {
    sessionData.microsoft365 = microsoft365Data;
  }
  
  await chrome.storage.local.set({
    __nexos_admin_session: sessionData
  });
  
  // Inicializar todos os managers
  try {
    console.log('[Admin] Inicializando managers...');
    
    await initPermissionManager();
    await initNotificationManager();
    await initReportExporter();
    await initLiveDashboard();
    await initUserRoleManager();
    await initSupervisionManager();
    
    console.log('[Admin] ✅ Todos os managers inicializados');
  } catch (error) {
    console.error('[Admin] ❌ Erro ao inicializar managers:', error);
  }
  
  // Definir role do usuário no PermissionManager
  // Buscar role salvo no UserRoleManager (obrigatório)
  let userRole = null;
  
  if (window.userRoleManager) {
    userRole = window.userRoleManager.getUserRole(email);
    if (userRole) {
      console.log('[Admin] ✅ Role carregado do UserRoleManager:', userRole);
    } else {
      console.error('[Admin] ❌ ERRO: Usuário sem role cadastrado!');
      alert('❌ Erro: Usuário sem cargo definido. Entre em contato com o administrador.');
      showLoginScreen();
      return;
    }
  } else {
    console.error('[Admin] ❌ ERRO: UserRoleManager não inicializado!');
    alert('❌ Erro ao carregar sistema de permissões. Recarregue a página.');
    showLoginScreen();
    return;
  }
  
  try {
    await window.permissionManager.setCurrentUser(email, userRole);
    const role = window.permissionManager.getCurrentRole();
    console.log('[Admin] ✅ Usuário configurado:', email, '| Role:', role?.name);
  } catch (error) {
    console.error('[Admin] ❌ Erro ao configurar role:', error);
  }
  
  // Registrar no LogManager
  if (!isRestore) {
    await window.logManager.setCurrentUser(email);
    await window.logManager.info('admin', 'admin_login', 'Admin ' + email + ' fez login');
    
    // Enviar notificação de login
    if (window.notificationManager) {
      await window.notificationManager.notifyInfo(
        'Login Realizado',
        `Bem-vindo, ${email}!`,
        { email, timestamp: Date.now() }
      );
    }
  }
  
  // Mostrar dashboard
  showDashboard();
  
  // Iniciar timers
  startSessionTimer();
  
  // Iniciar Live Dashboard (substitui startRefreshTimer antigo)
  if (window.liveDashboard) {
    const config = await chrome.storage.local.get('__nexos_admin_config');
    const adminConfig = config.__nexos_admin_config || { autoRefresh: true };
    
    if (adminConfig.autoRefresh) {
      window.liveDashboard.start('overview');
      console.log('[Admin] ✅ Live Dashboard iniciado');
    }
  }
  
  // Solicitar permissão para notificações desktop
  await requestNotificationPermission();
  
  // Iniciar polling de aprovações pendentes
  await startApprovalsPolling();
  
  // Mostrar alerta de boas-vindas (apenas na primeira vez)
  if (!isRestore && ADMIN_USERS.includes('*')) {
    setTimeout(() => {
      const role = window.permissionManager?.getCurrentRole();
      const msg = '🎉 Bem-vindo ao Admin Dashboard!\n\n' +
                  `Seu cargo: ${role?.name || 'Não definido'}\n\n` +
                  'Você está em MODO DEBUG (aceita qualquer email).\n\n' +
                  'Para adicionar seu email permanentemente:\n' +
                  '1. Vá em "⚙️ Configurações"\n' +
                  '2. Role até "Administradores Autorizados"\n' +
                  '3. Adicione: ' + email + '\n' +
                  '4. Depois remova o wildcard \'*\' do código';
      alert(msg);
    }, 1000);
  }
}

// NOTA: Listener de logout movido para setupNavigationListeners()

async function logout() {
  await window.logManager.info('admin', 'admin_logout', 'Admin ' + currentUser + ' fez logout');
  await window.logManager.clearCurrentUser();
  
  // Parar Live Dashboard
  if (window.liveDashboard) {
    window.liveDashboard.stop();
  }
  
  // Parar polling de aprovações
  stopApprovalsPolling();
  
  // Limpar Permission Manager
  if (window.permissionManager) {
    await window.permissionManager.clearCurrentUser();
  }
  
  // Limpar sessão
  await chrome.storage.local.remove(['__nexos_admin_session']);
  
  // Parar timers
  clearInterval(refreshTimer);
  clearInterval(sessionTimer);
  
  currentUser = null;
  showLoginScreen();
}

function showLoginError(message) {
  const errorEl = document.getElementById('login-error');
  errorEl.textContent = message;
  errorEl.classList.add('show');
  
  setTimeout(() => {
    errorEl.classList.remove('show');
  }, 3000);
}

function showLoginScreen() {
  document.getElementById('login-screen').style.display = 'flex';
  document.getElementById('dashboard-screen').style.display = 'none';

  // Resetar estado dos botões de login para o padrão
  try {
    const btn = document.getElementById('btn-microsoft-login');
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = `
        <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 8px; vertical-align:middle;">
          <rect width="10" height="10" fill="#F25022"/>
          <rect x="11" width="10" height="10" fill="#7FBA00"/>
          <rect y="11" width="10" height="10" fill="#00A4EF"/>
          <rect x="11" y="11" width="10" height="10" fill="#FFB900"/>
        </svg>
        Entrar com Microsoft 365
      `;
    }

    const testBtn = document.getElementById('btn-test-auth');
    if (testBtn) {
      testBtn.disabled = false;
      testBtn.textContent = '🧪 Modo de Teste (Desenvolvimento)';
    }
  } catch (err) {
    console.warn('[Admin] Erro ao resetar botões de login:', err);
  }
}

function showDashboard() {
  console.log('[Admin] showDashboard() chamado');
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('dashboard-screen').style.display = 'flex';
  console.log('[Admin] Dashboard exibido');
  
  // Atualizar info do usuário
  updateUserInfo();
  console.log('[Admin] Informações do usuário atualizadas');
  
  // IMPORTANTE: Setup dos listeners DEPOIS de exibir o dashboard
  console.log('[Admin] Chamando setupNavigationListeners()...');
  setupNavigationListeners();
  
  // Carregar painel inicial (aguardar managers estarem prontos)
  console.log('[Admin] Aguardando managers...');
  setTimeout(() => {
    console.log('[Admin] Carregando painel inicial: overview');
    window.loadPanel('overview');
  }, 300);
}

// Função para atualizar informações do usuário na sidebar
async function updateUserInfo() {
  const emailEl = document.getElementById('current-user-email');
  const nameEl = document.getElementById('current-user-name');
  const avatarEl = document.querySelector('.user-avatar');
  
  // Buscar dados da sessão
  const storage = await chrome.storage.local.get(['__nexos_admin_session']);
  const microsoft365Data = storage.__nexos_admin_session?.microsoft365;
  
  if (microsoft365Data) {
    // Usuário logado com Microsoft 365
    console.log('[Admin] 🎨 Atualizando UI com dados Microsoft 365');
    
    // Nome completo (apenas nome e primeiro sobrenome)
    if (nameEl) {
      const fullName = microsoft365Data.displayName || currentUser.split('@')[0];
      const nameParts = fullName.split(' ').filter(p => p.length > 0);
      const firstName = nameParts[0] || '';
      const firstLastName = nameParts[1] || ''; // Primeiro sobrenome
      nameEl.textContent = nameParts.length > 1 ? `${firstName} ${firstLastName}` : firstName;
    }
    
    // Cargo (role)
    const roleEl = document.getElementById('current-user-role');
    if (roleEl && window.userRoleManager) {
      const userRole = window.userRoleManager.getUserRole(currentUser);
      if (userRole && window.ROLES) {
        const roleData = Object.values(window.ROLES).find(r => r.id === userRole);
        roleEl.textContent = roleData ? roleData.name : '';
      }
    }
    
    // Email (removido - agora mostramos o cargo)
    if (emailEl) {
      emailEl.style.display = 'none'; // Ocultar email
      
      // Adicionar badge se for modo teste
      if (microsoft365Data.isTestMode) {
        const testBadge = document.createElement('span');
        testBadge.textContent = '🧪 TESTE';
        testBadge.style.cssText = `
          display: inline-block;
          margin-left: 8px;
          padding: 2px 6px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          font-size: 0.625rem;
          font-weight: 600;
          border-radius: 4px;
          vertical-align: middle;
        `;
        emailEl.appendChild(testBadge);
      }
    }
    
    // Foto do perfil
    if (avatarEl && microsoft365Data.photo) {
      avatarEl.style.backgroundImage = `url(${microsoft365Data.photo})`;
      avatarEl.style.backgroundSize = 'cover';
      avatarEl.style.backgroundPosition = 'center';
      avatarEl.textContent = ''; // Remover emoji
      
      // Adicionar borda se for modo teste
      if (microsoft365Data.isTestMode) {
        avatarEl.style.border = '3px solid #764ba2';
        avatarEl.style.boxShadow = '0 0 10px rgba(118, 75, 162, 0.5)';
      }
    }
    
    // Adicionar tooltip com informações adicionais
    if (avatarEl && microsoft365Data.roleData) {
      avatarEl.title = `${microsoft365Data.displayName}\n${microsoft365Data.roleData.roleName}\nGrupos: ${microsoft365Data.roleData.groups.join(', ')}`;
    }
    
  } else {
    // Login tradicional (sem Microsoft 365)
    if (nameEl) {
      const email = currentUser.split('@')[0];
      const nameParts = email.split('.').filter(p => p.length > 0);
      const firstName = nameParts[0] || '';
      const firstLastName = nameParts[1] || ''; // Primeiro sobrenome
      nameEl.textContent = nameParts.length > 1 ? 
        `${firstName.charAt(0).toUpperCase() + firstName.slice(1)} ${firstLastName.charAt(0).toUpperCase() + firstLastName.slice(1)}` : 
        email;
    }
    
    // Cargo
    const roleEl = document.getElementById('current-user-role');
    if (roleEl && window.userRoleManager) {
      const userRole = window.userRoleManager.getUserRole(currentUser);
      if (userRole && window.ROLES) {
        const roleData = Object.values(window.ROLES).find(r => r.id === userRole);
        roleEl.textContent = roleData ? roleData.name : '';
      }
    }
    
    if (emailEl) emailEl.style.display = 'none';
  }
}

// ===================================================================
// NAVEGAÇÃO
// ===================================================================

function setupNavigationListeners() {
  console.log('[Admin] Configurando listeners de navegação...');
  
  const navItems = document.querySelectorAll('.nav-item');
  console.log('[Admin] Nav items encontrados:', navItems.length);
  
  navItems.forEach((item, index) => {
    console.log(`[Admin] Anexando listener ao item ${index}:`, item.dataset.panel);
    // Ocultar/Desabilitar itens admin-only se o usuário não tiver permissão
    try {
      const panelName = item.dataset.panel;
      const isAdminOnly = ADMIN_ONLY_PANELS.includes(panelName);
      const hasAccess = window.permissionManager?.hasPermission('access_admin_panel') || window.permissionManager?.hasPermission('manage_users') || false;
      if (isAdminOnly && !hasAccess) {
        // esconder visualmente mas manter no DOM (pode ser reativado após permissão)
        item.style.display = 'none';
        console.log('[Admin] Escondendo nav item (apenas admin):', panelName);
        return; // não anexar listener
      }
    } catch (err) {
      console.warn('[Admin] Erro checando permissão para nav-item:', err);
    }

    item.addEventListener('click', (e) => {
      e.preventDefault();
      console.log('[Admin] Nav item clicado:', item.dataset.panel);
      const panel = item.dataset.panel;
      loadPanel(panel);
    });
  });

  const refreshBtn = document.getElementById('refresh-btn');
  if (refreshBtn) {
    console.log('[Admin] Anexando listener ao botão refresh');
    refreshBtn.addEventListener('click', () => {
      console.log('[Admin] Refresh clicado, recarregando:', currentPanel);
      loadPanel(currentPanel);
    });
  } else {
    console.warn('[Admin] Botão refresh não encontrado!');
  }
  
  // Anexar listener ao botão de logout
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    console.log('[Admin] Anexando listener ao botão logout');
    logoutBtn.addEventListener('click', async () => {
      console.log('[Admin] Logout clicado');
      await logout();
    });
  } else {
    console.warn('[Admin] Botão logout não encontrado!');
  }
  
  console.log('[Admin] ✅ Listeners de navegação configurados');
}

// NOTA: setupNavigationListeners() é chamado dentro de showDashboard()
// após o dashboard estar visível, garantindo que os elementos existam

// Tornar loadPanel global para que admin-panels.js possa acessá-la
window.loadPanel = function(panelName) {
  console.log('[Admin] ═══════════════════════════════════════════════════');
  console.log('[Admin] loadPanel() chamado com:', panelName);
  currentPanel = panelName;
  
  // Parar Live Dashboard do painel anterior
  if (window.liveDashboard) {
    window.liveDashboard.stop();
  }
  
  // Atualizar nav ativa
  console.log('[Admin] Atualizando nav items...');
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.panel === panelName);
  });
  
  // Atualizar título
  const titles = {
    overview: 'Visão Geral',
    users: 'Usuários Ativos',
    'user-management': 'Gerenciamento de Usuários',
    approvals: 'Aprovações Pendentes',
    'approval-history': 'Histórico de Aprovações',
    logs: 'Logs de Operações',
    statistics: 'Estatísticas',
    storage: 'Storage & Sync',
    alerts: 'Alertas',
    'sharepoint-setup': 'Setup SharePoint',
    'extraction-testing': 'Testar Extração',
    settings: 'Configurações'
  };
  
  console.log('[Admin] Atualizando título para:', titles[panelName]);
  document.getElementById('panel-title').textContent = titles[panelName];
  document.getElementById('panel-breadcrumb').textContent = `Dashboard / ${titles[panelName]}`;
  
  // Carregar conteúdo
  console.log('[Admin] Limpando content area...');
  const contentArea = document.getElementById('content-area');
  contentArea.innerHTML = '<div class="loading"><div class="spinner"></div><p>Carregando...</p></div>';
  console.log('[Admin] Loading spinner exibido');
  
  setTimeout(async () => {
    console.log('[Admin] Timeout executado, renderizando painel:', panelName);
    try {
      switch (panelName) {
        case 'overview':
          console.log('[Admin] Renderizando: Overview');
          await renderOverviewPanel();
          break;
        case 'general':
          console.log('[Admin] Renderizando: General (Painel Público)');
          await renderGeneralPanel();
          break;
        case 'users':
          console.log('[Admin] Renderizando: Users');
          await renderUsersPanel();
          break;
        case 'user-management':
          console.log('[Admin] Renderizando: User Management');
          await renderUserManagementPanel();
          try { await updatePendingUsersBadge(); } catch (e) { console.warn('[Admin] Erro atualizando badge após renderUserManagementPanel:', e); }
          break;
        case 'approvals':
          console.log('[Admin] Renderizando: Approvals');
          await renderApprovalsPanel();
          break;
        case 'approval-history':
          console.log('[Admin] Renderizando: Approval History');
          await renderApprovalHistoryPanel();
          break;
        case 'logs':
          console.log('[Admin] Renderizando: Logs');
          await renderLogsPanel();
          break;
        case 'statistics':
          console.log('[Admin] Renderizando: Statistics');
          await renderStatisticsPanel();
          break;
        case 'storage':
          console.log('[Admin] Renderizando: Storage');
          await renderStoragePanel();
          break;
        case 'alerts':
          console.log('[Admin] Renderizando: Alerts');
          await renderAlertsPanel();
          break;
        case 'sharepoint-setup':
          console.log('[Admin] Renderizando: SharePoint Setup');
          await renderSharePointSetupPanel();
          break;
        case 'extraction-testing':
          console.log('[Admin] Renderizando: Extraction Testing');
          await renderExtractionTestingPanel();
          break;
        case 'settings':
          console.log('[Admin] Renderizando: Settings');
          await renderSettingsPanel();
          break;
        default:
          console.error('[Admin] Painel desconhecido:', panelName);
      }
      console.log('[Admin] ✅ Painel renderizado com sucesso:', panelName);
      console.log('[Admin] ═══════════════════════════════════════════════════');
      
      // Iniciar Live Dashboard para o novo painel (se auto-refresh estiver ativado)
      if (window.liveDashboard) {
        const config = await chrome.storage.local.get('__nexos_admin_config');
        const adminConfig = config.__nexos_admin_config || { autoRefresh: true };
        
        if (adminConfig.autoRefresh) {
          window.liveDashboard.start(panelName);
          console.log('[Admin] ✅ Live Dashboard iniciado para:', panelName);
        }
      }
    } catch (err) {
      console.error('[Admin] ❌ Erro ao renderizar painel:', panelName);
      console.error('[Admin] Error:', err);
      console.error('[Admin] ═══════════════════════════════════════════════════');
    }
  }, 300);
}

// ===================================================================
// PAINEL: VISÃO GERAL
// ===================================================================

async function renderOverviewPanel() {
  console.log('[Admin] renderOverviewPanel() iniciado');
  
  try {
    console.log('[Admin] Buscando estatísticas...');
    const stats = await window.logManager.getStatistics(1); // Últimas 24h
    console.log('[Admin] Estatísticas:', stats);
    
    console.log('[Admin] Buscando sessões ativas...');
    const sessions = await window.logManager.getActiveSessions();
    console.log('[Admin] Sessões:', sessions.length);
    
    console.log('[Admin] Buscando alertas...');
    const alertsData = await chrome.storage.local.get(['__nexos_alerts']);
    const alerts = alertsData.__nexos_alerts || [];
    const unreadAlerts = alerts.filter(a => !a.read).length;
    console.log('[Admin] Alertas:', alerts.length, 'não lidos:', unreadAlerts);
  
  const html = `
    <div class="stats-grid">
      <div class="stat-card success">
        <div class="stat-label">Total de Operações (24h)</div>
        <div class="stat-value">${stats.total.toLocaleString('pt-BR')}</div>
        <div class="stat-change positive">↑ Últimas 24 horas</div>
      </div>
      
      <div class="stat-card">
        <div class="stat-label">Usuários Ativos</div>
        <div class="stat-value">${sessions.filter(s => s.status === 'online').length}</div>
        <div class="stat-change">${sessions.length} total</div>
      </div>
      
      <div class="stat-card warning">
        <div class="stat-label">Taxa de Erro</div>
        <div class="stat-value">${stats.errorRate}%</div>
        <div class="stat-change ${stats.errorRate > 5 ? 'negative' : 'positive'}">
          ${stats.errorRate > 5 ? '↑ Acima do normal' : '✓ Dentro do esperado'}
        </div>
      </div>
      
      <div class="stat-card error">
        <div class="stat-label">Alertas Não Lidos</div>
        <div class="stat-value">${unreadAlerts}</div>
        <div class="stat-change">${alerts.length} total</div>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">Atividade Recente</div>
          <div class="card-subtitle">Últimas 10 operações</div>
        </div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>Usuário</th>
              <th>Módulo</th>
              <th>Ação</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody id="recent-activity-tbody">
            <tr><td colspan="5" class="loading">Carregando...</td></tr>
          </tbody>
        </table>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Top 5 Usuários Mais Ativos</div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Usuário</th>
              <th>Operações</th>
              <th>Última Atividade</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody id="top-users-tbody">
            ${stats.topUsers.map(u => {
              const session = sessions.find(s => s.user === u.user);
              const statusBadge = session?.status === 'online' ? 'success' : 'error';
              const statusText = session?.status === 'online' ? 'online' : 'offline';
              const statusStyle = session?.status === 'online' ? '' : 'style="background: #DC2626; color: white;"';
              return `
                <tr>
                  <td>${u.user}</td>
                  <td>${u.count}</td>
                  <td>${session ? formatTimestamp(session.lastSeen) : '-'}</td>
                  <td><span class="badge badge-${statusBadge}" ${statusStyle}>${statusText}</span></td>
                </tr>
              `;
            }).join('') || '<tr><td colspan="4" class="empty-state">Nenhum usuário ativo</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
  
    document.getElementById('content-area').innerHTML = html;
    console.log('[Admin] HTML do overview inserido');
    
    // Carregar atividade recente
    console.log('[Admin] Carregando atividade recente...');
    const { logs } = await window.logManager.searchLogs({ limit: 10 });
    const tbody = document.getElementById('recent-activity-tbody');
    
    if (logs.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" class="empty-state">Nenhuma atividade recente</td></tr>';
    } else {
      tbody.innerHTML = logs.map(log => `
        <tr>
          <td>${formatTimestamp(log.timestamp)}</td>
          <td>${log.user}</td>
          <td><span class="badge badge-info">${log.module}</span></td>
          <td>${formatAction(log.action)}</td>
          <td><span class="badge badge-${getLevelBadge(log.level)}">${log.level}</span></td>
        </tr>
      `).join('');
    }
    
    // Atualizar status de conexão
    updateConnectionStatus(true);
    console.log('[Admin] ✅ Overview renderizado com sucesso');
    
  } catch (error) {
    console.error('[Admin] ❌ Erro ao renderizar Overview:', error);
    document.getElementById('content-area').innerHTML = `
      <div class="error-message">
        <h3>⚠️ Erro ao Carregar Dashboard</h3>
        <p>${error.message}</p>
        <button class="btn btn-primary" data-action="retryOverview">Tentar Novamente</button>
      </div>
    `;
  }
}

// Painel geral, visível para todos os membros (ponto de entrada público)
async function renderGeneralPanel() {
  const container = document.getElementById('content-area');
  if (!container) return;

  const storage = await chrome.storage.local.get(['__nexos_admin_session']);
  const microsoft365Data = storage.__nexos_admin_session?.microsoft365;
  const currentEmail = window.currentUserEmail || (microsoft365Data ? microsoft365Data.email : '');

  container.innerHTML = `
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">Painel Central</div>
          <div class="card-subtitle">Área pública com funcionalidades destinadas a todos os membros</div>
        </div>
      </div>
      <div class="card-body">
        <p>Bem-vindo ao Painel Central. Aqui ficam recursos de uso comum e novidades.</p>
        <p>Se você precisa de acesso ao painel administrador, solicite abaixo — um Admin Master será notificado.</p>

        <div style="margin-top: 1rem;">
          <button id="btn-request-admin" class="btn btn-primary">🔒 Solicitar Acesso de Administrador</button>
        </div>

        <div id="request-status" style="margin-top: 1rem; color: #555; font-size: 0.95rem;"></div>
      </div>
    </div>
  `;

  document.getElementById('btn-request-admin').addEventListener('click', async () => {
    try {
      document.getElementById('btn-request-admin').disabled = true;
      document.getElementById('request-status').textContent = 'Enviando solicitação...';

      // Garantir UserRoleManager carregado
      if (!window.userRoleManager) {
        await loadScript('admin/user-role-manager.js');
        window.userRoleManager = new window.UserRoleManager();
        await window.userRoleManager.init();
      }

      const session = await chrome.storage.local.get(['__nexos_admin_session']);
      const mData = session.__nexos_admin_session?.microsoft365;
      const email = window.currentUserEmail || mData?.profile?.email || mData?.email || '';
      const name = mData?.profile?.displayName || (email ? email.split('@')[0] : 'Usuário');

      // Adicionar aos pendentes indicando que é uma solicitação de admin
      await window.userRoleManager.addPendingUser({
        email: email,
        name: name,
        department: 'Solicitação de Acesso',
        requestedAt: Date.now(),
        microsoft365: !!mData,
        photo: mData?.photo || null,
        suggestedRole: 'admin_master',
        accessRequest: 'admin'
      });

      // Atualizar badge lateral
      try { await updatePendingUsersBadge(); } catch (e) { console.warn('[Admin] Falha ao atualizar badge após request-admin:', e); }

      // Notificar via toast
      if (window.toastNotifications) {
        window.toastNotifications.info(
          `${name} (${email}) solicitou acesso ao Painel Administrador.`,
          {
            title: '📩 Solicitação de Acesso Admin'
          }
        );
      }

      document.getElementById('request-status').textContent = 'Solicitação enviada. Aguarde a aprovação do Admin Master.';
    } catch (err) {
      console.error('[Admin] Erro ao solicitar acesso admin:', err);
      document.getElementById('request-status').textContent = 'Erro ao enviar solicitação: ' + (err.message || err);
    } finally {
      document.getElementById('btn-request-admin').disabled = false;
    }
  });
}

// ===================================================================
// PAINEL: USUÁRIOS ATIVOS
// ===================================================================

async function renderUsersPanel() {
  const sessions = await window.logManager.getActiveSessions();
  
  // Atualizar badge
  document.getElementById('users-badge').textContent = sessions.filter(s => s.status === 'online').length;
  
  const html = `
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">Sessões Ativas (Últimas 24h)</div>
          <div class="card-subtitle">${sessions.length} usuários com atividade</div>
        </div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Usuário</th>
              <th>Status</th>
              <th>Última Atividade</th>
              <th>Tempo desde Última Atividade</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            ${sessions.map(session => {
              const elapsed = Date.now() - session.lastSeen;
              const elapsedStr = formatElapsed(elapsed);
              
              return `
                <tr>
                  <td>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                      <span style="font-size: 1.5rem;">👤</span>
                      <span>${session.user}</span>
                    </div>
                  </td>
                  <td>
                    <span class="badge badge-${session.status === 'online' ? 'success' : session.status === 'idle' ? 'warning' : 'error'}">
                      ${session.status.toUpperCase()}
                    </span>
                  </td>
                  <td>${formatTimestamp(session.lastSeen)}</td>
                  <td>${elapsedStr}</td>
                  <td>
                    <button class="btn-secondary" data-action="viewUserLogs" data-param="${session.user}">
                      Ver Logs
                    </button>
                  </td>
                </tr>
              `;
            }).join('') || '<tr><td colspan="5" class="empty-state"><div class="empty-state-icon">👥</div><p>Nenhum usuário ativo</p></td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
  
  document.getElementById('content-area').innerHTML = html;
  updateConnectionStatus(true);
}

// ===================================================================
// PAINEL: LOGS DE OPERAÇÕES
// ===================================================================

// NOTA: logsCurrentPage e logsFilters agora são variáveis globais (topo do arquivo)

// ===================================================================
// FUNÇÕES DE SUPORTE PARA LOGS (movidas para fora de renderLogsPanel)
// ===================================================================

/**
 * Muda para uma página específica de logs
 */
async function changePage(page) {
  logsCurrentPage = page;
  await loadLogs();
}

async function loadLogs() {
  const limit = 50;
  const offset = (logsCurrentPage - 1) * limit;
  
  const { logs, total } = await window.logManager.searchLogs({
    ...logsFilters,
    limit,
    offset
  });
  
  const tbody = document.getElementById('logs-tbody');
  
  if (logs.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-state"><div class="empty-state-icon">📋</div><p>Nenhum log encontrado</p></td></tr>';
  } else {
    tbody.innerHTML = logs.map(log => `
      <tr>
        <td style="white-space: nowrap;">${formatTimestamp(log.timestamp)}</td>
        <td><span class="badge badge-${getLevelBadge(log.level)}">${log.level}</span></td>
        <td>${log.user}</td>
        <td><span class="badge badge-info">${log.module}</span></td>
        <td style="white-space: nowrap;">${formatAction(log.action)}</td>
        <td style="max-width: 300px; overflow: hidden; text-overflow: ellipsis;">${log.message}</td>
        <td>
          <button class="btn-secondary" data-action="viewLogMetadata" data-param="${log.id}">Ver</button>
        </td>
      </tr>
    `).join('');
  }
  
  // Atualizar contador de resultados
  updateLogsResultsSummary(logs.length, total, offset, limit);
  
  // Paginação
  renderLogsPagination(total, limit);
  
  // Popular dropdown de usuários (apenas na primeira carga)
  if (logsCurrentPage === 1 && !document.getElementById('filter-user').dataset.populated) {
    await populateUserFilter();
  }
}

async function updateLogsResultsSummary(currentCount, total, offset, limit) {
  const summaryEl = document.getElementById('logs-results-summary');
  const textEl = document.getElementById('logs-count-text');
  
  if (!summaryEl || !textEl) return;
  
  const hasFilters = Object.keys(logsFilters).some(key => logsFilters[key] && (Array.isArray(logsFilters[key]) ? logsFilters[key].length > 0 : true));
  
  if (hasFilters && total > 0) {
    summaryEl.style.display = 'block';
    const start = offset + 1;
    const end = Math.min(offset + limit, total);
    textEl.textContent = `📊 Mostrando ${start}-${end} de ${total.toLocaleString('pt-BR')} logs filtrados`;
  } else if (hasFilters && total === 0) {
    summaryEl.style.display = 'block';
    textEl.textContent = `⚠️ Nenhum log encontrado com os filtros aplicados`;
  } else {
    summaryEl.style.display = 'none';
  }
}

async function populateUserFilter() {
  try {
    // Buscar todos os usuários únicos dos logs
    const { logs } = await window.logManager.searchLogs({ limit: 10000 });
    const uniqueUsers = [...new Set(logs.map(log => log.user).filter(u => u))].sort();
    
    const userSelect = document.getElementById('filter-user');
    if (!userSelect) return;
    
    // Manter o "Todos" e adicionar usuários únicos
    uniqueUsers.forEach(user => {
      const option = document.createElement('option');
      option.value = user;
      option.textContent = user;
      userSelect.appendChild(option);
    });
    
    userSelect.dataset.populated = 'true';
  } catch (error) {
    console.error('[Admin] Erro ao popular filtro de usuários:', error);
  }
}

function renderLogsPagination(total, limit) {
  const totalPages = Math.ceil(total / limit);
  const paginationEl = document.getElementById('logs-pagination');
  
  if (totalPages <= 1) {
    paginationEl.innerHTML = '';
    return;
  }
  
  let html = `
    <button ${logsCurrentPage === 1 ? 'disabled' : ''} data-action="prevLogPage">Anterior</button>
  `;
  
  for (let i = 1; i <= totalPages; i++) {
    if (i === 1 || i === totalPages || (i >= logsCurrentPage - 2 && i <= logsCurrentPage + 2)) {
      html += `<button class="${i === logsCurrentPage ? 'active' : ''}" data-action="gotoLogPage" data-param="${i}">${i}</button>`;
    } else if (i === logsCurrentPage - 3 || i === logsCurrentPage + 3) {
      html += `<span>...</span>`;
    }
  }
  
  html += `
    <button ${logsCurrentPage === totalPages ? 'disabled' : ''} data-action="nextLogPage">Próxima</button>
  `;
  
  paginationEl.innerHTML = html;
}

async function renderLogsPanel(page = 1) {
  const loadingId = window.globalLoading?.show('logs-panel');
  logsCurrentPage = page;
  
  const html = `
    <div class="card">
      <div class="card-header">
        <div class="card-title">Filtros Avançados</div>
      </div>
      <div class="filters">
        <div class="filter-group">
          <label>📅 Data Inicial</label>
          <input type="date" id="filter-date-start" class="filter-date-input">
        </div>
        <div class="filter-group">
          <label>📅 Data Final</label>
          <input type="date" id="filter-date-end" class="filter-date-input">
        </div>
        <div class="filter-group">
          <label>🎚️ Níveis</label>
          <div class="filter-multiselect">
            <button type="button" class="filter-multiselect-trigger" id="filter-level-trigger">
              <span id="filter-level-text">Todos</span>
              <span class="filter-multiselect-arrow">▼</span>
            </button>
            <div class="filter-multiselect-dropdown" id="filter-level-dropdown" style="display: none;">
              <label class="filter-checkbox-label">
                <input type="checkbox" value="INFO" class="filter-level-checkbox"> INFO
              </label>
              <label class="filter-checkbox-label">
                <input type="checkbox" value="WARN" class="filter-level-checkbox"> WARN
              </label>
              <label class="filter-checkbox-label">
                <input type="checkbox" value="ERROR" class="filter-level-checkbox"> ERROR
              </label>
              <label class="filter-checkbox-label">
                <input type="checkbox" value="DEBUG" class="filter-level-checkbox"> DEBUG
              </label>
            </div>
          </div>
        </div>
        <div class="filter-group">
          <label>📦 Módulo</label>
          <select id="filter-module">
            <option value="">Todos</option>
            <option value="content">Content</option>
            <option value="background">Background</option>
            <option value="whatsapp">WhatsApp</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <div class="filter-group">
          <label>👤 Usuário</label>
          <select id="filter-user">
            <option value="">Todos</option>
          </select>
        </div>
        <div class="filter-group">
          <label>🔍 Buscar</label>
          <input type="text" id="filter-search" placeholder="Buscar em mensagens...">
        </div>
        <div class="filter-group">
          <label>&nbsp;</label>
          <button class="btn-primary" data-action="applyLogFilters">Aplicar Filtros</button>
        </div>
        <div class="filter-group">
          <label>&nbsp;</label>
          <button class="btn-secondary" data-action="clearLogFilters">Limpar</button>
        </div>
        <div class="filter-group">
          <label>&nbsp;</label>
          <button class="btn-success" data-action="exportLogsCSV">📥 Exportar Filtrados</button>
        </div>
      </div>
    </div>
    
    <div class="card" id="logs-results-summary" style="display: none;">
      <div class="card-body" style="padding: 1rem; background: var(--bg-tertiary); border-left: 3px solid var(--primary); color: var(--text-primary); transition: all var(--transition-normal);">
        <strong id="logs-count-text">Carregando...</strong>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Histórico de Operações</div>
      </div>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>Nível</th>
              <th>Usuário</th>
              <th>Módulo</th>
              <th>Ação</th>
              <th>Mensagem</th>
              <th>Metadata</th>
            </tr>
          </thead>
          <tbody id="logs-tbody">
            <tr><td colspan="7" class="loading">Carregando...</td></tr>
          </tbody>
        </table>
      </div>
      <div id="logs-pagination" class="pagination"></div>
    </div>
  `;
  
  document.getElementById('content-area').innerHTML = html;
  
  // Inicializar multiselect de níveis
  initializeLogLevelMultiselect();
  
  // Inicializar filtros em tempo real
  initializeLogFiltersRealtime();
  
  // Carregar logs
  await loadLogs();
  
  window.globalLoading?.hide(loadingId);
  updateConnectionStatus(true);
}

function initializeLogLevelMultiselect() {
  const trigger = document.getElementById('filter-level-trigger');
  const dropdown = document.getElementById('filter-level-dropdown');
  const textEl = document.getElementById('filter-level-text');
  const checkboxes = document.querySelectorAll('.filter-level-checkbox');
  
  if (!trigger || !dropdown || !textEl) return;
  
  // Toggle dropdown
  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
  });
  
  // Fechar dropdown ao clicar fora
  document.addEventListener('click', () => {
    dropdown.style.display = 'none';
  });
  
  dropdown.addEventListener('click', (e) => {
    e.stopPropagation();
  });
  
  // Atualizar texto ao selecionar checkboxes
  checkboxes.forEach(cb => {
    cb.addEventListener('change', () => {
      const selected = Array.from(checkboxes)
        .filter(c => c.checked)
        .map(c => c.value);
      
      if (selected.length === 0) {
        textEl.textContent = 'Todos';
      } else if (selected.length === checkboxes.length) {
        textEl.textContent = 'Todos';
      } else {
        textEl.textContent = selected.join(', ');
      }
    });
  });
}

function initializeLogFiltersRealtime() {
  const dateStart = document.getElementById('filter-date-start');
  const dateEnd = document.getElementById('filter-date-end');
  const filterModule = document.getElementById('filter-module');
  const filterUser = document.getElementById('filter-user');
  const filterSearch = document.getElementById('filter-search');
  const checkboxes = document.querySelectorAll('.filter-level-checkbox');
  
  // Debounce para o campo de busca
  let searchTimeout;
  const debouncedApplyFilters = () => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      window.applyLogFilters();
    }, 500);
  };
  
  // Event listeners para aplicar filtros automaticamente
  if (dateStart) dateStart.addEventListener('change', () => window.applyLogFilters());
  if (dateEnd) dateEnd.addEventListener('change', () => window.applyLogFilters());
  if (filterModule) filterModule.addEventListener('change', () => window.applyLogFilters());
  if (filterUser) filterUser.addEventListener('change', () => window.applyLogFilters());
  if (filterSearch) filterSearch.addEventListener('input', debouncedApplyFilters);
  
  checkboxes.forEach(cb => {
    cb.addEventListener('change', () => window.applyLogFilters());
  });
}

// ===================================================================
// FUNÇÕES window.* PARA EVENT DELEGATION
// ===================================================================

window.applyLogFilters = async function() {
  const opId = window.globalLoading?.show('filter-logs');
  
  try {
    // Obter níveis selecionados (checkboxes)
    const selectedLevels = Array.from(document.querySelectorAll('.filter-level-checkbox:checked'))
      .map(cb => cb.value);
    
    logsFilters = {
      levels: selectedLevels.length > 0 ? selectedLevels : undefined,
      module: document.getElementById('filter-module').value || undefined,
      user: document.getElementById('filter-user').value || undefined,
      search: document.getElementById('filter-search').value || undefined,
      dateStart: document.getElementById('filter-date-start').value || undefined,
      dateEnd: document.getElementById('filter-date-end').value || undefined
    };
    
    // Remover propriedades undefined
    Object.keys(logsFilters).forEach(key => {
      if (logsFilters[key] === undefined) {
        delete logsFilters[key];
      }
    });
    
    logsCurrentPage = 1;
    await loadLogs();
  } finally {
    window.globalLoading?.hide(opId);
  }
};

window.clearLogFilters = async function() {
  logsFilters = {};
  
  // Limpar inputs
  document.getElementById('filter-date-start').value = '';
  document.getElementById('filter-date-end').value = '';
  document.getElementById('filter-module').value = '';
  document.getElementById('filter-user').value = '';
  document.getElementById('filter-search').value = '';
  
  // Desmarcar todos os checkboxes de nível
  document.querySelectorAll('.filter-level-checkbox').forEach(cb => {
    cb.checked = false;
  });
  
  // Atualizar texto do trigger de níveis
  document.getElementById('filter-level-text').textContent = 'Todos';
  
  logsCurrentPage = 1;
  await loadLogs();
};

window.viewUserLogs = function(user) {
  logsFilters = { user };
  loadPanel('logs');
};

window.viewLogMetadata = async function(logId) {
  const { logs } = await window.logManager.searchLogs({ limit: 10000 });
  const log = logs.find(l => l.id === logId);
  
  if (log) {
    const metadataStr = JSON.stringify(log.metadata, null, 2);
    alert('Metadata:\n\n' + metadataStr);
  }
};

window.exportLogsCSV = async function() {
  const opId = window.globalLoading?.show('export-logs');
  
  try {
    const { logs } = await window.logManager.searchLogs({ ...logsFilters, limit: 10000 });
    
    const csv = [
    ['Timestamp', 'Nível', 'Usuário', 'Módulo', 'Ação', 'Mensagem', 'Pedido', 'Plataforma', 'Duração (ms)'],
    ...logs.map(log => [
      new Date(log.timestamp).toLocaleString('pt-BR'),
      log.level,
      log.user,
      log.module,
      log.action,
      log.message,
      log.metadata.pedido || '',
      log.metadata.platform || '',
      log.metadata.duration || ''
    ])
  ].map(row => row.map(cell => '"' + cell + '"').join(',')).join('\n');
  
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'nexos-logs-' + Date.now() + '.csv';
  a.click();
  URL.revokeObjectURL(url);
  
  await window.logManager.info('admin', 'logs_export', 'Admin ' + currentUser + ' exportou ' + logs.length + ' logs');
    
    if (window.toastNotifications) {
      window.toastNotifications.success(`${logs.length} logs exportados com sucesso!`, {
        title: '📥 Exportação Concluída'
      });
    }
  } catch (error) {
    console.error('[Admin] Erro ao exportar logs:', error);
    
    if (window.toastNotifications) {
      window.toastNotifications.error(error.message, {
        title: 'Erro ao Exportar'
      });
    } else {
      alert('❌ Erro ao exportar logs: ' + error.message);
    }
  } finally {
    window.globalLoading?.hide(opId);
  }
};

// ===================================================================
// TIMERS
// ===================================================================

function startSessionTimer() {
  sessionTimer = setInterval(async () => {
    const session = await chrome.storage.local.get(['__nexos_admin_session']);
    if (!session.__nexos_admin_session) {
      await logout();
      return;
    }
    
    const elapsed = Date.now() - session.__nexos_admin_session.timestamp;
    if (elapsed > SESSION_TIMEOUT) {
      alert('Sessão expirada por inatividade');
      await logout();
    }
  }, 60 * 1000); // Check every minute
}

window.startRefreshTimer = async function() {
  // Carregar configurações do usuário
  const config = await chrome.storage.local.get(['__nexos_admin_config']);
  const adminConfig = config.__nexos_admin_config || {
    autoRefresh: false,
    refreshInterval: 10
  };
  
  // Limpar timer anterior se existir
  if (refreshTimer) {
    clearInterval(refreshTimer);
    refreshTimer = null;
  }
  
  // Verificar se auto-refresh está habilitado
  if (!adminConfig.autoRefresh) {
    console.log('[Admin] Auto-refresh desabilitado nas configurações');
    return;
  }
  
  const intervalMs = (adminConfig.refreshInterval || 10) * 1000;
  console.log(`[Admin] Auto-refresh habilitado: ${adminConfig.refreshInterval}s (${intervalMs}ms)`);
  
  refreshTimer = setInterval(() => {
    if (document.getElementById('dashboard-screen')?.style.display !== 'none') {
      console.log('[Admin] Auto-refresh: recarregando painel', currentPanel);
      window.loadPanel(currentPanel);
    }
  }, intervalMs);
};

// ===================================================================
// NOTIFICAÇÕES EM TEMPO REAL - Polling de Aprovações
// ===================================================================

let approvalsPollingTimer = null;
let lastApprovalCount = 0;

/**
 * Inicia polling de aprovações pendentes
 */
async function startApprovalsPolling() {
  // Limpar timer anterior se existir
  if (approvalsPollingTimer) {
    clearInterval(approvalsPollingTimer);
    approvalsPollingTimer = null;
  }
  
  // Verificar se usuário tem permissão para aprovar
  if (!window.permissionManager?.hasPermission('approve_actions')) {
    console.log('[Admin] Polling de aprovações desabilitado - sem permissão');
    return;
  }
  
  if (!window.supervisionManager) {
    console.log('[Admin] Polling de aprovações desabilitado - SupervisionManager não disponível');
    return;
  }
  
  console.log('[Admin] 🔔 Iniciando polling de aprovações (30s)');
  
  // Primeira verificação imediata
  await checkPendingApprovals();
  
  // Polling a cada 30 segundos
  approvalsPollingTimer = setInterval(async () => {
    await checkPendingApprovals();
  }, 30000); // 30 segundos
}

/**
 * Para o polling de aprovações
 */
function stopApprovalsPolling() {
  if (approvalsPollingTimer) {
    clearInterval(approvalsPollingTimer);
    approvalsPollingTimer = null;
    console.log('[Admin] 🔕 Polling de aprovações parado');
  }
}

/**
 * Verifica aprovações pendentes e notifica
 */
async function checkPendingApprovals() {
  try {
    const currentUserEmail = window.currentUserEmail || '';
    if (!currentUserEmail) return;
    
    const pendingRequests = await window.supervisionManager.getPendingRequests(currentUserEmail);
    const supervisorCount = pendingRequests.length;

    // Contar também usuários SP com status=pendente
    let spPendingCount = 0;
    if (typeof _fetchNexosUsuarios === 'function') {
      try {
        const { users } = await _fetchNexosUsuarios();
        spPendingCount = users.filter(u => (u.Status || '').toLowerCase() === 'pendente').length;
      } catch { /* silencioso — não bloquear polling */ }
    }

    const currentCount = supervisorCount + spPendingCount;
    
    // Atualizar badge no menu
    const approvalsBadge = document.getElementById('approvals-badge');
    if (approvalsBadge) {
      if (currentCount > 0) {
        approvalsBadge.textContent = currentCount;
        approvalsBadge.style.display = 'inline-flex';
      } else {
        approvalsBadge.textContent = '0';
        approvalsBadge.style.display = 'none';
      }
      
      // Adicionar animação se houver novas aprovações
      if (currentCount > lastApprovalCount && lastApprovalCount >= 0) {
        approvalsBadge.classList.add('pulse');
        setTimeout(() => approvalsBadge.classList.remove('pulse'), 2000);
      }
    }
    
    // Notificar se houver novas aprovações
    if (currentCount > lastApprovalCount && lastApprovalCount > 0) {
      const newCount = currentCount - lastApprovalCount;
      console.log(`[Admin] 🔔 ${newCount} nova(s) aprovação(ões) pendente(s)!`);
      
      // Notificação visual
      if (window.notificationManager) {
        await window.notificationManager.notifyWarning(
          'Novas Aprovações Pendentes',
          `Você tem ${newCount} nova(s) solicitação(ões) aguardando aprovação.`
        );
      }
      
      // Notificação desktop (Chrome Notification API)
      if (Notification.permission === 'granted') {
        new Notification('Nexos Admin - Aprovações Pendentes', {
          body: `${newCount} nova(s) solicitação(ões) aguardando sua aprovação.`,
          icon: chrome.runtime.getURL('images/icon128.png'),
          badge: chrome.runtime.getURL('images/icon48.png'),
          tag: 'nexos-approvals',
          requireInteraction: false
        });
      }
      
      // Som de notificação (opcional)
      playNotificationSound();
    }
    
    lastApprovalCount = currentCount;
    
  } catch (error) {
    console.error('[Admin] Erro ao verificar aprovações pendentes:', error);
  }
}

/**
 * Toca som de notificação
 */
function playNotificationSound() {
  try {
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTUIGWi77eeYSwwOUKPj8LJoHgY4kdfy0HgsBS10x/DhkUgNE121' +
          '6fCoVRQKRp/g8b1rIAUzgc7y2ooyCBlouuzok0EODlCj4/C2aB4FOpHX8tB3KwYtdMfw4pFIDRNdtenyqFYUCkaf4PK9aiAFNIHO8tmLMggZaLrtyJNBDg5Qo+T');
    audio.volume = 0.3;
    audio.play().catch(() => {}); // Silenciar erro se autoplay bloqueado
  } catch (error) {
    // Ignorar erro de som
  }
}

/**
 * Solicitar permissão para notificações desktop
 */
async function requestNotificationPermission() {
  if ('Notification' in window && Notification.permission === 'default') {
    const permission = await Notification.requestPermission();
    console.log('[Admin] Permissão de notificação:', permission);
    return permission === 'granted';
  }
  return Notification.permission === 'granted';
}

// Resetar timeout em atividade
['mousedown', 'keydown', 'scroll', 'touchstart'].forEach(event => {
  document.addEventListener(event, async () => {
    if (currentUser) {
      await chrome.storage.local.set({
        __nexos_admin_session: {
          user: currentUser,
          timestamp: Date.now()
        }
      });
    }
  }, true);
});

// ===================================================================
// PAINEL: APROVAÇÕES PENDENTES
// ===================================================================

async function renderApprovalsPanel() {
  const container = document.getElementById('content-area');
  if (!container) {
    console.error('[Admin] ❌ Elemento content-area não encontrado');
    return;
  }

  console.log('[Admin] 📋 Renderizando painel de aprovações');

  // Verificar permissão
  if (!window.permissionManager?.hasPermission('approve_actions')) {
    const currentRole = window.permissionManager?.getCurrentRole();
    const userEmail = window.currentUserEmail || 'não autenticado';
    
    container.innerHTML = `
      <div class="error-panel">
        <h2>❌ Acesso Negado</h2>
        <p><strong>Você não tem permissão para aprovar ações.</strong></p>
        <p>Permissão necessária: <code>approve_actions</code></p>
        
        <div style="margin-top: 1.5rem; padding: 1rem; background: var(--gray-50); border-radius: 0.5rem; border-left: 4px solid var(--info);">
          <p style="margin: 0 0 0.5rem 0;"><strong>ℹ️ Informações:</strong></p>
          <p style="margin: 0 0 0.25rem 0;">Usuário: <code>${userEmail}</code></p>
          <p style="margin: 0 0 0.25rem 0;">Cargo atual: <strong>${currentRole?.name || 'Não definido'}</strong></p>
        </div>
        
        <div style="margin-top: 1.5rem; padding: 1rem; background: var(--gray-50); border-radius: 0.5rem; border-left: 4px solid var(--warning);">
          <p style="margin: 0 0 0.5rem 0;"><strong>🔧 Como resolver:</strong></p>
          <ol style="margin: 0; padding-left: 1.5rem;">
            <li>Faça <strong>logout</strong> (botão no menu lateral)</li>
            <li><strong>Recarregue</strong> a extensão em <code>chrome://extensions</code></li>
            <li>Faça <strong>login novamente</strong></li>
            <li>Verifique seu cargo em <strong>"Gerenciar Cargos"</strong></li>
          </ol>
          <p style="margin: 1rem 0 0 0; font-size: 0.875rem; color: var(--gray-600);">
            <strong>Nota:</strong> Apenas cargos de <em>Assistente II</em> ou superior podem aprovar ações.
          </p>
        </div>
        
        <div style="margin-top: 1.5rem; display: flex; gap: 0.75rem;">
          <button class="btn btn-primary" onclick="location.reload()">
            🔄 Recarregar Página
          </button>
          <button class="btn btn-secondary" data-action="switchPanel" data-param="user-management">
            🔐 Ver Meus Cargos
          </button>
        </div>
      </div>
    `;
    return;
  }

  // Garantir que SupervisionManager está inicializado
  if (!window.supervisionManager) {
    container.innerHTML = `
      <div class="error-panel">
        <h2>⚠️ Sistema de Supervisão Indisponível</h2>
        <p>O SupervisionManager não foi inicializado.</p>
        <button class="btn btn-primary" onclick="location.reload()">Recarregar</button>
      </div>
    `;
    return;
  }

  const currentUserEmail = window.currentUserEmail || '';
  const pendingRequests = await window.supervisionManager.getPendingRequests(currentUserEmail);
  
  // Badge: soma solicitações supervisor + usuários SP pendentes
  // (o SP count será refinado quando a seção SP carregar abaixo)
  const approvalsBadge = document.getElementById('approvals-badge');
  // Atualização preliminar com supervisor count; a badge será re-atualizada após carregar SP
  if (approvalsBadge) {
    approvalsBadge.textContent = pendingRequests.length || '0';
    approvalsBadge.style.display = pendingRequests.length > 0 ? 'inline-flex' : 'none';
  }

  container.innerHTML = `
    <div class="panel-header">
      <div>
        <h2>✅ Aprovações Pendentes</h2>
        <p class="subtitle">Solicitações aguardando sua aprovação</p>
      </div>
      <div class="panel-actions">
        <button class="btn btn-secondary" data-action="refreshApprovals">
          🔄 Atualizar
        </button>
      </div>
    </div>

    <!-- Novos usuários aguardando acesso (SharePoint Nexos_Usuarios) -->
    <div id="sp-pending-users-section" style="margin-bottom:24px;">
      <div style="background:#FFFBEB;border:1.5px solid #FDE68A;border-radius:12px;padding:16px 20px;">
        <div style="font-size:13px;color:#92400E;">⏳ Carregando usuários pendentes do SharePoint…</div>
      </div>
    </div>

    <!-- Estatísticas -->
    <div class="stats-grid" style="margin-bottom: 2rem;">
      <div class="stat-card warning">
        <div class="stat-value">${pendingRequests.length}</div>
        <div class="stat-label">Solicitações Pendentes</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${pendingRequests.filter(r => Date.now() - r.timestamp < 300000).length}</div>
        <div class="stat-label">Nos Últimos 5 Minutos</div>
      </div>
      <div class="stat-card error">
        <div class="stat-value">${pendingRequests.filter(r => Date.now() - r.timestamp > 600000).length}</div>
        <div class="stat-label">Mais de 10 Minutos</div>
      </div>
    </div>

    ${pendingRequests.length === 0 ? `
      <div class="info-box">
        <h3 style="margin: 0 0 0.5rem 0;">🎉 Nenhuma Aprovação Pendente</h3>
        <p style="margin: 0; color: var(--gray-600);">
          Todas as solicitações foram processadas.
        </p>
      </div>
    ` : `
      <div class="card">
        <div class="card-header">
          <div class="card-title">Solicitações Aguardando Aprovação</div>
        </div>
        <div class="table-container">
          <table class="data-table">
            <thead>
              <tr>
                <th>Solicitante</th>
                <th>Ação</th>
                <th>Descrição</th>
                <th>Há quanto tempo</th>
                <th>Expira em</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              ${pendingRequests.map(request => {
                const elapsed = Date.now() - request.timestamp;
                const timeAgo = formatTimeAgo(elapsed);
                const expiresIn = request.expiresAt - Date.now();
                const expiresInText = expiresIn > 0 ? formatTimeAgo(Math.abs(expiresIn - 900000)) : '⚠️ Expirado';
                const isExpired = expiresIn <= 0;
                
                return `
                  <tr ${isExpired ? 'style="opacity: 0.5;"' : ''}>
                    <td>
                      <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                        <strong>${request.userId}</strong>
                        ${request.userRole ? `<span class="badge badge-info" style="width: fit-content;">${window.ROLES[request.userRole]?.name || request.userRole}</span>` : ''}
                      </div>
                    </td>
                    <td><span class="badge badge-warning">${request.action}</span></td>
                    <td style="max-width: 300px;">${request.reason || '-'}</td>
                    <td style="white-space: nowrap;">${timeAgo}</td>
                    <td style="white-space: nowrap;">
                      ${isExpired ? 
                        '<span class="badge badge-error">Expirado</span>' : 
                        `<span class="badge">${expiresInText}</span>`
                      }
                    </td>
                    <td>
                      <div style="display: flex; gap: 0.5rem;">
                        <button 
                          class="btn btn-success" 
                          data-action="approveRequest" 
                          data-param="${request.id}"
                          ${isExpired ? 'disabled' : ''}
                          title="Aprovar solicitação"
                        >
                          ✅ Aprovar
                        </button>
                        <button 
                          class="btn btn-error" 
                          data-action="rejectRequest" 
                          data-param="${request.id}"
                          ${isExpired ? 'disabled' : ''}
                          title="Rejeitar solicitação"
                        >
                          ❌ Rejeitar
                        </button>
                      </div>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `}
  `;

  updateConnectionStatus(true);

  // ── Buscar usuários pendentes do SharePoint ──────────────────────────────
  const spSection = document.getElementById('sp-pending-users-section');
  if (spSection && typeof _fetchNexosUsuarios === 'function') {
    try {
      const { users } = await _fetchNexosUsuarios();
      const pending = users.filter(u => (u.Status || '').toLowerCase() === 'pendente');

      // Atualizar badge final: supervisor + SP pendentes
      const finalBadge = document.getElementById('approvals-badge');
      if (finalBadge) {
        const totalCount = pendingRequests.length + pending.length;
        finalBadge.textContent = totalCount;
        finalBadge.style.display = totalCount > 0 ? 'inline-flex' : 'none';
      }

      if (pending.length === 0) {
        spSection.innerHTML = `
          <div style="background:#ECFDF5;border:1.5px solid #A7F3D0;border-radius:12px;padding:14px 20px;
            font-size:13px;color:#065F46;">
            ✅ Nenhum usuário novo aguardando aprovação de acesso ao sistema.
          </div>`;
      } else {
        spSection.innerHTML = `
          <div style="background:#FFFBEB;border:1.5px solid #FDE68A;border-radius:12px;padding:16px 20px;">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap;">
              <span style="font-size:15px;font-weight:700;color:#92400E;">🆕 Novos Usuários Aguardando Acesso</span>
              <span style="background:#FDE68A;color:#92400E;border-radius:999px;font-size:12px;
                font-weight:700;padding:2px 10px;">${pending.length}</span>
              <span style="font-size:12px;color:#92400E;margin-left:auto;">
                Fizeram login mas ainda não têm acesso ao sistema.
              </span>
            </div>
            <div style="display:flex;flex-direction:column;gap:10px;">
              ${pending.map(u => {
                const nome  = u.NomeExibicao || u.NomeCompleto || u.Title || '—';
                const email = u.Email || '';
                const cargo = u.Cargo || '—';
                const depto = u.Departamento || '—';
                const dt    = u.DataCriacao ? new Date(u.DataCriacao).toLocaleString('pt-BR', {dateStyle:'short',timeStyle:'short'}) : '—';
                return `
                  <div style="background:#fff;border:1.5px solid #FDE68A;border-radius:10px;
                    padding:14px 16px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
                    ${typeof _adminAvatarHtml === 'function' ? _adminAvatarHtml(u, 44) : ''}
                    <div style="flex:1;min-width:200px;">
                      <div style="font-weight:700;color:#111827;font-size:14px;">${nome}</div>
                      <div style="font-size:12px;color:#6B7280;">${email}</div>
                      <div style="font-size:12px;color:#6B7280;margin-top:2px;">
                        <span>🎭 ${cargo}</span><span style="margin:0 6px;">·</span>
                        <span>🏢 ${depto}</span><span style="margin:0 6px;">·</span>
                        <span>📅 ${dt}</span>
                      </div>
                    </div>
                    <div style="display:flex;gap:8px;flex-shrink:0;">
                      <button data-action="usuarioAprovar" data-item-id="${u._itemId}" data-email="${email}"
                        style="background:#10B981;color:#fff;border:none;border-radius:8px;
                        padding:9px 20px;font-size:13px;font-weight:600;cursor:pointer;">
                        ✅ Aprovar
                      </button>
                      <button data-action="usuarioRejeitar" data-item-id="${u._itemId}" data-email="${email}"
                        style="background:#F59E0B;color:#fff;border:none;border-radius:8px;
                        padding:9px 20px;font-size:13px;font-weight:600;cursor:pointer;">
                        🚫 Rejeitar
                      </button>
                    </div>
                  </div>`;
              }).join('')}
            </div>
          </div>`;
        if (typeof _adminLoadAvatarsWithToken === 'function') {
          _adminLoadAvatarsWithToken(spSection);
        }
      }
    } catch (e) {
      spSection.innerHTML = `
        <div style="background:#FEF2F2;border:1.5px solid #FECACA;border-radius:12px;padding:14px 20px;
          font-size:13px;color:#B91C1C;">
          ⚠️ Não foi possível carregar usuários pendentes: ${e.message}
        </div>`;
    }
  } else if (spSection) {
    spSection.innerHTML = '';
  }
}

/**
 * Formata tempo decorrido em texto legível
 */
function formatTimeAgo(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days}d ${hours % 24}h`;
  if (hours > 0) return `${hours}h ${minutes % 60}m`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
  return `${seconds}s`;
}

// ===================================================================
// PAINEL: HISTÓRICO DE APROVAÇÕES
// ===================================================================

// Estado dos filtros de histórico
let historyFilters = {
  user: '',
  supervisor: '',
  status: '',
  dateFrom: '',
  dateTo: ''
};

async function renderApprovalHistoryPanel() {
  const container = document.getElementById('content-area');
  if (!container) {
    console.error('[Admin] ❌ Elemento content-area não encontrado');
    return;
  }

  console.log('[Admin] 📜 Renderizando painel de histórico de aprovações');

  // Verificar permissão
  if (!window.permissionManager?.hasPermission('view_approval_history')) {
    container.innerHTML = `
      <div class="error-panel">
        <h2>❌ Acesso Negado</h2>
        <p>Você não tem permissão para visualizar o histórico de aprovações.</p>
        <p>Permissão necessária: <code>view_approval_history</code></p>
      </div>
    `;
    return;
  }

  // Garantir que SupervisionManager está inicializado
  if (!window.supervisionManager) {
    container.innerHTML = `
      <div class="error-panel">
        <h2>⚠️ Sistema de Supervisão Indisponível</h2>
        <p>O SupervisionManager não foi inicializado.</p>
        <button class="btn btn-primary" onclick="location.reload()">Recarregar</button>
      </div>
    `;
    return;
  }

  // Buscar histórico completo
  const history = await window.supervisionManager.getApprovalHistory();
  
  // Aplicar filtros
  let filteredHistory = history;
  
  if (historyFilters.user) {
    filteredHistory = filteredHistory.filter(h => 
      h.user?.toLowerCase().includes(historyFilters.user.toLowerCase())
    );
  }
  
  if (historyFilters.supervisor) {
    filteredHistory = filteredHistory.filter(h => 
      h.approver?.toLowerCase().includes(historyFilters.supervisor.toLowerCase())
    );
  }
  
  if (historyFilters.status) {
    filteredHistory = filteredHistory.filter(h => h.status === historyFilters.status);
  }
  
  if (historyFilters.dateFrom) {
    const fromDate = new Date(historyFilters.dateFrom).getTime();
    filteredHistory = filteredHistory.filter(h => h.timestamp >= fromDate);
  }
  
  if (historyFilters.dateTo) {
    const toDate = new Date(historyFilters.dateTo).getTime() + (24 * 60 * 60 * 1000); // Até o fim do dia
    filteredHistory = filteredHistory.filter(h => h.timestamp <= toDate);
  }
  
  // Estatísticas
  const stats = {
    total: history.length,
    approved: history.filter(h => h.status === 'approved').length,
    rejected: history.filter(h => h.status === 'rejected').length,
    expired: history.filter(h => h.status === 'expired').length,
    filtered: filteredHistory.length
  };

  container.innerHTML = `
    <div class="panel-header">
      <div>
        <h2>📜 Histórico de Aprovações</h2>
        <p class="subtitle">Registro completo de todas as solicitações processadas</p>
      </div>
      <div class="panel-actions">
        <button class="btn btn-secondary" data-action="refreshHistory">
          🔄 Atualizar
        </button>
        <button class="btn btn-success" data-action="exportHistoryCSV">
          📥 Exportar CSV
        </button>
      </div>
    </div>

    <!-- Estatísticas -->
    <div class="stats-grid" style="margin-bottom: 2rem;">
      <div class="stat-card">
        <div class="stat-value">${stats.total}</div>
        <div class="stat-label">Total de Solicitações</div>
      </div>
      <div class="stat-card success">
        <div class="stat-value">${stats.approved}</div>
        <div class="stat-label">Aprovadas</div>
      </div>
      <div class="stat-card error">
        <div class="stat-value">${stats.rejected}</div>
        <div class="stat-label">Rejeitadas</div>
      </div>
      <div class="stat-card warning">
        <div class="stat-value">${stats.expired}</div>
        <div class="stat-label">Expiradas</div>
      </div>
    </div>

    <!-- Filtros -->
    <div class="card" style="margin-bottom: 1.5rem;">
      <div class="card-header">
        <div class="card-title">Filtros</div>
      </div>
      <div class="filters">
        <div class="filter-group">
          <label>Usuário</label>
          <input 
            type="text" 
            id="filter-history-user" 
            placeholder="Email do usuário..."
            value="${historyFilters.user}"
          >
        </div>
        <div class="filter-group">
          <label>Supervisor</label>
          <input 
            type="text" 
            id="filter-history-supervisor" 
            placeholder="Email do supervisor..."
            value="${historyFilters.supervisor}"
          >
        </div>
        <div class="filter-group">
          <label>Status</label>
          <select id="filter-history-status">
            <option value="">Todos</option>
            <option value="approved" ${historyFilters.status === 'approved' ? 'selected' : ''}>Aprovado</option>
            <option value="rejected" ${historyFilters.status === 'rejected' ? 'selected' : ''}>Rejeitado</option>
            <option value="expired" ${historyFilters.status === 'expired' ? 'selected' : ''}>Expirado</option>
          </select>
        </div>
        <div class="filter-group">
          <label>Data Início</label>
          <input 
            type="date" 
            id="filter-history-date-from"
            value="${historyFilters.dateFrom}"
          >
        </div>
        <div class="filter-group">
          <label>Data Fim</label>
          <input 
            type="date" 
            id="filter-history-date-to"
            value="${historyFilters.dateTo}"
          >
        </div>
        <div class="filter-group">
          <label>&nbsp;</label>
          <button class="btn-primary" data-action="applyHistoryFilters">Aplicar</button>
        </div>
        <div class="filter-group">
          <label>&nbsp;</label>
          <button class="btn-secondary" data-action="clearHistoryFilters">Limpar</button>
        </div>
      </div>
    </div>

    ${filteredHistory.length === 0 ? `
      <div class="info-box">
        <h3 style="margin: 0 0 0.5rem 0;">📭 Nenhum Registro Encontrado</h3>
        <p style="margin: 0; color: var(--gray-600);">
          ${history.length === 0 ? 
            'Ainda não há aprovações registradas no sistema.' : 
            'Nenhum registro corresponde aos filtros aplicados.'}
        </p>
      </div>
    ` : `
      <div class="card">
        <div class="card-header">
          <div class="card-title">Histórico (${stats.filtered} registros)</div>
        </div>
        <div class="table-container">
          <table class="data-table">
            <thead>
              <tr>
                <th>Data/Hora</th>
                <th>Usuário</th>
                <th>Ação</th>
                <th>Status</th>
                <th>Processado Por</th>
                <th>Tempo de Resposta</th>
                <th>Motivo</th>
              </tr>
            </thead>
            <tbody>
              ${filteredHistory.map(record => {
                const statusBadge = {
                  'approved': 'success',
                  'rejected': 'error',
                  'expired': 'warning'
                }[record.status] || '';
                
                const statusText = {
                  'approved': '✅ Aprovado',
                  'rejected': '❌ Rejeitado',
                  'expired': '⏱️ Expirado'
                }[record.status] || record.status;
                
                const processedBy = record.approver || '-';
                const processedTime = record.approvedAt || record.rejectedAt;
                const responseTime = processedTime ? 
                  formatTimeAgo(processedTime - record.timestamp) : '-';
                
                // Buscar role do usuário
                const userRole = window.userRoleManager?.getUserRole(record.user);
                const roleName = userRole ? (window.ROLES[userRole]?.name || userRole) : null;
                
                return `
                  <tr>
                    <td style="white-space: nowrap;">${formatTimestamp(record.timestamp)}</td>
                    <td>
                      <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                        <span>${record.user}</span>
                        ${roleName ? `<span class="badge badge-info" style="width: fit-content; font-size: 0.75rem;">${roleName}</span>` : ''}
                      </div>
                    </td>
                    <td><span class="badge">${record.action}</span></td>
                    <td><span class="badge badge-${statusBadge}">${statusText}</span></td>
                    <td>${processedBy}</td>
                    <td style="white-space: nowrap;">${responseTime}</td>
                    <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis;">
                      ${record.rejectionReason || '-'}
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `}
  `;

  updateConnectionStatus(true);
}

/**
 * Aplica filtros no histórico
 */
async function applyHistoryFilters() {
  historyFilters = {
    user: document.getElementById('filter-history-user')?.value || '',
    supervisor: document.getElementById('filter-history-supervisor')?.value || '',
    status: document.getElementById('filter-history-status')?.value || '',
    dateFrom: document.getElementById('filter-history-date-from')?.value || '',
    dateTo: document.getElementById('filter-history-date-to')?.value || ''
  };
  
  await renderApprovalHistoryPanel();
}

/**
 * Limpa filtros do histórico
 */
async function clearHistoryFilters() {
  historyFilters = {
    user: '',
    supervisor: '',
    status: '',
    dateFrom: '',
    dateTo: ''
  };
  
  document.getElementById('filter-history-user').value = '';
  document.getElementById('filter-history-supervisor').value = '';
  document.getElementById('filter-history-status').value = '';
  document.getElementById('filter-history-date-from').value = '';
  document.getElementById('filter-history-date-to').value = '';
  
  await renderApprovalHistoryPanel();
}

/**
 * Exporta histórico para CSV
 */
async function exportHistoryCSV() {
  if (!window.supervisionManager) {
    alert('❌ SupervisionManager não disponível');
    return;
  }
  
  const history = await window.supervisionManager.getApprovalHistory();
  
  // Aplicar mesmos filtros
  let filteredHistory = history;
  
  if (historyFilters.user) {
    filteredHistory = filteredHistory.filter(h => 
      h.user?.toLowerCase().includes(historyFilters.user.toLowerCase())
    );
  }
  
  if (historyFilters.supervisor) {
    filteredHistory = filteredHistory.filter(h => 
      h.approver?.toLowerCase().includes(historyFilters.supervisor.toLowerCase())
    );
  }
  
  if (historyFilters.status) {
    filteredHistory = filteredHistory.filter(h => h.status === historyFilters.status);
  }
  
  if (historyFilters.dateFrom) {
    const fromDate = new Date(historyFilters.dateFrom).getTime();
    filteredHistory = filteredHistory.filter(h => h.timestamp >= fromDate);
  }
  
  if (historyFilters.dateTo) {
    const toDate = new Date(historyFilters.dateTo).getTime() + (24 * 60 * 60 * 1000);
    filteredHistory = filteredHistory.filter(h => h.timestamp <= toDate);
  }
  
  const csv = [
    ['Data/Hora', 'Usuário', 'Cargo', 'Ação', 'Status', 'Processado Por', 'Tempo de Resposta', 'Motivo/Descrição'],
    ...filteredHistory.map(record => {
      const statusText = {
        'approved': 'Aprovado',
        'rejected': 'Rejeitado',
        'expired': 'Expirado'
      }[record.status] || record.status;
      
      const processedBy = record.approver || '-';
      const processedTime = record.approvedAt || record.rejectedAt;
      const responseTime = processedTime ? 
        formatTimeAgo(processedTime - record.timestamp) : '-';
      
      const userRole = window.userRoleManager?.getUserRole(record.user);
      const roleName = userRole ? (window.ROLES[userRole]?.name || userRole) : '-';
      
      return [
        new Date(record.timestamp).toLocaleString('pt-BR'),
        record.user,
        roleName,
        record.action,
        statusText,
        processedBy,
        responseTime,
        record.rejectionReason || '-'
      ];
    })
  ].map(row => row.map(cell => '"' + String(cell).replace(/"/g, '""') + '"').join(',')).join('\n');
  
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' }); // BOM para Excel
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `historico-aprovacoes-${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
  
  // Log
  if (window.logManager) {
    await window.logManager.info('admin', 'history_export', 
      `Admin ${window.currentUserEmail} exportou ${filteredHistory.length} registros de aprovações`);
  }
  
  // Notificar
  if (window.notificationManager) {
    await window.notificationManager.notifySuccess(
      'Histórico Exportado',
      `${filteredHistory.length} registros foram exportados para CSV.`
    );
  }
}

// =============================
// Event Delegation (Fix CSP)
// =============================
document.addEventListener('click', async (e) => {
  const button = e.target.closest('button[data-action]');
  
  // Log apenas botões com data-action (reduz poluição do console)
  if (!button) {
    return; // Silencioso: é normal clicar em botões sem data-action
  }
  
  const clickedBtn = e.target.closest('button') || e.target;
  console.log('[Admin][Click] Botão com data-action clicado:', clickedBtn.dataset.action);

  const action = button.dataset.action;
  const param = button.dataset.param;
  
  console.log('[Admin][EventDelegation] Action:', action, 'Param:', param);

  // Logs Panel Actions
  if (action === 'applyLogFilters') {
    console.log('[Admin] Botão "Aplicar Filtros" clicado');
    if (typeof window.applyLogFilters === 'function') {
      await window.applyLogFilters();
    } else {
      console.error('[Admin] Função window.applyLogFilters não encontrada');
    }
  } else if (action === 'clearLogFilters') {
    console.log('[Admin] Botão "Limpar Filtros" clicado');
    if (typeof window.clearLogFilters === 'function') {
      await window.clearLogFilters();
    } else {
      console.error('[Admin] Função window.clearLogFilters não encontrada');
    }
  } else if (action === 'exportLogsCSV') {
    console.log('[Admin] Botão "Exportar CSV" clicado');
    if (typeof window.exportLogsCSV === 'function') {
      await window.exportLogsCSV();
    } else {
      console.error('[Admin] Função window.exportLogsCSV não encontrada');
    }
  } else if (action === 'viewLogMetadata') {
    console.log('[Admin] Botão "Ver Metadados" clicado, log:', param);
    if (typeof window.viewLogMetadata === 'function') {
      window.viewLogMetadata(param);
    } else {
      console.error('[Admin] Função window.viewLogMetadata não encontrada');
    }
  } else if (action === 'prevLogPage') {
    console.log('[Admin] Botão "Anterior" clicado');
    if (logsCurrentPage > 1) {
      await changePage(logsCurrentPage - 1);
    }
  } else if (action === 'nextLogPage') {
    console.log('[Admin] Botão "Próxima" clicado');
    await changePage(logsCurrentPage + 1);
  } else if (action === 'gotoLogPage') {
    console.log('[Admin] Botão página clicado:', param);
    await changePage(parseInt(param));
  }
  // Overview Panel Actions
  else if (action === 'retryOverview') {
    console.log('[Admin] Botão "Tentar Novamente" clicado');
    await window.loadPanel('overview');
  }
  // Users Panel Actions
  else if (action === 'viewUserLogs') {
    if (typeof window.viewUserLogs === 'function') window.viewUserLogs(param);
  }
  // User Management Panel Actions
  else if (action === 'exportUsersJSON') {
    if (typeof window.exportUsersToJSON === 'function') window.exportUsersToJSON();
  }
  else if (action === 'showAddUserModal') {
    if (typeof window.showAddUserModal === 'function') window.showAddUserModal();
  }
  else if (action === 'showEditUserModal') {
    if (typeof window.showEditUserModal === 'function') window.showEditUserModal(param);
  }
  else if (action === 'removeUserRole') {
    if (typeof window.removeUserRole === 'function') await window.removeUserRole(param);
  }
  else if (action === 'closeModal') {
    button.closest('.nexos-overlay')?.remove();
  }
  else if (action === 'saveNewUser') {
    if (typeof window.saveNewUser === 'function') await window.saveNewUser();
  }
  else if (action === 'saveEditedUser') {
    if (typeof window.saveEditedUser === 'function') await window.saveEditedUser(param);
  }
  else if (action === 'showAssignSupervisorModal') {
    if (typeof window.showAssignSupervisorModal === 'function') await window.showAssignSupervisorModal(param);
  }
  else if (action === 'saveSupervisor') {
    if (typeof window.saveSupervisor === 'function') await window.saveSupervisor(param);
  }
  // Approvals Panel Actions
  else if (action === 'refreshApprovals') {
    await renderApprovalsPanel();
  }
  else if (action === 'switchPanel') {
    await window.loadPanel(param);
  }
  // User Management — Atualizar
  else if (action === 'refreshUserManagement') {
    await renderUserManagementPanel();
  }
  // User Management — Filtros
  else if (action === 'filterUsuarios') {
    window._usuariosFilter = param;
    await renderUserManagementPanel();
  }
  // User Management — Aprovar usuário SP
  else if (action === 'usuarioAprovar') {
    const itemId = button.dataset.itemId;
    const email  = button.dataset.email;
    if (typeof _usuariosAction === 'function') await _usuariosAction('approve', itemId, email);
  }
  // User Management — Rejeitar/Revogar usuário SP
  else if (action === 'usuarioRejeitar') {
    const itemId = button.dataset.itemId;
    const email  = button.dataset.email;
    if (typeof _usuariosAction === 'function') await _usuariosAction('reject', itemId, email);
  }
  // User Management — Remover usuário SP
  else if (action === 'usuarioRemover') {
    const itemId = button.dataset.itemId;
    const nome   = button.dataset.nome;
    const email  = button.dataset.email;
    if (typeof _usuariosConfirmRemove === 'function') _usuariosConfirmRemove(itemId, nome, email);
  }
  // User Management — Fechar modal de confirmação de remoção
  else if (action === 'closeRmUserModal') {
    const modal = document.getElementById('rm-user-modal');
    if (modal) modal.style.display = 'none';
  }
  // Approval History Actions
  else if (action === 'refreshHistory') {
    await renderApprovalHistoryPanel();
  }
  else if (action === 'applyHistoryFilters') {
    await applyHistoryFilters();
  }
  else if (action === 'clearHistoryFilters') {
    await clearHistoryFilters();
  }
  else if (action === 'exportHistoryCSV') {
    await exportHistoryCSV();
  }
  else if (action === 'approveRequest') {
    if (window.supervisionManager) {
      try {
        const success = await window.supervisionManager.approveRequest(
          param, 
          window.currentUserEmail || ''
        );
        
        if (success) {
          // Notificar sucesso
          if (window.notificationManager) {
            await window.notificationManager.notifySuccess(
              'Solicitação Aprovada',
              'A solicitação foi aprovada com sucesso!'
            );
          }
          
          // Log
          if (window.logManager) {
            await window.logManager.info('admin', 'approval_granted', `Solicitação ${param} aprovada`);
          }
          
          // Recarregar painel
          await renderApprovalsPanel();
        } else {
          alert('❌ Erro ao aprovar solicitação. Verifique suas permissões.');
        }
      } catch (error) {
        console.error('[Admin] Erro ao aprovar:', error);
        alert('❌ Erro ao aprovar: ' + error.message);
      }
    }
  }
  else if (action === 'rejectRequest') {
    if (window.supervisionManager) {
      const reason = prompt('Motivo da rejeição (opcional):');
      if (reason === null) return; // Cancelou
      
      try {
        const success = await window.supervisionManager.rejectRequest(
          param, 
          window.currentUserEmail || '', 
          reason || 'Não especificado'
        );
        
        if (success) {
          // Notificar
          if (window.notificationManager) {
            await window.notificationManager.notifyWarning(
              'Solicitação Rejeitada',
              'A solicitação foi rejeitada.'
            );
          }
          
          // Log
          if (window.logManager) {
            await window.logManager.info('admin', 'approval_rejected', `Solicitação ${param} rejeitada`);
          }
          
          // Recarregar painel
          await renderApprovalsPanel();
        } else {
          alert('❌ Erro ao rejeitar solicitação. Verifique suas permissões.');
        }
      } catch (error) {
        console.error('[Admin] Erro ao rejeitar:', error);
        alert('❌ Erro ao rejeitar: ' + error.message);
      }
    }
  }
  // Statistics Panel Actions (definidas em admin-panels.js)
  else if (action === 'setStatsPeriod') {
    if (typeof setStatsPeriod === 'function') {
      setStatsPeriod(parseInt(param));
    }
  }
  // Storage Panel Actions (definidas em admin-panels.js)
  else if (action === 'forceSync') {
    if (typeof forceSync === 'function') {
      await forceSync();
    }
  } else if (action === 'cleanOldLogs') {
    if (typeof cleanOldLogs === 'function') {
      await cleanOldLogs();
    }
  } else if (action === 'backupData') {
    if (typeof backupData === 'function') {
      await backupData();
    }
  } else if (action === 'clearCache') {
    if (typeof clearCache === 'function') {
      await clearCache();
    }
  } else if (action === 'viewStorageValue') {
    if (typeof viewStorageValue === 'function') {
      viewStorageValue(param);
    }
  } else if (action === 'deleteStorageKey') {
    if (typeof deleteStorageKey === 'function') {
      await deleteStorageKey(param);
    }
  }
  // Alerts Panel Actions
  else if (action === 'markAlertRead') {
    if (typeof markAlertRead === 'function') {
      await markAlertRead(param);
    }
  } else if (action === 'markAllAlertsRead') {
    if (typeof markAllAlertsRead === 'function') {
      await markAllAlertsRead();
    }
  } else if (action === 'viewAlertDetails') {
    if (typeof viewAlertDetails === 'function') {
      viewAlertDetails(param);
    }
  }
  // Settings Panel Actions
  else if (action === 'saveSettings') {
    if (typeof saveSettings === 'function') {
      await saveSettings();
    }
  } else if (action === 'addAdmin') {
    if (typeof addAdmin === 'function') {
      addAdmin();
    }
  } else if (action === 'removeAdmin') {
    if (typeof removeAdmin === 'function') {
      removeAdmin(param);
    }
  }
  // SharePoint Setup Actions
  else if (action === 'createCompletedOrdersList') {
    await createCompletedOrdersList();
  } else if (action === 'addSampleData') {
    await addSampleDataToList(param);
  } else if (action === 'testListConnection') {
    await testListConnection(param);
  }
}); // Fecha document.addEventListener('click')

}); // Fecha document.addEventListener('DOMContentLoaded')

// ==================== SharePoint Setup Panel ====================

async function renderSharePointSetupPanel() {
  const contentArea = document.getElementById('content-area');
  
  contentArea.innerHTML = `
    <div class="panel-section">
      <div class="section-header">
        <h2>🔧 Setup SharePoint - Dashboard Financeiro</h2>
        <p>Configure a lista Nexos_PedidosConcluidos necessária para o Dashboard Financeiro da v2.2.2</p>
      </div>

      <div class="card" id="setup-status-card">
        <div class="card-header">
          <h3>📊 Status do Setup</h3>
        </div>
        <div class="card-body">
          <div class="status-item">
            <span class="status-label">SharePoint Site:</span>
            <span class="status-value">https://gpabr.sharepoint.com/sites/Nexos</span>
          </div>
          <div class="status-item">
            <span class="status-label">Lista Nexos_PedidosConcluidos:</span>
            <span class="status-value" id="list-status">
              <span class="loading-inline">Verificando...</span>
            </span>
          </div>
          <div id="list-details" style="display: none; margin-top: 1rem; padding: 1rem; background: var(--bg-secondary); border-radius: 8px;">
            <!-- Detalhes da lista serão inseridos aqui -->
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h3>🚀 Ações de Setup</h3>
        </div>
        <div class="card-body">
          <div class="alert alert-info">
            <strong>ℹ️ Informação:</strong> Esta ferramenta criará automaticamente a lista SharePoint com todos os campos necessários para o Dashboard Financeiro.
          </div>

          <div class="action-buttons" style="display: flex; gap: 1rem; margin-top: 1.5rem; flex-wrap: wrap;">
            <button class="btn btn-primary" data-action="createCompletedOrdersList" style="flex: 1; min-width: 200px;">
              <span class="btn-icon">🔨</span>
              <span>Criar Lista SharePoint</span>
            </button>
            <button class="btn btn-secondary" id="add-sample-btn" disabled style="flex: 1; min-width: 200px;">
              <span class="btn-icon">📝</span>
              <span>Adicionar Dados de Exemplo</span>
            </button>
            <button class="btn btn-secondary" id="test-connection-btn" disabled style="flex: 1; min-width: 200px;">
              <span class="btn-icon">🔗</span>
              <span>Testar Conexão</span>
            </button>
          </div>

          <div id="setup-progress" style="display: none; margin-top: 2rem;">
            <h4>📈 Progresso</h4>
            <div class="progress-bar" style="width: 100%; height: 24px; background: var(--bg-secondary); border-radius: 12px; overflow: hidden; margin-top: 0.5rem;">
              <div id="progress-fill" style="width: 0%; height: 100%; background: linear-gradient(90deg, var(--primary), var(--accent)); transition: width 0.3s;"></div>
            </div>
            <p id="progress-text" style="margin-top: 0.5rem; font-size: 0.875rem; color: var(--text-secondary);"></p>
          </div>

          <div id="setup-log" style="display: none; margin-top: 2rem;">
            <h4>📋 Log de Operações</h4>
            <div style="background: var(--bg-secondary); border-radius: 8px; padding: 1rem; max-height: 300px; overflow-y: auto; font-family: 'Courier New', monospace; font-size: 0.875rem;">
              <pre id="log-content" style="margin: 0; color: var(--text-primary);"></pre>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h3>📚 Documentação</h3>
        </div>
        <div class="card-body">
          <div class="doc-links">
            <a href="#" onclick="alert('Abrir: SHAREPOINT_SETUP.md'); return false;" class="doc-link">
              📄 SHAREPOINT_SETUP.md - Guia Completo de Setup
            </a>
            <a href="#" onclick="alert('Abrir: SHAREPOINT_MANUAL_SETUP.md'); return false;" class="doc-link">
              🛠️ SHAREPOINT_MANUAL_SETUP.md - Setup Manual (Alternativa)
            </a>
            <a href="#" onclick="alert('Abrir: SHAREPOINT_GRAPH_API.md'); return false;" class="doc-link">
              🔧 SHAREPOINT_GRAPH_API.md - Detalhes da API Graph
            </a>
          </div>
        </div>
      </div>
    </div>
  `;

  // Verificar status da lista
  await checkListStatus();
}

async function checkListStatus() {
  const statusElement = document.getElementById('list-status');
  const detailsElement = document.getElementById('list-details');
  
  try {
    if (!window.graphClient) {
      throw new Error('GraphClient não inicializado');
    }

    const siteId = await window.graphClient._resolveSiteId();
    const listsResponse = await window.graphClient._makeRequest(
      `${window.graphClient.baseUrl}/sites/${siteId}/lists`
    );
    
    const existingList = listsResponse.value?.find(l => l.name === 'Nexos_PedidosConcluidos');
    
    if (existingList) {
      statusElement.innerHTML = '<span style="color: var(--success);">✅ Lista encontrada</span>';
      
      // Mostrar detalhes
      detailsElement.style.display = 'block';
      detailsElement.innerHTML = `
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
          <div>
            <strong>List ID:</strong><br>
            <code style="font-size: 0.75rem; word-break: break-all;">${existingList.id}</code>
          </div>
          <div>
            <strong>Criada em:</strong><br>
            ${new Date(existingList.createdDateTime).toLocaleString('pt-BR')}
          </div>
          <div>
            <strong>Status:</strong><br>
            <span style="color: var(--success);">✅ Pronta para uso</span>
          </div>
        </div>
      `;
      
      // Habilitar botões
      document.getElementById('add-sample-btn').disabled = false;
      document.getElementById('add-sample-btn').dataset.action = 'addSampleData';
      document.getElementById('add-sample-btn').dataset.param = existingList.id;
      
      document.getElementById('test-connection-btn').disabled = false;
      document.getElementById('test-connection-btn').dataset.action = 'testListConnection';
      document.getElementById('test-connection-btn').dataset.param = existingList.id;
      
    } else {
      statusElement.innerHTML = '<span style="color: var(--warning);">⚠️ Lista não encontrada</span>';
      detailsElement.style.display = 'none';
    }
    
  } catch (error) {
    console.error('[SharePointSetup] Erro ao verificar lista:', error);
    statusElement.innerHTML = `<span style="color: var(--error);">❌ Erro: ${error.message}</span>`;
    detailsElement.style.display = 'none';
  }
}

async function createCompletedOrdersList() {
  const progressDiv = document.getElementById('setup-progress');
  const logDiv = document.getElementById('setup-log');
  const logContent = document.getElementById('log-content');
  const progressFill = document.getElementById('progress-fill');
  const progressText = document.getElementById('progress-text');
  
  // Mostrar UI de progresso
  progressDiv.style.display = 'block';
  logDiv.style.display = 'block';
  logContent.textContent = '';
  
  function addLog(message, type = 'info') {
    const timestamp = new Date().toLocaleTimeString('pt-BR');
    const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : type === 'warning' ? '⚠️' : 'ℹ️';
    logContent.textContent += `[${timestamp}] ${icon} ${message}\n`;
    logDiv.scrollTop = logDiv.scrollHeight;
  }
  
  function setProgress(percent, text) {
    progressFill.style.width = `${percent}%`;
    progressText.textContent = text;
  }
  
  try {
    addLog('Iniciando criação da lista Nexos_PedidosConcluidos...');
    setProgress(10, 'Conectando ao SharePoint...');
    
    if (!window.graphClient) {
      throw new Error('GraphClient não está disponível');
    }
    
    addLog('GraphClient encontrado, iniciando processo...');
    setProgress(20, 'Resolvendo Site ID...');
    
    const result = await window.graphClient.createCompletedOrdersList();
    
    setProgress(90, 'Finalizando...');
    addLog(`Status: ${result.status}`, result.status === 'created' ? 'success' : 'warning');
    addLog(result.message, result.status === 'created' ? 'success' : 'warning');
    
    if (result.stats) {
      addLog(`Campos adicionados: ${result.stats.fieldsAdded}`);
      addLog(`Campos pulados: ${result.stats.fieldsSkipped}`);
      if (result.stats.errors > 0) {
        addLog(`Erros: ${result.stats.errors}`, 'warning');
      }
    }
    
    if (result.errors && result.errors.length > 0) {
      addLog('Detalhes dos erros:', 'warning');
      result.errors.forEach(err => {
        addLog(`  - ${err.field}: ${err.error}`, 'error');
      });
    }
    
    setProgress(100, '✅ Concluído!');
    addLog('Processo finalizado com sucesso!', 'success');
    
    // Atualizar status
    setTimeout(() => {
      checkListStatus();
    }, 1000);
    
  } catch (error) {
    console.error('[SharePointSetup] Erro:', error);
    addLog(`ERRO: ${error.message}`, 'error');
    setProgress(0, '❌ Falhou');
    alert(`❌ Erro ao criar lista:\n${error.message}`);
  }
}

async function addSampleDataToList(listId) {
  const logDiv = document.getElementById('setup-log');
  const logContent = document.getElementById('log-content');
  
  logDiv.style.display = 'block';
  
  function addLog(message, type = 'info') {
    const timestamp = new Date().toLocaleTimeString('pt-BR');
    const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';
    logContent.textContent += `[${timestamp}] ${icon} ${message}\n`;
    logDiv.scrollTop = logDiv.scrollHeight;
  }
  
  try {
    addLog('Adicionando pedido de exemplo...');
    
    const result = await window.graphClient.addSampleCompletedOrder(listId);
    
    addLog('Pedido de exemplo adicionado com sucesso!', 'success');
    addLog(`Item ID: ${result.id}`);
    
    alert('✅ Pedido de exemplo adicionado com sucesso!');
    
  } catch (error) {
    console.error('[SharePointSetup] Erro ao adicionar exemplo:', error);
    addLog(`ERRO: ${error.message}`, 'error');
    alert(`❌ Erro ao adicionar exemplo:\n${error.message}`);
  }
}

async function testListConnection(listId) {
  const logDiv = document.getElementById('setup-log');
  const logContent = document.getElementById('log-content');
  
  logDiv.style.display = 'block';
  
  function addLog(message, type = 'info') {
    const timestamp = new Date().toLocaleTimeString('pt-BR');
    const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';
    logContent.textContent += `[${timestamp}] ${icon} ${message}\n`;
    logDiv.scrollTop = logDiv.scrollHeight;
  }
  
  try {
    addLog('Testando conexão com a lista...');
    
    const siteId = await window.graphClient._resolveSiteId();
    addLog(`Site ID: ${siteId}`);
    
    // Buscar itens da lista
    const itemsResponse = await window.graphClient._makeRequest(
      `${window.graphClient.baseUrl}/sites/${siteId}/lists/${listId}/items?$expand=fields&$top=5`
    );
    
    const itemCount = itemsResponse.value?.length || 0;
    addLog(`Total de itens na lista: ${itemCount}`, 'success');
    
    if (itemCount > 0) {
      addLog('Primeiros itens encontrados:');
      itemsResponse.value.slice(0, 3).forEach((item, index) => {
        const fields = item.fields;
        addLog(`  ${index + 1}. ${fields.PedidoID || 'Sem ID'} - ${fields.Plataforma || 'Sem plataforma'} - R$ ${fields.CustoEntrega || 0}`);
      });
    }
    
    addLog('Conexão testada com sucesso!', 'success');
    alert('✅ Conexão OK!\n\nA lista está acessível e pronta para uso.');
    
  } catch (error) {
    console.error('[SharePointSetup] Erro ao testar conexão:', error);
    addLog(`ERRO: ${error.message}`, 'error');
    alert(`❌ Erro ao testar conexão:\n${error.message}`);
  }
}
