'use strict';

// ════════════════════════════════════════════════
// LOGGER — console + UI log panel
// ════════════════════════════════════════════════
const LOG = (() => {
  const entries = [];
  const body = document.getElementById('log-body');
  const countEl = document.getElementById('log-count');

  function add(type, args) {
    const msg = args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' ');
    const time = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    entries.push({ type, msg, time });

    // Limitar array E DOM ao mesmo teto (200 entradas)
    const MAX_LOG = 200;
    if (entries.length > MAX_LOG) {
      entries.shift();
      if (body && body.firstChild) body.removeChild(body.firstChild);
    }

    if (!body || !countEl) return;

    const div = document.createElement('div');
    div.className = 'log-entry';
    div.innerHTML = `<span style="color:var(--muted)">${time}</span><span class="l-${type}">[${type.toUpperCase()}]</span>${escapeHtml(msg)}`;
    body.appendChild(div);
    body.scrollTop = body.scrollHeight;
    countEl.textContent = `${entries.length} entradas`;
  }

  return {
    info: (...a) => { console.log('%c[MONITOR]', 'color:#818cf8;font-weight:bold', ...a); add('info', a); },
    ok: (...a) => { console.log('%c[✓ OK]', 'color:#34d399;font-weight:bold', ...a); add('ok', a); },
    warn: (...a) => { console.warn('%c[⚠ WARN]', 'color:#fbbf24;font-weight:bold', ...a); add('warn', a); },
    error: (...a) => { console.error('%c[✕ ERROR]', 'color:#f87171;font-weight:bold', ...a); add('err', a); },
    api: (...a) => { console.log('%c[API]', 'color:#60a5fa;font-weight:bold', ...a); add('api', a); },
    sp: (...a) => { console.log('%c[SHAREPOINT]', 'color:#60c3fb;font-weight:bold', ...a); add('sp', a); },
    pk: (...a) => { console.log('%c[PICKING]', 'color:#a78bfa;font-weight:bold', ...a); add('pk', a); },
  };
})();

function escapeHtml(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function clearLogs() {
  const body = document.getElementById('log-body');
  const count = document.getElementById('log-count');
  if (body) body.innerHTML = '';
  if (count) count.textContent = '0 entradas';
}

function toggleLog() {
  document.getElementById('log-panel')?.classList.toggle('open');
}

// ════════════════════════════════════════════════
// STATE
// ════════════════════════════════════════════════
let orders = [];
let tratativas = {};
// Acumulador persistido no localStorage — sobrevive ao polling e ao reload
const ACUM_KEY = 'monitor_acum_v1';
let _totalAcumuladoHoje = (() => {
  try {
    const saved = JSON.parse(localStorage.getItem(ACUM_KEY) || '{}');
    const hoje = new Date().toDateString();
    if (saved.dia === hoje && Array.isArray(saved.ids)) return new Set(saved.ids);
  } catch (_) {}
  return new Set();
})();
let _totalAcumuladoDia = new Date().toDateString();

function _salvarAcumulado() {
  try {
    localStorage.setItem(ACUM_KEY, JSON.stringify({ dia: _totalAcumuladoDia, ids: [..._totalAcumuladoHoje] }));
  } catch (_) {}
}
function _registrarNoAcumulado(ids) {
  const hoje = new Date().toDateString();
  if (_totalAcumuladoDia !== hoje) {
    _totalAcumuladoHoje.clear();
    _totalAcumuladoDia = hoje;
  }
  ids.forEach(id => _totalAcumuladoHoje.add(id));
  _salvarAcumulado();
}

// ── Cache de pedidos resolvidos (objetos completos) ───────────────────────
// Persiste no sessionStorage durante o dia para que pedidos resolvidos
// continuem visíveis mesmo após saírem da query ativa da Instaleap.
const RESOLVIDOS_KEY = 'monitor_resolvidos_v1';

function _carregarCacheResolvidos() {
  try {
    const saved = JSON.parse(sessionStorage.getItem(RESOLVIDOS_KEY) || '{}');
    const hoje = new Date().toDateString();
    if (saved.dia === hoje && Array.isArray(saved.pedidos)) return saved.pedidos;
  } catch (_) {}
  return [];
}

function _salvarCacheResolvidos(pedidos) {
  try {
    sessionStorage.setItem(RESOLVIDOS_KEY, JSON.stringify({
      dia: new Date().toDateString(),
      pedidos,
    }));
  } catch (_) {}
}

// Mapa em memória: jobId → objeto do pedido (para renderização)
let _cacheResolvidos = Object.fromEntries(
  _carregarCacheResolvidos().map(o => [o.jobId, o])
);

function _registrarResolvidosCache(pedidosArray) {
  let mudou = false;
  pedidosArray.forEach(o => {
    if (!_cacheResolvidos[o.jobId]) {
      _cacheResolvidos[o.jobId] = o;
      mudou = true;
    }
  });
  if (mudou) _salvarCacheResolvidos(Object.values(_cacheResolvidos));
}

function _limparResolvidosCacheSeNecessario() {
  // Remove do cache pedidos que voltaram a ter status ativo (reabertos)
  Object.keys(_cacheResolvidos).forEach(id => {
    const t = tratativas[id];
    if (t && t.status !== 'Resolvido' && t.status !== 'Sem ação necessária') {
      delete _cacheResolvidos[id];
    }
  });
  _salvarCacheResolvidos(Object.values(_cacheResolvidos));
}
let spCache = { siteId: null, listId: null };
let filterMode = 'todos';
let _ilStatusFilter = ''; // status IL selecionado no dropdown
let tabMode = localStorage.getItem('monitor_tabMode') || 'pendentes'; // 'todos' | 'pendentes' | 'andamento' | 'resolvidos'
let andamentoSubFilter = 'todos';  // 'todos' | 'manuais' | 'tratativa'
let sortCol = 'diff';
let sortDir = 1;
let countdown = 60;
let pollingTimer = null;
let spPollTimer = null;       // polling exclusivo do SharePoint (15s)
let saveTimers = {};
let isDemo = true;
let isLoading = false;
let currentAuthUser = null;
let nexosAuthReady = false;

// ── Helpers: persistir/restaurar dados do usuário entre reloads ──
const _USER_CACHE_KEY = 'monitor_auth_user_v1';
function _persistUserCache(user) {
  if (!user) return;
  try {
    sessionStorage.setItem(_USER_CACHE_KEY, JSON.stringify({
      displayName: user.displayName || user.name || '',
      email:       user.email       || '',
      photo:       user.photo       || user.photoUrl || '',
    }));
  } catch (_) {}
}
function _restoreUserCache() {
  try {
    const raw = sessionStorage.getItem(_USER_CACHE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (_) { return null; }
}
function _clearUserCache() {
  try { sessionStorage.removeItem(_USER_CACHE_KEY); } catch (_) {}
}
// Aplica foto/nome na sidebar sem precisar do objeto user completo
function _applySidebarUserUI(u) {
  if (!u) return;
  const nameEl     = document.getElementById('sidebar-user-name');
  const emailEl    = document.getElementById('sidebar-user-email');
  const photoEl    = document.getElementById('sidebar-user-photo');
  const fallbackEl = document.getElementById('sidebar-user-photo-fallback');
  if (nameEl)  nameEl.textContent  = u.displayName || u.name || 'Usuário';
  if (emailEl) emailEl.textContent = u.email || '';
  if (photoEl && fallbackEl) {
    if (u.photo || u.photoUrl) {
      photoEl.src = u.photo || u.photoUrl;
      photoEl.style.display = 'block';
      fallbackEl.style.display = 'none';
    } else {
      photoEl.style.display = 'none';
      fallbackEl.style.display = 'flex';
    }
  }
}

/**
 * Mostra/esconde itens de nav e seções de acordo com o nível de acesso.
 * Regras:
 *  - Monitor / Dashboard 2 / Dashboard 3 → Auxiliar | Assistente | Assistente2 | Gestão
 *  - Histórico Tratativas                → Somente Gestão
 *  - Histórico Solicitações              → Somente Gestão
 */
function _aplicarNavAccessControl() {
  const nivel = (_monitorUserNivel || '').toLowerCase();
  const isGestao = nivel === 'gestão' || nivel === 'gestao';

  // Itens com acesso restrito a Gestão
  const itemsGestao = ['btn-historico', 'btn-hist-solicitacoes', 'nav-group-gestao'];
  itemsGestao.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = isGestao ? '' : 'none';
  });

  // Separador do grupo Gestão só aparece se houver itens visíveis
  document.querySelectorAll('.nav-group-sep').forEach(el => {
    el.style.display = isGestao ? '' : 'none';
  });

  LOG.info(`[NavAccess] Nível: "${nivel}" → Gestão: ${isGestao}`);
}

let focusedId = null;         // jobId da linha que o usuário está atuando (azul)
let _monitorUserNivel = null; // nível de acesso Nexos (Departamento do SP)

// ════════════════════════════════════════════════
// AVATAR CACHE — fotos via lista Nexos_Usuarios no SP
// Campos: Email (ou UserEmail), FotoURL, NomeCompleto
// Carrega a lista inteira uma vez e serve todos os avatares do cache.
// ════════════════════════════════════════════════
const _photoCache   = new Map();  // email.toLowerCase() → blobUrl (string) | Promise
let   _nexosUserMap = null;       // email → { fotoUrl, nome } — null = ainda não carregou

/**
 * Carrega a lista Nexos_Usuarios completa e popula _nexosUserMap.
 * Só faz a request uma vez por sessão.
 */
async function _loadNexosUsuarios() {
  if (_nexosUserMap !== null) return _nexosUserMap;
  _nexosUserMap = {};  // marca como "carregando" para evitar chamadas duplas

  const token = secureTokens['sp-token'];
  if (!token) { _nexosUserMap = null; return null; }

  // Precisamos do siteId — reutiliza o cache do SP principal
  const ids = await resolveSP().catch(() => null);
  if (!ids?.siteId) { _nexosUserMap = null; return null; }

  try {
    // Buscar a lista pelo nome display
    const listRes = await fetch(
      `https://graph.microsoft.com/v1.0/sites/${ids.siteId}/lists/Nexos_Usuarios`,
      { headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' } }
    );
    if (!listRes.ok) { LOG.warn('Nexos_Usuarios: lista não encontrada', listRes.status); _nexosUserMap = null; return null; }
    const listData = await listRes.json();
    const listId = listData.id;

    // Buscar todos os itens
    const itemsRes = await fetch(
      `https://graph.microsoft.com/v1.0/sites/${ids.siteId}/lists/${listId}/items?$expand=fields&$top=500`,
      { headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' } }
    );
    if (!itemsRes.ok) { _nexosUserMap = null; return null; }
    const itemsData = await itemsRes.json();

    (itemsData.value || []).forEach(item => {
      const f = item.fields || {};
      // Suporta variações de nome de campo
      const email = (f.Email || f.UserEmail || f.email || '').toLowerCase().trim();
      if (!email) return;
      _nexosUserMap[email] = {
        fotoUrl: f.FotoURL || f.Foto || f.PhotoURL || f.Avatar || '',
        nome:    f.NomeCompleto || f.Nome || f.Title || '',
      };
    });

    LOG.ok(`Nexos_Usuarios: ${Object.keys(_nexosUserMap).length} usuários carregados`);
    return _nexosUserMap;
  } catch (e) {
    LOG.warn('Nexos_Usuarios: erro ao carregar:', e.message);
    _nexosUserMap = null;
    return null;
  }
}

/**
 * Retorna um token válido para chamadas ao Microsoft Graph.
 * Tenta unifiedAuth → NexosAuth → sp-token (fallback — pode não funcionar para Graph).
 */
async function _getGraphToken() {
  if (window.unifiedAuth && typeof window.unifiedAuth.getMSALToken === 'function') {
    try { const t = await window.unifiedAuth.getMSALToken(); if (t) return t; } catch (_) {}
  }
  if (window.NexosAuth) {
    const u = window.NexosAuth.getCurrentUser();
    if (u?.accessToken) return u.accessToken;
  }
  // fallback: sp-token às vezes também é um token Graph dependendo do fluxo de auth
  return secureTokens['sp-token'] || null;
}

/**
 * Retorna a blob URL da foto do usuário.
 * Busca diretamente pelo Graph API usando o email — não depende da FotoURL salva no SP.
 * Cacheia como blob para CSP e evita re-fetches.
 */
async function _fetchUserPhoto(email) {
  if (!email) return null;
  const key = email.toLowerCase();

  const cached = _photoCache.get(key);
  if (typeof cached === 'string') return cached;
  if (cached && typeof cached.then === 'function') return cached;

  const promise = (async () => {
    const token = await _getGraphToken();
    if (!token) return null;

    // Tentar buscar foto pelo Graph API diretamente (email como identificador)
    const graphUrl = `https://graph.microsoft.com/v1.0/users/${encodeURIComponent(key)}/photo/$value`;
    try {
      const r = await fetch(graphUrl, { headers: { Authorization: `Bearer ${token}` } });
      if (r.ok) {
        const url = URL.createObjectURL(await r.blob());
        _photoCache.set(key, url);
        return url;
      }
    } catch (_) {}

    // Fallback: tentar pela FotoURL salva na lista Nexos_Usuarios (se existir)
    const map = await _loadNexosUsuarios().catch(() => null);
    const user = map?.[key];
    if (user?.fotoUrl && !user.fotoUrl.includes('$value')) {
      // URL pública (não precisa de token)
      try {
        const r2 = await fetch(user.fotoUrl);
        if (r2.ok) {
          const url = URL.createObjectURL(await r2.blob());
          _photoCache.set(key, url);
          return url;
        }
      } catch (_) {}
    }

    _photoCache.set(key, null);
    return null;
  })();

  _photoCache.set(key, promise);
  return promise;
}

function _applyPhotosToDOM(email, url) {
  const key = email.toLowerCase();
  document.querySelectorAll(`[data-avatar-email="${CSS.escape(email)}"], [data-avatar-email="${CSS.escape(key)}"]`)
    .forEach(wrap => {
      let img = wrap.querySelector('.editor-avatar-img');
      const ini = wrap.querySelector('.editor-avatar-initials');
      if (!img) {
        img = document.createElement('img');
        img.className = 'editor-avatar-img';
        img.alt = wrap.dataset.avatarName || '';
        wrap.prepend(img);
      }
      img.src = url;
      img.style.display = '';
      if (ini) ini.style.display = 'none';
      // Remover nós de texto com iniciais (ex: "FM") que ficam visíveis ao lado da foto
      wrap.childNodes.forEach(node => {
        if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
          node.textContent = '';
        }
      });
    });
}

/**
 * Solicita foto e aplica no DOM quando pronta.
 */
function _loadAvatarsByEmail(email) {
  if (!email) return;
  const key = email.toLowerCase();
  const cached = _photoCache.get(key);
  if (typeof cached === 'string' && cached) { _applyPhotosToDOM(email, cached); return; }
  _fetchUserPhoto(key).then(url => { if (url) _applyPhotosToDOM(email, url); });
}

/**
 * Pré-carrega a lista Nexos_Usuarios e a foto do usuário logado.
 * Chamado logo após login + token disponível.
 */
async function _preFetchSelfPhoto() {
  const email = currentAuthUser?.email;
  if (!email || !secureTokens['sp-token']) return;
  const url = await _fetchUserPhoto(email.toLowerCase());
  if (url) _applyPhotosToDOM(email, url);
}
// CLOCK SYNC — offset entre relógio local e servidor
// Garante que todas as máquinas usem o mesmo epoch UTC
// ════════════════════════════════════════════════
let _serverOffset = 0;        // ms: serverTime - Date.now() (calculado ao receber header Date:)
let _serverOffsetReady = false;

/**
 * Atualiza o offset a partir do header Date: de uma resposta HTTP.
 * Chame com a Response de qualquer fetch ao Graph / SharePoint.
 */
function calibrateServerClock(response) {
  try {
    const dateHeader = response.headers.get('date');
    if (!dateHeader) return;
    const serverMs = new Date(dateHeader).getTime();
    if (isNaN(serverMs)) return;
    _serverOffset = serverMs - Date.now();
    _serverOffsetReady = true;
    console.log(`[MONITOR] Clock calibrado: offset ${_serverOffset > 0 ? '+' : ''}${_serverOffset}ms em relação ao servidor`);
  } catch (_) {}
}

/**
 * Retorna o timestamp atual corrigido pelo offset do servidor.
 * Substitui Date.now() em todos os cálculos de alinhamento de polling.
 */
function serverNow() {
  return Date.now() + _serverOffset;
}

// ════════════════════════════════════════════════
// CONFIG — localStorage
// ════════════════════════════════════════════════
const CFG_KEY = 'monitor_v3_cfg';
const SECURE_TOKENS_KEY = 'nexos-secure-tokens'; // chrome.storage.local — nunca no DOM

// Campos públicos (ficam no DOM / localStorage normalmente)
const CFG_PUBLIC_FIELDS = [
  'il-base', 'il-status', 'il-size',
  'pk-base', 'pk-endpoint', 'pk-field', 'pk-concurrency',
  'sp-site', 'sp-list', 'sp-f-id', 'sp-f-loja', 'sp-f-slot', 'sp-f-status', 'sp-f-text'
];

// Tokens sensíveis — armazenados APENAS em chrome.storage.local, nunca no DOM
const SECURE_TOKEN_FIELDS = ['il-token', 'pk-token', 'sp-token'];

// Cache em memória dos tokens seguros (preenchido na inicialização e ao receber token novo)
const secureTokens = { 'il-token': '', 'pk-token': '', 'sp-token': '' };

/** Persiste os tokens seguros no chrome.storage.local */
function saveSecureTokens() {
  if (typeof chrome === 'undefined' || !chrome.storage) return;
  chrome.storage.local.set({ [SECURE_TOKENS_KEY]: { ...secureTokens } });
}

/** Carrega os tokens seguros do chrome.storage.local para o cache em memória */
async function loadSecureTokens() {
  if (typeof chrome === 'undefined' || !chrome.storage) return;
  return new Promise(resolve => {
    chrome.storage.local.get([SECURE_TOKENS_KEY], result => {
      const saved = result[SECURE_TOKENS_KEY] || {};
      SECURE_TOKEN_FIELDS.forEach(f => {
        if (saved[f]) secureTokens[f] = saved[f];
      });
      resolve();
    });
  });
}

/** Lê config completa: campos públicos do DOM + tokens do cache em memória */
function readCfg() {
  const c = {};
  CFG_PUBLIC_FIELDS.forEach(f => {
    const el = document.getElementById(f);
    if (el) c[f] = el.value.trim();
  });
  // Tokens vêm do cache seguro, nunca do DOM
  SECURE_TOKEN_FIELDS.forEach(f => { c[f] = secureTokens[f] || ''; });
  return c;
}

/** Atualiza o badge de status de um token na UI */
function updateTokenBadge(field, hasToken) {
  const badge = document.getElementById(`${field}-badge`);
  if (!badge) return;
  if (hasToken) {
    badge.textContent = '● Configurado';
    badge.style.color = 'var(--green, #34d399)';
  } else {
    badge.textContent = '○ Não configurado';
    badge.style.color = 'var(--muted, #6b7280)';
  }
}

/** Atualiza todos os badges de token */
function refreshTokenBadges() {
  SECURE_TOKEN_FIELDS.forEach(f => updateTokenBadge(f, !!secureTokens[f]));
}

function saveConfig() {
  // Salvar campos públicos no localStorage
  const pub = {};
  CFG_PUBLIC_FIELDS.forEach(f => {
    const el = document.getElementById(f);
    if (el) pub[f] = el.value.trim();
  });
  localStorage.setItem(CFG_KEY, JSON.stringify(pub));

  // Tokens sensíveis já estão em secureTokens — apenas persistir
  saveSecureTokens();

  spCache = { siteId: null, listId: null };
  isDemo = false;
  setMode('live');
  showToast('Configuração salva. Iniciando conexão...', 'info');
  LOG.info('Configuração salva. Iniciando refresh.');
  refreshAll();
}

function loadConfig() {
  try {
    const c = JSON.parse(localStorage.getItem(CFG_KEY) || '{}');

    // Migração: corrigir URL base da Instaleap se estava com valor inválido antigo
    if (!c['il-base'] || c['il-base'] === 'https://adminapi.instaleap.io') {
      c['il-base'] = 'https://avt-backend.instaleap.io';
    }

    // Migração: consultar apenas pedidos ATIVOS na Instaleap.
    // DELIVERED e FINISHED não precisam ser puxados a cada ciclo —
    // o acumulador _totalAcumuladoHoje já os registrou quando eram ativos.
    const IL_STATUS_ATIVOS = 'STORED,GOING_TO_ORIGIN,GOING_TO_DESTINATION,TRANSFERRING, DELIVERED';
    const OLD_STATUS_VALS = [
      'STORED,GOING_TO_ORIGIN,TRANSFERRING',
      'STORED,GOING_TO_ORIGIN,TRANSFERRING,DELIVERED',
      'STORED,GOING_TO_ORIGIN,GOING_TO_DESTINATION,TRANSFERRING,DELIVERED,FINISHED',
    ];
    if (!c['il-status'] || OLD_STATUS_VALS.includes(c['il-status'])) {
      c['il-status'] = IL_STATUS_ATIVOS;
    }

    // Migração: garantir page_size mínimo de 50 (valor 10 era workaround antigo desnecessário)
    if (!c['il-size'] || Number(c['il-size']) < 50) {
      c['il-size'] = '50';
    }

    // Persistir todas as migrações de uma vez
    localStorage.setItem(CFG_KEY, JSON.stringify(c));

    // Padrão SharePoint: preencher sp-site se nunca foi salvo
    if (!c['sp-site']) {
      c['sp-site'] = 'gpabr.sharepoint.com/sites/Nexos';
    }

    CFG_PUBLIC_FIELDS.forEach(id => {
      const el = document.getElementById(id);
      if (el && c[id] !== undefined) el.value = c[id];
    });

    // Determinar modo com base nos tokens em memória + campos públicos
    const hasConfig = secureTokens['il-token'] || secureTokens['pk-token'] || c['sp-site'] || c['sp-list'];
    if (hasConfig) {
      isDemo = false;
      setMode('live');
      LOG.info('Configuração restaurada.');
    }

    refreshTokenBadges();
  } catch (e) {
    LOG.warn('Erro ao carregar config:', e.message);
  }
}

function toggleConfig() {
  document.getElementById('config-panel')?.classList.toggle('open');
}

function setMode(mode) {
  const el = document.getElementById('mode-badge');
  if (!el) return;
  el.className = `mode-badge mode-${mode}`;
  el.textContent = mode.toUpperCase();
}

// ════════════════════════════════════════════════
// PROGRESS BAR
// ════════════════════════════════════════════════
let progressValue = 0;
let progressTimer = null;

function startProgress() {
  const bar = document.getElementById('top-progress');
  const fill = document.getElementById('top-fill');
  if (!bar || !fill) return;

  bar.classList.add('active');
  progressValue = 0;
  fill.style.width = '0%';

  clearInterval(progressTimer);
  progressTimer = setInterval(() => {
    progressValue = Math.min(progressValue + (1 + Math.random() * 3), 85);
    fill.style.width = progressValue + '%';
  }, 200);
}

function finishProgress(ok = true) {
  clearInterval(progressTimer);
  const fill = document.getElementById('top-fill');
  const bar = document.getElementById('top-progress');
  if (!fill || !bar) return;

  fill.style.background = ok ? 'linear-gradient(90deg,var(--accent),var(--accent2))' : 'var(--red)';
  fill.style.width = '100%';

  setTimeout(() => {
    bar.classList.remove('active');
    fill.style.width = '0%';
    fill.style.background = '';
  }, 600);
}

// ════════════════════════════════════════════════
// SIDEBAR
// ════════════════════════════════════════════════
function bindSidebarEvents() {
  // Sidebar sempre colapsada (só ícones) — sem toggle de expand
  const sidebar = document.getElementById('left-sidebar');
  if (sidebar) {
    sidebar.classList.add('collapsed');
    sidebar.classList.add('sidebar-icon-only');
  }

  // ── Itens de navegação ──────────────────────────────────────────────────
  let _navTooltipTimer = null; // timer de remoção do tooltip (compartilhado entre itens)

  document.querySelectorAll('.sidebar-nav-item').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.sidebar-nav-item').forEach(x => x.classList.remove('active'));
      btn.classList.add('active');
      const dashboard = btn.dataset.dashboard;
      LOG.info('Sidebar → dashboard selecionado:', dashboard);
      // Trocar view principal
      document.getElementById('view-monitor').style.display          = dashboard === 'monitor'           ? '' : 'none';
      document.getElementById('view-historico').style.display        = dashboard === 'historico'         ? '' : 'none';
      document.getElementById('view-hist-solicitacoes').style.display = dashboard === 'hist-solicitacoes' ? '' : 'none';
      if (dashboard === 'historico')         carregarHistoricoView();
      if (dashboard === 'hist-solicitacoes') carregarHistSolicitacoes();
    });

    // Tooltip flutuante ao lado do ícone
    btn.addEventListener('mouseenter', () => {
      // Cancelar remoção pendente de tooltip anterior
      if (_navTooltipTimer) { clearTimeout(_navTooltipTimer); _navTooltipTimer = null; }

      const label = btn.querySelector('.nav-label')?.textContent || '';
      if (!label) return;
      let tip = document.getElementById('sidebar-tooltip');
      if (!tip) {
        tip = document.createElement('div');
        tip.id = 'sidebar-tooltip';
        document.body.appendChild(tip);
      }
      const rect = btn.getBoundingClientRect();
      tip.textContent = label;
      tip.style.cssText = `
        position:fixed;left:${rect.right + 10}px;top:${rect.top + rect.height / 2}px;
        transform:translateY(-50%);
        background:var(--surface2,#1e2130);border:1px solid var(--border,#2a2d3a);
        color:var(--text,#e2e8f0);font-size:12px;font-family:var(--font,'Inter',sans-serif);
        padding:5px 10px;border-radius:6px;z-index:999999;pointer-events:none;
        box-shadow:0 4px 16px rgba(0,0,0,.4);white-space:nowrap;opacity:1;
        transition:opacity .15s;
      `;
    });

    btn.addEventListener('mouseleave', () => {
      const tip = document.getElementById('sidebar-tooltip');
      if (tip) tip.style.opacity = '0';
      _navTooltipTimer = setTimeout(() => {
        document.getElementById('sidebar-tooltip')?.remove();
        _navTooltipTimer = null;
      }, 150);
    });
  });

  // ── Menu dropdown da foto do usuário ────────────────────────────────────
  _bindUserPhotoDropdown();

  // ── Fallback para avatares de editor com foto quebrada ──────────────────
  document.addEventListener('error', (e) => {
    const img = e.target;
    // Logo da sidebar
    if (img.id === 'sidebar-logo-img') {
      img.style.display = 'none';
      if (img.nextElementSibling) img.nextElementSibling.style.display = 'flex';
      return;
    }
    // Avatar do editor na tabela
    if (img.classList.contains('editor-avatar-img')) {
      img.style.display = 'none';
      if (img.nextElementSibling) img.nextElementSibling.style.display = 'flex';
    }
  }, true);

  // ── Painel de Histórico SP — filtros e atualizar ────────────────────────
  document.getElementById('hist-refresh-btn')?.addEventListener('click', () => carregarHistoricoView());
  let _histDebounce;
  document.getElementById('hist-filtro-busca')?.addEventListener('input', () => {
    clearTimeout(_histDebounce);
    _histDebounce = setTimeout(() => aplicarFiltrosHistorico(), 300);
  });
  document.getElementById('hist-filtro-status')?.addEventListener('change',  () => aplicarFiltrosHistorico());
  document.getElementById('hist-filtro-loja')?.addEventListener('change',    () => aplicarFiltrosHistorico());
  document.getElementById('hist-filtro-editor')?.addEventListener('change',  () => aplicarFiltrosHistorico());
  document.getElementById('hist-filtro-periodo')?.addEventListener('change', () => aplicarFiltrosHistorico());

  // Sort nas colunas do histórico (delegação a nível da view)
  document.getElementById('view-historico')?.addEventListener('click', e => {
    const th = e.target.closest('[data-sort-hist]');
    if (th) sortHistorico(th.dataset.sortHist);
  });

  // ── Histórico de Solicitações ──────────────────────────────────────────
  document.getElementById('hs-refresh-btn')?.addEventListener('click', () => carregarHistSolicitacoes());
  document.getElementById('hs-export-csv-btn')?.addEventListener('click', () => exportarHistSolCSV());
  document.getElementById('hs-export-xls-btn')?.addEventListener('click', () => exportarHistSolXLS());
  document.getElementById('hs-limpar-filtros-btn')?.addEventListener('click', () => limparFiltrosHistSol());

  // Filtros reativos
  let _hsDebounce;
  const _hsInputHandler = () => { clearTimeout(_hsDebounce); _hsDebounce = setTimeout(() => aplicarFiltrosHistSol(), 250); };
  document.getElementById('hs-busca')?.addEventListener('input', _hsInputHandler);
  ['hs-filtro-status','hs-filtro-plataforma','hs-filtro-loja','hs-filtro-solicitante','hs-filtro-modalidade','hs-filtro-formato',
   'hs-data-de','hs-data-ate'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', () => aplicarFiltrosHistSol());
  });

  // Alternador diário/mensal
  document.querySelectorAll('.hs-period-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.hs-period-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      _hsPeriodo = btn.dataset.hsPeriod;
      recalcularMetricasHistSol();
    });
  });

  // Sort nas colunas
  document.getElementById('hs-table')?.addEventListener('click', e => {
    const th = e.target.closest('[data-hs-sort]');
    if (th) sortHistSol(th.dataset.hsSort);
  });
}

/** Cria e conecta o dropdown que aparece ao clicar na foto do usuário */
function _bindUserPhotoDropdown() {
  const photoWrap = document.getElementById('sidebar-user-card');
  if (!photoWrap) return;

  // Criar dropdown uma única vez — começa fora da viewport para evitar flash no rodapé
  let dropdown = document.getElementById('user-photo-dropdown');
  if (!dropdown) {
    dropdown = document.createElement('div');
    dropdown.id = 'user-photo-dropdown';
    dropdown.className = 'user-photo-dropdown';
    // Posição inicial segura fora da tela (evita aparecer no canto/rodapé antes do 1º clique)
    dropdown.style.top  = '-9999px';
    dropdown.style.left = '-9999px';
    dropdown.innerHTML = `
      <button class="upd-item" id="upd-config" data-action="config">
        <span class="upd-icon">⚙</span>
        <span>Configurações</span>
      </button>
      <div class="upd-sep"></div>
      <button class="upd-item upd-danger" id="upd-logout" data-action="logout">
        <span class="upd-icon">↩</span>
        <span>Sair</span>
      </button>
    `;
    document.body.appendChild(dropdown);
  }

  // Clique na foto ou avatar fallback
  const photoEl  = document.getElementById('sidebar-user-photo');
  const fallback = document.getElementById('sidebar-user-photo-fallback');

  function openDropdown(triggerEl) {
    if (!currentAuthUser) return; // só abre se autenticado

    const triggerRect = triggerEl.getBoundingClientRect();

    // Sidebar pode estar oculta (display:none) — usar largura fixa conhecida (78px) como fallback
    const sidebar = document.getElementById('left-sidebar');
    const sidebarRight = (sidebar && sidebar.offsetParent !== null)
      ? sidebar.getBoundingClientRect().right
      : 78;

    // Mover para fora da tela antes de tornar visível (medir altura sem flash)
    dropdown.style.top  = '-9999px';
    dropdown.style.left = '-9999px';
    dropdown.classList.remove('upd-hidden');
    dropdown.classList.add('upd-visible');

    // Após render: posicionar corretamente
    requestAnimationFrame(() => {
      const dh = dropdown.offsetHeight || 90;
      let top = triggerRect.top + triggerRect.height / 2 - dh / 2;
      top = Math.max(8, Math.min(top, window.innerHeight - dh - 8));
      dropdown.style.top  = `${top}px`;
      dropdown.style.left = `${sidebarRight + 10}px`;
    });
  }

  [photoEl, fallback].forEach(el => {
    el?.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = dropdown.classList.contains('upd-visible');
      if (isOpen) {
        _closeUserDropdown();
      } else {
        openDropdown(el);
      }
    });
    if (el) el.style.cursor = 'pointer';
  });

  // Ações do dropdown
  dropdown.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    _closeUserDropdown();
    if (btn.dataset.action === 'config') {
      toggleConfig();
    } else if (btn.dataset.action === 'logout') {
      nexosLogoutNexosOnly();
    }
  });

  // Fechar ao clicar fora
  document.addEventListener('click', (e) => {
    if (!dropdown.classList.contains('upd-visible')) return;
    if (!dropdown.contains(e.target)) _closeUserDropdown();
  });
}

function _closeUserDropdown() {
  const dropdown = document.getElementById('user-photo-dropdown');
  if (!dropdown) return;
  dropdown.classList.remove('upd-visible');
  dropdown.classList.add('upd-hidden');
}

function resetSidebarAuthUi() {
  const loginBtn = document.getElementById('login-btn');
  const loginBtn2 = document.getElementById('sidebar-login-btn');
  const logoutBtn = document.getElementById('sidebar-logout-btn');
  const nameEl = document.getElementById('sidebar-user-name');
  const emailEl = document.getElementById('sidebar-user-email');
  const photoEl = document.getElementById('sidebar-user-photo');
  const fallbackEl = document.getElementById('sidebar-user-photo-fallback');

  if (nameEl) nameEl.textContent = 'Não autenticado';
  if (emailEl) emailEl.textContent = 'Faça login para continuar';

  if (photoEl) {
    photoEl.src = '';
    photoEl.style.display = 'none';
  }

  if (fallbackEl) {
    fallbackEl.style.display = 'flex';
  }

  if (loginBtn) {
    loginBtn.style.display = '';
    loginBtn.disabled = false;
    loginBtn.textContent = '🔐 Entrar';
  }

  if (logoutBtn) {
    logoutBtn.style.display = 'none';
  }
}

// ════════════════════════════════════════════════
// LOGIN WALL (overlay bloqueante)
// ════════════════════════════════════════════════
function resetLoginWall() {
  const btn = document.getElementById('wall-login-btn');
  const statusEl = document.getElementById('wall-login-status');
  const errorEl = document.getElementById('wall-login-error');
  if (btn) {
    btn.disabled = false;
    btn.innerHTML = '<span>🔑</span> Entrar com Conta Corporativa (Microsoft)';
  }
  if (statusEl) statusEl.textContent = '';
  if (errorEl) { errorEl.style.display = 'none'; errorEl.textContent = ''; }
  // Garantir que step1 esteja visível e step2 oculto ao resetar
  const step1 = document.getElementById('wall-step1');
  const step2 = document.getElementById('wall-step2');
  if (step1) step1.style.display = '';
  if (step2) step2.style.display = 'none';
}

/** Transiciona o login wall para a Etapa 2 (aguardando Instaleap) */
function showLoginWallStep2() {
  const step1 = document.getElementById('wall-step1');
  const step2 = document.getElementById('wall-step2');
  const retryBtn = document.getElementById('wall-step2-retry-btn');
  const statusEl = document.getElementById('wall-step2-status');
  if (step1) step1.style.display = 'none';
  if (step2) step2.style.display = '';
  if (retryBtn) retryBtn.style.display = 'none';
  if (statusEl) statusEl.textContent = 'Aguardando login Instaleap...';
}

/** Atualiza o status visível na Etapa 2 */
function setLoginWallStep2Status(msg, showRetry = false) {
  const statusEl = document.getElementById('wall-step2-status');
  const retryBtn = document.getElementById('wall-step2-retry-btn');
  if (statusEl) statusEl.textContent = msg;
  if (retryBtn) retryBtn.style.display = showRetry ? '' : 'none';
}

/** Exibe o overlay de bloqueio do painel quando a sessão Instaleap expira */
function showILLockOverlay(msg) {
  const overlay = document.getElementById('il-lock-overlay');
  const statusEl = document.getElementById('il-lock-status');
  const btn = document.getElementById('il-lock-reconect-btn');
  if (overlay) overlay.style.display = 'flex';
  if (statusEl) statusEl.textContent = msg || '';
  if (btn) { btn.disabled = false; btn.innerHTML = '<span>🔑</span> Reconectar Instaleap'; }
}

/** Esconde o overlay de bloqueio do painel Instaleap */
function hideILLockOverlay() {
  const overlay = document.getElementById('il-lock-overlay');
  const statusEl = document.getElementById('il-lock-status');
  if (overlay) overlay.style.display = 'none';
  if (statusEl) statusEl.textContent = '';
}

function showLoginWall(mode = 'normal') {
  const wall = document.getElementById('nexos-login-wall');
  if (!wall) return;

  // Esconder sidebar durante o login — ela só aparece após autenticação
  const sidebar = document.getElementById('left-sidebar');
  if (sidebar) sidebar.style.display = 'none';

  if (mode === 'logout') {
    // Mostra mensagem de desconectado por 2s antes de revelar o botão de login
    const btn = document.getElementById('wall-login-btn');
    const statusEl = document.getElementById('wall-login-status');
    const errorEl = document.getElementById('wall-login-error');

    // Esconde botão e erro, mostra mensagem central de logout
    if (btn) btn.style.display = 'none';
    if (errorEl) { errorEl.style.display = 'none'; errorEl.textContent = ''; }
    if (statusEl) {
      statusEl.style.cssText = 'margin-top:14px;font-size:13px;color:var(--amber,#f59e0b);min-height:18px;font-family:var(--mono);text-align:center;';
      statusEl.textContent = '🔓 Sessão encerrada. Você foi desconectado.';
    }

    wall.style.display = 'flex';
    LOG.info('AUTH: sessão encerrada, exibindo aviso de logout');

    setTimeout(() => {
      // Restaura o botão e limpa a mensagem após 2s
      if (btn) { btn.style.display = ''; btn.disabled = false; btn.innerHTML = '<span>🔑</span> Entrar com Conta Corporativa (Microsoft)'; }
      if (statusEl) { statusEl.style.cssText = 'margin-top:14px;font-size:11px;color:var(--muted);min-height:18px;font-family:var(--mono);'; statusEl.textContent = ''; }
    }, 2000);
  } else {
    resetLoginWall();
    wall.style.display = 'flex';
    LOG.info('AUTH: exibindo tela de login obrigatório');
  }
}

function hideLoginWall() {
  const wall = document.getElementById('nexos-login-wall');
  if (wall) {
    wall.style.display = 'none';
    resetLoginWall();
  }
  // Mostrar sidebar novamente após login bem-sucedido
  const sidebar = document.getElementById('left-sidebar');
  if (sidebar) sidebar.style.display = '';
}

function showLoginWallIfNeeded() {
  // Exibe o wall em qualquer contexto quando não há sessão ativa
  showLoginWall();
}

// ════════════════════════════════════════════════
// AUTH INTEGRATION — NEXOS AUTH
// ════════════════════════════════════════════════
function getNexosAuthObject() {
  if (window.NexosAuth && typeof window.NexosAuth.requireAuth === 'function') {
    return window.NexosAuth;
  }
  return null;
}

async function ensureNexosAuthAvailable(timeoutMs = 15000, intervalMs = 150) {
  const start = Date.now();

  while (Date.now() - start < timeoutMs) {
    const auth = getNexosAuthObject();
    if (auth) {
      nexosAuthReady = true;
      console.log('[MONITOR] AUTH: NexosAuth detectado com sucesso');
      return auth;
    }
    await new Promise(resolve => setTimeout(resolve, intervalMs));
  }

  nexosAuthReady = false;
  return null;
}

// ════════════════════════════════════════════════
// SP APP TOKEN — client credentials via background
// Todos os acessos ao SP usam token de aplicação,
// eliminando a necessidade de permissão individual por usuário.
// ════════════════════════════════════════════════

/** Cache local em memória (complementa o cache do service worker) */
let _spAppTokenCache = null;

/**
 * Obtém token de aplicação (client credentials) do service worker.
 * O client_secret fica APENAS no background.js — nunca exposto ao DOM.
 * Cacheia em memória para evitar round-trips desnecessários ao SW.
 */
async function getSpAppToken() {
  // Cache em memória válido por mais de 1 minuto
  if (_spAppTokenCache && _spAppTokenCache.expiresAt > Date.now() + 60000) {
    return _spAppTokenCache.token;
  }

  if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
    LOG.warn('SP: chrome.runtime não disponível para obter app token');
    return null;
  }

  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'SP_APP_TOKEN' }, resp => {
      if (chrome.runtime.lastError) {
        LOG.warn('SP app token: erro de comunicação com background:', chrome.runtime.lastError.message);
        resolve(null);
        return;
      }
      if (resp?.success && resp.token) {
        _spAppTokenCache = { token: resp.token, expiresAt: resp.expiresAt };
        console.log('[MONITOR] SP: app token obtido via client_credentials');
        resolve(resp.token);
      } else {
        LOG.warn('SP app token: falha —', resp?.error);
        resolve(null);
      }
    });
  });
}

async function syncSharePointTokenFromAuth() {
  // Scopes para SharePoint via Graph
  const SP_SCOPES = ['https://graph.microsoft.com/.default'];
  const SP_SCOPES_EXPLICIT = ['User.Read', 'Sites.ReadWrite.All'];

  // Salva token nos secureTokens e retorna
  const _save = (token, source) => {
    secureTokens['sp-token'] = token;
    // pk-token usa o mesmo token Microsoft (API interna GPA usa Azure AD)
    // Sempre atualizar junto com sp-token para evitar pk-token expirado
    secureTokens['pk-token'] = token;
    saveSecureTokens();
    refreshTokenBadges();
    console.log(`[MONITOR] AUTH: sp-token/pk-token obtidos via ${source}`);
    return token;
  };

  // Extrai email de JWT sem verificar assinatura
  const _emailFromJwt = (jwt) => {
    try {
      const p = JSON.parse(atob(jwt.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      return p.upn || p.preferred_username || p.email || null;
    } catch { return null; }
  };

  try {
    // ── Estratégia 1: NexosAuth.getToken() — token do login principal ──
    // Desde que o background.js peça Sites.ReadWrite.All no login, este token já funciona para SP
    const auth = await ensureNexosAuthAvailable();
    if (auth && typeof auth.getToken === 'function') {
      const token = await auth.getToken();
      if (token) return _save(token, 'NexosAuth.getToken');
    }

    // ── Estratégia 2: MSAL silent com conta em cache (se disponível) ──
    if (window.msalAuth && !window.msalAuth.initialized) {
      const deadline = Date.now() + 4000;
      while (window.msalAuth && !window.msalAuth.initialized && Date.now() < deadline) {
        await new Promise(r => setTimeout(r, 150));
      }
    }

    const msalInst = window.msalAuth?.msalInstance;
    if (msalInst) {
      const cached = msalInst.getAllAccounts();
      for (const account of (cached || [])) {
        for (const scopes of [SP_SCOPES, SP_SCOPES_EXPLICIT]) {
          try {
            const resp = await msalInst.acquireTokenSilent({ scopes, account });
            if (resp?.accessToken) return _save(resp.accessToken, `MSAL silent (${account.username})`);
          } catch (e) { /* tenta próximo */ }
        }
      }

      // loginHint a partir do JWT atual
      const jwt0 = secureTokens['sp-token'];
      const hint = jwt0 ? _emailFromJwt(jwt0) : currentAuthUser?.email;
      if (hint) {
        for (const scopes of [SP_SCOPES, SP_SCOPES_EXPLICIT]) {
          try {
            const resp = await msalInst.acquireTokenSilent({ scopes, loginHint: hint });
            if (resp?.accessToken) return _save(resp.accessToken, `MSAL silent loginHint (${hint})`);
          } catch (e) { /* tenta próximo */ }
        }
      }
    }

    LOG.warn('AUTH: nenhum token disponível para SharePoint');
    return null;
  } catch (error) {
    LOG.warn('AUTH: erro ao sincronizar token:', error.message);
    return null;
  }
}

// ── Verificação / auto-registro em Nexos_Usuarios (Monitor) ─────────────────
/**
 * Garante que o usuário está registrado em Nexos_Usuarios com status aprovado.
 * Reutiliza window.NexosUserManager (carregado via nexos-user-manager.js).
 * Retorna true se acesso liberado, false se bloqueado.
 */
async function _ensureMonitorUserRegistered(user) {
  if (!user?.email) return true;

  const um = window.NexosUserManager;
  if (!um) {
    LOG.warn('AUTH: NexosUserManager não disponível — verificação ignorada');
    return true;
  }

  try { await um.initialize(); } catch (e) {
    LOG.warn('AUTH: NexosUserManager.initialize() falhou:', e.message);
    return true;
  }

  let record = await um.getUserByEmail(user.email);

  if (!record) {
    LOG.info('AUTH: 1º acesso no Monitor — registrando em Nexos_Usuarios...');
    const created = await um.createUser({
      id:          user.id || '',
      email:       user.email,
      name:        user.name || user.displayName || '',
      displayName: user.displayName || user.name || '',
      jobTitle:    user.jobTitle || '',
      department:  user.department || '',
      photo:       user.photo || ''
    });
    if (created.success) {
      record = created.user;
    } else {
      LOG.warn('AUTH: falha ao criar usuário no SP:', created.error);
      return true;
    }
  }

  const status = (record.Status || '').toLowerCase();
  if (status === 'aprovado') {
    // Salva nível de acesso para controle da sidebar
    // Se Departamento estiver vazio → fallback para 'gestão' (usuário aprovado sem nível definido)
    const nivelRaw = (record.Departamento || '').trim();
    _monitorUserNivel = nivelRaw ? nivelRaw.toLowerCase() : 'gestão';
    if (!nivelRaw) {
      LOG.warn('[NavAccess] ⚠️ Usuário sem Departamento definido — acesso concedido como Gestão temporariamente. Defina o nível via painel Admin.');
    }
    return true;
  }

  _showMonitorAccessBlocked(status, user);
  return false;
}

/**
 * Exibe tela de bloqueio de acesso no Monitor de Pedidos Armazenados.
 */
function _showMonitorAccessBlocked(status, user) {
  document.getElementById('nexos-monitor-access-blocked')?.remove();

  const isPending = status === 'pendente';
  const icon   = isPending ? '⏳' : '🚫';
  const title  = isPending ? 'Aguardando Aprovação' : 'Acesso Negado';
  const color  = isPending ? '#F59E0B' : '#EF4444';
  const bgCard = isPending ? '#FFFBEB' : '#FEF2F2';
  const border = isPending ? '#FDE68A' : '#FECACA';
  const nameDisplay = user?.name || user?.email || '';

  const message = isPending
    ? `Seu cadastro foi recebido e está aguardando aprovação pelo administrador Nexos.<br>
       <span style="font-size:13px;color:#78716C;">Você receberá acesso assim que um administrador aprovar seu perfil.</span>`
    : `Seu acesso foi negado pelo administrador Nexos.<br>
       <span style="font-size:13px;color:#78716C;">Entre em contato com o suporte para mais informações.</span>`;

  const overlay = document.createElement('div');
  overlay.id = 'nexos-monitor-access-blocked';
  overlay.style.cssText = [
    'position:fixed', 'inset:0', 'z-index:2147483647',
    'display:flex', 'align-items:center', 'justify-content:center',
    'background:rgba(15,23,42,0.92)', 'backdrop-filter:blur(6px)',
    'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif'
  ].join(';');

  overlay.innerHTML = `
    <div style="background:${bgCard};border:1.5px solid ${border};border-radius:16px;
                padding:40px 48px;max-width:460px;width:90%;text-align:center;
                box-shadow:0 20px 60px rgba(0,0,0,0.4);">
      <div style="font-size:56px;margin-bottom:16px;line-height:1;">${icon}</div>
      <div style="font-size:22px;font-weight:700;color:${color};margin-bottom:12px;">${title}</div>
      ${nameDisplay ? `<div style="font-size:14px;color:#6B7280;margin-bottom:16px;">👤 ${nameDisplay}</div>` : ''}
      <div style="font-size:15px;color:#374151;line-height:1.6;margin-bottom:28px;">${message}</div>
      ${isPending ? `
        <div style="background:#FFF7ED;border:1px solid #FED7AA;border-radius:8px;
                    padding:12px 16px;font-size:12px;color:#92400E;margin-bottom:24px;">
          💡 <strong>Administradores:</strong> acesse o Painel Admin da Nexos para aprovar este usuário.
        </div>` : ''}
      <button id="nexos-monitor-blocked-refresh" style="background:${color};color:#fff;border:none;
        border-radius:8px;padding:10px 24px;font-size:14px;font-weight:600;cursor:pointer;margin-right:8px;">
        🔄 Verificar novamente
      </button>
      <button id="nexos-monitor-blocked-logout" style="background:transparent;color:#6B7280;
        border:1.5px solid #D1D5DB;border-radius:8px;padding:10px 20px;font-size:14px;cursor:pointer;">
        Sair
      </button>
    </div>
  `;

  document.body.appendChild(overlay);

  overlay.querySelector('#nexos-monitor-blocked-refresh')?.addEventListener('click', async () => {
    overlay.remove();
    window.NexosUserManager?.usersCache?.clear?.();
    const allowed = await _ensureMonitorUserRegistered(user);
    if (allowed && currentAuthUser) {
      const token = await syncSharePointTokenFromAuth().catch(() => null);
      // Limpar guard para permitir re-execução
      window._loginSuccessHandled = false;
      await onLoginSuccessFromNexos(currentAuthUser, token);
    }
  });

  overlay.querySelector('#nexos-monitor-blocked-logout')?.addEventListener('click', () => {
    nexosLogout();
    overlay.remove();
  });
}

async function onLoginSuccessFromNexos(user, token) {
  // Guard: evitar execução dupla se o evento onLogin e o handler direto dispararem juntos
  if (window._loginSuccessHandled) {
    LOG.warn('AUTH: onLoginSuccessFromNexos já executado para este login — ignorando chamada duplicada');
    return;
  }
  window._loginSuccessHandled = true;
  // Limpar o guard após 8 segundos para permitir futuros logins
  setTimeout(() => { window._loginSuccessHandled = false; }, 8000);

  currentAuthUser = user;
  _persistUserCache(user);  // ← persiste nome/email para sobreviver ao reload
  _preFetchSelfPhoto();     // ← pré-carrega foto via /me/photo com o token recém obtido

  // ── Verificar / registrar usuário em Nexos_Usuarios ──────────────────────
  // Mesma lógica do picking-init.js: cria com status 'pendente' no 1º acesso
  // e bloqueia o painel até aprovação pelo admin.
  const accessAllowed = await _ensureMonitorUserRegistered(user);
  if (!accessAllowed) {
    // Tela de bloqueio exibida — não liberar o painel
    return;
  }
  _aplicarNavAccessControl();
  // ─────────────────────────────────────────────────────────────────────────

  const loginBtn = document.getElementById('login-btn');
  const loginBtn2 = document.getElementById('sidebar-login-btn');
  const logoutBtn = document.getElementById('sidebar-logout-btn');

  _applySidebarUserUI(user);  // ← centralizado em uma função reutilizável

  if (loginBtn) {
    loginBtn.style.display = 'none';
    loginBtn.disabled = false;
    loginBtn.textContent = '🔐 Entrar';
  }

  if (logoutBtn) {
    logoutBtn.style.display = '';
  }

  spCache = { siteId: null, listId: null };
  refreshTokenBadges();

  LOG.ok('AUTH: conectado como', user.email || user.displayName || user.name);
  showToast(`✓ Conectado como ${user.email || user.displayName || user.name}`, 'success');

  // 🚀 Login sequencial — o painel só é liberado após AMBOS os logins estarem prontos
  if (secureTokens['il-token']) {
    // Instaleap já autenticado: liberar painel imediatamente
    LOG.info('AUTH: il-token já disponível — liberando painel e iniciando refresh');
    hideLoginWall();
    setTimeout(() => refreshAll(), 300);
  } else {
    // Instaleap ainda não autenticado — manter login wall, avançar para Etapa 2
    LOG.info('AUTH: il-token ausente — exibindo Etapa 2 (login Instaleap)');
    showLoginWallStep2();
    // Pré-carregar tratativas do SharePoint em paralelo, sem bloquear o fluxo
    fetchSharePoint().then(spMap => {
      if (spMap && Object.keys(spMap).length > 0) {
        LOG.sp(`Pré-carga SP: ${Object.keys(spMap).length} tratativas carregadas após login`);
        Object.entries(spMap).forEach(([id, t]) => {
          if (!tratativas[id]) {
            tratativas[id] = { ...t };
          } else if (!tratativas[id].spItemId && t.spItemId) {
            tratativas[id].spItemId = t.spItemId;
          }
        });
        if (orders.length > 0) renderTable();
      }
    }).catch(e => LOG.warn('Pré-carga SP falhou:', e.message));
    setTimeout(() => instaleapLoginAuto(), 800);
  }
}

async function nexosLogin() {
  const loginBtn = document.getElementById('login-btn');
  const loginBtn2 = document.getElementById('sidebar-login-btn');

  try {
    if (loginBtn) {
      loginBtn.disabled = true;
      loginBtn.textContent = '⏳ Carregando...';
    }

    const auth = await ensureNexosAuthAvailable(15000, 150);
    if (!auth) {
      throw new Error('NexosAuth não foi carregado na página');
    }

    if (loginBtn) {
      loginBtn.textContent = '⏳ Abrindo login...';
    }

    const user = await auth.requireAuth({
      silent: false,
      forceLogin: false
    });

    if (!user) {
      throw new Error('Login cancelado ou não concluído');
    }

    currentAuthUser = user;

    const token = await syncSharePointTokenFromAuth();
    if (!token) {
      LOG.warn('AUTH: login concluído, mas token não foi retornado');
    }

    await onLoginSuccessFromNexos(user, token);
    hideLoginWall();
    return user;
  } catch (error) {
    LOG.error('AUTH login falhou:', error.message);
    showToast('Login falhou: ' + error.message, 'error');

    if (loginBtn) {
      loginBtn.disabled = false;
      loginBtn.textContent = '🔐 Entrar';
    }

    return null;
  }
}

async function nexosLogout() {
  try {
    const auth = getNexosAuthObject();

    if (auth && typeof auth.logout === 'function') {
      await auth.logout();
      return;
    }

    currentAuthUser = null;
    resetSidebarAuthUi();
    spCache = { siteId: null, listId: null };
    LOG.info('AUTH: logout local concluído');
  } catch (error) {
    LOG.error('AUTH logout falhou:', error.message);
  }
}

/**
 * Logout parcial: desconecta apenas o acesso Nexos (Microsoft/SP).
 * Preserva il-token e pk-token para não interromper o Instaleap.
 * Usado no dropdown de usuário da sidebar.
 */
async function nexosLogoutNexosOnly() {
  try {
    stopPolling();

    // Limpar APENAS sp-token; preservar il-token e pk-token
    const ilToken = secureTokens['il-token'];
    const pkToken = secureTokens['pk-token'];

    secureTokens['sp-token'] = '';
    saveSecureTokens();

    // Restaurar il-token e pk-token caso saveSecureTokens os tenha zerado
    secureTokens['il-token'] = ilToken;
    secureTokens['pk-token'] = pkToken;
    saveSecureTokens();

    spCache = { siteId: null, listId: null };
    currentAuthUser = null;
    window._loginSuccessHandled = false;

    // Deslogar apenas do NexosAuth (MSAL / Microsoft)
    try {
      const auth = getNexosAuthObject();
      if (auth && typeof auth.logout === 'function') await auth.logout();
    } catch (_) { /* ignorar falhas silenciosas */ }

    resetSidebarAuthUi();
    refreshTokenBadges();
    showLoginWall('logout');
    LOG.info('AUTH: logout Nexos-only — il-token e pk-token preservados');
  } catch (error) {
    LOG.error('AUTH nexosLogoutNexosOnly falhou:', error.message);
  }
}

// ════════════════════════════════════════════════
// REVALIDAÇÃO DE SESSÃO — 401 / token expirado
// ════════════════════════════════════════════════

/** Chamado sempre que uma requisição ao SP/Graph retorna 401 ou o token some.
 *  Invalida o cache SP, limpa tokens e força o usuário a logar novamente.
 *  Protegido contra chamadas duplicadas em cascata (debounce de 5 s).
 */
let _sessionExpiredHandling = false;
async function handleSpAuthError(reason = 'Token expirado ou inválido') {
  if (_sessionExpiredHandling) return;   // evitar cascata
  _sessionExpiredHandling = true;
  setTimeout(() => { _sessionExpiredHandling = false; }, 5000);

  LOG.warn('AUTH: sessão SP inválida —', reason, '— forçando re-login');

  // Parar polling para não gerar mais erros enquanto o usuário não logou
  stopPolling();

  // Limpar caches
  spCache = { siteId: null, listId: null };
  SECURE_TOKEN_FIELDS.forEach(f => { secureTokens[f] = ''; });
  saveSecureTokens();
  refreshTokenBadges();
  currentAuthUser = null;
  window._loginSuccessHandled = false;
  window._ilLoginPending = false;

  // Tentar revogar sessão no NexosAuth (sem bloquear)
  try {
    const auth = getNexosAuthObject();
    if (auth && typeof auth.logout === 'function') await auth.logout();
  } catch (_) { /* ignorar */ }

  // Exibir login wall com mensagem de expiração
  resetSidebarAuthUi();
  showToast('⚠️ Sessão expirada. Faça login novamente.', 'error');
  showLoginWall('logout');
}

async function tryRestoreNexosSession() {
  try {
    const auth = await ensureNexosAuthAvailable(15000, 150);
    if (!auth) {
      LOG.warn('AUTH: NexosAuth não disponível para restore');
      resetSidebarAuthUi();
      showLoginWallIfNeeded();
      return;
    }

    if (typeof auth.isAuthenticated !== 'function' || typeof auth.getCurrentUser !== 'function') {
      LOG.warn('AUTH: API incompleta em window.NexosAuth');
      resetSidebarAuthUi();
      showLoginWallIfNeeded();
      return;
    }

    const isAuth = await auth.isAuthenticated();
    if (!isAuth) {
      LOG.info('AUTH: nenhuma sessão ativa encontrada');
      resetSidebarAuthUi();
      showLoginWallIfNeeded();
      return;
    }

    const user = auth.getCurrentUser();
    if (!user) {
      LOG.info('AUTH: sessão ativa sem usuário carregado');
      resetSidebarAuthUi();
      showLoginWallIfNeeded();
      return;
    }

    const token = await syncSharePointTokenFromAuth();
    await onLoginSuccessFromNexos(user, token);
    hideLoginWall();

    LOG.ok('AUTH: sessão restaurada para', user.email || user.displayName || user.name);
  } catch (error) {
    LOG.warn('AUTH restore falhou:', error.message);
    resetSidebarAuthUi();
    showLoginWallIfNeeded();
  }
}

// ════════════════════════════════════════════════
// INSTALEAP LOGIN — captura token via popup
// ════════════════════════════════════════════════
// INSTALEAP LOGIN — captura token via popup
// ════════════════════════════════════════════════

/** Função interna compartilhada: envia IL_AUTH_REQUEST e retorna o token */
async function _requestInstaleapToken() {
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
    throw new Error('Esta funcionalidade requer a extensão Chrome instalada.');
  }
  const email = currentAuthUser?.email || null;
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('Tempo esgotado (5 min).')), 5 * 60 * 1000 + 5000);
    chrome.runtime.sendMessage({ type: 'IL_AUTH_REQUEST', email }, (response) => {
      clearTimeout(timeout);
      if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
      if (!response) { reject(new Error('Sem resposta do background.')); return; }
      resolve(response);
    });
  });
}

/** Salva o token capturado no cache seguro e persiste */
function _applyInstaleapToken(token) {
  secureTokens['il-token'] = token;
  saveSecureTokens();
  refreshTokenBadges();
  // Iniciar ouvinte de revogação no chrome.storage
  _watchInstaleapTokenRevocation();
}

/** Ativa ouvinte para detectar revogação do token Instaleap (logout em outra aba) */
function _watchInstaleapTokenRevocation() {
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.onChanged) return;
  // Remover listener anterior se existir
  if (window._ilRevokeListener) {
    chrome.storage.onChanged.removeListener(window._ilRevokeListener);
  }
  window._ilRevokeListener = function (changes, area) {
    if (area !== 'local' || !changes[SECURE_TOKENS_KEY]) return;
    const newVal = changes[SECURE_TOKENS_KEY].newValue || {};
    if (!newVal['il-token'] && secureTokens['il-token']) {
      // Token foi removido — aguardar 6s antes de agir.
      // Isso evita false-positives quando o usuário abre um link Instaleap em nova aba:
      // o interceptor pode emitir IL_TOKEN_REVOKED durante um redirect transitório para /login,
      // mas o token volta ao storage rapidamente após autenticação da nova aba.
      LOG.warn('IL: token removido do storage — aguardando 6s para confirmar revogação real...');
      if (window._ilRevokeDebounce) clearTimeout(window._ilRevokeDebounce);
      window._ilRevokeDebounce = setTimeout(() => {
        window._ilRevokeDebounce = null;
        // Reler o storage para confirmar que o token ainda está ausente
        chrome.storage.local.get([SECURE_TOKENS_KEY], (result) => {
          const confirmTokens = result[SECURE_TOKENS_KEY] || {};
          if (!confirmTokens['il-token'] && secureTokens['il-token']) {
            // Confirmado: token continua ausente — é um logout real
            secureTokens['il-token'] = '';
            refreshTokenBadges();
            LOG.warn('IL: revogação confirmada — bloqueando painel');
            showILLockOverlay('Sessão Instaleap encerrada. Reconecte para continuar.');
          } else if (confirmTokens['il-token']) {
            // Token voltou (nova aba se autenticou) — atualizar cache e não bloquear
            LOG.info('IL: token voltou ao storage (nova aba autenticou) — mantendo sessão do painel');
            secureTokens['il-token'] = confirmTokens['il-token'];
            refreshTokenBadges();
          }
        });
      }, 6000);
    }
  };
  chrome.storage.onChanged.addListener(window._ilRevokeListener);
}

/** Login manual pelo botão nas configurações */
/** Login automático sequencial — disparado após login Microsoft quando il-token ausente */
async function instaleapLoginAuto() {
  // Guard: evitar abertura simultânea de múltiplas janelas Instaleap
  // (pode ocorrer quando onLoginSuccessFromNexos é disparado 2x no mesmo login)
  if (window._ilLoginPending) {
    LOG.warn('IL: Login Instaleap já em andamento — ignorando chamada duplicada');
    return;
  }
  window._ilLoginPending = true;

  showToast('🔑 Agora faça login no Instaleap para carregar os pedidos...', 'info');
  LOG.info('IL: Iniciando login automático sequencial após Microsoft...');
  try {
    const result = await _requestInstaleapToken();
    if (!result.success) throw new Error(result.error || 'Cancelado.');
    _applyInstaleapToken(result.token);
    LOG.ok('IL: Token obtido no fluxo sequencial — verificando Picking Admin...');
    showToast('✅ Instaleap autenticado!', 'success');
    window._ilLoginPending = false;

    // Etapa 3: verificar token Picking Admin
    const pkToken = await new Promise(resolve => {
      try { chrome.storage.local.get(['nexos-gpa-api-token'], r => resolve((r && r['nexos-gpa-api-token']) || '')); }
      catch { resolve(''); }
    });
    if (pkToken) {
      // Picking já autenticado — liberar painel
      hideLoginWall();
      hideILLockOverlay();
      _watchPickingTokenRevocation();
      saveConfig();
    } else {
      // Solicitar login Picking Admin antes de liberar o painel
      LOG.info('PK: token ausente após IL — exibindo Etapa 3');
      showLoginWallStep3();
      setTimeout(() => pickingAdminLoginAuto(), 600);
    }
  } catch (err) {
    window._ilLoginPending = false;
    LOG.warn('IL: Login sequencial cancelado/falhou:', err.message);
    setLoginWallStep2Status('Login cancelado ou falhou. Tente novamente.', true);
    showToast('⚙ Login Instaleap não concluído. Use o botão nas Configurações.', 'warn');
  }
}

// ════════════════════════════════════════════════
// PROXY DE FETCH — roteia chamadas via background service worker
// Necessário para contornar CORS em páginas de extensão (chrome-extension://)
// O background service worker não está sujeito às restrições CORS das APIs.
// ════════════════════════════════════════════════
async function nexosFetch(url, options = {}) {
  if (typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) {
    // Retry até 3 tentativas quando SW retorna status 0 (service worker acordando — falha transitória)
    let lastResp = null;
    for (let swAttempt = 0; swAttempt < 3; swAttempt++) {
      if (swAttempt > 0) {
        await new Promise(r => setTimeout(r, 800 * swAttempt));
      }
      lastResp = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action: 'nexos_fetch', url, options }, resp => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (!resp) { reject(new Error('Sem resposta do background (nexosFetch)')); return; }
          resolve(resp);
        });
      });
      // Qualquer status diferente de 0 (inclusive erros HTTP reais) — retornar imediatamente
      if (lastResp.status !== 0) break;
    }
    // Emula interface Response
    return {
      ok:     lastResp.ok,
      status: lastResp.status,
      json:   () => {
        try { return Promise.resolve(JSON.parse(lastResp.body)); }
        catch (e) { return Promise.reject(new Error('JSON inválido: ' + e.message)); }
      },
      text:   () => Promise.resolve(lastResp.body || ''),
    };
  }
  // Fallback direto (pode falhar por CORS em páginas de extensão)
  return fetch(url, options);
}

// ════════════════════════════════════════════════
// INSTALEAP API
// ════════════════════════════════════════════════
// Fleets são carregadas dinamicamente da API e filtradas por nome.
// Qualquer frota cujo name contenha "uber" ou "99" (case-insensitive) é incluída.
// Fallback: IDs fixos usados se a API de fleets falhar ou retornar vazio.

const IL_FLEETS_FALLBACK = [
  '0eacd42a-b1cf-4f07-82f2-1f5d45441e63',
  '20e1aebf-98f9-4504-b0df-0350ce3f0775',
  '289c493f-5a2c-43ac-a714-db46be7c444c',
  '31a99a53-30d2-47eb-aa3d-337bba7d552e',
  '31c7f897-8a44-4970-8e8e-e0e704879a7f',
  '407d6874-bac0-4d2e-9d18-4c9e46a238e5',
  '5134533a-d14c-4882-9cf2-2d9cc5850367',
  '55b8ec2c-9333-4163-ab52-39fde2ccf9a9',
  '698860e1-576c-4794-9685-f40c0e19f654',
  '6e998ae0-11b4-4020-88f0-0478c6781a8e',
  '7237e60b-2dd9-484e-ac16-7cfcea51dbdb',
  '75ca4a17-ac18-43fc-a11d-ab759148353a',
  '7797677e-b18c-437a-aa31-9bd581f1bcd4',
  '7bad4b97-89a2-41f6-9991-75607939a585',
  '994fe22e-90d8-4c09-ac7f-8aab0164838b',
  'a0fd2c92-a648-4e22-a654-0f2c41309229',
  'ce93c062-bab2-4ab2-af05-fdd2e710a794',
  'e2f3ba9e-0717-4783-b9fd-38e78313988e',
  'e6ae48bd-1fe5-4e64-bda0-a53e3501156e',
  '63e476c1-a3ec-4995-a3af-4390b8244385',
  '686e1d6c-cffc-4df4-bb5c-b97fcf007046',
  'a586d4d1-9ea8-43f2-a6d4-ae6ab20ed362',
  'c00a2150-15e5-41d3-bc75-36e7aa47d8bb'
];

// Cache em memória — recarregado a cada sessão (TTL 12h no storage)
let _ilFleetsCached = null;

/**
 * Busca todas as frotas da API Instaleap e retorna os IDs das que têm
 * "uber" ou "99" no nome. Cacheia no chrome.storage.local por 12h.
 * Fallback: lista fixa IL_FLEETS_FALLBACK.
 */
async function resolveILFleets() {
  // 1. Cache em memória (evita chamadas repetidas na mesma sessão)
  if (_ilFleetsCached) return _ilFleetsCached;

  const CACHE_KEY = 'nexos-il-fleets-cache';
  const TTL_MS = 12 * 60 * 60 * 1000; // 12 horas

  // 2. Cache no storage
  try {
    const stored = await chrome.storage.local.get(CACHE_KEY);
    const entry = stored[CACHE_KEY];
    if (entry && entry.ids) {
      // Cache de fallback (403) usa TTL menor: 1h
      const ttl = entry.fallback ? (60 * 60 * 1000) : TTL_MS;
      if ((Date.now() - entry.ts) < ttl) {
        _ilFleetsCached = entry.ids.join(',');
        if (!entry.fallback) LOG.ok(`[Fleets] Cache hit — ${entry.ids.length} frotas (Uber/99)`);
        return _ilFleetsCached;
      }
    }
  } catch (_) { /* storage não disponível, seguir */ }

  // 3. Buscar da API
  const c = readCfg();
  if (!c['il-token'] || !c['il-base']) {
    LOG.warn('[Fleets] Token/base não configurados — usando fallback');
    _ilFleetsCached = IL_FLEETS_FALLBACK.join(',');
    return _ilFleetsCached;
  }

  try {
    const res = await fetch(`${c['il-base']}/hela/api/v1/fleets`, {
      headers: { 'Authorization': `Bearer ${c['il-token']}`, 'Accept': 'application/json' }
    });

    if (res.status === 403) {
      // 403 = token sem permissão para listar frotas (falha permanente).
      // Usar fallback e cachear por 1h para não tentar de novo a cada reload.
      console.debug('[Fleets] Endpoint /fleets retornou 403 — token sem permissão. Usando fallback (cache 1h).');
      _ilFleetsCached = IL_FLEETS_FALLBACK.join(',');
      try {
        await chrome.storage.local.set({ [CACHE_KEY]: { ids: IL_FLEETS_FALLBACK, ts: Date.now(), fallback: true } });
      } catch (_) {}
      return _ilFleetsCached;
    }

    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const json = await res.json();

    // A API pode retornar { data: { fleets: [...] } } ou { fleets: [...] } ou [ ... ]
    const list = json?.data?.fleets ?? json?.fleets ?? (Array.isArray(json) ? json : []);

    const filtered = list
      .filter(f => f && f.id && f.name)
      .filter(f => {
        const name = f.name.toLowerCase();
        return name.includes('uber') || name.includes('99');
      })
      .map(f => f.id);

    if (filtered.length > 0) {
      _ilFleetsCached = filtered.join(',');
      LOG.ok(`[Fleets] ${filtered.length} frotas Uber/99 encontradas:`, list.filter(f => {
        const name = (f.name || '').toLowerCase();
        return name.includes('uber') || name.includes('99');
      }).map(f => f.name));

      // Persistir cache
      try {
        await chrome.storage.local.set({ [CACHE_KEY]: { ids: filtered, ts: Date.now() } });
      } catch (_) {}

      return _ilFleetsCached;
    }

    LOG.warn('[Fleets] Nenhuma frota Uber/99 encontrada na API — usando fallback');
  } catch (e) {
    LOG.warn('[Fleets] Falha ao buscar fleets da API:', e.message, '— usando fallback');
  }

  _ilFleetsCached = IL_FLEETS_FALLBACK.join(',');
  return _ilFleetsCached;
}

async function fetchInstaleap({ onPage } = {}) {
  const c = readCfg();
  if (!c['il-token']) {
    LOG.warn('Token Instaleap não configurado. Pulando.');
    return null;
  }

  const today = new Date().toISOString().split('T')[0];
  // Usar ontem como início: captura pedidos "de um dia para o outro" na mesma query
  const yesterday = new Date(Date.now() - 24 * 3600 * 1000).toISOString().split('T')[0];
  const slotFrom = `${yesterday} 00:00:00`;

  const allRows = [];
  const seenIds = new Set();

  // Resolver frotas Uber/99 dinamicamente (com cache)
  const ilFleets = await resolveILFleets();

  let page = 1;
  const requestedPageSize = String(c['il-size'] || '50');
  const pageSizeNum = parseInt(requestedPageSize, 10) || 50;
  const hardLimit = 200; // segurança absoluta: nunca mais que 200 páginas
  let totalPages = hardLimit; // será ajustado após página 1
  let effectivePageSize = pageSizeNum; // pode ser reduzido em caso de ERR_CONTENT_LENGTH_MISMATCH

  while (page <= totalPages && page <= hardLimit) {
    // Parâmetros — fleets Uber/99 resolvidas dinamicamente
    const paramsObj = {
      page: String(page),
      page_size: String(effectivePageSize),
      status: c['il-status'] || 'STORED,GOING_TO_ORIGIN,DELIVERED,IN_ROUTE,GOING_TO_DESTINATION,TRANSFERRING',
      slot_from_store_tz: slotFrom,
      fleets: ilFleets
    };

    const params = new URLSearchParams(paramsObj);

    const url = `${c['il-base']}/hela/api/v2/jobs?${params}`;
    console.log('%c[API]', 'color:#60a5fa;font-weight:bold', `Instaleap página ${page} (page_size=${effectivePageSize}) →`, url);

    // Retry com degradação de page_size para ERR_CONTENT_LENGTH_MISMATCH
    let res, fetchErr;
    for (let attempt = 0; attempt < 3; attempt++) {
      if (attempt > 0) {
        // Reduzir page_size pela metade a cada falha de rede (mínimo 5)
        effectivePageSize = Math.max(5, Math.floor(effectivePageSize / 2));
        paramsObj.page_size = String(effectivePageSize);
        const retryParams = new URLSearchParams(paramsObj);
        LOG.warn(`Instaleap página ${page} — retry ${attempt} com page_size=${effectivePageSize}`);
        try {
          res = await nexosFetch(`${c['il-base']}/hela/api/v2/jobs?${retryParams}`, {
            headers: { 'Authorization': `Bearer ${c['il-token']}`, 'Accept': 'application/json' }
          });
          fetchErr = null;
          break;
        } catch (e) {
          fetchErr = e;
          LOG.warn(`Instaleap página ${page} — tentativa ${attempt + 1} falhou: ${e.message}`);
          await new Promise(r => setTimeout(r, 1500 * attempt));
        }
      } else {
        try {
          res = await nexosFetch(url, {
            headers: {
              'Authorization': `Bearer ${c['il-token']}`,
              'Accept': 'application/json'
            }
          });
          fetchErr = null;
          break;
        } catch (e) {
          fetchErr = e;
          LOG.warn(`Instaleap página ${page} — tentativa 1 falhou: ${e.message}`);
          await new Promise(r => setTimeout(r, 1500));
        }
      }
    }
    if (fetchErr) {
      // Página 1 sem dados → erro fatal (não há nada para exibir)
      if (page === 1) throw fetchErr;
      // Páginas seguintes → descarta a página com erro e retorna o que já foi carregado
      LOG.warn(`Instaleap página ${page}: falha de rede após 3 tentativas (ERR_CONTENT_LENGTH_MISMATCH?). Retornando ${allRows.length} registro(s) já carregados.`);
      break;
    }

    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      const err = new Error(`Instaleap ${res.status} ${res.statusText}: ${txt.slice(0, 200)}`);
      // Marcar erros de autenticação para tratamento especial no caller
      if (res.status === 401 || res.status === 403) err.isAuthError = true;
      throw err;
    }

    const json = await res.json();
    const data = Array.isArray(json.data) ? json.data : [];

    // Capturar total real da API para calcular número de páginas
    const totalRecords = json.pagination?.total ?? json.metadata?.pagination?.total ?? null;

    // Ajustar totalPages após receber resposta da página 1
    if (page === 1 && totalRecords !== null) {
      totalPages = Math.ceil(totalRecords / pageSizeNum);
      LOG.info(`Instaleap: ${totalRecords} registros no total → ${totalPages} páginas de ${pageSizeNum}`);
    }

    LOG.ok(`Instaleap página ${page}: ${data.length} registros` + (totalRecords !== null && page === 1 ? ` (total API: ${totalRecords})` : ''));

    // Log diagnóstico na página 1: estrutura do primeiro item + pagination
    if (page === 1) {
      console.log('[INSTALEAP] 🔍 pagination:', JSON.stringify(json.pagination ?? json.metadata, null, 2));
      if (data.length > 0) {
        console.log('[INSTALEAP] 🔍 Primeiro item (estrutura):', JSON.stringify(data[0], null, 2).substring(0, 2000));
      } else {
        console.warn('[INSTALEAP] ⚠ Página 1 vazia. Resposta completa:', JSON.stringify(json, null, 2).substring(0, 1000));
      }
    }

    if (data.length === 0) {
      LOG.info(`Página ${page} vazia. Fim da paginação.`);
      break;
    }

    let addedThisPage = 0;

    for (const item of data) {
      const j = item.nebula_job || item;
      const cf = item.custom_fields || item;
      const id = String(j.job_number || j.id || '');

      if (!id || seenIds.has(id)) continue;
      seenIds.add(id);
      addedThisPage++;

      const storeName = (j.store?.name || j.store_name || '').split(' - ')[0].trim();
      const from = j.slot?.from || j.slot_from || '';
      const to = j.slot?.to || j.slot_to || '';

      // IDs para montar links: instaleapId = nebula_job.id, plataformaId = nebula_job.tasks[2].id
      const instaleapId = String(j.id || '');
      const task2 = j.tasks?.[2];
      const plataformaId = String(task2?.id || '');
      // nebula_job.tasks[2].contact_info.name — nome do motorista/plataforma
      const platformName = String(task2?.contact_info?.name || '');
      const rawStatus = String(cf.partial_status || j.status || '');

      allRows.push({
        jobId: id,
        instaleapId,
        plataformaId,
        platformName,
        loja: storeName,
        status: rawStatus,
        slotFrom: from,
        slotTo: to,
        slot: formatSlot(from, to),
        pickingStatus: '',
        pickingRaw: null,
      });
    }

    if (addedThisPage === 0) {
      LOG.warn(`Página ${page} não trouxe novos IDs. Encerrando para evitar loop.`);
      break;
    }

    // Callback incremental: notifica o caller com os dados parciais para renderização imediata
    if (typeof onPage === 'function') {
      try { onPage([...allRows]); } catch (e) { /* não bloquear paginação por erro na UI */ }
    }

    page++;
  }

  LOG.ok(`Instaleap total acumulado: ${allRows.length} registros`);
  return allRows;
}

function formatSlot(from, to) {
  try {
    if (!from && !to) return '—';
    const fDate = from ? new Date(from) : null;
    const tDate = to ? new Date(to) : null;

    if (tDate) {
      const rounded = new Date(tDate);
      rounded.setMinutes(rounded.getMinutes() + 1);
      rounded.setMinutes(0);
      rounded.setSeconds(0);
      const ff = fDate ? fDate.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '?';
      const tf = rounded.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
      return `${ff} – ${tf}`;
    }

    if (fDate) return fDate.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    return '—';
  } catch {
    return '—';
  }
}

// ════════════════════════════════════════════════
// GPA PICKING API
// ════════════════════════════════════════════════

/**
 * Busca dados de VÁRIOS pedidos na Instaleap de uma só vez (paralelo).
 * Sem `fleets` — pedidos de outros dias podem ter frota diferente ou nenhuma.
 * Retorna Map<jobId, objetoNormalizado>.
 */
// Cache em memória para stubs de pedidos anteriores:
// evita re-consultar o mesmo pedido em todo ciclo de 60s
const _stubIlCache = new Map(); // jobId → { data, ts, status }
const STUB_CACHE_TTL = 3 * 60 * 1000; // re-consulta após 3 min

async function fetchInstaleapByOrders(jobIds) {
  const c = readCfg();
  if (!c['il-token'] || !jobIds.length) return new Map();

  const now = Date.now();

  // Separar quais precisam de fetch (cache expirado ou status não-final)
  const toFetch = jobIds.filter(id => {
    const cached = _stubIlCache.get(String(id));
    if (!cached) return true;
    if (now - cached.ts > STUB_CACHE_TTL) return true;
    return false; // ainda válido no cache
  });

  // Limitar concorrência máxima em 10 requests simultâneos para evitar rate limit
  const MAX_CONCURRENT = 10;
  const freshMap = new Map();

  for (let i = 0; i < toFetch.length; i += MAX_CONCURRENT) {
    const batch = toFetch.slice(i, i + MAX_CONCURRENT);
    const results = await Promise.allSettled(batch.map(async jobId => {
      try {
        const slotStart = new Date(now - 90 * 24 * 3600 * 1000).toISOString().slice(0, 10);
        const params = new URLSearchParams({
          page: '1',
          page_size: '10',
          general: String(jobId),
          slot_from_store_tz: JSON.stringify({ start: `${slotStart} 00:00:00` }),
        });
        const res = await fetch(`${c['il-base']}/hela/api/v2/jobs?${params}`, {
          headers: { Authorization: `Bearer ${c['il-token']}`, Accept: 'application/json' }
        });
        if (!res.ok) return null;
        const json = await res.json();
        const data = Array.isArray(json.data) ? json.data : [];
        const jobIdStr = String(jobId);
        const match =
          data.find(item => String((item.nebula_job || item).job_number || (item.nebula_job || item).id || '') === jobIdStr) ||
          data.find(item => { const n = String((item.nebula_job || item).job_number || (item.nebula_job || item).id || ''); return n && (n.includes(jobIdStr) || jobIdStr.includes(n)); });
        if (!match) return null;
        const j  = match.nebula_job || match;
        const cf = match.custom_fields || match;
        const from = j.slot?.from || j.slot_from || '';
        const to   = j.slot?.to   || j.slot_to   || '';
        const task2 = j.tasks?.[2];
        return {
          jobId:        String(j.job_number || j.id || jobId),
          instaleapId:  String(j.id || ''),
          plataformaId: String(task2?.id || ''),
          platformName: String(task2?.contact_info?.name || ''),
          loja:         (j.store?.name || j.store_name || '').split(' - ')[0].trim(),
          status:       String(cf.partial_status || j.status || ''),
          slotFrom:     from,
          slotTo:       to,
          slot:         formatSlot(from, to),
        };
      } catch (e) {
        LOG.warn(`fetchInstaleapByOrders(${jobId}) erro:`, e.message);
        return null;
      }
    }));

    results.forEach((r, idx) => {
      const id = String(batch[idx]);
      if (r.status === 'fulfilled' && r.value) {
        _stubIlCache.set(id, { data: r.value, ts: now, status: r.value.status });
        freshMap.set(id, r.value);
      }
    });
  }

  // Montar mapa final: frescos + cache ainda válido
  const map = new Map();
  for (const id of jobIds.map(String)) {
    if (freshMap.has(id)) {
      map.set(id, freshMap.get(id));
    } else {
      const cached = _stubIlCache.get(id);
      if (cached) map.set(id, cached.data);
    }
  }

  const fetched = toFetch.length;
  const fromCache = jobIds.length - fetched;
  LOG.ok(`fetchInstaleapByOrders: ${map.size}/${jobIds.length} pedidos (${fetched} fetch, ${fromCache} cache)`);
  return map;
}

/** Alias singular para compatibilidade com chamadas pontuais */
async function fetchInstaleapByOrder(jobId) {
  const map = await fetchInstaleapByOrders([jobId]);
  return map.get(String(jobId)) ?? null;
}
// ════════════════════════════════════════════════
// PICKING ADMIN AUTH — captura token via popup
// ════════════════════════════════════════════════

/** Exibe overlay de bloqueio quando o token picking expira durante o uso */
function showPKLockOverlay(msg) {
  const overlay = document.getElementById('pk-lock-overlay');
  const statusEl = document.getElementById('pk-lock-status');
  const btn = document.getElementById('pk-lock-reconect-btn');
  if (overlay) overlay.style.display = 'flex';
  if (statusEl) statusEl.textContent = msg || '';
  if (btn) { btn.disabled = false; btn.innerHTML = '<span>🔑</span> Reconectar Picking Admin'; }
}

function hidePKLockOverlay() {
  const overlay = document.getElementById('pk-lock-overlay');
  const statusEl = document.getElementById('pk-lock-status');
  if (overlay) overlay.style.display = 'none';
  if (statusEl) statusEl.textContent = '';
}

/** Transiciona o login wall para a Etapa 3 (aguardando Picking Admin) */
function showLoginWallStep3() {
  const step2 = document.getElementById('wall-step2');
  const step3 = document.getElementById('wall-step3');
  const statusEl = document.getElementById('wall-step3-status');
  const retryBtn = document.getElementById('wall-step3-retry-btn');
  if (step2) step2.style.display = 'none';
  if (step3) step3.style.display = '';
  if (statusEl) statusEl.textContent = 'Aguardando login Picking Admin...';
  if (retryBtn) retryBtn.style.display = 'none';
}

function setLoginWallStep3Status(msg, showRetry = false) {
  const statusEl = document.getElementById('wall-step3-status');
  const retryBtn = document.getElementById('wall-step3-retry-btn');
  if (statusEl) statusEl.textContent = msg;
  if (retryBtn) retryBtn.style.display = showRetry ? '' : 'none';
}

/** Envia PK_AUTH_REQUEST ao background e retorna resposta */
async function _requestPickingToken() {
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
    throw new Error('Esta funcionalidade requer a extensão Chrome instalada.');
  }
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('Tempo esgotado (5 min).')), 5 * 60 * 1000 + 5000);
    chrome.runtime.sendMessage({ type: 'PK_AUTH_REQUEST' }, (response) => {
      clearTimeout(timeout);
      if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
      if (!response) { reject(new Error('Sem resposta do background.')); return; }
      resolve(response);
    });
  });
}

/** Login automático sequencial — disparado após login Instaleap quando token picking ausente */
async function pickingAdminLoginAuto() {
  if (window._pkLoginPending) {
    LOG.warn('PK: Login Picking Admin já em andamento — ignorando chamada duplicada');
    return;
  }
  window._pkLoginPending = true;

  showToast('🔑 Agora faça login no Picking Admin para carregar os status...', 'info');
  LOG.info('PK: Iniciando login Picking Admin sequencial...');
  try {
    const result = await _requestPickingToken();
    if (!result.success) throw new Error(result.error || 'Cancelado.');
    // Token já foi salvo no storage pelo background; apenas confirmar
    LOG.ok('PK: Token obtido — liberando painel');
    showToast('✅ Picking Admin autenticado! Carregando pedidos...', 'success');
    hideLoginWall();
    hidePKLockOverlay();
    saveConfig();
    window._pkLoginPending = false;
  } catch (err) {
    window._pkLoginPending = false;
    LOG.warn('PK: Login Picking Admin cancelado/falhou:', err.message);
    setLoginWallStep3Status('Login cancelado ou falhou. Tente novamente.', true);
    showToast('⚙ Login Picking Admin não concluído.', 'warn');
  }
}

/** Ouvinte: detecta remoção do token picking pelo background (expirado) */
function _watchPickingTokenRevocation() {
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.onChanged) return;
  if (window._pkRevokeListener) chrome.storage.onChanged.removeListener(window._pkRevokeListener);
  window._pkRevokeListener = function (changes, area) {
    if (area !== 'local' || !changes['nexos-gpa-api-token']) return;
    const newVal = changes['nexos-gpa-api-token'].newValue;
    if (!newVal) {
      LOG.warn('PK: nexos-gpa-api-token removido do storage — exibindo overlay de re-auth');
      showPKLockOverlay('Sessão Picking Admin expirada. Reconecte para continuar.');
    }
  };
  chrome.storage.onChanged.addListener(window._pkRevokeListener);
}

async function fetchOnePicking(jobId, cfg, gpaToken) {
  if (!gpaToken) {
    showPKLockOverlay('Token Picking Admin ausente. Faça login novamente.');
    return { jobId, status: 'Sem token', brand: '', raw: null };
  }

  const headers = {
    'Authorization': `Bearer ${gpaToken}`,
    'Accept': 'application/json'
  };

  const today = new Date().toISOString().slice(0, 10);
  const STATUS_LIST = 'AGUARDANDO_SEPARACAO,INICIO_SEPARACAO_ERRO,EM_INICIALIZACAO,EM_SEPARACAO,PEDIDO_INTERROMPIDO,REVISAO,VALIDACAO_CLIENTE,AGUARDANDO_PREPEDIDO,PREPEDIDO_GERADO,PREPEDIDO_ERRO,PAGAMENTO_ERRO,CONSULTA_PAGAMENTO,PAGAMENTO_APROVADO,AGUARDANDO_PAGAMENTO,AGUARDANDO_TRANSPORTE,AGUARDANDO_RETIRADA,EM_TRANSPORTE,ENTREGUE,NAO_ENTREGUE,FEITO_SA,CANCELAMENTO_SOLICITADO,CANCELADO';
  const pickingQuery = `sort=status,asc&saNumber=${encodeURIComponent(jobId)}&deliveryDateFrom=${today}&deliveryDateTo=${today}&size=20&statusList=${STATUS_LIST}&windowFrom=00:00&windowTo=23:00`;
  const url = `${cfg['pk-base']}/picking/api/v1/orders/list/summary/v2/store/0?${pickingQuery}`;

  try {
    const res = await fetch(url, { method: 'GET', headers });

    if (res.status === 401 || res.status === 403) {
      await new Promise(r => chrome.storage.local.remove('nexos-gpa-api-token', r));
      showPKLockOverlay('Sessão Picking Admin expirada. Reconecte para continuar.');
      return { jobId, status: 'Token expirado', brand: '', raw: null };
    }

    if (!res.ok) {
      return { jobId, status: 'Erro HTTP ' + res.status, brand: '', raw: null };
    }

    const json = await res.json();
    const contents = json.content || json.contents || json.Contents || [];
    if (!Array.isArray(contents) || !contents.length) {
      return { jobId, status: 'Não encontrado', brand: '', raw: null };
    }

    const finalEntry = contents.find(c => {
      const s = String(c?.status || '').toUpperCase();
      return s.includes('CANCEL') || s === 'DELIVERED' || s === 'FINISHED' || s.includes('ENTREGUE');
    });
    const first = finalEntry || contents[contents.length - 1];
    const status = (first?.status || '').trim();

    return { jobId, status: status || 'Não encontrado', brand: 'PA', raw: null };
  } catch (e) {
    console.warn(`[PICKING] ${jobId}: exceção — ${e.message}`);
    return { jobId, status: 'erro', brand: '', raw: null };
  }
}

async function fetchAllPicking(jobIds) {
  const c = readCfg();
  if (!jobIds.length) return {};

  // Verificar token picking antes de iniciar
  const gpaToken = await new Promise(resolve => {
    try { chrome.storage.local.get(['nexos-gpa-api-token'], r => resolve((r && r['nexos-gpa-api-token']) || '')); }
    catch { resolve(''); }
  });
  if (!gpaToken) {
    showPKLockOverlay('Token Picking Admin ausente. Faça login para ver os status dos pedidos.');
    return {};
  }

  const concurrency = parseInt(c['pk-concurrency'] || '10', 10);
  console.log(`[MONITOR] Picking: ${jobIds.length} pedidos, concorrência ${concurrency}`);

  const results = {};
  const queue = [...jobIds];

  async function worker() {
    while (queue.length) {
      const id = queue.shift();
      try {
        const r = await fetchOnePicking(id, c, gpaToken);
        results[id] = r.status;
      } catch (e) {
        console.warn(`[MONITOR] Picking erro ${id}:`, e.message);
        results[id] = 'erro';
      }
    }
  }

  const workers = Array.from({ length: Math.min(concurrency, jobIds.length) }, () => worker());
  await Promise.all(workers);

  console.log(`[MONITOR] Picking completo: ${Object.keys(results).length} respostas`);
  return results;
}

// ════════════════════════════════════════════════
// SHAREPOINT GRAPH API
// ════════════════════════════════════════════════
async function resolveSP_base() {
  if (spCache.siteId && spCache.listId) return spCache;

  const c = readCfg();
  if (!c['sp-site']) return null;

  // Usa token delegado do usuário — mesmo esquema das outras listas (picking overlay)
  const token = await syncSharePointTokenFromAuth();
  if (!token) {
    LOG.warn('SP: token do usuário não disponível para resolver site/lista');
    return null;
  }

  const [host, ...pathParts] = c['sp-site'].replace('https://', '').split('/');
  const sitePath = pathParts.join('/');

  LOG.sp(`Resolvendo site: ${host}:/${sitePath}`);
  const siteRes = await fetch(
    `https://graph.microsoft.com/v1.0/sites/${host}:/${sitePath}`,
    { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' } }
  );
  if (!siteRes.ok) {
    if (siteRes.status === 401) {
      handleSpAuthError('Token sem permissão no site SP (401)');
      throw new Error('SP site 401: sessão expirada — revalidação iniciada');
    }
    throw new Error(`SP site ${siteRes.status}: ${siteRes.statusText}`);
  }
  // Calibrar relógio usando o header Date: do servidor (sync entre máquinas)
  calibrateServerClock(siteRes);
  const site = await siteRes.json();
  spCache.siteId = site.id;
  LOG.sp('Site ID:', site.id);

  const listRes = await fetch(
    `https://graph.microsoft.com/v1.0/sites/${site.id}/lists/${c['sp-list']}`,
    { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' } }
  );
  if (!listRes.ok) throw new Error(`SP lista ${listRes.status}: ${listRes.statusText}`);
  const list = await listRes.json();
  spCache.listId = list.id;
  LOG.sp('Lista ID:', list.id, '— Display:', list.displayName);

  return spCache;
}

async function resolveSP() {
  // Sincroniza token delegado do usuário antes de resolver (igual ao picking overlay)
  const token = await syncSharePointTokenFromAuth();
  if (!token) {
    // Sem token após tentativa — sessão inválida
    await handleSpAuthError('Nenhum token disponível para SharePoint');
    throw new Error('SP: sem token — sessão expirada');
  }
  try {
    return await resolveSP_base();
  } catch (err) {
    if (err.message && (err.message.includes('401') || err.message.includes('sessão expirada'))) {
      // handleSpAuthError já foi chamado dentro de resolveSP_base para 401
      spCache = { siteId: null, listId: null };
    }
    throw err;
  }
}

async function fetchSharePoint() {
  const c = readCfg();
  if (!c['sp-site']) {
    LOG.warn('SharePoint não configurado (sp-site ausente). Tratativas só locais.');
    return {};
  }

  // Token delegado do usuário — mesmo esquema das outras listas
  const token = await syncSharePointTokenFromAuth();
  if (!token) {
    LOG.warn('SP token do usuário não disponível. Tratativas só locais.');
    return {};
  }

  const ids = await resolveSP().catch(e => { LOG.error('SP resolve:', e.message); return null; });
  if (!ids) return {};

  const url = `https://graph.microsoft.com/v1.0/sites/${ids.siteId}/lists/${ids.listId}/items?$expand=fields&$top=5000`;
  console.log('%c[SHAREPOINT]', 'color:#60c3fb;font-weight:bold', 'Buscando tratativas:', url);

  const res = await fetch(url, {
    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
  });
  if (!res.ok) {
    if (res.status === 401) { handleSpAuthError('Token expirado ao buscar items SP (401)'); return {}; }
    throw new Error(`SP items ${res.status}: ${res.statusText}`);
  }

  // Calibrar clock E definir spLastCheck com tempo exato do servidor.
  // O filtro Modified gt '...' do polling usará esse timestamp — independente do relógio local.
  calibrateServerClock(res);
  const _spLoadDateHeader = res.headers.get('date');
  if (_spLoadDateHeader) {
    // Subtrai 5s de margem para não perder itens gravados próximo ao momento do load
    spLastCheck = new Date(new Date(_spLoadDateHeader).getTime() - 5000).toISOString();
    LOG.sp(`spLastCheck ancorado no servidor: ${spLastCheck}`);
  }

  const data = await res.json();
  console.log('%c[SHAREPOINT]', 'color:#60c3fb;font-weight:bold', `${data.value?.length ?? 0} tratativas carregadas`);

  const fId     = c['sp-f-id']     || 'IDPedidoGPA';
  const fStatus = c['sp-f-status'] || 'StatusTratativa';
  const fText   = c['sp-f-text']   || 'Tratativa';
  const fLoja   = c['sp-f-loja']   || 'Loja';
  const fSlot   = c['sp-f-slot']   || 'Slot';

  const map = {};
  (data.value || []).forEach(item => {
    const f  = item.fields || {};
    const id = String(f[fId] || '');
    if (id) {
      const status = f[fStatus] || 'Pendente';
      const isResolved = status === 'Resolvido' || status === 'Sem ação necessária';
      const editorSP = item.lastModifiedBy?.user || {};
      map[id] = {
        status,
        texto:    f[fText]  || '',
        loja:     f[fLoja]  || '',   // guardado para reconstruir stub se o pedido sair da IL
        slot:     f[fSlot]  || '',
        spItemId: item.id,
        resolvedAt: isResolved && item.lastModifiedDateTime
          ? item.lastModifiedDateTime.slice(0, 10)
          : undefined,
        // Editor vem sempre do SP (fonte de verdade compartilhada)
        editor: editorSP.displayName || editorSP.email
          ? {
              nome:  editorSP.displayName || '',
              email: editorSP.email       || '',
              at:    item.lastModifiedDateTime || '',
            }
          : undefined,
      };
    }
  });

  return map;
}

async function saveTratativa(jobId) {
  const c = readCfg();
  const t = tratativas[jobId];
  if (!t) return;

  // Token delegado do usuário — mesmo esquema das outras listas (nome do usuário aparece no SP)
  const token = await syncSharePointTokenFromAuth();
  if (!token) {
    await handleSpAuthError('Token indisponível ao salvar tratativa');
    setSaveInd(jobId, 'err', '✕ sem auth');
    return;
  }
  if (!c['sp-site']) {
    setSaveInd(jobId, 'local', '● local');
    LOG.info(`Tratativa ${jobId} salva apenas localmente (SP não configurado)`);
    return;
  }

  setSaveInd(jobId, 'saving', '↑...');

  try {
    const ids = await resolveSP();
    if (!ids) throw new Error('Não foi possível resolver site/lista SP');

    const fId     = c['sp-f-id']     || 'IDPedidoGPA';
    const fLoja   = c['sp-f-loja']   || 'Loja';
    const fSlot   = c['sp-f-slot']   || 'Slot';
    const fStatus = c['sp-f-status'] || 'StatusTratativa';
    const fText   = c['sp-f-text']   || 'Tratativa';

    const order = orders.find(o => o.jobId === jobId);

    const fields = {
      [fId]:     jobId,
      [fStatus]: t.status,
      [fText]:   t.texto,
    };
    if (order) {
      fields[fLoja] = order.loja;
      fields[fSlot] = order.slot;
    }

    let res;
    if (t.spItemId) {
      LOG.sp(`PATCH item ${t.spItemId} para pedido ${jobId}`);
      res = await fetch(
        `https://graph.microsoft.com/v1.0/sites/${ids.siteId}/lists/${ids.listId}/items/${t.spItemId}/fields`,
        {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify(fields)
        }
      );
    } else {
      // Antes de criar, verificar se já existe no SP para evitar duplicatas
      // (race condition: SP fetch ainda não terminou quando o usuário salva)
      LOG.sp(`Verificando existência no SP para pedido ${jobId}...`);
      const checkRes = await fetch(
        `https://graph.microsoft.com/v1.0/sites/${ids.siteId}/lists/${ids.listId}/items` +
        `?$expand=fields&$filter=fields/${fId} eq '${encodeURIComponent(jobId)}'&$top=1&$select=id`,
        { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' } }
      );
      if (checkRes.ok) {
        const checkData = await checkRes.json();
        const existing = checkData.value?.[0];
        if (existing?.id) {
          // Já existe — usar PATCH
          tratativas[jobId].spItemId = existing.id;
          LOG.sp(`Item já existia no SP: id=${existing.id} — usando PATCH`);
          res = await fetch(
            `https://graph.microsoft.com/v1.0/sites/${ids.siteId}/lists/${ids.listId}/items/${existing.id}/fields`,
            {
              method: 'PATCH',
              headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
              },
              body: JSON.stringify(fields)
            }
          );
        }
      }
      if (!res) {
        LOG.sp(`POST novo item para pedido ${jobId}`);
        res = await fetch(
          `https://graph.microsoft.com/v1.0/sites/${ids.siteId}/lists/${ids.listId}/items`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json',
              'Accept': 'application/json'
            },
            body: JSON.stringify({ fields })
          }
        );
        if (res.ok) {
          const d = await res.json();
          tratativas[jobId].spItemId = d.id;
          LOG.sp(`Item criado no SP: id=${d.id}`);
        }
      }
    }

    if (!res.ok) {
      if (res.status === 401) {
        handleSpAuthError('Token expirado ao salvar tratativa (401)');
        setSaveInd(jobId, 'err', '✕ sessão expirada');
        return;
      }
      const errTxt = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status}: ${errTxt.slice(0, 200)}`);
    }

    LOG.ok(`Tratativa ${jobId} salva no SharePoint`);
    setSaveInd(jobId, 'saved', '✓ salvo');
    // Não avança spLastCheck aqui — o próprio item recém salvo será visto no próximo poll
    // mas será ignorado porque statusChanged e textoChanged serão false (já atualizados localmente)
  } catch (e) {
    LOG.error(`Erro ao salvar tratativa ${jobId}:`, e.message);
    setSaveInd(jobId, 'err', '✕ erro');
    showToast('Erro ao salvar no SharePoint: ' + e.message, 'error');
  }
}

// ══════════════════════════════════════════════════════════════
// PAINEL DE HISTÓRICO — busca completa do SP com metadados
// ══════════════════════════════════════════════════════════════
// Cache dos itens brutos do SP para filtros locais sem re-buscar
let _historicoItemsCache = [];
let _histSortCol = 'modifiedAt'; // coluna padrão: mais recente primeiro
let _histSortDir = -1;           // -1 = desc, 1 = asc

function sortHistorico(col) {
  if (_histSortCol === col) { _histSortDir *= -1; }
  else { _histSortCol = col; _histSortDir = col === 'modifiedAt' || col === 'createdAt' ? -1 : 1; }
  aplicarFiltrosHistorico();
}

function _atualizarIndicadoresSortHistorico() {
  document.querySelectorAll('[data-sort-hist]').forEach(th => {
    const col = th.dataset.sortHist;
    const span = document.getElementById(`hsa-${col}`);
    if (!span) return;
    if (col === _histSortCol) {
      th.classList.add('sorted');
      span.textContent = _histSortDir === 1 ? '▲' : '▼';
    } else {
      th.classList.remove('sorted');
      span.textContent = '';
    }
  });
}

async function fetchHistoricoSP() {
  const c = readCfg();
  if (!c['sp-site']) return { error: 'SharePoint não configurado.' };

  const token = await syncSharePointTokenFromAuth();
  if (!token) return { error: 'Sem autenticação SharePoint.' };

  const ids = await resolveSP().catch(() => null);
  if (!ids) return { error: 'Não foi possível resolver site/lista SP.' };

  const fId     = c['sp-f-id']     || 'IDPedidoGPA';
  const fLoja   = c['sp-f-loja']   || 'Loja';
  const fSlot   = c['sp-f-slot']   || 'Slot';
  const fStatus = c['sp-f-status'] || 'StatusTratativa';
  const fText   = c['sp-f-text']   || 'Tratativa';

  const url = `https://graph.microsoft.com/v1.0/sites/${ids.siteId}/lists/${ids.listId}/items` +
    `?$expand=fields` +
    `&$top=5000`;
    // lastModifiedBy vem na resposta por padrão (não é navigation property, não precisa de $expand)

  const res = await fetch(url, {
    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
  });
  if (!res.ok) {
    if (res.status === 401) { handleSpAuthError('Token expirado ao buscar histórico SP'); return { error: 'Sessão expirada.' }; }
    return { error: `Erro HTTP ${res.status}` };
  }

  const data = await res.json();
  _historicoItemsCache = (data.value || []).map(item => {
    const f      = item.fields || {};
    const editor = item.lastModifiedBy?.user || {};
    return {
      jobId:       String(f[fId]     || '—'),
      loja:        String(f[fLoja]   || '—'),
      slot:        String(f[fSlot]   || '—'),
      status:      String(f[fStatus] || 'Pendente'),
      texto:       String(f[fText]   || ''),
      modifiedAt:  item.lastModifiedDateTime || '',
      createdAt:   item.createdDateTime || '',
      editorNome:  editor.displayName || '',
      editorEmail: editor.email || '',
    };
  });

  return { items: _historicoItemsCache };
}

function aplicarFiltrosHistorico() {
  let items = [..._historicoItemsCache];

  const q       = (document.getElementById('hist-filtro-busca')?.value   || '').toLowerCase().trim();
  const status  =  document.getElementById('hist-filtro-status')?.value  || '';
  const loja    =  document.getElementById('hist-filtro-loja')?.value    || '';
  const editor  =  document.getElementById('hist-filtro-editor')?.value  || '';
  const periodo =  document.getElementById('hist-filtro-periodo')?.value || '';

  if (q) items = items.filter(i =>
    i.jobId.toLowerCase().includes(q) ||
    i.loja.toLowerCase().includes(q)  ||
    i.texto.toLowerCase().includes(q) ||
    i.editorNome.toLowerCase().includes(q)
  );
  if (status)  items = items.filter(i => i.status === status);
  if (loja)    items = items.filter(i => i.loja   === loja);
  if (editor)  items = items.filter(i => i.editorNome === editor);
  if (periodo) {
    const agora = Date.now();
    const limites = { hoje: 86400000, '7d': 7*86400000, '30d': 30*86400000 };
    const ms = limites[periodo];
    if (ms) items = items.filter(i => i.modifiedAt && (agora - new Date(i.modifiedAt).getTime()) <= ms);
  }

  // ── Ordenação ────────────────────────────────────────────────────────────
  const col = _histSortCol;
  const dir = _histSortDir;
  items.sort((a, b) => {
    let va = a[col] || '', vb = b[col] || '';
    // Datas: comparar como timestamps
    if (col === 'modifiedAt' || col === 'createdAt') {
      va = va ? new Date(va).getTime() : 0;
      vb = vb ? new Date(vb).getTime() : 0;
      return (va - vb) * dir;
    }
    // Strings: localeCompare
    return va.toString().localeCompare(vb.toString(), 'pt-BR', { sensitivity: 'base' }) * dir;
  });

  renderHistoricoTabela(items);
  _atualizarIndicadoresSortHistorico();
  document.getElementById('hist-result-count').textContent =
    `${items.length} de ${_historicoItemsCache.length} registros`;
}

function _popularSelectsHistorico(items) {
  const lojas   = [...new Set(items.map(i => i.loja).filter(Boolean))].sort();
  const editores = [...new Set(items.map(i => i.editorNome).filter(Boolean))].sort();

  const selLoja = document.getElementById('hist-filtro-loja');
  const selEd   = document.getElementById('hist-filtro-editor');
  if (selLoja) {
    const cur = selLoja.value;
    selLoja.innerHTML = `<option value="">Todas as lojas</option>` +
      lojas.map(l => `<option value="${escapeHtml(l)}">${escapeHtml(l)}</option>`).join('');
    selLoja.value = cur;
  }
  if (selEd) {
    const cur = selEd.value;
    selEd.innerHTML = `<option value="">Todos os operadores</option>` +
      editores.map(e => `<option value="${escapeHtml(e)}">${escapeHtml(e)}</option>`).join('');
    selEd.value = cur;
  }
}

function _atualizarMetricasHistorico(items) {
  const total      = items.length;
  const resolvidos = items.filter(i => i.status === 'Resolvido' || i.status === 'Sem ação necessária').length;
  const andamento  = items.filter(i => i.status === 'Em andamento').length;
  const pendentes  = items.filter(i => i.status === 'Pendente').length;
  const manuais    = items.filter(i => i.status === 'Solicitado manual').length;
  const editores   = new Set(items.map(i => i.editorNome).filter(Boolean)).size;
  const pct        = total > 0 ? Math.round(resolvidos / total * 100) : 0;

  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  set('hm-total-val',     total);
  set('hm-resolvidos-val', resolvidos);
  set('hm-andamento-val',  andamento);
  set('hm-pendentes-val',  pendentes);
  set('hm-manuais-val',    manuais);
  set('hm-editores-val',   editores);
  set('hm-resolvidos-pct', `${pct}% do total`);
  set('hist-total-label',  `${total} registros no SharePoint`);
}

const HIST_STATUS_CLS = {
  'Resolvido':           'hist-s-resolvido',
  'Sem ação necessária': 'hist-s-sem',
  'Em andamento':        'hist-s-andamento',
  'Solicitado manual':   'hist-s-manual',
  'Pendente':            'hist-s-pendente',
};

function renderHistoricoTabela(items) {
  const tbody = document.getElementById('hist-tbody');
  if (!tbody) return;

  if (!items || !items.length) {
    tbody.innerHTML = `<tr><td colspan="8" class="hist-td-empty">Nenhum registro encontrado com os filtros selecionados.</td></tr>`;
    return;
  }

  tbody.innerHTML = items.map(it => {
    const cls      = HIST_STATUS_CLS[it.status] || 'hist-s-pendente';
    const when     = tempoRelativo(it.modifiedAt);
    const dtEdit   = it.modifiedAt ? new Date(it.modifiedAt).toLocaleString('pt-BR') : '—';
    const dtCreate = it.createdAt  ? new Date(it.createdAt).toLocaleString('pt-BR')  : '—';
    const emailKey = (it.editorEmail || '').toLowerCase();
    const iniciais = (it.editorNome || '').split(' ').filter(Boolean).slice(0, 2).map(p => p[0]).join('').toUpperCase() || '?';
    const tooltip  = `${escapeHtml(it.editorNome || 'Desconhecido')}${it.editorEmail ? '\n' + escapeHtml(it.editorEmail) : ''}`;
    const cachedPhoto = typeof _photoCache.get(emailKey) === 'string' ? _photoCache.get(emailKey) : null;
    const avatarStyle = cachedPhoto ? `background-image:url('${cachedPhoto}');background-size:cover;color:transparent;` : '';

    return `<tr>
      <td class="hist-td-jobid" title="${escapeHtml(it.jobId)}">${escapeHtml(it.jobId)}</td>
      <td>${escapeHtml(it.loja)}</td>
      <td style="white-space:nowrap">${escapeHtml(it.slot)}</td>
      <td><span class="hist-badge ${cls}">${escapeHtml(it.status)}</span></td>
      <td class="hist-td-anotacao">${it.texto ? escapeHtml(it.texto) : '<span style="color:var(--muted)">—</span>'}</td>
      <td>
        <div class="hist-td-editor">
          <span class="hist-td-avatar" title="${tooltip}" data-avatar-email="${escapeHtml(emailKey)}" style="${avatarStyle}">${cachedPhoto ? '' : iniciais}</span>
          <span>${escapeHtml(it.editorNome || 'Desconhecido')}</span>
        </div>
      </td>
      <td class="hist-td-time" title="${dtEdit}">${when}</td>
      <td class="hist-td-time">${dtCreate}</td>
    </tr>`;
  }).join('');

  // Carrega avatares assíncronos para os emails que ainda não estão em cache
  const emailsVistos = new Set();
  items.forEach(it => {
    if (it.editorEmail && !emailsVistos.has(it.editorEmail.toLowerCase())) {
      emailsVistos.add(it.editorEmail.toLowerCase());
      _loadAvatarsByEmail(it.editorEmail);
    }
  });
}

/* ══════════════════════════════════════════════════════════════════════════
   HISTÓRICO DE SOLICITAÇÕES — lógica completa
   ══════════════════════════════════════════════════════════════════════════ */

/** Estado interno do painel */
let _hsDados = [];           // todos os registros carregados
let _hsFiltrados = [];       // após filtros
let _hsSortCol = 'horario';  // coluna de ordenação atual
let _hsSortAsc = false;      // direção
let _hsPeriodo = 'mes';      // 'dia' | 'mes'

/** Campos da lista SP que mapeiam para as colunas da tabela.
 *  Podem ser sobrescritos via config futuramente. */
const HS_SP_FIELDS = {
  idPedido:    'PedidoGPAID',
  nexosOrderId:'LinkTitle',
  // loja   → join com Nexos_Pedidos (CodigoLoja) por PedidoGPAID; fallback: extrair do LinkTitle
  // formato → join com Nexos_Pedidos (FlagEntregue) por PedidoGPAID
  status:      'StatusPicking',   // 'entregue' | 'cancelado'
  plataforma:  'Plataforma',
  modalidade:  'ModalidadedeEnvio',
  valor:       'ValorSolicitacao',
  idPlataforma:'TrackingLink',    // Hiperlink — extração via _hsExtrairTextoHtml()
  // solicitante vem de item.createdBy.user.displayName (campo de sistema, não em fields)
  horario:     'Created',
};

/** Carrega pedidos finalizados do SharePoint.
 *  Lista: Nexos_PedidosArmazenados (mesma do monitor) com filtro StatusFinalizado.
 *  Campos extras (Plataforma, Modalidade, Valor…) são gravados pelo picking overlay. */
async function carregarHistSolicitacoes() {
  const nivel = (_monitorUserNivel || '').toLowerCase();
  const isGestao = nivel === 'gestão' || nivel === 'gestao';

  const container = document.getElementById('view-hist-solicitacoes');
  if (!isGestao && _monitorUserNivel !== null) {
    // Usuário autenticado mas sem nível Gestão — mostrar bloqueio
    if (container) {
      container.innerHTML = `
        <div class="access-blocked-panel">
          <div class="ab-icon">🔒</div>
          <div class="ab-title">Acesso Restrito</div>
          <div class="ab-sub">O painel <strong>Histórico de Solicitações</strong> é exclusivo
          para o nível <strong>Gestão</strong>.<br>Entre em contato com o administrador Nexos.</div>
        </div>`;
    }
    return;
  }

  const tbody = document.getElementById('hs-tbody');
  if (tbody) tbody.innerHTML = `<tr><td colspan="10" class="hs-td-empty">⏳ Buscando no SharePoint...</td></tr>`;

  const c = readCfg();
  if (!c['sp-site']) {
    if (tbody) tbody.innerHTML = `<tr><td colspan="10" class="hs-td-empty" style="color:var(--amber)">
      ⚙ Configure o site SharePoint no painel de Configurações para usar este painel.</td></tr>`;
    return;
  }

  // ── Lista hardcoded: Historico_Solicitacoes ──────────────────────────────
  // Nome da lista conforme cadastrado no SharePoint — não usa cfg.spList (que é Nexos_StatusPedidos)
  const HS_LIST_NAME = 'Nexos_StatusPedidos';

  try {
    // Token delegado do usuário — mesmo esquema das outras listas
    const token = await syncSharePointTokenFromAuth();
    if (!token) throw new Error('Token SP não disponível. Faça login corporativo.');

    // Resolver siteId (reutiliza cache do monitor se disponível)
    // Forçar re-resolução se o cache tiver siteId inválido (null/undefined/string 'null')
    let siteId = (spCache.siteId && spCache.siteId !== 'null') ? spCache.siteId : null;
    if (!siteId) {
      const [host, ...pathParts] = c['sp-site'].replace('https://', '').split('/');
      const sitePath = pathParts.join('/');
      const siteRes = await fetch(
        `https://graph.microsoft.com/v1.0/sites/${host}:/${sitePath}`,
        { headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' } }
      );
      if (!siteRes.ok) throw new Error(`SP site ${siteRes.status}: ${siteRes.statusText}`);
      const siteData = await siteRes.json();
      siteId = siteData.id;
      spCache.siteId = siteId; // atualizar cache
    }

    // Verificar se a lista existe — se não encontrar por nome, tentar descobrir
    // $orderby por campos de sistema usa createdDateTime (nível de item), não fields/Created
    // $select=createdBy garante que o campo de sistema Author (solicitante) venha no response
    const url = `https://graph.microsoft.com/v1.0/sites/${siteId}/lists/${encodeURIComponent(HS_LIST_NAME)}/items`
      + `?$expand=fields`
      + `&$select=id,createdDateTime,createdBy,fields`
      + `&$top=5000&$orderby=createdDateTime desc`;

    const resp = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!resp.ok) {
      const txt = await resp.text().catch(() => '');
      // Se a lista não foi encontrada, tentar listar todas para diagnóstico
      if (resp.status === 404) {
        try {
          const listsRes = await fetch(
            `https://graph.microsoft.com/v1.0/sites/${siteId}/lists?$select=id,displayName,name&$top=100`,
            { headers: { Authorization: `Bearer ${token}` } }
          );
          if (listsRes.ok) {
            const listsData = await listsRes.json();
            const names = (listsData.value || []).map(l => l.displayName || l.name).join(', ');
            throw new Error(`Lista "${HS_LIST_NAME}" não encontrada no site. Listas disponíveis: ${names || '(nenhuma)'}`);
          }
        } catch (diagErr) {
          if (diagErr.message.includes('Listas disponíveis')) throw diagErr;
        }
      }
      throw new Error(`HTTP ${resp.status} — ${txt}`);
    }
    const data = await resp.json();

    // ── Batch: buscar CodigoLoja e FlagEntregue de Nexos_Pedidos ──────────────
    const pedidosMap = new Map(); // PedidoGPAID → { loja, formato }
    try {
      const pedidosResp = await fetch(
        `https://graph.microsoft.com/v1.0/sites/${siteId}/lists/${encodeURIComponent('Nexos_Pedidos')}/items`
        // IDPedidoGPA é o campo Title (PK); CodigoLoja pode ter nome interno C_x00f3_digoLoja
        + `?$expand=fields($select=Title,CodigoLoja,C_x00f3_digoLoja,Modalidade)&$top=5000`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (pedidosResp.ok) {
        const pd = await pedidosResp.json();
        for (const p of pd.value || []) {
          const pf = p.fields || {};
          // Title = IDPedidoGPA (PK da lista Nexos_Pedidos)
          const pedidoId = pf.Title || pf.IDPedidoGPA;
          if (pedidoId) pedidosMap.set(String(pedidoId), {
            loja:    pf.CodigoLoja || pf.C_x00f3_digoLoja || '—',
            formato: pf.Modalidade || '—',
          });
        }
        LOG.ok(`[HistSol] ${pedidosMap.size} registros de Nexos_Pedidos carregados para join`);
      } else {
        LOG.warn(`[HistSol] Nexos_Pedidos fetch ${pedidosResp.status} — loja/formato via fallback`);
      }
    } catch (e) {
      LOG.warn('[HistSol] Falha ao buscar Nexos_Pedidos:', e.message);
    }

    const items = (data.value || []).map(item => {
      const f = item.fields || {};
      const statusRaw = (f[HS_SP_FIELDS.status] || '').toLowerCase();
      const plat      = (f[HS_SP_FIELDS.plataforma] || '').toLowerCase();
      // solicitante: campo de sistema, vem em item.createdBy (não em fields)
      const solicitante = item.createdBy?.user?.displayName
        || item.createdBy?.user?.email
        || f['Author']
        || '—';
      // idPlataforma: campo Hiperlink pode retornar HTML wrapper — extrair apenas o texto
      const idPlataformaRaw = f[HS_SP_FIELDS.idPlataforma] || '';
      const idPlataforma    = _hsExtrairTextoHtml(idPlataformaRaw) || '—';
      // loja/formato: join com Nexos_Pedidos; fallback loja do LinkTitle (NEXOS-ts-LOJA-pedido)
      const pedInfo = pedidosMap.get(String(f[HS_SP_FIELDS.idPedido] || '')) || {};
      const nexosId = f[HS_SP_FIELDS.nexosOrderId] || '';
      const idParts = nexosId.split('-');
      // formato: NEXOS-{timestamp}-{loja}-{pedidoId} → loja = índice 2 (timestamp sem hífens)
      const lojaFromId = idParts.length >= 4 ? idParts.slice(2, idParts.length - 1).join('-') : '—';
      return {
        id:          item.id,
        idPedido:    f[HS_SP_FIELDS.idPedido]    || f[HS_SP_FIELDS.nexosOrderId] || '—',
        nexosOrderId:f[HS_SP_FIELDS.nexosOrderId] || '',
        formato:     pedInfo.formato || '—',
        loja:        pedInfo.loja    || lojaFromId || '—',
        status:      statusRaw.includes('final') ? 'entregue' : statusRaw.includes('cancel') ? 'cancelado' : statusRaw || '—',
        plataforma:  f[HS_SP_FIELDS.plataforma].toUpperCase() || '—',
        plataformaKey: plat.includes('uber') ? 'uber' : plat.includes('lala') ? 'lalamove' : plat.includes('99') ? '99' : plat.includes('james') ? 'james' : 'outros',
        modalidade:  f[HS_SP_FIELDS.modalidade]   || '—',
        valor:       parseFloat(f[HS_SP_FIELDS.valor]) || 0,
        idPlataforma,
        solicitante,
        horario:     f[HS_SP_FIELDS.horario]      || item.createdDateTime || '',
      };
    });

    _hsDados = items;
    LOG.ok(`[HistSol] ${items.length} registros carregados de ${HS_LIST_NAME}`);

    // Preencher selects de loja e solicitante
    _hsPopularSelects(items);
    aplicarFiltrosHistSol();

    document.getElementById('hs-total-label').textContent =
      `${items.length} registro${items.length !== 1 ? 's' : ''} carregado${items.length !== 1 ? 's' : ''}`;

  } catch (err) {
    LOG.error('[HistSol] Erro ao carregar:', err.message);
    if (tbody) tbody.innerHTML = `<tr><td colspan="10" class="hs-td-empty" style="color:var(--red)">
      ❌ ${escapeHtml(err.message)}</td></tr>`;
  }
}

/** Detecta o "formato" do pedido a partir do ID (NEXOS-LOJA-NUM ou numérico ou UUID) */
function _hsFormatoFromId(id) {
  if (!id || id === '—') return '—';
  if (/^NEXOS-/i.test(id))     return 'NEXOS';
  if (/^\d{6,}$/.test(id))     return 'NUMÉRICO';
  if (/^[0-9a-f-]{36}$/i.test(id)) return 'UUID';
  return 'OUTRO';
}

/**
 * Extrai texto puro de um campo que pode conter HTML wrapper do SharePoint.
 * Campos Hiperlink do SP retornam algo como:
 *   <div class="ExternalClass...">1ec61b58-6321-436f-ab7d-7c4632882c8d</div>
 * Esta função retorna apenas o texto interno, sem tags.
 */
function _hsExtrairTextoHtml(valor) {
  if (!valor) return '';
  const str = String(valor).trim();
  // Sem HTML — retornar direto
  if (!str.includes('<')) return str;
  // Extrair textContent via DOMParser (funciona em contexto de página)
  try {
    const doc = new DOMParser().parseFromString(str, 'text/html');
    return (doc.body.textContent || '').trim();
  } catch (_) {
    // Fallback: remover tags com regex
    return str.replace(/<[^>]+>/g, '').trim();
  }
}

/** Preenche os selects dinâmicos de Loja e Solicitante */
function _hsPopularSelects(items) {
  const lojas = [...new Set(items.map(i => i.loja).filter(v => v && v !== '—'))].sort();
  const solicitantes = [...new Set(items.map(i => i.solicitante).filter(v => v && v !== '—'))].sort();
  const formatos = [...new Set(items.map(i => i.formato).filter(v => v && v !== '—'))].sort();


  const selLoja = document.getElementById('hs-filtro-loja');
  if (selLoja) {
    selLoja.innerHTML = '<option value="">Todas as lojas</option>' +
      lojas.map(l => `<option value="${escapeHtml(l)}">${escapeHtml(l)}</option>`).join('');
  }
  const selSol = document.getElementById('hs-filtro-solicitante');
  if (selSol) {
    selSol.innerHTML = '<option value="">Todos os solicitantes</option>' +
      solicitantes.map(s => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join('');
  }
  const selFormato = document.getElementById('hs-filtro-formato');
  if (selFormato) {
    selFormato.innerHTML = '<option value="">Todos os formatos</option>' +
      formatos.map(f => `<option value="${escapeHtml(f)}">${escapeHtml(f)}</option>`).join('');
  }
}
  

/** Aplica todos os filtros e re-renderiza a tabela */
function aplicarFiltrosHistSol() {
  const busca      = (document.getElementById('hs-busca')?.value || '').toLowerCase().trim();
  const status     = document.getElementById('hs-filtro-status')?.value     || '';
  const plataforma = document.getElementById('hs-filtro-plataforma')?.value || '';
  const loja       = document.getElementById('hs-filtro-loja')?.value       || '';
  const solicitante= document.getElementById('hs-filtro-solicitante')?.value || '';
  const modalidade = document.getElementById('hs-filtro-modalidade')?.value || '';
  const formato = document.getElementById('hs-filtro-formato')?.value || '';
  const dataDe     = document.getElementById('hs-data-de')?.value  || '';
  const dataAte    = document.getElementById('hs-data-ate')?.value || '';

  _hsFiltrados = _hsDados.filter(it => {
    if (status     && it.status           !== status)     return false;
    if (plataforma && it.plataformaKey    !== plataforma) return false;
    if (loja       && it.loja             !== loja)       return false;
    if (solicitante&& it.solicitante      !== solicitante) return false;
    if (formato    && it.formato          !== formato)    return false;

    if (modalidade) {
      const m = (it.modalidade || '').toLowerCase();
      if (modalidade === 'moto' && !m.includes('moto'))  return false;
      if (modalidade === 'carro'&& !m.includes('carr'))  return false;
      if (modalidade === 'utilitario' && !m.includes('utilit'))   return false;
    }
    if (dataDe) {
      const d = new Date(it.horario);
      if (isNaN(d) || d < new Date(dataDe)) return false;
    }
    if (dataAte) {
      const d = new Date(it.horario);
      const ate = new Date(dataAte); ate.setHours(23,59,59,999);
      if (isNaN(d) || d > ate) return false;
    }
    if (busca) {
      const txt = [it.idPedido, it.nexosOrderId, it.loja, it.solicitante, it.idPlataforma]
        .join(' ').toLowerCase();
      if (!txt.includes(busca)) return false;
    }
    return true;
  });

  sortHistSol(_hsSortCol, true); // mantém ordenação atual
  _hsRenderizarTabela();
  recalcularMetricasHistSol();

  const rc = document.getElementById('hs-result-count');
  if (rc) rc.textContent = `${_hsFiltrados.length} resultado${_hsFiltrados.length !== 1 ? 's' : ''}`;
}

/** Ordena a lista filtrada */
function sortHistSol(col, silencioso = false) {
  if (!silencioso) {
    if (_hsSortCol === col) _hsSortAsc = !_hsSortAsc;
    else { _hsSortCol = col; _hsSortAsc = col !== 'horario'; }
  }
  _hsFiltrados.sort((a, b) => {
    let va = a[col] ?? '', vb = b[col] ?? '';
    if (col === 'horario') { va = new Date(va); vb = new Date(vb); }
    else if (col === 'valor') { va = Number(va); vb = Number(vb); }
    else { va = String(va).toLowerCase(); vb = String(vb).toLowerCase(); }
    return _hsSortAsc ? (va < vb ? -1 : va > vb ? 1 : 0) : (va > vb ? -1 : va < vb ? 1 : 0);
  });
  // Atualizar indicadores visuais
  document.querySelectorAll('#hs-table thead th').forEach(th => {
    const arr = th.querySelector('.sort-arr');
    if (!arr) return;
    if (th.dataset.hsSort === _hsSortCol) arr.textContent = _hsSortAsc ? '↑' : '↓';
    else arr.textContent = '';
    th.classList.toggle('sorted', th.dataset.hsSort === _hsSortCol);
  });
  if (!silencioso) _hsRenderizarTabela();
}

/** Renderiza as linhas da tabela */
function _hsRenderizarTabela() {
  const tbody = document.getElementById('hs-tbody');
  if (!tbody) return;

  if (!_hsFiltrados.length) {
    tbody.innerHTML = `<tr><td colspan="10" class="hs-td-empty">
      Nenhum pedido encontrado com os filtros aplicados.</td></tr>`;
    return;
  }

  tbody.innerHTML = _hsFiltrados.map(it => {
    const statusBadge = it.status === 'entregue'
      ? `<span class="hs-status-entregue">✅ Entregue</span>`
      : `<span class="hs-status-cancelado">⛔ Cancelado</span>`;

    const plat = it.plataformaKey;
    const platBadge = `<span class="plat plat-${plat === 'uber' ? 'uber' : plat === 'james' ? 'james' : plat === '99' ? '99' : 'outros'}">${escapeHtml(it.plataforma)}</span>`;

    const mod = (it.modalidade || '').toLowerCase();
    const modClass = mod.includes('moto') ? 'modal-moto' : mod.includes('carr') ? 'modal-carro' :
                     mod.includes('bic')  ? 'modal-bike' : mod.includes('utilit') ? 'modal-utilitario' : 'modal-outros';
    const modIcon  = mod.includes('moto') ? '🛵' : mod.includes('carr') ? '🚗' :
                     mod.includes('utilit')  ? '🚚' : '📦';
    const modBadge = `<span class="modal-badge ${modClass}">${modIcon} ${escapeHtml(it.modalidade)}</span>`;

    const valor = it.valor ? `R$ ${it.valor.toFixed(2)}` : '—';
    const horario = it.horario ? _hsFormatarHorario(it.horario) : '—';

    return `<tr>
      <td><span class="hs-td-id">${escapeHtml(it.idPedido)}</span></td>
      <td><span class="hs-td-formato">${escapeHtml(it.formato)}</span></td>
      <td>${escapeHtml(it.loja)}</td>
      <td>${statusBadge}</td>
      <td>${platBadge}</td>
      <td>${it.modalidade !== '—' ? modBadge : '<span style="color:var(--muted)">—</span>'}</td>
      <td><span class="hs-td-valor">${valor}</span></td>
      <td><span class="hs-td-formato">${escapeHtml(it.idPlataforma)}</span></td>
      <td>${escapeHtml(it.solicitante)}</td>
      <td><span class="hs-td-time">${horario}</span></td>
    </tr>`;
  }).join('');
}

/** Formata data/hora para exibição */
function _hsFormatarHorario(raw) {
  try {
    const d = new Date(raw);
    return d.toLocaleString('pt-BR', { day:'2-digit', month:'2-digit', year:'2-digit',
      hour:'2-digit', minute:'2-digit' });
  } catch { return raw; }
}

/** Recalcula métricas comparativas (diário ou mensal) */
function recalcularMetricasHistSol() {
  const agora = new Date();

  // Definir janelas de tempo
  const periodoAtual   = _hsPeriodo === 'dia' ? _hsInicioFimDia(agora, 0)   : _hsInicioFimMes(agora, 0);
  const periodoAnterior= _hsPeriodo === 'dia' ? _hsInicioFimDia(agora, -1)  : _hsInicioFimMes(agora, -1);
  const labelAtual     = _hsPeriodo === 'dia' ? 'HOJE' : 'MÊS';
  const labelAnterior  = _hsPeriodo === 'dia' ? 'ONTEM' : 'MÊS ANT.';

  // Atualizar badge de período
  document.querySelectorAll('[id^="hs-period-badge-"]').forEach(el => el.textContent = labelAtual);

  const atual    = _hsDados.filter(it => _hsInPeriodo(it.horario, periodoAtual));
  const anterior = _hsDados.filter(it => _hsInPeriodo(it.horario, periodoAnterior));

  const calc = (arr) => ({
    total:       arr.length,
    entregues:   arr.filter(i => i.status === 'entregue').length,
    cancelados:  arr.filter(i => i.status === 'cancelado').length,
    plataformas: new Set(arr.map(i => i.plataformaKey)).size,
    solicitantes:new Set(arr.map(i => i.solicitante)).size,
    valor:       arr.reduce((s, i) => s + (i.valor || 0), 0),
  });

  const ca = calc(atual);
  const cp = calc(anterior);

  _hsAtualizarMetrica('hs-m-total',       ca.total,       cp.total,       '',   labelAnterior, false);
  _hsAtualizarMetrica('hs-m-entregues',   ca.entregues,   cp.entregues,   '',   labelAnterior, true);
  _hsAtualizarMetrica('hs-m-cancelados',  ca.cancelados,  cp.cancelados,  '',   labelAnterior, false);
  _hsAtualizarMetrica('hs-m-plataformas', ca.plataformas, cp.plataformas, '',   labelAnterior, true);
  _hsAtualizarMetrica('hs-m-solicitantes',ca.solicitantes,cp.solicitantes,'',   labelAnterior, true);
  _hsAtualizarMetricaValor('hs-m-valor-total', ca.valor, cp.valor, labelAnterior);
}

function _hsAtualizarMetrica(id, atual, anterior, sufixo, labelAnt, maiorEBom) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = atual + (sufixo || '');

  const cmpEl = document.getElementById(id + '-cmp');
  if (!cmpEl) return;
  if (anterior === 0) { cmpEl.textContent = ''; return; }
  const diff = atual - anterior;
  const pct  = Math.abs(Math.round((diff / anterior) * 100));
  const up   = diff > 0;
  const cls  = diff === 0 ? 'hs-cmp-eq' : (up === maiorEBom ? 'hs-cmp-up' : 'hs-cmp-down');
  const arrow= diff === 0 ? '→' : up ? '↑' : '↓';
  cmpEl.innerHTML = `<span class="${cls}">${arrow} ${pct}%</span> <span style="color:var(--muted);font-size:9px">vs ${labelAnt}</span>`;
}

function _hsAtualizarMetricaValor(id, atual, anterior, labelAnt) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = `R$ ${atual.toFixed(2)}`;

  const cmpEl = document.getElementById(id + '-cmp');
  if (!cmpEl) return;
  if (anterior === 0) { cmpEl.textContent = ''; return; }
  const diff = atual - anterior;
  const pct  = Math.abs(Math.round((diff / anterior) * 100));
  const up   = diff > 0;
  const cls  = up ? 'hs-cmp-up' : diff < 0 ? 'hs-cmp-down' : 'hs-cmp-eq';
  const arrow= diff === 0 ? '→' : up ? '↑' : '↓';
  cmpEl.innerHTML = `<span class="${cls}">${arrow} ${pct}%</span> <span style="color:var(--muted);font-size:9px">vs ${labelAnt}</span>`;
}

/** Retorna { inicio, fim } para N dias atrás */
function _hsInicioFimDia(ref, offsetDias) {
  const d = new Date(ref);
  d.setDate(d.getDate() + offsetDias);
  const inicio = new Date(d); inicio.setHours(0, 0, 0, 0);
  const fim    = new Date(d); fim.setHours(23, 59, 59, 999);
  return { inicio, fim };
}
/** Retorna { inicio, fim } para N meses atrás */
function _hsInicioFimMes(ref, offsetMeses) {
  const d = new Date(ref);
  d.setDate(1);
  d.setMonth(d.getMonth() + offsetMeses);
  const inicio = new Date(d); inicio.setHours(0, 0, 0, 0);
  const fim = new Date(inicio.getFullYear(), inicio.getMonth() + 1, 0); fim.setHours(23, 59, 59, 999);
  return { inicio, fim };
}
function _hsInPeriodo(raw, { inicio, fim }) {
  if (!raw) return false;
  const d = new Date(raw);
  return !isNaN(d) && d >= inicio && d <= fim;
}

/** Limpa todos os filtros do painel */
function limparFiltrosHistSol() {
  ['hs-busca','hs-data-de','hs-data-ate'].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = '';
  });
  ['hs-filtro-status','hs-filtro-plataforma','hs-filtro-loja','hs-filtro-solicitante','hs-filtro-modalidade','hs-filtro-formato'].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = '';
  });
  aplicarFiltrosHistSol();
}

/* ── Exportação ─────────────────────────────────────────────────────────── */

/** Converte _hsFiltrados em array de objetos para exportação */
function _hsParaLinhas() {
  return _hsFiltrados.map(it => ({
    'ID Pedido':              it.idPedido,
    'Formato do Pedido':      it.formato,
    'Loja':                   it.loja,
    'Status':                 it.status === 'entregue' ? 'Entregue' : 'Cancelado',
    'Plataforma':             it.plataforma,
    'Modalidade de Envio':    it.modalidade,
    'Valor (R$)':             it.valor || 0,
    'ID da Plataforma':       it.idPlataforma,
    'Solicitante':            it.solicitante,
    'Horário da Solicitação': it.horario ? _hsFormatarHorario(it.horario) : '—',
  }));
}

/** Exporta para CSV (sem dependências externas) */
function exportarHistSolCSV() {
  const linhas = _hsParaLinhas();
  if (!linhas.length) { showToast('Nenhum dado para exportar.', 'warn'); return; }

  const cabecalho = Object.keys(linhas[0]);
  const csvEscape = v => `"${String(v).replace(/"/g, '""')}"`;
  const conteudo  = [cabecalho.map(csvEscape).join(',')]
    .concat(linhas.map(row => cabecalho.map(k => csvEscape(row[k])).join(','))).join('\r\n');

  const blob = new Blob(['\uFEFF' + conteudo], { type: 'text/csv;charset=utf-8;' });
  _hsDownload(blob, `historico_solicitacoes_${_hsDataArquivo()}.csv`);
  showToast('CSV exportado com sucesso!', 'success');
}

/** Exporta para XLS (HTML table trick — compatível com Excel) */
function exportarHistSolXLS() {
  const linhas = _hsParaLinhas();
  if (!linhas.length) { showToast('Nenhum dado para exportar.', 'warn'); return; }

  const cabecalho = Object.keys(linhas[0]);
  const ths = cabecalho.map(h => `<th>${h}</th>`).join('');
  const trs = linhas.map(row =>
    `<tr>${cabecalho.map(k => `<td>${String(row[k]).replace(/</g, '&lt;')}</td>`).join('')}</tr>`
  ).join('');
  const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
    <head><meta charset="UTF-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets>
    <x:ExcelWorksheet><x:Name>Solicitações</x:Name></x:ExcelWorksheet></x:ExcelWorksheets>
    </x:ExcelWorkbook></xml><![endif]--></head>
    <body><table border="1">${'<tr>' + ths + '</tr>'}${trs}</table></body></html>`;

  const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8' });
  _hsDownload(blob, `historico_solicitacoes_${_hsDataArquivo()}.xls`);
  showToast('XLS exportado com sucesso!', 'success');
}

function _hsDownload(blob, nome) {
  const url = URL.createObjectURL(blob);
  const a   = document.createElement('a');
  a.href    = url; a.download = nome; a.style.display = 'none';
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
}

function _hsDataArquivo() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}`;
}

/* ══════════════════════════════════════════════════════════════════════════ */

async function carregarHistoricoView() {
  if (tbody) tbody.innerHTML = `<tr><td colspan="8" class="hist-td-empty">⏳ Buscando registros no SharePoint...</td></tr>`;

  const result = await fetchHistoricoSP();
  if (result.error) {
    if (tbody) tbody.innerHTML = `<tr><td colspan="8" class="hist-td-empty" style="color:var(--red)">❌ ${escapeHtml(result.error)}</td></tr>`;
    return;
  }

  _popularSelectsHistorico(result.items);
  _atualizarMetricasHistorico(result.items);
  aplicarFiltrosHistorico();
}

async function testSP() {
  showToast('Testando conexão com SharePoint (token do usuário)...', 'info');
  try {
    const token = await syncSharePointTokenFromAuth();
    if (!token) {
      throw new Error('Token do usuário não disponível — faça login primeiro');
    }

    // Invalida cache para forçar re-resolve
    spCache = { siteId: null, listId: null };
    const ids = await resolveSP();
    if (!ids) throw new Error('Não resolveu site/lista');

    LOG.sp('Teste OK — site:', ids.siteId, 'lista:', ids.listId);
    showToast('✓ SharePoint conectado! Site e lista resolvidos.', 'success');
  } catch (e) {
    LOG.error('Teste SP falhou:', e.message);
    showToast('SP falhou: ' + e.message, 'error');
  }
}

// ════════════════════════════════════════════════
// MERGE
// ════════════════════════════════════════════════
function mergeData(ilRows, pkMap, spMap) {
  const merged = ilRows.map(r => ({
    ...r,
    pickingStatus: pkMap[r.jobId] || '',
  }));

  // Sincronizar tratativas do SharePoint — SP é a fonte de verdade compartilhada entre usuários.
  // Sempre atualiza status e texto do SP para que tratativas de outros usuários apareçam.
  Object.entries(spMap).forEach(([id, t]) => {
    if (!tratativas[id]) {
      tratativas[id] = { ...t };
    } else {
      // Atualiza status e texto do SP (sobrescreve edições locais não salvas)
      tratativas[id].status  = t.status  || tratativas[id].status;
      tratativas[id].texto   = t.texto   || tratativas[id].texto;
      // Editor sempre vem do SP — é a fonte de verdade de quem fez a última alteração
      if (t.editor) tratativas[id].editor = t.editor;
      // Sincronizar resolvedAt do SP
      if (t.resolvedAt) tratativas[id].resolvedAt = t.resolvedAt;
      else if (t.status !== 'Resolvido' && t.status !== 'Sem ação necessária') {
        delete tratativas[id].resolvedAt;
      }
      // Preservar spItemId se ainda não tínhamos
      if (!tratativas[id].spItemId && t.spItemId) {
        tratativas[id].spItemId = t.spItemId;
      } else if (t.spItemId) {
        tratativas[id].spItemId = t.spItemId;
      }
    }
  });

  merged.forEach(o => {
    const ilFinal = isILFinal(o.status); // DELIVERED, FINISHED ou CANCELLED

    if (!tratativas[o.jobId]) {
      // ── Pedido NOVO vindo da API ──────────────────────────────────────────
      // Se já chegou em estado final (entregue/cancelado), não criar tratativa
      // nem incluir no monitoramento ativo — não há ação necessária do time.
      if (ilFinal) return; // pular: será filtrado em getFiltered

      const motivo = atencaoNecessaria(o);
      if (motivo) {
        tratativas[o.jobId] = { status: 'Pendente', texto: '', spItemId: null, _motivo: motivo };
      }
    } else {
      // ── Pedido JÁ em acompanhamento ──────────────────────────────────────
      // Atualizar motivo para refletir o estado atual
      const motivo = atencaoNecessaria(o);
      if (tratativas[o.jobId].status === 'Pendente') {
        tratativas[o.jobId]._motivo = motivo || tratativas[o.jobId]._motivo;
      }

      // Se transitou para estado final (entregue/cancelado) e tem tratativa ativa,
      // registrar automaticamente como resolvido no SharePoint.
      const t = tratativas[o.jobId];
      const temTratativa = t.spItemId || (t.texto && t.texto.trim()) || t.status !== 'Pendente';
      const jaResolvido  = t.status === 'Resolvido' || t.status === 'Sem ação necessária';
      if (ilFinal && temTratativa && !jaResolvido && !t._autoResolvendo) {
        const ilS = String(o.status || '').toUpperCase();
        const isDelivered = ilS === 'DELIVERED' || ilS === 'FINISHED';
        // "Solicitado manual" = entrega sendo feita via Uber manualmente.
        // Só auto-resolve quando a IL confirmar ENTREGUE — nunca ao CANCELAR
        // (o pedido Uber pode ainda estar a caminho quando a IL cancela).
        if (t.status === 'Solicitado manual' && !isDelivered) return;
        t._autoResolvendo = true; // guard para não salvar múltiplas vezes
        const novoStatus = isDelivered ? 'Resolvido' : 'Sem ação necessária';
        t.status = novoStatus;
        t.resolvedAt = new Date().toISOString().slice(0, 10);
        t._autoActionAt = Date.now(); // protege editor original no próximo polling SP
        LOG.ok(`Auto-resolução: pedido ${o.jobId} → "${novoStatus}" (IL: ${o.status})`);
        // Guardar no cache de resolvidos antes de salvar no SP
        _registrarResolvidosCache([o]);
        // Salvar no SharePoint em background
        saveTratativa(o.jobId).finally(() => { delete t._autoResolvendo; });
      }
    }
  });

  // ── Acumular pedidos únicos do dia (persistido no localStorage) ──────────
  _registrarNoAcumulado(merged.map(o => o.jobId));

  // ── Pedidos "Em andamento"/"Solicitado manual" no SP mas ausentes na IL ──
  // Quando o pedido sai do filtro da Instaleap (ex: mudança de janela de tempo)
  // mas ainda tem tratativa ativa em aberto, criamos um stub para mantê-lo
  // visível no painel até que alguém conclua como "Resolvido" / "Sem ação necessária".
  Object.entries(spMap).forEach(([id, t]) => {
    if (t.status !== 'Em andamento' && t.status !== 'Solicitado manual') return;
    if (merged.some(o => o.jobId === id)) return; // já veio da IL → não duplicar
    // Preservar pickingStatus já conhecido (evita resetar para '' a cada ciclo)
    const existing = typeof orders !== 'undefined'
      ? orders.find(o => o.jobId === id)
      : null;
    merged.push({
      jobId:               id,
      loja:                t.loja || existing?.loja || '—',
      slot:                t.slot || existing?.slot || '—',
      status:              existing?.status || 'IN_PROGRESS', // IL artificial — não é final
      pickingStatus:       existing?.pickingStatus || '',
      pickingRaw:          existing?.pickingRaw    || null,
      slotFrom:            existing?.slotFrom      || null,
      slotTo:              existing?.slotTo        || null,
      instaleapId:         existing?.instaleapId   || '',
      plataformaId:        existing?.plataformaId  || '',
      platformName:        existing?.platformName  || '',
      _retidoPorTratativa: true,            // flag: fora do filtro IL, mas mantido pela tratativa
    });
    LOG.info(`mergeData: stub criado para "${id}" ausente na IL (tratativa: ${t.status})`);
  });

  return merged;
}

// ════════════════════════════════════════════════
// TIME UTILITIES
// ════════════════════════════════════════════════
function getSlotToDate(o) {
  if (!o.slotTo) return null;
  try { return new Date(o.slotTo); } catch { return null; }
}

function diffMin(o) {
  const dt = getSlotToDate(o);
  if (!dt || isNaN(dt)) return null;
  return Math.round((dt - Date.now()) / 60000);
}

function formatDiff(o) {
  const d = diffMin(o);
  if (d === null) return '—';
  const abs = Math.abs(d);
  let txt;
  if (abs >= 1440) {
    // 24h+ → exibir em dias e horas
    const dias = Math.floor(abs / 1440);
    const hrs  = Math.floor((abs % 1440) / 60);
    txt = hrs > 0 ? `${dias}d${hrs}h` : `${dias}d`;
  } else {
    const h = Math.floor(abs / 60);
    const m = abs % 60;
    txt = h > 0 ? `${h}h${m > 0 ? m + 'min' : ''}` : `${m}min`;
  }
  return d < 0 ? `+${txt} atraso` : txt;
}

function diffClass(o) {
  const d = diffMin(o);
  if (d === null) return 't-muted';
  if (d < 0) return 't-red';
  if (d < 30) return 't-amber';
  return 't-green';
}

function diffIcon(o) {
  const d = diffMin(o);
  if (d === null) return '?';
  if (d < 0) return '▲';
  if (d < 30) return '◔';
  return '✓';
}

// ════════════════════════════════════════════════
// RENDER
// ════════════════════════════════════════════════
// Set de IDs de pedidos cujo status mudou recentemente (highlight visual temporário)
const updatedIds = new Set();
// Set de IDs de pedidos NOVOS detectados pelo polling — persiste até interação do usuário na linha
const newIds = new Set();

function isCancelled(status) {
  const s = String(status || '').toUpperCase().replace(/[-_\s]/g, '');
  return s.includes('CANCEL');
}

function isOrderCancelled(o) {
  // Pedido é considerado cancelado se qualquer campo de status indicar isso
  return isCancelled(o.status) || isCancelled(o.pickingStatus);
}

/** Retorna true se o status Instaleap indica estado final (entregue ou cancelado) */
function isILFinal(status) {
  const s = String(status || '').toUpperCase();
  return s === 'FINISHED' || isCancelled(s);
}

/** Retorna true se o status picking indica estado final */
function isPickingFinal(pickingStatus) {
  const s = String(pickingStatus || '').toLowerCase();
  return s.includes('entregue') || s.includes('delivered') || s.includes('cancelado') || s.includes('cancel');
}

/**
 * Analisa se o pedido precisa de atenção do time.
 * Retorna null se o pedido está convergido (pode sair do painel),
 * ou uma string descrevendo o motivo da atenção necessária.
 */
function atencaoNecessaria(o) {
  const ilS  = String(o.status || '').toUpperCase();
  const ilDelivered = ilS === 'DELIVERED' || ilS === 'FINISHED';
  const ilCancelled = isCancelled(ilS);
  const ilFinal     = ilDelivered || ilCancelled;

  const pk = String(o.pickingStatus || '').toLowerCase();
  const pkEmpty     = !pk;
  const pkDelivered = pk.includes('entregue') || pk.includes('delivered');
  const pkCancelled = pk.includes('cancelado') || (pk.includes('cancel') && !pkDelivered);
  const pkFinal     = pkDelivered || pkCancelled;

  const semAlocacao = !o.platformName;

  // Sem alocação em pedido ativo → precisa alocar
  if (semAlocacao && !ilFinal) return 'Sem alocação';

  // Ambos entregues → convergido, sem atenção
  if (ilDelivered && pkDelivered) return null;

  // Ambos cancelados → convergido, sem atenção
  if (ilCancelled && pkCancelled) return null;

  // IL entregue mas picking cancelado → divergência
  if (ilDelivered && pkCancelled) return 'Divergência: entregue × cancelado';

  // IL cancelado mas picking entregue → divergência
  if (ilCancelled && pkDelivered) return 'Divergência: cancelado × entregue';

  // IL cancelado + picking ativo ou vazio → precisa verificar
  if (ilCancelled && !pkEmpty && !pkFinal) return 'Cancelado com picking ativo';
  if (ilCancelled && pkEmpty) return 'Cancelado sem picking';

  // IL ativo + picking entregue → pedido finalizado no picking mas não na IL
  if (!ilFinal && pkDelivered) return 'Picking: entregue';

  // IL ativo + picking cancelado → entregador cancelou
  if (!ilFinal && pkCancelled) return 'Picking: cancelado';

  // IL ativo sem picking ainda → normal, acompanhar
  if (!ilFinal && pkEmpty) return null; // aguardando picking, sem problema

  // IL ativo + picking ativo → em andamento normal → sem atenção urgente
  return null;
}

function statusBadge(o) {
  const status = o.status || '';
  const s = status.toUpperCase();
  const ilId = o.instaleapId || o.jobId || '';
  const href = ilId ? `https://control.instaleap.io/orders/${encodeURIComponent(ilId)}` : '';
  const wrap = (cls, label, title = '') => {
    const tip = title ? ` title="${title}"` : '';
    return href
      ? `<a class="badge ${cls}" href="${href}" target="_blank"${tip}>${label}</a>`
      : `<span class="badge ${cls}"${tip}>${label}</span>`;
  };

  if (s === 'STORED')               return wrap('badge-stored',      'ARMAZENADO');
  if (s === 'GOING_TO_ORIGIN')      return wrap('badge-going',       'A CAMINHO');
  if (s === 'GOING_TO_DESTINATION') return wrap('badge-destination', 'A DESTINO');
  if (s === 'TRANSFERRING')         return wrap('badge-transfer',    'TRANSFERINDO');
  if (s === 'DELIVERED')            return wrap('badge-delivered',   'ENTREGANDO');
  if (s === 'FINISHED')             return wrap('badge-delivered',   'ENTREGUE');
  if (isCancelled(status)) {
    // Pedido retido no painel por ter tratativa pendente
    if (o._retidoPorTratativa) {
      return wrap('badge-cancelled badge-retido', '⚠ CANCELADO', 'Fora da API — retido por tratativa pendente. Resolva para remover.');
    }
    return wrap('badge-cancelled', 'CANCELADO');
  }
  // Status desconhecido — mostrar em cinza neutro com indicador se retido
  const retidoSuffix = o._retidoPorTratativa
    ? ` <span title="Saiu da API — retido por tratativa pendente" style="opacity:.7">⚠</span>`
    : '';
  return href
    ? `<a class="badge" style="background:var(--surface2);color:var(--muted)" href="${href}" target="_blank">${escapeHtml(status || '—')}${retidoSuffix}</a>`
    : `<span class="badge" style="background:var(--surface2);color:var(--muted)">${escapeHtml(status || '—')}${retidoSuffix}</span>`;
}

function pickingBadge(o) {
  const s = o.pickingStatus || '';
  const platId = o.plataformaId || '';
  const pedido = o.jobId || '';
  const loja   = o.loja   || '';
  const href = (loja && pedido)
    ? `https://picking-admin.backoffice.gpa.digital/pedidos/loja/${encodeURIComponent(loja)}/detalhe/${encodeURIComponent(pedido)}`
    : '';
  const l = s.toLowerCase();

  let cls, label;
  if (!s)                                                                                { cls = 'pk-vazio';          label = '—'; }
  else if (l.includes('entregue') || l.includes('delivered'))                           { cls = 'pk-entregue';       label = 'ENTREGUE'; }
  else if (l.includes('pronto') || l.includes('ready') || l === 'picked')               { cls = 'pk-pronto';         label = 'PRONTO'; }
  else if (l.includes('coletado') || l.includes('collected'))                           { cls = 'pk-coletado';       label = 'COLETADO'; }
  else if (l.includes('payment') || l.includes('pagamento'))                            { cls = 'pk-payment-error';  label = '⚠ ERRO PAGAMENTO'; }
  else if (l.includes('cupom') || l.includes('fiscal') || l.includes('invoice'))        { cls = 'pk-pronto';         label = 'AGU. CUPOM FISCAL'; }
  else if (l.includes('cancelamento_solicitado') || l.includes('cancel_request'))       { cls = 'pk-cancelado';      label = 'CANCELAMENTO SOLICITADO'; }
  else if (isCancelled(s))                                                               { cls = 'pk-cancelado';      label = 'CANCELADO'; }
  // "Aguardando Transporte" — pedido separado, aguardando coleta pelo entregador
  else if (l.includes('em_transporte') || l.includes('em transporte') ||
           l.includes('waiting_for_pickup') || l.includes('ready_for_pickup') ||
           l.includes('aguardando_transporte') || l.includes('aguardando transporte'))  { cls = 'pk-aguardando-transporte'; label = 'AGU. TRANSPORTE'; }
  // "Aguardando Separação" — pedido criado/pendente, ainda não iniciado no picking
  else if (l.includes('aguard') || l.includes('wait') || l.includes('pending') ||
           l.includes('created') || l.includes('criado'))                               { cls = 'pk-aguardando';     label = 'AGU. SEPARAÇÃO'; }
  else if (l.includes('separ') || l.includes('consulta') || l.includes('picking') ||
           l.includes('process') || l.includes('in_progress') || l.includes('progress')){ cls = 'pk-separando';      label = 'SEPARANDO'; }
  else                                                                                   { cls = 'pk-vazio';          label = escapeHtml(s); }

  return href
    ? `<a class="pk ${cls}" href="${href}" target="_blank" title="Abrir picking (Pedido: ${escapeHtml(pedido)})">${label}</a>`
    : `<span class="pk ${cls}">${label}</span>`;
}

// UUID v4 regex — detecta se o texto É ou CONTÉM um UUID v4
const UUID_RE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;

/**
 * Gera o link do portal 99 para um pedido específico.
 * O link é lido pela extensão Chrome que aplica o filtro automaticamente.
 * @param {string} pedido - ID único do pedido na 99
 * @returns {string} URL formatada, ou '' se pedido inválido
 */
function gerarLink99(pedido) {
  if (!pedido || typeof pedido !== 'string' || !pedido.trim()) return '';
  // nexos_order é lido pelo content-99app.js para preencher o campo automaticamente
  return `https://entrega.99app.com/delivers?from=menu&nexos_order=${encodeURIComponent(pedido.trim())}`;
}

function platformBadge(o) {
  const name    = o.platformName || '';
  const platId  = o.plataformaId || '';
  const pedido  = o.jobId || '';
  const loja    = o.loja  || '';
  const nu = name.toUpperCase();

  // Solicitado manual → badge "Uber manual" com link por jobId
  const _trat = tratativas[o.jobId];
  if (_trat?.status === 'Solicitado manual') {
    const href = pedido
      ? `https://direct.uber.com/accounts/740e6e18-263c-4f1a-8ee6-a8a706696e89?searchInputValue=${encodeURIComponent(pedido)}`
      : '';
    return href
      ? `<a class="plat plat-uber" href="${href}" target="_blank" title="Uber manual (pedido: ${escapeHtml(pedido)})">Uber manual</a>`
      : `<span class="plat plat-uber">Uber manual</span>`;
  }

  // Sem alocação
  if (!name) {
    return `<span class="plat plat-sem-alocacao">Sem alocação</span>`;
  }

  // Motorista Uber
  if (nu.includes('MOTORISTA UBER') || nu.includes('UBER')) {
    const href = platId
      ? `https://direct.uber.com/accounts/740e6e18-263c-4f1a-8ee6-a8a706696e89?searchInputValue=${encodeURIComponent(platId)}`
      : '';
    return href
      ? `<a class="plat plat-uber" href="${href}" target="_blank" title="${escapeHtml(name)}">Uber</a>`
      : `<span class="plat plat-uber">Uber</span>`;
  }

  // James Delivery
  if (nu.includes('JAMES')) {
    const href = pedido
      ? `https://james-orkestra.backoffice.gpa.digital/pedidos/${encodeURIComponent(pedido)}/tracking`
      : '';
    return href
      ? `<a class="plat plat-james" href="${href}" target="_blank" title="${escapeHtml(name)}">James</a>`
      : `<span class="plat plat-james">James</span>`;
  }

  // Contém "uuid" (literal) ou corresponde ao padrão UUID v4 — link Uber
  if (nu.includes('UUID') || UUID_RE.test(name)) {
    const href = platId
      ? `https://direct.uber.com/accounts/740e6e18-263c-4f1a-8ee6-a8a706696e89?searchInputValue=${encodeURIComponent(platId)}`
      : '';
    return href
      ? `<a class="plat plat-uuid" href="${href}" target="_blank" title="${escapeHtml(name)}">${escapeHtml(name)}</a>`
      : `<span class="plat plat-uuid">${escapeHtml(name)}</span>`;
  }

  // Qualquer outro nome real (sem UUID, sem "UBER", sem "JAMES") → entregador da 99
  const href99 = gerarLink99(pedido); // sempre usa o jobId do pedido
  return href99
    ? `<a class="plat plat-99" href="${href99}" target="_blank" title="Abrir na 99 (${escapeHtml(name)})">${escapeHtml(name)}</a>`
    : `<span class="plat plat-99">${escapeHtml(name)}</span>`;
}

function statusSelCls(st) {
  const s = (st || '').toLowerCase();
  if (s.includes('andamento')) return 's-andamento';
  if (s.includes('resolv')) return 's-resolvido';
  if (s.includes('sem')) return 's-sem';
  if (s.includes('manual')) return 's-manual';
  return 's-pendente';
}

function getFiltered() {
  const q = (document.getElementById('search-input')?.value || '').toLowerCase().trim();
  const dateFrom = document.getElementById('filter-date-from')?.value || '';
  const dateTo = document.getElementById('filter-date-to')?.value || '';
  let rows = [...orders];

  // ── Excluir pedidos convergidos sem tratativa ativa ──────────────────────
  // Pedido convergido = ambos IL e picking em estado final alinhado (ex: ENTREGUE+Entregue)
  // E sem tratativa ativa (apenas Pendente automático ou sem tratativa)
  // Exceção: filtros específicos de "entregues" ou "cancelados" mostram tudo,
  // e a aba "resolvidos" já usa orders[] completo abaixo — sem pré-filtro.
  if (filterMode !== 'entregues' && filterMode !== 'cancelados' && tabMode !== 'resolvidos') {
    rows = rows.filter(o => {
      const t = tratativas[o.jobId];
      // Tratativa explicitamente ativa em aberto → sempre manter no painel,
      // mesmo que o pedido já tenha saído do filtro da Instaleap.
      // Só sai quando concluído como "Resolvido" ou "Sem ação necessária".
      if (t?.status === 'Em andamento' || t?.status === 'Solicitado manual') return true;
      // Se tem tratativa manual (status ≠ Pendente automático ou texto preenchido) → mostrar
      const temTratativaManual = t && (t.status !== 'Pendente' || (t.texto && t.texto.trim()));
      if (temTratativaManual) return true;
      // Se IL já está em estado final (Entregue / Finalizado / Cancelado):
      // o pedido sai do painel independente do status do picking.
      // (Cobre tanto o cenário normal quanto o erro sistêmico de integração.)
      if (isILFinal(o.status)) return false;
      // Se ambos IL e picking convergidos em estado final → sai
      if (isPickingFinal(o.pickingStatus)) return false;
      // Se há motivo de atenção identificado → mostrar
      if (atencaoNecessaria(o)) return true;
      // Nos demais casos, mostrar normalmente
      return true;
    });
  }

  // ── Filtro de aba (aplicado sobre o pré-filtro acima) ───────────────────
  if (tabMode !== 'todos') {
    switch (tabMode) {
      case 'pendentes':
        rows = rows.filter(o => { const t = tratativas[o.jobId]; return !t || t.status === 'Pendente'; });
        break;
      case 'andamento':
        rows = rows.filter(o => {
          const t = tratativas[o.jobId];
          if (andamentoSubFilter === 'manuais')   return t?.status === 'Solicitado manual';
          if (andamentoSubFilter === 'tratativa') return t?.status === 'Em andamento';
          return t?.status === 'Em andamento' || t?.status === 'Solicitado manual';
        });
        break;
      case 'resolvidos':
        // Usa orders[] completo para incluir pedidos já fora da IL
        rows = orders.filter(o => {
          const t = tratativas[o.jobId];
          return t && (t.status === 'Resolvido' || t.status === 'Sem ação necessária');
        });
        break;
    }
  }

  switch (filterMode) {
    case 'atrasados':
      rows = rows.filter(o => diffMin(o) !== null && diffMin(o) < 0);
      break;
    case 'cancelados':
      rows = rows.filter(o => isOrderCancelled(o));
      break;
    case 'entregues':
      rows = rows.filter(o => {
        const s = (o.status || '').toUpperCase();
        const pk = (o.pickingStatus || '').toLowerCase();
        return s === 'DELIVERED' || s === 'FINISHED' || pk.includes('entregue') || pk.includes('delivered');
      });
      break;
    case 'andamento':
      // mantido por compatibilidade (não há mais botão no DOM, mas pode ser chamado via código)
      rows = rows.filter(o => { const t = tratativas[o.jobId]; return t && t.status === 'Em andamento'; });
      break;
    case 'manuais':
      rows = rows.filter(o => { const t = tratativas[o.jobId]; return t && t.status === 'Solicitado manual'; });
      break;
    case 'pendentes':
      rows = rows.filter(o => { const t = tratativas[o.jobId]; return !t || t.status === 'Pendente'; });
      break;
    case 'resolvidos':
      // Parte de orders[] completo para não perder pedidos já saídos do pré-filtro (isILFinal)
      rows = orders.filter(o => {
        const t = tratativas[o.jobId];
        return t && (t.status === 'Resolvido' || t.status === 'Sem ação necessária');
      });
      break;
    case 'il-status':
      rows = rows.filter(o => (o.status || '').toUpperCase() === _ilStatusFilter);
      break;
  }

  // Filtro de data — ignorado se houver busca ativa
  if (!q) {
    // RESOLVIDOS: padrão é a data de hoje quando nenhuma data foi especificada
    let effectiveFrom = dateFrom;
    let effectiveTo   = dateTo;
    const isResolvidosView = filterMode === 'resolvidos' || tabMode === 'resolvidos';
    if (isResolvidosView && !dateFrom && !dateTo) {
      effectiveFrom = new Date().toISOString().slice(0, 10);
      effectiveTo   = effectiveFrom;
    }

    if (effectiveFrom) {
      const from = new Date(effectiveFrom + 'T00:00:00');
      if (isResolvidosView) {
        // Filtrar pela data de resolução (resolvedAt), não pelo slot
        rows = rows.filter(o => {
          const ra = tratativas[o.jobId]?.resolvedAt;
          return ra && ra >= effectiveFrom;
        });
      } else {
        rows = rows.filter(o => {
          const d = o.slotFrom ? new Date(o.slotFrom) : (o.slotTo ? new Date(o.slotTo) : null);
          return d && d >= from;
        });
      }
    }
    if (effectiveTo) {
      const to = new Date(effectiveTo + 'T23:59:59');
      if (isResolvidosView) {
        rows = rows.filter(o => {
          const ra = tratativas[o.jobId]?.resolvedAt;
          return ra && ra <= effectiveTo;
        });
      } else {
        rows = rows.filter(o => {
          const d = o.slotFrom ? new Date(o.slotFrom) : (o.slotTo ? new Date(o.slotTo) : null);
          return d && d <= to;
        });
      }
    }
  }

  // Busca livre — sempre aplicada, independente de data
  if (q) {
    rows = rows.filter(o =>
      o.jobId.toLowerCase().includes(q) ||
      o.loja.toLowerCase().includes(q) ||
      o.status.toLowerCase().includes(q)
    );
  }

  rows.sort((a, b) => {
    // Cancelados sempre no topo (prioridade máxima)
    const aCancelled = isOrderCancelled(a) ? 1 : 0;
    const bCancelled = isOrderCancelled(b) ? 1 : 0;
    if (aCancelled !== bCancelled) return bCancelled - aCancelled;

    let va, vb;
    if (sortCol === 'diff') {
      va = diffMin(a) ?? 99999;
      vb = diffMin(b) ?? 99999;
    } else if (sortCol === 'pickingStatus') {
      va = (a.pickingStatus || '').toLowerCase();
      vb = (b.pickingStatus || '').toLowerCase();
    } else {
      va = (a[sortCol] || '').toLowerCase();
      vb = (b[sortCol] || '').toLowerCase();
    }
    if (va < vb) return -sortDir;
    if (va > vb) return sortDir;
    return 0;
  });

  return rows;
}

let _renderTableTimer = null; // guard contra múltiplos renders pendentes

function renderTable() {
  const tbody = document.getElementById('tbody');
  if (!tbody) return;

  const rows = getFiltered();
  const filterCount = document.getElementById('filter-count');
  if (filterCount) filterCount.textContent = rows.length + ' pedido' + (rows.length !== 1 ? 's' : '');

  document.querySelectorAll('thead th[data-col]').forEach(th => {
    const sa = th.querySelector('.sort-arr');
    if (!sa) return;
    if (th.dataset.col === sortCol) {
      th.classList.add('sorted');
      sa.textContent = sortDir === 1 ? '↑' : '↓';
    } else {
      th.classList.remove('sorted');
      sa.textContent = '';
    }
  });

  if (isLoading && !orders.length) {
    tbody.innerHTML = `
      <tr><td colspan="9">
        <div class="state-panel">
          <div class="state-icon" style="font-size:24px">⏳</div>
          <div class="state-title">Carregando dados...</div>
          <div class="state-sub">Buscando pedidos nas APIs configuradas. Aguarde.</div>
        </div>
      </td></tr>`;
    return;
  }

  if (!rows.length && !orders.length) {
    tbody.innerHTML = `
      <tr><td colspan="9">
        <div class="state-panel">
          <div class="state-icon">📋</div>
          <div class="state-title">Sem dados carregados</div>
          <div class="state-sub">Configure as APIs e clique em <b>↻ Atualizar</b>, ou use os dados demo para experimentar o painel.</div>
          <div class="state-actions">
            <button class="btn btn-primary btn-sm" data-action="open-config">⚙ Config</button>
            <button class="btn btn-sm" data-action="load-demo">▷ Demo</button>
          </div>
        </div>
      </td></tr>`;
    bindDynamicEvents();
    return;
  }

  if (!rows.length) {
    tbody.innerHTML = `
      <tr><td colspan="9">
        <div class="state-panel">
          <div class="state-icon">🔍</div>
          <div class="state-title">Nenhum resultado</div>
          <div class="state-sub">Nenhum pedido corresponde ao filtro atual. Tente mudar o filtro ou limpar a busca.</div>
          <div class="state-actions">
            <button class="btn btn-sm" data-action="show-all">Mostrar todos</button>
          </div>
        </div>
      </td></tr>`;
    bindDynamicEvents();
    return;
  }

  // ── Diff animado: detectar linhas que saem e linhas que entram ───────────
  if (_renderTableTimer) { clearTimeout(_renderTableTimer); _renderTableTimer = null; }

  const newIdSet = new Set(rows.map(o => o.jobId));

  // IDs estáveis no DOM (excluindo os que já estão em animação de saída)
  const currentTrs       = [...tbody.querySelectorAll('tr[data-oid]')];
  const leavingTrs       = currentTrs.filter(tr => !newIdSet.has(tr.dataset.oid) && !tr.classList.contains('row-leaving'));
  const stableIds        = new Set(
    currentTrs.filter(tr => !leavingTrs.includes(tr)).map(tr => tr.dataset.oid)
  );

  const doRender = () => {
    _renderTableRows(tbody, rows, stableIds);
  };

  if (leavingTrs.length > 0) {
    leavingTrs.forEach(tr => tr.classList.add('row-leaving'));
    _renderTableTimer = setTimeout(() => { _renderTableTimer = null; doRender(); }, 200);
  } else {
    doRender();
  }
}

/**
 * Substitui o conteúdo do tbody com as linhas calculadas.
 * `prevIds` = conjunto de IDs que já estavam estáveis no DOM antes desta chamada;
 * qualquer ID fora desse conjunto é tratado como "entrando" e recebe animação.
 */
function _renderTableRows(tbody, rows, prevIds) {
  tbody.innerHTML = rows.map(o => {
    const atrasado  = diffMin(o) !== null && diffMin(o) < 0;
    const cancelled = isOrderCancelled(o);
    const updated   = updatedIds.has(o.jobId);
    const isNew     = newIds.has(o.jobId);
    const entering  = !prevIds.has(o.jobId); // linha que não estava no DOM antes
    const isFocused = focusedId === o.jobId;
    const t = tratativas[o.jobId] || { status: 'Pendente', texto: '' };
    const sCls = statusSelCls(t.status);
    const textoEsc = escapeHtml(t.texto || '').replace(/"/g, '&quot;');
    const motivo = (t.status === 'Pendente') ? (t._motivo || atencaoNecessaria(o)) : null;
    const rowCls = [
      entering   ? 'row-entering'  : '',
      atrasado   ? 'row-atrasado'  : '',
      cancelled  ? 'row-cancelled' : '',
      updated    ? 'row-updated'   : '',
      isNew      ? 'row-new'       : '',
      isFocused  ? 'row-focused'   : '',
    ].filter(Boolean).join(' ');

    return `<tr class="${rowCls}" data-oid="${escapeHtml(o.jobId)}">
      <td>
        <div class="job-id">${escapeHtml(o.jobId)}</div>
        ${isNew ? `<span class="badge badge-new-tag">🆕 NOVO</span>` : ''}
        ${atrasado ? `<span class="badge badge-late">ATRASADO</span>` : ''}
        ${cancelled ? `<span class="badge badge-cancelled-tag">⚠ CANCELADO</span>` : ''}
      </td>
      <td><div class="job-store">${escapeHtml(o.loja || '—')}</div></td>
      <td><span class="slot-txt">${escapeHtml(o.slot)}</span></td>
      <td>
        <span class="timer ${diffClass(o)}">${diffIcon(o)} ${formatDiff(o)}</span>
      </td>
      <td>${statusBadge(o)}</td>
      <td>${pickingBadge(o)}</td>
      <td>${platformBadge(o)}</td>
      <td>
        <select class="status-sel ${sCls}" data-oid="${escapeHtml(o.jobId)}" data-role="status">
          ${['Pendente', 'Em andamento', 'Resolvido', 'Sem ação necessária', 'Solicitado manual'].map(s =>
            `<option value="${escapeHtml(s)}"${t.status === s ? ' selected' : ''}>${escapeHtml(s)}</option>`
          ).join('')}
        </select>
        ${motivo ? `<div class="motivo-tag" title="${escapeHtml(motivo)}">⚠ ${escapeHtml(motivo)}</div>` : ''}
      </td>
      <td>
        <textarea class="nota-input" rows="1"
          placeholder="Anotação..."
          data-oid="${escapeHtml(o.jobId)}"
          data-role="nota">${textoEsc}</textarea>
      </td>
      <td style="text-align:center">
        ${editorBadge(o.jobId)}
      </td>
    </tr>`;
  }).join('');

  bindDynamicEvents();
}

function updateStats() {
  // Alimentar acumulador (persistido) com pedidos atualmente no painel
  _registrarNoAcumulado(orders.map(o => o.jobId));

  // "Ativos no painel" = pedidos sem status final na IL
  const ativos = orders.filter(o => !isILFinal(o.status));
  const total = ativos.length;
  const acumuladoHoje = _totalAcumuladoHoje.size;

  // Atrasados: pedidos ativos com slot vencido E que ainda precisam de atenção
  // (exclui já resolvidos, sem ação necessária, etc.)
  const atrasados = ativos.filter(o => {
    if (diffMin(o) === null || diffMin(o) >= 0) return false;
    const t = tratativas[o.jobId];
    if (t && (t.status === 'Resolvido' || t.status === 'Sem ação necessária')) return false;
    return true;
  }).length;

  // "Em tratativa" = pedidos onde o time está ativamente trabalhando
  const emTratativa = orders.filter(o => {
    const t = tratativas[o.jobId];
    if (!t) return false;
    const s = t.status || '';
    return s === 'Em andamento' || s === 'Solicitado manual';
  }).length;

  // Resolvidos: apenas os do dia de hoje (baseado em resolvedAt)
  const hoje = new Date().toISOString().slice(0, 10);
  const resolvidosIds = new Set(
    Object.entries(tratativas)
      .filter(([, t]) => {
        if (t.status !== 'Resolvido' && t.status !== 'Sem ação necessária') return false;
        // Só conta se resolvedAt for hoje ou não tiver data (sessão atual)
        if (!t.resolvedAt) return true;
        return t.resolvedAt.slice(0, 10) === hoje;
      })
      .map(([id]) => id)
  );
  const resolvidos = resolvidosIds.size;

  // Breakdown por plataforma — apenas "Sem alocação"
  const semAlocacaoCount = ativos.filter(o => {
    const _trat = tratativas[o.jobId];
    if (_trat?.status === 'Solicitado manual') return false;
    return !o.platformName;
  }).length;

  function setCard(id, val) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = val;
    el.classList.remove('stat-dash');
  }

  setCard('sv-total', total);
  setCard('sv-atrasados', atrasados);
  setCard('sv-pendentes', emTratativa);

  // Sub-label "Em tratativa": detalhamento
  const ssPend = document.getElementById('ss-pendentes');
  if (ssPend) {
    const andamento = orders.filter(o => tratativas[o.jobId]?.status === 'Em andamento').length;
    const manual    = orders.filter(o => tratativas[o.jobId]?.status === 'Solicitado manual').length;
    ssPend.textContent = total > 0
      ? `${andamento} andamento · ${manual} manual`
      : 'Em andamento / Manual';
  }

  setCard('sv-resolvidos', resolvidos);

  // Card sem alocação
  const saEl = document.getElementById('sv-sem-alocacao');
  if (saEl) {
    saEl.textContent = semAlocacaoCount;
    saEl.classList.remove('stat-dash');
  }
  const ssSa = document.getElementById('ss-sem-alocacao');
  if (ssSa) ssSa.textContent = semAlocacaoCount === 0 ? 'Todos alocados ✓' : 'Aguardando entregador';

  ['sc-total', 'sc-atrasados', 'sc-pendentes', 'sc-resolvidos', 'sc-pk'].forEach(id => {
    const c = document.getElementById(id);
    if (c) c.classList.add('has-data');
  });

  const ssTotal = document.getElementById('ss-total');
  if (ssTotal) ssTotal.textContent = `${acumuladoHoje} acumulados hoje`;

  const ssResolvidos = document.getElementById('ss-resolvidos');
  if (ssResolvidos) ssResolvidos.textContent = acumuladoHoje > 0 ? `${Math.round(resolvidos / acumuladoHoje * 100)}% dos acumulados` : '';

  // ── Badges das abas ──────────────────────────────────────────────────────
  const tabPendentes  = orders.filter(o => { const t = tratativas[o.jobId]; return !t || t.status === 'Pendente'; }).length;
  const tabAndamento  = orders.filter(o => { const t = tratativas[o.jobId]; return t?.status === 'Em andamento' || t?.status === 'Solicitado manual'; }).length;
  const tabResolvidos = resolvidos;
  const setMtabCount = (id, val) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = val > 0 ? val : '';
    el.style.display = val > 0 ? '' : 'none';
  };
  setMtabCount('mtab-count-pendentes',  tabPendentes);
  setMtabCount('mtab-count-andamento',  tabAndamento);
  setMtabCount('mtab-count-resolvidos', tabResolvidos);
}

function setLastUpdate(type = 'full') {
  const el = document.getElementById('last-update');
  if (!el) return;
  const time = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const label = type === 'full' ? 'Atualização completa' : 'Picking atualizado';
  el.textContent = `${label} às ${time}`;
}

// ════════════════════════════════════════════════
// EVENTS
// ════════════════════════════════════════════════
function onStatus(oid, val, el) {
  const t = tratativas[oid] || { status: 'Pendente', texto: '', spItemId: null };
  const anterior = t.status || 'Pendente';
  if (anterior === val) return; // nada mudou

  // Confirmação antes de alterar
  const labels = {
    'Pendente': 'Pendente',
    'Em andamento': 'Em andamento',
    'Solicitado manual': 'Solicitado manual',
    'Resolvido': 'Resolvido',
    'Sem ação necessária': 'Sem ação necessária',
  };
  const ok = confirm(`Confirmar alteração da tratativa?\n\nDE: ${labels[anterior] || anterior}\nPARA: ${labels[val] || val}`);
  if (!ok) {
    // Reverter o select para o valor anterior
    el.value = anterior;
    el.className = `status-sel ${statusSelCls(anterior)}`;
    return;
  }

  if (!tratativas[oid]) tratativas[oid] = { status: 'Pendente', texto: '', spItemId: null };
  tratativas[oid].status = val;
  if (val === 'Resolvido' || val === 'Sem ação necessária') {
    tratativas[oid].resolvedAt = new Date().toISOString().slice(0, 10);
    // Guardar no cache para manter visível após sair da API ativa
    const pedido = orders.find(o => o.jobId === oid);
    if (pedido) _registrarResolvidosCache([pedido]);
  } else {
    delete tratativas[oid].resolvedAt;
    // Se foi reaberto, remover do cache de resolvidos
    delete _cacheResolvidos[oid];
    _salvarCacheResolvidos(Object.values(_cacheResolvidos));
  }
  el.className = `status-sel ${statusSelCls(val)}`;
  debounceSave(oid);
  updateStats();
  _removerLinhaSeExcluida(oid); // remove imediatamente se o filtro atual não inclui o novo status
  LOG.info(`Status tratativa ${oid} → "${val}"`);
}

/**
 * Remove a linha do painel imediatamente (com animação de saída) quando o novo
 * status da tratativa deixa de corresponder ao filtro ativo — sem precisar
 * aguardar o próximo ciclo de polling para o DOM ser atualizado.
 */
function _removerLinhaSeExcluida(oid) {
  const t = tratativas[oid];

  // Decidir se a aba/filtro atual exclui o novo status
  let deveExcluir = false;

  // Prioridade: aba ativa (tabMode) > filterMode
  if (tabMode !== 'todos') {
    switch (tabMode) {
      case 'pendentes':
        deveExcluir = !(!t || t.status === 'Pendente');
        break;
      case 'andamento':
        if (andamentoSubFilter === 'manuais')   deveExcluir = t?.status !== 'Solicitado manual';
        else if (andamentoSubFilter === 'tratativa') deveExcluir = t?.status !== 'Em andamento';
        else deveExcluir = !(t?.status === 'Em andamento' || t?.status === 'Solicitado manual');
        break;
      case 'resolvidos':
        deveExcluir = !(t?.status === 'Resolvido' || t?.status === 'Sem ação necessária');
        break;
    }
  } else {
    // Sem aba ativa: usar filterMode (compatibilidade com filtros de ocorrências)
    switch (filterMode) {
      case 'pendentes':
        deveExcluir = !(!t || t.status === 'Pendente');
        break;
      case 'andamento':
        deveExcluir = t?.status !== 'Em andamento';
        break;
      case 'manuais':
        deveExcluir = t?.status !== 'Solicitado manual';
        break;
      case 'resolvidos':
        deveExcluir = !(t?.status === 'Resolvido' || t?.status === 'Sem ação necessária');
        break;
      default:
        deveExcluir = false;
    }
  }
  if (!deveExcluir) return;

  const tbody = document.getElementById('tbody');
  const tr = tbody?.querySelector(`tr[data-oid="${CSS.escape(oid)}"]`);
  if (!tr) return;

  // Animação de saída suave antes de remover
  tr.style.transition = 'opacity 0.25s ease, transform 0.25s ease';
  tr.style.opacity = '0';
  tr.style.transform = 'translateX(10px)';
  setTimeout(() => {
    tr.remove();
    updateStats();
    // Se tbody ficou vazio, renderiza o estado vazio corretamente
    if (tbody && !tbody.querySelector('tr[data-oid]')) renderTable();
  }, 260);
}

function onAnotacao(oid, val) {
  if (!tratativas[oid]) tratativas[oid] = { status: 'Pendente', texto: '', spItemId: null };
  tratativas[oid].texto = val;
  // Se anotação foi preenchida e ainda está como Pendente → promover para Em andamento
  if (val.trim() && tratativas[oid].status === 'Pendente') {
    tratativas[oid].status = 'Em andamento';
    // Atualizar o select na linha correspondente (suporta id e data-oid)
    const sel = document.getElementById(`sel-${oid}`)
             || document.querySelector(`.status-sel[data-oid="${CSS.escape(oid)}"]`);
    if (sel) {
      sel.value = 'Em andamento';
      sel.className = `status-sel ${statusSelCls('Em andamento')}`;
    }
    updateStats();
    // Mover linha para fora da aba Pendentes imediatamente
    _removerLinhaSeExcluida(oid);
  }
  debounceSave(oid);
}

function debounceSave(oid) {
  setSaveInd(oid, 'saving', '↑...');
  // Registrar quem está editando (usuário logado atual)
  if (currentAuthUser && tratativas[oid]) {
    tratativas[oid].editor = {
      nome:  currentAuthUser.displayName || currentAuthUser.name || '',
      email: currentAuthUser.email || '',
      at:    new Date().toISOString(),
    };
    // Atualizar avatar na coluna imediatamente
    const cell = document.getElementById(`si-${oid}`)?.closest('td');
    if (cell) cell.innerHTML = editorBadge(oid);
  }
  // Marca como "em edição" — o refreshSP não vai sobrescrever enquanto o debounce estiver ativo
  spEditingIds.add(oid);
  clearTimeout(saveTimers[oid]);
  saveTimers[oid] = setTimeout(() => {
    spEditingIds.delete(oid); // libera o lock antes de salvar
    saveTratativa(oid);
  }, 1800);
}

function setSaveInd(oid, cls, txt) {
  const el = document.getElementById(`si-${oid}`);
  if (el) {
    el.className = `save-ind si-${cls}`;
    el.textContent = txt;
  }
}

/**
 * Retorna texto relativo ao tempo passado (ex: "há 5 minutos", "há 2 horas")
 */
function tempoRelativo(isoDate) {
  if (!isoDate) return '';
  const diff = Math.floor((Date.now() - new Date(isoDate).getTime()) / 1000);
  if (diff < 60)  return 'há menos de 1 min';
  if (diff < 3600) return `há ${Math.floor(diff / 60)} min`;
  if (diff < 86400) return `há ${Math.floor(diff / 3600)}h`;
  return `há ${Math.floor(diff / 86400)}d`;
}

/**
 * Gera o HTML do avatar do editor (iniciais + foto assíncrona via Graph).
 * Sempre renderiza iniciais imediatamente; a foto é carregada em background.
 */
function editorBadge(oid) {
  const t = tratativas[oid];
  const ed = t?.editor;
  if (!ed) return `<span class="save-ind" id="si-${escapeHtml(oid)}"></span>`;

  const nome  = escapeHtml(
    ed.nome ||
    (_nexosUserMap && email ? _nexosUserMap[email]?.nome : '') ||
    'Desconhecido'
  );
  const email = (ed.email || '').toLowerCase();
  const when  = tempoRelativo(ed.at);
  const whenFull = ed.at ? new Date(ed.at).toLocaleString('pt-BR') : '';

  const iniciais = (ed.nome || '')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map(p => p[0].toUpperCase())
    .join('') || '?';

  const tooltip = `${when}&#10;${escapeHtml(nome)}${email ? '&#10;' + escapeHtml(email) : ''}${whenFull ? '&#10;' + whenFull : ''}`;

  // Verifica se já temos a foto em cache (blob URL) para renderizar direto
  const cachedUrl = typeof _photoCache.get(email) === 'string' ? _photoCache.get(email) : null;
  const imgHtml = cachedUrl
    ? `<img src="${escapeHtml(cachedUrl)}" class="editor-avatar-img" alt="${escapeHtml(nome)}">`
    : '';
  const iniStyle = cachedUrl ? 'display:none' : '';

  // Solicitar foto em background se ainda não foi carregada
  if (email && !cachedUrl) _loadAvatarsByEmail(email);

  return `
    <span class="save-ind" id="si-${escapeHtml(oid)}"></span>
    <span class="editor-avatar" title="${tooltip}" aria-label="Editado por ${nome}"
          data-avatar-email="${escapeHtml(email)}" data-avatar-name="${escapeHtml(nome)}">
      ${imgHtml}
      <span class="editor-avatar-initials" style="${iniStyle}">${escapeHtml(iniciais)}</span>
    </span>`;
}

function sortBy(col) {
  if (sortCol === col) sortDir *= -1;
  else { sortCol = col; sortDir = 1; }
  renderTable();
}

function setFilter(mode, btn) {
  filterMode = mode;
  document.querySelectorAll('.filter-chip').forEach(b => b.classList.remove('active'));
  // Se o modo não é do grupo de ocorrências, resetar o label do dropdown
  const GRP_MODES = new Set(['cancelados', 'entregues']);
  const grpLabel = document.getElementById('filter-grp-label');
  if (!GRP_MODES.has(mode)) {
    if (grpLabel) grpLabel.textContent = 'Ocorrências ▾';
    document.querySelectorAll('.filter-chip-option[data-filter]').forEach(o => o.classList.remove('selected'));
  }
  // Se o modo não é il-status, resetar o label do dropdown IL
  if (mode !== 'il-status') {
    const ilLabel = document.getElementById('filter-il-label');
    if (ilLabel) ilLabel.textContent = 'Status IL ▾';
    document.querySelectorAll('.filter-chip-option[data-il-status]').forEach(o => o.classList.remove('selected'));
    _ilStatusFilter = '';
  }
  if (btn) btn.classList.add('active');
  renderTable();
}

/**
 * Ativa uma das abas principais do Monitor.
 * Ao trocar de aba os filtros secundários (Ocorrências, Status IL) são resetados,
 * mas a busca livre é preservada.
 */
function setTab(tab) {
  tabMode = tab;
  localStorage.setItem('monitor_tabMode', tab);
  andamentoSubFilter = 'todos';

  // UI: destacar aba ativa
  document.querySelectorAll('.monitor-tab').forEach(b => b.classList.remove('active'));
  const activeTab = document.getElementById(`mtab-${tab}`);
  if (activeTab) activeTab.classList.add('active');

  // Mostrar/ocultar subfiltros da aba Em andamento
  const subFilters = document.getElementById('andamento-subfilters');
  if (subFilters) subFilters.style.display = tab === 'andamento' ? 'flex' : 'none';

  // Resetar subfiltro ativo para "todos"
  document.querySelectorAll('[data-sub-andamento]').forEach(b => {
    b.classList.toggle('active', b.dataset.subAndamento === 'todos');
  });

  // Resetar filtros de ocorrências e IL (não fazem sentido combinados com aba específica)
  filterMode = 'todos';
  _ilStatusFilter = '';
  const grpLabel = document.getElementById('filter-grp-label');
  if (grpLabel) grpLabel.textContent = 'Ocorrências ▾';
  const ilLabel = document.getElementById('filter-il-label');
  if (ilLabel) ilLabel.textContent = 'Status IL ▾';
  document.querySelectorAll('.filter-chip-option').forEach(o => o.classList.remove('selected'));

  renderTable();
}

// Guard: só recupera o acumulado uma vez por sessão (evita múltiplas queries)
let _acumRecuperado = false;

/**
 * Faz uma query leve à IL com status DELIVERED,FINISHED para recuperar IDs
 * de pedidos do dia que já foram entregues/finalizados — só para o acumulador.
 * Roda em background, não bloqueia a UI.
 */
async function _recuperarAcumuladoBackground() {
  if (_acumRecuperado) return;
  _acumRecuperado = true;

  const c = readCfg();
  if (!c['il-token'] || !c['il-base']) return;

  try {
    const today = new Date().toISOString().split('T')[0];
    const ilFleets = await resolveILFleets();
    const params = new URLSearchParams({
      page: '1',
      page_size: '200',
      status: 'DELIVERED,FINISHED',
      slot_from_store_tz: `${today} 00:00:00`,
      fleets: ilFleets,
    });
    const res = await fetch(`${c['il-base']}/hela/api/v2/jobs?${params}`, {
      headers: { 'Authorization': `Bearer ${c['il-token']}`, 'Accept': 'application/json' }
    });
    if (!res.ok) return;
    const json = await res.json();
    const ids = (Array.isArray(json.data) ? json.data : []).map(r => r.job_id || r.jobId || r.id).filter(Boolean);
    if (ids.length) {
      _registrarNoAcumulado(ids);
      updateStats(); // atualiza o card com o valor correto
      console.log(`[MONITOR] Acumulado recuperado: +${ids.length} pedidos finalizados do dia`);
    }
  } catch (e) {
    console.warn('[MONITOR] Recuperação de acumulado falhou:', e.message);
  }
}

async function refreshAll() {
  if (isLoading) {
    LOG.warn('refreshAll chamado enquanto carregando — ignorado');
    return;
  }

  isLoading = true;
  const btn = document.getElementById('refresh-btn');
  if (btn) {
    btn.disabled = true;
    btn.textContent = '⟳ Carregando...';
  }

  const guide = document.getElementById('setup-guide');

  startProgress();
  renderTable();

  try {
    LOG.info('=== refreshAll iniciado ===');

    // SP e IL correm em paralelo.
    // _spMapCache: recebe o mapa SP assim que disponível (null enquanto pendente).
    // Usado no onPage para aplicar tratativas já na primeira renderização incremental.
    let _spMapCache = null;

    // Picking também em paralelo: inicia após a 1ª página da IL chegar
    let _pickingStarted = false;
    let _latestPickingMap = {};

    const [ilRows, spMap] = await Promise.all([
      fetchInstaleap({
        onPage: async (partialRows) => {
          // Renderização incremental: mostrar pedidos à medida que chegam
          if (!isLoading) return; // abortado

          // Merge com SP já disponível (ou {} se SP ainda não resolveu)
          orders = mergeData(partialRows, _latestPickingMap, _spMapCache || {});
          renderTable();
          updateStats();

          // Iniciar picking em background na 1ª página (não bloqueia IL)
          if (!_pickingStarted) {
            _pickingStarted = true;
            fetchAllPicking(partialRows.map(r => r.jobId)).then(pkMap => {
              _latestPickingMap = pkMap;
              if (isLoading) {
                // Atualiza picking nas linhas já renderizadas
                orders = orders.map(o => ({ ...o, pickingStatus: pkMap[o.jobId] || o.pickingStatus }));
                renderTable();
              }
            }).catch(() => {});
          }
        }
      }).catch(e => {
        LOG.error('Instaleap falhou:', e.message);
        if (e.isAuthError) {
          // Token expirado ou inválido — bloquear painel e iniciar re-login
          LOG.warn('IL: Token expirado (401/403) — bloqueando painel até reconexão');
          secureTokens['il-token'] = '';
          saveSecureTokens();
          refreshTokenBadges();
          // Bloquear painel e acionar popup de re-login
          showILLockOverlay('Sessão expirada. Abrindo janela de reconexão...');
          setTimeout(() => instaleapLoginAuto(), 600);
          return null;
        }
        showToast('Instaleap: ' + e.message, 'error');
        return null;
      }),
      fetchSharePoint().then(m => { _spMapCache = m; return m; }).catch(e => {
        LOG.warn('SharePoint falhou:', e.message);
        _spMapCache = {};
        return {};
      })
    ]);

    if (!ilRows) {
      LOG.warn('Sem dados da Instaleap — abortando refresh');
      const cfgCheck = readCfg();
      if (!cfgCheck['il-token'] && !window._ilLoginPending) {
        // Nenhum token configurado — orientar o usuário a configurar
        showToast('⚙ Token Instaleap não configurado. Abra as Configurações para inserir o token.', 'warn');
        finishProgress(false);
        isLoading = false;
        if (btn) { btn.disabled = false; btn.textContent = '↻ Atualizar'; }
        renderTable();
        updateStats();
        return;
      } else if (orders.length > 0) {
        // Erro de rede mas o onPage já trouxe dados parciais — avisar e manter o que há
        showToast(`⚠️ Carregamento incompleto: erro de rede na Instaleap. Exibindo ${orders.length} pedido(s) parcialmente carregados.`, 'warn');
        finishProgress(false);
        isLoading = false;
        if (btn) { btn.disabled = false; btn.textContent = '↻ Atualizar'; }
        return;
      } else {
        // Falha total com il-token presente → sessão expirada ou inválida
        // Bloquear o painel e forçar reconexão do Instaleap
        orders = [];
        LOG.warn('IL: falha total com il-token presente — limpando token e bloqueando painel');
        secureTokens['il-token'] = '';
        saveSecureTokens();
        refreshTokenBadges();
        window._ilLoginPending = false;
        finishProgress(false);
        isLoading = false;
        if (btn) { btn.disabled = false; btn.textContent = '↻ Atualizar'; }
        renderTable();
        updateStats();
        showILLockOverlay('Sessão Instaleap expirada ou inválida. Reconecte para continuar.');
        return;
      }
    }

    LOG.info(`${ilRows.length} pedidos da Instaleap`);

    // Picking final completo (todos os pedidos, incluindo páginas 2+)
    const pkMap = await fetchAllPicking(ilRows.map(r => r.jobId)).catch(e => {
      LOG.warn('Picking falhou:', e.message);
      return _latestPickingMap; // usar o que já temos do background fetch
    });

    // ── Merge principal ───────────────────────────────────────────────────
    orders = mergeData(ilRows, pkMap, spMap);

    // ── Buscar picking dos stubs (_retidoPorTratativa) em background ──────
    // Os stubs são criados dentro de mergeData e não estavam em ilRows,
    // portanto não foram incluídos no pkMap acima. Buscamos agora em paralelo.
    const stubOrders = orders.filter(o => o._retidoPorTratativa);
    if (stubOrders.length > 0 && readCfg()['pk-token']) {
      fetchAllPicking(stubOrders.map(o => o.jobId)).then(stubPkMap => {
        let changed = 0;
        orders = orders.map(o => {
          if (!o._retidoPorTratativa) return o;
          const pk = stubPkMap[o.jobId];
          if (pk && pk !== o.pickingStatus) { changed++; return { ...o, pickingStatus: pk }; }
          return o;
        });
        if (changed > 0) { renderTable(); }
      }).catch(() => {});
    }

    // ── Buscar status IL real dos stubs em background ─────────────────────
    // mergeData cria stubs com status artificial ('IN_PROGRESS').
    // Buscamos o status real via fetchInstaleapByOrders sem bloquear a render.
    if (stubOrders.length > 0 && readCfg()['il-token']) {
      fetchInstaleapByOrders(stubOrders.map(o => o.jobId)).then(stubIlMap => {
        let ilChanged = 0;
        orders = orders.map(o => {
          if (!o._retidoPorTratativa) return o;
          const fresh = stubIlMap.get(String(o.jobId));
          if (!fresh) return o;
          if (o.status !== fresh.status) {
            LOG.info(`Stub IL (carga): ${fresh.jobId}: "${o.status}" → "${fresh.status}"`);
            ilChanged++;
          }
          return {
            ...o,
            status:       fresh.status,
            instaleapId:  fresh.instaleapId  || o.instaleapId,
            plataformaId: fresh.plataformaId || o.plataformaId,
            platformName: fresh.platformName || o.platformName,
            loja:         fresh.loja         || o.loja,
            slot:         fresh.slot         || o.slot,
            slotFrom:     fresh.slotFrom     || o.slotFrom,
            slotTo:       fresh.slotTo       || o.slotTo,
          };
        });
        if (ilChanged > 0) { renderTable(); updateStats(); }
      }).catch(e => LOG.warn('Stubs IL (carga) falhou:', e.message));
    }

    // ── Registrar no cache os pedidos que acabaram de ser resolvidos ──────
    // (enquanto ainda estão em orders[] frescos da API)
    const resolvidosFrescos = orders.filter(o => {
      const t = tratativas[o.jobId];
      return t && (t.status === 'Resolvido' || t.status === 'Sem ação necessária');
    });
    _registrarResolvidosCache(resolvidosFrescos);

    // ── Injetar pedidos resolvidos do cache que já saíram da API ─────────
    _limparResolvidosCacheSeNecessario();
    const idsAtivos = new Set(orders.map(o => o.jobId));
    Object.values(_cacheResolvidos).forEach(o => {
      if (!idsAtivos.has(o.jobId)) {
        // Garantir que o objeto do cache tenha a tratativa mais recente
        orders.push({ ...o });
      }
    });

    const nAtivos = orders.filter(o => { const t = tratativas[o.jobId]; return !t || (t.status !== 'Resolvido' && t.status !== 'Sem ação necessária'); }).length;
    const nResolvidos = orders.length - nAtivos;
    LOG.ok(`Merge completo: ${nAtivos} ativos + ${nResolvidos} resolvidos (cache)`);

    // ── Detecção de erro sistêmico ─────────────────────────────────────────
    // Se mais de 10 pedidos estiverem ENTREGUE na Instaleap mas com picking
    // ainda "Aguardando" (vazio ou sem status final), pode indicar falha de integração.
    const THRESHOLD_SISTEMIC = 10;
    const sistemicCandidates = orders.filter(o => {
      const ilS = String(o.status || '').toUpperCase();
      const ilEntregue = ilS === 'DELIVERED' || ilS === 'FINISHED';
      const pk = String(o.pickingStatus || '').toLowerCase();
      const pkPendente = !pk || pk === 'aguardando' || pk === 'não encontrado' || pk === 'nao encontrado';
      return ilEntregue && pkPendente;
    });
    if (sistemicCandidates.length > THRESHOLD_SISTEMIC) {
      LOG.warn(`Possível erro sistêmico: ${sistemicCandidates.length} pedidos ENTREGUES na Instaleap com picking pendente — removidos do painel`);
      const sistemicIds = new Set(sistemicCandidates.map(o => o.jobId));
      orders = orders.filter(o => !sistemicIds.has(o.jobId));
      // Toast persistente de alerta
      showToast(
        `⚠️ ALERTA SISTÊMICO: ${sistemicCandidates.length} pedidos entregues na Instaleap sem confirmação no picking. Verifique integração com sistema de coleta.`,
        'error'
      );
      LOG.error(`Erro sistêmico detectado: ${sistemicCandidates.length} pedidos removidos do painel. IDs: ${[...sistemicIds].slice(0, 5).join(', ')}${sistemicIds.size > 5 ? '...' : ''}`);
    }
    // ──────────────────────────────────────────────────────────────────────

    if (guide) guide.style.display = 'none';

    renderTable();
    updateStats();
    setLastUpdate('full');
    resetCountdown();
    startPolling();
    finishProgress(true);

    // ── Recuperação do acumulado do dia (background, não bloqueia UI) ──────
    // Faz uma query leve à IL com DELIVERED,FINISHED só para registrar IDs
    // no acumulador. Importante para o primeiro load do dia.
    _recuperarAcumuladoBackground();

    const atrasados = orders.filter(o => {
      if (isILFinal(o.status)) return false;
      if (diffMin(o) === null || diffMin(o) >= 0) return false;
      const t = tratativas[o.jobId];
      if (t && (t.status === 'Resolvido' || t.status === 'Sem ação necessária')) return false;
      return true;
    }).length;
    if (atrasados > 0) {
      showToast(`⚠ ${atrasados} pedido${atrasados > 1 ? 's' : ''} atrasado${atrasados > 1 ? 's' : ''} sem resolução`, 'warn');
    } else {
      showToast(`✓ ${orders.filter(o => !isILFinal(o.status)).length} pedidos carregados`, 'success');
    }
  } catch (e) {
    LOG.error('refreshAll erro geral:', e.message, e.stack);
    showToast('Erro geral: ' + e.message, 'error');
    finishProgress(false);
    setMode('error');
  } finally {
    isLoading = false;
    if (btn) {
      btn.disabled = false;
      btn.textContent = '↻ Atualizar';
    }
  }
}

async function refreshPicking() {
  if (!orders.length || isLoading) return;

  console.log('[MONITOR] Refresh automático: Picking + reconciliação completa Instaleap...');
  const pd = document.getElementById('pulse-dot');
  if (pd) pd.className = 'pulse-dot loading';

  try {
    // 1. Reconciliação completa com a API Instaleap
    //    1. Buscar lista principal do IL → reconstruir orders → renderizar imediatamente.
    //    2. Stubs (pedidos retidos por tratativa) são buscados em background sem bloquear a render.
    //    3. Quando os stubs chegarem, atualizar os statuses e re-renderizar incrementalmente.
    const c = readCfg();
    if (c['il-token']) {
      try {
        // Passo 1: busca principal
        const freshRows = await fetchInstaleap();

        if (freshRows && freshRows.length > 0) {
          // Índice rápido dos pedidos atuais para preservar dados locais
          const existingMap = new Map(orders.map(o => [o.jobId, o]));
          // Conjunto dos IDs que a API retornou agora
          const freshIds    = new Set(freshRows.map(r => r.jobId));

          // ── Novos pedidos (ainda não estavam no painel) ──────────────────
          // Ignorar pedidos que já chegam em estado final (entregue/cancelado) —
          // não há ação necessária do time para esses casos.
          const newOrders = freshRows.filter(r => {
            if (existingMap.has(r.jobId)) return false; // já está no painel
            return !isILFinal(r.status); // só aceitar pedidos ativos
          });
          if (newOrders.length > 0) {
            LOG.ok(`Polling: ${newOrders.length} pedido(s) novo(s) detectado(s)`);
            showToast(`🆕 ${newOrders.length} novo(s) pedido(s) detectado(s)!`, 'info');
            newOrders.forEach(r => newIds.add(r.jobId));
          }

          // ── Mudanças de status em pedidos já existentes ──────────────────
          freshRows.forEach(fresh => {
            const existing = existingMap.get(fresh.jobId);
            if (!existing) return;
            if (existing.status !== fresh.status) {
              LOG.info(`Polling: status ${fresh.jobId}: "${existing.status}" → "${fresh.status}"`);
              updatedIds.add(fresh.jobId);
              setTimeout(() => { updatedIds.delete(fresh.jobId); }, 8000);
              if (isCancelled(fresh.status) && !isCancelled(existing.status)) {
                showToast(`⛔ Pedido ${fresh.jobId} foi CANCELADO!`, 'error');
              }
              // Se transitou para ENTREGUE/CANCELADO e tem tratativa ativa → auto-resolução no SP
              if (isILFinal(fresh.status) && !isILFinal(existing.status)) {
                const t = tratativas[fresh.jobId];
                const temTratativa = t && (t.spItemId || (t.texto && t.texto.trim()) || (t.status && t.status !== 'Pendente'));
                const jaResolvido  = t && (t.status === 'Resolvido' || t.status === 'Sem ação necessária');
                if (temTratativa && !jaResolvido && !t._autoResolvendo) {
                  const ilS = fresh.status.toUpperCase();
                  const isDelivered = ilS === 'DELIVERED' || ilS === 'FINISHED';
                  // "Solicitado manual": entrega Uber em andamento.
                  // Só auto-resolve quando IL confirmar ENTREGUE — jamais ao CANCELAR.
                  if (t.status === 'Solicitado manual' && !isDelivered) return;
                  t._autoResolvendo = true;
                  t.status = isDelivered ? 'Resolvido' : 'Sem ação necessária';
                  t.resolvedAt = new Date().toISOString().slice(0, 10);
                  t._autoActionAt = Date.now();
                  LOG.ok(`Auto-resolução polling: pedido ${fresh.jobId} → "${t.status}" (IL: ${fresh.status})`);
                  saveTratativa(fresh.jobId).finally(() => { delete t._autoResolvendo; });
                }
              }
            }
          });

          // ── Pedidos que saíram da API: preservar se tiverem tratativa ────
          // Um pedido permanece no painel enquanto não for marcado como
          // "Resolvido" / "Sem ação necessária" — mesmo após cancelado/entregue.
          const removedFromApi = orders.filter(o => !freshIds.has(o.jobId));
          const mustKeep = [];
          for (const o of removedFromApi) {
            const t = tratativas[o.jobId];
            const temTratativaManual = t && (
              t.spItemId ||
              (t.texto && t.texto.trim() !== '') ||
              (t.status && t.status !== 'Pendente')
            );
            const jaResolvido = t && (
              t.status === 'Resolvido' ||
              t.status === 'Sem ação necessária'
            );

            if (jaResolvido) {
              // Sempre manter resolvidos para aparecer no filtro de Resolvidos
              mustKeep.push(o);
            } else if (temTratativaManual) {
              // Tratativa manual ainda em aberto → reter no painel
              o._retidoPorTratativa = true;
              mustKeep.push(o);
              LOG.info(`Polling: pedido ${o.jobId} removido da API mas retido (tem tratativa manual)`);
            }
            // Sem tratativa → sai silenciosamente
          }

          // ── Reconstrução: API + pedidos retidos (com status atual, sem aguardar stubs) ──
          orders = [
            ...freshRows
              .filter(fresh => !isILFinal(fresh.status) || existingMap.has(fresh.jobId))
              .map(fresh => {
                const prev = existingMap.get(fresh.jobId);
                return {
                  ...fresh,
                  pickingStatus: prev?.pickingStatus || '',
                  pickingRaw:    prev?.pickingRaw    || null,
                };
              }),
            ...mustKeep.map(o => ({ ...o })),
          ];

          LOG.ok(`Polling: lista reconciliada → ${orders.length} pedido(s) (retidos: ${mustKeep.length}, antes: ${existingMap.size})`);

          // Passo 2: buscar stubs em background — NÃO bloqueia renderização principal
          const activeStubs = mustKeep
            .filter(o => o._retidoPorTratativa && !isILFinal(o.status))
            .map(o => o.jobId);
          if (activeStubs.length > 0) {
            fetchInstaleapByOrders(activeStubs).then(stubMap => {
              let stubChanged = 0;
              orders = orders.map(o => {
                const fresh = stubMap.get(String(o.jobId));
                if (!fresh) return o;
                if (o.status !== fresh.status) {
                  LOG.info(`Stub IL update ${fresh.jobId}: "${o.status}" → "${fresh.status}"`);
                  updatedIds.add(fresh.jobId);
                  setTimeout(() => { updatedIds.delete(fresh.jobId); }, 8000);
                  if (isILFinal(fresh.status)) _stubIlCache.delete(String(fresh.jobId));
                  stubChanged++;
                }
                return {
                  ...o,
                  status:       fresh.status,
                  instaleapId:  fresh.instaleapId  || o.instaleapId,
                  plataformaId: fresh.plataformaId || o.plataformaId,
                  platformName: fresh.platformName || o.platformName,
                  loja:         fresh.loja         || o.loja,
                  slot:         fresh.slot         || o.slot,
                  slotFrom:     fresh.slotFrom     || o.slotFrom,
                  slotTo:       fresh.slotTo       || o.slotTo,
                };
              });
              if (stubChanged > 0) {
                LOG.ok(`Stubs IL: ${stubChanged} status atualizados`);
                renderTable();
                updateStats();
              }
            }).catch(e => LOG.warn('Stubs IL fetch falhou:', e.message));
          }
        }
      } catch (e) {
        LOG.warn('Polling Instaleap falhou:', e.message);
        if (e.isAuthError) {
          // Token expirado durante polling — bloquear painel e reconectar
          LOG.warn('IL: Token expirado durante polling (401/403) — bloqueando painel');
          secureTokens['il-token'] = '';
          saveSecureTokens();
          refreshTokenBadges();
          showILLockOverlay('Sessão expirada durante monitoramento. Reconectando...');
          setTimeout(() => instaleapLoginAuto(), 600);
          return; // sai do refreshPicking
        }
        // Em caso de falha na API IL não-auth, mantém lista atual (não limpa)
      }
    }

    // 2. Atualizar picking apenas de pedidos ainda ativos na IL
    // (pedidos finalizados não precisam de nova consulta ao picking)
    const activeOrders = orders.filter(o => !isILFinal(o.status));
    const pkMap = await fetchAllPicking(activeOrders.map(o => o.jobId));
    let pkChanged = 0;

    orders = orders.map(o => {
      const newStatus = pkMap[o.jobId] || o.pickingStatus;
      if (newStatus !== o.pickingStatus) {
        pkChanged++;
        updatedIds.add(o.jobId);
        setTimeout(() => { updatedIds.delete(o.jobId); renderTable(); }, 8000);
      }
      return { ...o, pickingStatus: newStatus };
    });

    if (pkChanged > 0) {
      LOG.ok(`Picking: ${pkChanged} status atualizados`);
    }

    // 4. Auto-conclusão: se IL e Picking ambos indicam entregue/cancelado,
    //    concluir a tratativa automaticamente e anotar no comentário.
    orders.forEach(o => {
      const ilS = String(o.status || '').toUpperCase();
      const pk  = String(o.pickingStatus || '').toLowerCase();
      const ilDelivered  = ilS === 'DELIVERED' || ilS === 'FINISHED';
      const ilCancelled  = isCancelled(ilS);
      const pkDelivered  = pk.includes('entregue') || pk.includes('delivered');
      const pkCancelled  = pk.includes('cancelado') || (pk.includes('cancel') && !pkDelivered);

      // Verificar se há convergência
      const convergiu =
        (ilDelivered && pkDelivered) ||
        (ilCancelled && pkCancelled);
      if (!convergiu) return;

      const t = tratativas[o.jobId];
      if (!t) return;
      const jaResolvido = t.status === 'Resolvido' || t.status === 'Sem ação necessária';
      if (jaResolvido || t._autoConvergindo) return;

      const tag   = ilDelivered && pkDelivered ? '(ENTREGUE)' : '(CANCELADO)';
      const novoStatus = ilDelivered ? 'Resolvido' : 'Sem ação necessária';

      // Adicionar tag ao comentário se ainda não estiver lá
      const textoAtual = t.texto || '';
      if (!textoAtual.includes(tag)) {
        t.texto = textoAtual ? `${textoAtual}\n${tag}` : tag;
      }
      t.status     = novoStatus;
      t.resolvedAt = new Date().toISOString().slice(0, 10);
      t._autoConvergindo = true;
      t._autoActionAt    = Date.now(); // protege editor original no próximo polling SP

      LOG.ok(`Auto-conclusão: pedido ${o.jobId} convergiu → "${novoStatus}" ${tag}`);
      showToast(`✅ Pedido ${o.jobId} concluído automaticamente ${tag}`, 'success');
      saveTratativa(o.jobId).finally(() => { delete t._autoConvergindo; });
    });

    renderTable();
    updateStats();
    setLastUpdate('picking');
    if (pd) pd.className = 'pulse-dot live';
  } catch (e) {
    LOG.error('refreshPicking erro:', e.message);
    if (pd) pd.className = 'pulse-dot error';
  }
}

// ════════════════════════════════════════════════
// POLLING / COUNTDOWN
// ════════════════════════════════════════════════
// SP POLLING — sincronização em tempo real (3s delta)
// ════════════════════════════════════════════════

// Timestamp do último item visto no SP — usado no filtro OData $filter=Modified gt '...'
let spLastCheck = null;
// Conjunto de jobIds com save pendente (debounce ativo) — nunca sobrescrever enquanto digitando
const spEditingIds = new Set();
// Back-off: conta erros consecutivos
let spErrorCount = 0;

/**
 * Busca APENAS os itens do SP modificados após `since`.
 * Retorna map { jobId -> { status, texto, spItemId, modified } }
 *
 * ESTRATÉGIA (2 fases):
 * Fase 1 — busca leve: apenas id + lastModifiedDateTime, sem $expand (suportado com $orderby)
 * Fase 2 — busca fields: só dos itens modificados (máx ~10 por ciclo de 3s)
 * Isso contorna a limitação do Graph API: $filter/$orderby + $expand não funcionam juntos.
 */
async function fetchSharePointDelta(since) {
  const c = readCfg();

  const token = await syncSharePointTokenFromAuth();
  if (!token) {
    handleSpAuthError('Token indisponível no polling SP');
    return {};
  }

  const ids = await resolveSP().catch(() => null);
  if (!ids) return {};

  const fId     = c['sp-f-id']     || 'IDPedidoGPA';
  const fStatus = c['sp-f-status'] || 'StatusTratativa';
  const fText   = c['sp-f-text']   || 'Tratativa';

  const sinceMs = since ? new Date(since).getTime() : 0;

  // ── Fase 1: buscar os 50 mais recentes (só metadados, sem fields) ───────
  const urlPhase1 = `https://graph.microsoft.com/v1.0/sites/${ids.siteId}/lists/${ids.listId}/items` +
                    `?$select=id,lastModifiedDateTime&$orderby=lastModifiedDateTime desc&$top=50`;

  const res1 = await fetch(urlPhase1, {
    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
  });
  if (!res1.ok) {
    if (res1.status === 401) { handleSpAuthError('Token expirado no polling SP (401)'); return {}; }
    throw new Error(`SP delta fase1 ${res1.status}: ${res1.statusText}`);
  }
  // Calibrar clock com o header Date: da resposta
  calibrateServerClock(res1);
  const data1 = await res1.json();

  // Filtrar no cliente: só itens modificados após since
  const changedItems = (data1.value || []).filter(item => {
    const itemMs = item.lastModifiedDateTime ? new Date(item.lastModifiedDateTime).getTime() : 0;
    return itemMs > sinceMs;
  });

  if (!changedItems.length) return {};

  // ── Fase 2: buscar fields + lastModifiedBy dos itens modificados ────────
  const map = {};
  await Promise.all(changedItems.map(async (item) => {
    try {
      // $expand=fields — lastModifiedBy vem por padrão no item (sem necessidade de expand)
      const urlFields = `https://graph.microsoft.com/v1.0/sites/${ids.siteId}/lists/${ids.listId}/items/${item.id}?$expand=fields`;
      const resF = await fetch(urlFields, {
        headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
      });
      if (!resF.ok) return;
      const d = await resF.json();
      const f = d.fields || {};
      const editorSP = d.lastModifiedBy?.user || {};
      const id = String(f[fId] || '');
      if (id) {
        const status = f[fStatus] || 'Pendente';
        const isResolved = status === 'Resolvido' || status === 'Sem ação necessária';
        map[id] = {
          status,
          texto:    f[fText] || '',
          spItemId: item.id,
          modified: item.lastModifiedDateTime || null,
          resolvedAt: isResolved && item.lastModifiedDateTime
            ? item.lastModifiedDateTime.slice(0, 10)
            : undefined,
          editor: editorSP.displayName || editorSP.email
            ? { nome: editorSP.displayName || '', email: editorSP.email || '', at: item.lastModifiedDateTime || '' }
            : undefined,
        };
      }
    } catch (_) {}
  }));

  return map;
}

/**
 * Atualiza cirurgicamente o DOM de uma linha sem re-renderizar a tabela inteira.
 * Só altera os campos que mudaram — preserva cursor/foco nos inputs.
 */
function patchRowDOM(id, statusChanged, textoChanged, isOtherUser) {
  const tbody = document.getElementById('tbody');
  if (!tbody) return;
  const tr = tbody.querySelector(`tr[data-oid="${CSS.escape(id)}"]`);
  if (!tr) return;

  const t = tratativas[id];

  // Atualiza o select de status (sem disparar evento)
  if (statusChanged) {
    const sel = tr.querySelector('[data-role="status"]');
    if (sel && sel !== document.activeElement) {
      sel.value = t.status;
      sel.className = `status-sel ${statusSelCls(t.status)}`;
    }
  }

  // Atualiza o textarea/input de anotação (sem disparar evento e sem tirar foco)
  if (textoChanged) {
    const inp = tr.querySelector('[data-role="nota"]');
    if (inp && inp !== document.activeElement) {
      inp.value = t.texto;
    }
  }

  // Flash verde animado para mudanças de outros usuários
  if (isOtherUser) {
    tr.classList.remove('row-sp-updated');
    void tr.offsetWidth; // reflow — reinicia animação CSS
    tr.classList.add('row-sp-updated');
    setTimeout(() => tr.classList.remove('row-sp-updated'), 2700);

    // Atualizar avatar/editor na última coluna
    const saveEl = tr.querySelector(`#si-${CSS.escape(id)}`);
    const editorCell = saveEl?.closest('td');
    if (editorCell) editorCell.innerHTML = editorBadge(id);
  }
}

async function refreshSP() {
  const c = readCfg();
  if (!c['sp-site']) return;

  try {
    const since  = spLastCheck;
    const spMap  = await fetchSharePointDelta(since);

    spErrorCount = 0;

    // Avança spLastCheck para o timestamp do servidor (já calibrado em fetchSharePointDelta).
    // Usa serverNow() para garantir consistência entre máquinas com relógios diferentes.
    // Subtrai 1s de margem para não perder itens gravados exatamente no limite.
    spLastCheck = new Date(serverNow() - 1000).toISOString();

    if (!Object.keys(spMap).length) return;

    let statsChanged = false;

    Object.entries(spMap).forEach(([id, t]) => {
      // Ignorar pedidos que o usuário está editando agora (debounce ativo)
      if (spEditingIds.has(id)) return;

      const cur = tratativas[id];
      if (!cur) return;

      // Sempre atualizar spItemId (necessário para saves futuros)
      if (t.spItemId && !cur.spItemId) cur.spItemId = t.spItemId;
      // Atualizar editor — EXCETO se foi uma auto-ação do sistema que fez o último PATCH:
      // nesse caso o SP registra o usuário logado como lastModifiedBy mesmo que outro
      // tenha sido o último a atuar manualmente. O flag _autoActionAt protege o editor.
      const autoActionRecente = cur._autoActionAt && (Date.now() - cur._autoActionAt < 90_000);
      if (t.editor && !autoActionRecente) cur.editor = t.editor;

      const statusChanged = t.status !== undefined && t.status !== cur.status;
      const textoChanged  = t.texto  !== undefined && t.texto  !== cur.texto;
      if (!statusChanged && !textoChanged) return;

      // Atualiza estado local
      if (statusChanged) { cur.status = t.status; statsChanged = true; }
      if (textoChanged)   cur.texto  = t.texto;

      // Patch cirúrgico no DOM — sem renderTable()
      // isOtherUser = true para qualquer linha que não seja a focada pelo usuário atual
      patchRowDOM(id, statusChanged, textoChanged, id !== focusedId);
    });

    // Só recalcula os contadores/stats se algum status mudou
    if (statsChanged) updateStats();

    // ── Atualização do painel Histórico (se estiver visível) ──────────────
    // Estratégia leve: só atualiza itens que já existem no cache; novos
    // itens aguardam o próximo carregarHistoricoView manual (botão Atualizar).
    const histView = document.getElementById('view-historico');
    if (histView && histView.style.display !== 'none' && _historicoItemsCache.length) {
      let histChanged = false;
      const fStatus = readCfg()['sp-f-status'] || 'StatusTratativa';
      const fText   = readCfg()['sp-f-text']   || 'Tratativa';
      Object.entries(spMap).forEach(([id, t]) => {
        const idx = _historicoItemsCache.findIndex(i => i.jobId === id);
        if (idx < 0) return; // item novo — só aparece no próximo refresh manual
        const h = _historicoItemsCache[idx];
        if (t.status !== undefined && t.status !== h.status) { h.status = t.status; histChanged = true; }
        if (t.texto  !== undefined && t.texto  !== h.texto)  { h.texto  = t.texto;  histChanged = true; }
        if (t.editor) {
          if (t.editor.nome  && t.editor.nome  !== h.editorNome)  { h.editorNome  = t.editor.nome;  histChanged = true; }
          if (t.editor.email && t.editor.email !== h.editorEmail) { h.editorEmail = t.editor.email; histChanged = true; }
        }
        if (t.modified && t.modified !== h.modifiedAt) { h.modifiedAt = t.modified; histChanged = true; }
      });
      if (histChanged) {
        _atualizarMetricasHistorico(_historicoItemsCache);
        aplicarFiltrosHistorico();
      }
    }

  } catch (e) {
    spErrorCount++;
    LOG.warn(`SP poll falhou (${spErrorCount}):`, e.message);
    if (spErrorCount >= 5) {
      LOG.warn('SP polling suspenso 30s por erros consecutivos.');
      stopSpPolling();
      setTimeout(() => { spErrorCount = 0; startSpPolling(); }, 30000);
    }
  }
}

function startSpPolling() {
  stopSpPolling();
  // Inicializa o timestamp de referência com agora (não re-aplica o que já carregamos)
  if (!spLastCheck) spLastCheck = new Date().toISOString();

  // ── Alinhamento ao relógio do servidor (ciclo de 3s) ─────────────────────
  // serverNow() usa o offset calibrado com o header Date: do Graph API,
  // garantindo que todas as máquinas disparem no mesmo instante UTC.
  const CYCLE_MS  = 3000;
  const msToNext  = CYCLE_MS - (serverNow() % CYCLE_MS);

  let spSyncTimeout = setTimeout(() => {
    spSyncTimeout = null;
    refreshSP();
    spPollTimer = setInterval(refreshSP, CYCLE_MS);
  }, msToNext);

  // Guardar referência para cancelamento em stopSpPolling
  startSpPolling._syncTimeout = spSyncTimeout;

  LOG.info(`SP polling alinhado ao servidor (3s) — próximo batimento em ~${Math.round(msToNext)}ms | offset=${_serverOffset}ms`);
}function stopSpPolling() {
  if (spPollTimer) { clearInterval(spPollTimer); spPollTimer = null; }
  if (startSpPolling._syncTimeout) { clearTimeout(startSpPolling._syncTimeout); startSpPolling._syncTimeout = null; }
}

/**
 * Tick visual do countdown — chamado a cada 1s pelo pollingTimer.
 * Lê quanto tempo real falta para o próximo batimento global (múltiplo de 60s no epoch do servidor).
 */
function _pollingTick() {
  // Usa serverNow() para que o countdown seja baseado no relógio do servidor, não da máquina local
  const secsInCycle = Math.floor(serverNow() / 1000) % 60;
  countdown = secsInCycle === 0 ? 60 : 60 - secsInCycle;

  const txtEl  = document.getElementById('cdown-txt');
  const fillEl = document.getElementById('cdown-fill');
  if (txtEl)  txtEl.textContent   = `Picking em ${countdown}s`;
  if (fillEl) fillEl.style.width  = (countdown / 60 * 100) + '%';
}

function startPolling() {
  stopPolling();

  // ── Alinhamento com o relógio do servidor ───────────────────────────────
  // serverNow() corrige o offset entre relógio local e servidor (header Date: do Graph API).
  // Todas as máquinas disparam no mesmo segundo "xx:00" do minuto UTC do servidor.
  const CYCLE_MS  = 60 * 1000;
  const nowMs     = serverNow();
  const msInCycle = nowMs % CYCLE_MS;
  const msToNext  = msInCycle === 0 ? CYCLE_MS : CYCLE_MS - msInCycle;

  countdown = Math.round(msToNext / 1000);
  LOG.info(`Polling alinhado ao relógio: próximo batimento em ~${countdown}s`);

  // Tick visual imediato (atualiza o texto antes do 1º setInterval)
  _pollingTick();

  // Tick visual a cada segundo
  pollingTimer = setInterval(_pollingTick, 1000);

  // Primeiro disparo alinhado ao batimento global
  let syncTimeout = setTimeout(() => {
    syncTimeout = null;
    refreshPicking();
    // A partir daqui: ciclos exatos de 60s
    pollingTimer60 = setInterval(refreshPicking, CYCLE_MS);
  }, msToNext);

  // Guardar referências para stopPolling()
  startPolling._syncTimeout  = syncTimeout;

  startSpPolling();

  const pulse = document.getElementById('pulse-dot');
  if (pulse) pulse.className = 'pulse-dot live';
  LOG.info('Polling iniciado (60s, sincronizado com relógio global)');
}

// Timer separado para o ciclo de 60s (após alinhamento)
let pollingTimer60 = null;

function stopPolling() {
  if (pollingTimer) {
    clearInterval(pollingTimer);
    pollingTimer = null;
  }
  if (pollingTimer60) {
    clearInterval(pollingTimer60);
    pollingTimer60 = null;
  }
  if (startPolling._syncTimeout) {
    clearTimeout(startPolling._syncTimeout);
    startPolling._syncTimeout = null;
  }
  stopSpPolling();
}

function resetCountdown() {
  countdown = 60;
  const txt = document.getElementById('cdown-txt');
  const fill = document.getElementById('cdown-fill');
  if (txt) txt.textContent = 'Picking em 60s';
  if (fill) fill.style.width = '100%';
}

// ════════════════════════════════════════════════
// DEMO DATA
// ════════════════════════════════════════════════
function loadDemo() {
  const now = Date.now();
  const ts = m => new Date(now + m * 60000).toISOString();

  orders = [
    { jobId: '21360515', loja: 'GPA Tijuca', status: 'STORED', slot: '08:00 – 10:00', slotFrom: ts(-120), slotTo: ts(-62), pickingStatus: 'Pronto' },
    { jobId: '21360623', loja: 'GPA Barra', status: 'STORED', slot: '09:00 – 11:00', slotFrom: ts(-90), slotTo: ts(-22), pickingStatus: 'Separando' },
    { jobId: '21360718', loja: 'GPA Centro', status: 'GOING_TO_ORIGIN', slot: '10:00 – 12:00', slotFrom: ts(-45), slotTo: ts(-8), pickingStatus: 'Pronto' },
    { jobId: '21360841', loja: 'GPA Tijuca', status: 'STORED', slot: '11:00 – 13:00', slotFrom: ts(-20), slotTo: ts(18), pickingStatus: 'Separando' },
    { jobId: '21360902', loja: 'GPA Barra', status: 'STORED', slot: '12:00 – 14:00', slotFrom: ts(-5), slotTo: ts(42), pickingStatus: 'Aguardando' },
    { jobId: '21361011', loja: 'GPA Norte', status: 'TRANSFERRING', slot: '13:00 – 15:00', slotFrom: ts(10), slotTo: ts(80), pickingStatus: 'Aguardando' },
    { jobId: '21361145', loja: 'GPA Tijuca', status: 'STORED', slot: '07:00 – 09:00', slotFrom: ts(-300), slotTo: ts(-180), pickingStatus: 'Coletado' },
    { jobId: '21361288', loja: 'GPA Ipanema', status: 'GOING_TO_ORIGIN', slot: '08:00 – 10:00', slotFrom: ts(-200), slotTo: ts(-95), pickingStatus: '' },
  ];

  tratativas = {
    '21360515': { status: 'Em andamento', texto: 'Motoboy sem bateria, solicitado novo.', spItemId: 'demo-1' },
    '21361145': { status: 'Resolvido', texto: 'Reentregue às 14h30.', spItemId: 'demo-2' },
    '21361288': { status: 'Sem ação necessária', texto: 'Cancelado a pedido do cliente.', spItemId: 'demo-3' },
  };

  isDemo = true;
  setMode('demo');

  const guide = document.getElementById('setup-guide');
  if (guide) guide.style.display = 'none';

  renderTable();
  updateStats();
  setLastUpdate('full');
  resetCountdown();
  startPolling();

  showToast('Dados demo carregados — 8 pedidos.', 'info');
  LOG.info('Demo carregado:', orders.length, 'pedidos');
}

// ════════════════════════════════════════════════
// TOAST
// ════════════════════════════════════════════════
let toastId = 0;
function showToast(msg, type = 'info') {
  const wrap = document.getElementById('toast-wrap');
  if (!wrap) return;

  const id = ++toastId;
  const div = document.createElement('div');
  div.className = `toast ${type}`;
  div.id = `toast-${id}`;
  div.innerHTML = `
    <span>${escapeHtml(msg)}</span>
    <button class="toast-close" data-toast-id="${id}">×</button>
  `;
  wrap.appendChild(div);

  div.querySelector('.toast-close')?.addEventListener('click', () => dismissToast(id));
  requestAnimationFrame(() => div.classList.add('show'));

  setTimeout(() => dismissToast(id), 4000);
}

function dismissToast(id) {
  const el = document.getElementById(`toast-${id}`);
  if (!el) return;
  el.classList.remove('show');
  setTimeout(() => el.remove(), 300);
}

// ════════════════════════════════════════════════
// BINDERS
// ════════════════════════════════════════════════
function bindStaticEvents() {
  document.getElementById('log-btn')?.addEventListener('click', toggleLog);
  document.getElementById('config-btn')?.addEventListener('click', toggleConfig);
  document.getElementById('refresh-btn')?.addEventListener('click', refreshAll);

  document.getElementById('save-config-btn')?.addEventListener('click', saveConfig);
  document.getElementById('test-sp-btn')?.addEventListener('click', testSP);
  document.getElementById('load-demo-btn')?.addEventListener('click', loadDemo);

  document.getElementById('empty-config-btn')?.addEventListener('click', toggleConfig);
  document.getElementById('empty-demo-btn')?.addEventListener('click', loadDemo);

  document.getElementById('search-input')?.addEventListener('input', renderTable);
  document.getElementById('filter-date-from')?.addEventListener('change', renderTable);
  document.getElementById('filter-date-to')?.addEventListener('change', renderTable);
  document.getElementById('log-header')?.addEventListener('click', toggleLog);

  document.getElementById('clear-logs-btn')?.addEventListener('click', (event) => {
    event.stopPropagation();
    clearLogs();
  });

  // ── Sidebar ──────────────────────────────────────────────────────────────
  bindSidebarEvents();

  document.getElementById('login-btn')?.addEventListener('click', nexosLogin);
  document.getElementById('sidebar-login-btn')?.addEventListener('click', nexosLogin);
  document.getElementById('sidebar-logout-btn')?.addEventListener('click', nexosLogout);

  // ── Botão do overlay de login bloqueante ──
  document.getElementById('wall-login-btn')?.addEventListener('click', async () => {
    const btn = document.getElementById('wall-login-btn');
    const statusEl = document.getElementById('wall-login-status');
    const errorEl = document.getElementById('wall-login-error');

    if (btn) { btn.disabled = true; btn.textContent = '⏳ Autenticando...'; }
    if (statusEl) statusEl.textContent = 'Abrindo janela de login Microsoft...';
    if (errorEl) errorEl.style.display = 'none';

    try {
      // No contexto da extensão, usar chrome.runtime.sendMessage diretamente
      // para acionar o launchWebAuthFlow do background (popup real do OS)
      // sem passar pelo showLoginOverlay (que fica atrás do wall)
      const hasChrome = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage;

      if (hasChrome) {
        const result = await new Promise((resolve, reject) => {
          const timeout = setTimeout(() => reject(new Error('TIMEOUT')), 120000);
          chrome.runtime.sendMessage({ type: 'MS_AUTH_REQUEST' }, (response) => {
            clearTimeout(timeout);
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
              return;
            }
            if (!response) {
              reject(new Error('Login cancelado pelo usuário.'));
              return;
            }
            if (response.success) {
              resolve(response);
            } else {
              reject(new Error(response.error || 'Falha na autenticação'));
            }
          });
        });

        if (result.user) {
          // Salvar sessão via NexosAuth para disparar callbacks e preencher tokens
          const auth = getNexosAuthObject();
          if (auth && auth.authManager && typeof auth.authManager.saveSession === 'function') {
            await auth.authManager.saveSession(result.user);
          }
          const token = await syncSharePointTokenFromAuth();
          // saveSession() acima já disparou triggerCallbacks('onLogin') → onLoginSuccessFromNexos.
          // Só chamar diretamente se o guard ainda não foi acionado (evita chamada duplicada).
          if (!window._loginSuccessHandled) {
            await onLoginSuccessFromNexos(result.user, token || result.token);
          }
          // Não fechar a wall aqui — onLoginSuccessFromNexos gerencia a transição
          // (fecha se Instaleap já pronto, ou avança para Etapa 2)
          if (statusEl) statusEl.textContent = `✅ Conta Microsoft conectada...`;
        } else {
          throw new Error('Login não retornou usuário.');
        }
      } else {
        // Fallback para contexto standalone (MSAL popup)
        const user = await nexosLogin();
        if (user) {
          if (statusEl) statusEl.textContent = `✅ Conta Microsoft conectada...`;
          // onLoginSuccessFromNexos já foi chamado pelo nexosLogin — não fechar wall manualmente
        } else {
          throw new Error('Login cancelado ou não concluído. Tente novamente.');
        }
      }
    } catch (err) {
      if (errorEl) {
        errorEl.textContent = '❌ ' + (err.message || 'Erro ao autenticar. Tente novamente.');
        errorEl.style.display = 'block';
      }
      if (statusEl) statusEl.textContent = '';
      if (btn) { btn.disabled = false; btn.innerHTML = '<span>🔑</span> Entrar com Conta Corporativa (Microsoft)'; }
    }
  });

  // ── Botão "Reconectar Instaleap" no overlay de bloqueio ──
  document.getElementById('il-lock-reconect-btn')?.addEventListener('click', () => {
    const btn = document.getElementById('il-lock-reconect-btn');
    const statusEl = document.getElementById('il-lock-status');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Abrindo login Instaleap...'; }
    if (statusEl) statusEl.textContent = 'Aguardando login...';
    instaleapLoginAuto();
  });

  // ── Botão "Reconectar Picking Admin" no overlay de bloqueio ──
  document.getElementById('pk-lock-reconect-btn')?.addEventListener('click', () => {
    const btn = document.getElementById('pk-lock-reconect-btn');
    const statusEl = document.getElementById('pk-lock-status');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Abrindo Picking Admin...'; }
    if (statusEl) statusEl.textContent = 'Aguardando login...';
    pickingAdminLoginAuto();
  });

  // ── Botão "Tentar novamente" na Etapa 2 do login wall ──
  document.getElementById('wall-step2-retry-btn')?.addEventListener('click', () => {
    setLoginWallStep2Status('Abrindo janela de login Instaleap...', false);
    instaleapLoginAuto();
  });

  // ── Botão "Tentar novamente" na Etapa 3 do login wall (Picking Admin) ──
  document.getElementById('wall-step3-retry-btn')?.addEventListener('click', () => {
    setLoginWallStep3Status('Abrindo janela de login Picking Admin...', false);
    pickingAdminLoginAuto();
  });

  // ── Abas do Monitor ────────────────────────────────────────────────────
  document.querySelectorAll('.monitor-tab').forEach(btn => {
    btn.addEventListener('click', () => setTab(btn.dataset.tab));
  });

  // Subfiltros da aba Em andamento
  document.querySelectorAll('[data-sub-andamento]').forEach(btn => {
    btn.addEventListener('click', () => {
      andamentoSubFilter = btn.dataset.subAndamento;
      document.querySelectorAll('[data-sub-andamento]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderTable();
    });
  });

  // ── Filter chips (Ocorrências e Status IL — não mais tratativa) ─────────
  document.querySelectorAll('.filter-chip[data-filter]').forEach(btn => {
    btn.addEventListener('click', () => {
      // Ao usar filtro de ocorrências, sair do modo de aba (voltar a "todos")
      if (tabMode !== 'todos') {
        tabMode = 'todos';
        andamentoSubFilter = 'todos';
        document.getElementById('andamento-subfilters').style.display = 'none';
        document.querySelectorAll('.monitor-tab').forEach(b => b.classList.remove('active'));
        document.getElementById('mtab-todos')?.classList.add('active');
      }
      setFilter(btn.dataset.filter, btn);
    });
  });

  // Dropdown grupo Ocorrências (Cancelados / Entregues)
  const grpBtn      = document.getElementById('filter-grp-btn');
  const grpDropdown = document.getElementById('filter-grp-dropdown');
  if (grpBtn && grpDropdown) {
    grpBtn.addEventListener('click', e => {
      e.stopPropagation();
      grpDropdown.classList.toggle('open');
    });
    document.addEventListener('click', () => grpDropdown.classList.remove('open'));
    grpDropdown.querySelectorAll('.filter-chip-option').forEach(opt => {
      opt.addEventListener('click', e => {
        e.stopPropagation();
        grpDropdown.classList.remove('open');
        // Atualizar label do botão
        const labelEl = document.getElementById('filter-grp-label');
        if (labelEl) labelEl.textContent = opt.dataset.label + ' ▾';
        // Marcar opção selecionada
        grpDropdown.querySelectorAll('.filter-chip-option').forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
        setFilter(opt.dataset.filter, grpBtn);
      });
    });
  }

  // Dropdown grupo Status IL (STORED / GOING_TO_ORIGIN / ...)
  const ilBtn      = document.getElementById('filter-il-btn');
  const ilDropdown = document.getElementById('filter-il-dropdown');
  if (ilBtn && ilDropdown) {
    ilBtn.addEventListener('click', e => {
      e.stopPropagation();
      ilDropdown.classList.toggle('open');
    });
    document.addEventListener('click', () => ilDropdown.classList.remove('open'));
    ilDropdown.querySelectorAll('.filter-chip-option').forEach(opt => {
      opt.addEventListener('click', e => {
        e.stopPropagation();
        ilDropdown.classList.remove('open');
        const labelEl = document.getElementById('filter-il-label');
        if (labelEl) labelEl.textContent = opt.dataset.label + ' ▾';
        ilDropdown.querySelectorAll('.filter-chip-option').forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
        _ilStatusFilter = opt.dataset.ilStatus;
        setFilter('il-status', ilBtn);
      });
    });
  }

  document.querySelectorAll('th[data-sort]').forEach(th => {
    th.addEventListener('click', () => {
      sortBy(th.dataset.sort);
    });
  });
}

// ════════════════════════════════════════════════
// FOCO DE LINHA — destaque azul permanente
// ════════════════════════════════════════════════

/** Define o pedido em foco (destaque azul) e atualiza a UI sem re-renderizar a tabela inteira */
function applyFocus(oid) {
  if (focusedId === oid) return; // já focado

  const tbody = document.getElementById('tbody');
  if (!tbody) return;

  // Remove foco anterior
  if (focusedId) {
    const prev = tbody.querySelector(`tr[data-oid="${CSS.escape(focusedId)}"]`);
    if (prev) prev.classList.remove('row-focused');
  }

  focusedId = oid;

  if (oid) {
    const tr = tbody.querySelector(`tr[data-oid="${CSS.escape(oid)}"]`);
    if (tr) tr.classList.add('row-focused');
  }
}

function bindDynamicEvents() {
  const tbody = document.getElementById('tbody');
  if (!tbody) return;

  // Remove destaque "NOVO" ao primeira interação na linha (clique, select, input)
  const dismissNew = (oid) => {
    if (!oid || !newIds.has(oid)) return;
    newIds.delete(oid);
    const tr = tbody.querySelector(`tr[data-oid="${CSS.escape(oid)}"]`);
    if (tr) {
      tr.classList.remove('row-new');
      const tag = tr.querySelector('.badge-new-tag');
      if (tag) tag.remove();
    }
  };

  tbody.querySelectorAll('[data-role="status"]').forEach(select => {
    select.addEventListener('change', function() {
      dismissNew(this.dataset.oid);
      applyFocus(this.dataset.oid);
      onStatus(this.dataset.oid, this.value, this);
    });
  });

  tbody.querySelectorAll('[data-role="nota"]').forEach(input => {
    input.addEventListener('keydown', function(e) {
      // Enter sem Shift → salvar (blur) ao invés de pular linha
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.blur();
      }
    });
    input.addEventListener('focus', function() {
      applyFocus(this.dataset.oid);
      // Guardar texto anterior (já salvo) para comparar no blur
      const oid = this.dataset.oid;
      this.dataset.textoAnterior = (tratativas[oid] && tratativas[oid].texto) ? tratativas[oid].texto : '';
      // Expandir textarea
      this.style.height = 'auto';
      this.style.height = Math.min(this.scrollHeight, 120) + 'px';
      this.style.overflowY = this.scrollHeight > 120 ? 'auto' : 'hidden';
    });
    input.addEventListener('input', function() {
      dismissNew(this.dataset.oid);
      // Apenas ajustar altura — salvar somente no Enter/blur
      this.style.height = 'auto';
      this.style.height = Math.min(this.scrollHeight, 120) + 'px';
      this.style.overflowY = this.scrollHeight > 120 ? 'auto' : 'hidden';
    });
    input.addEventListener('blur', function() {
      const oid = this.dataset.oid;
      const anterior = this.dataset.textoAnterior || '';
      const novo = this.value;
      // Sem alteração → não faz nada
      if (novo.trim() === anterior.trim()) {
        this.style.height = '';
        this.style.overflowY = '';
        return;
      }
      // Se havia anotação anterior e o texto foi alterado → pedir confirmação
      if (anterior.trim() && novo.trim() !== anterior.trim()) {
        const confirmar = confirm(
          `⚠️ Atenção: já existe uma anotação registrada.\n\n` +
          `ATUAL:\n"${anterior}"\n\n` +
          `NOVO:\n"${novo}"\n\n` +
          `Deseja sobrescrever a anotação anterior?`
        );
        if (confirmar) {
          onAnotacao(oid, novo);
        } else {
          // Cancelou → reverter campo e tratativa para o valor anterior
          this.value = anterior;
          if (tratativas[oid]) tratativas[oid].texto = anterior;
          clearTimeout(saveTimers[oid]);
          spEditingIds.delete(oid);
        }
      } else if (!anterior.trim() && novo.trim()) {
        // Primeira anotação → salvar direto
        onAnotacao(oid, novo);
      }
      // Retornar ao tamanho compacto
      this.style.height = '';
      this.style.overflowY = '';
    });
  });

  // Clique em qualquer parte da linha: foca e dispensa destaque novo
  tbody.querySelectorAll('tr[data-oid]').forEach(tr => {
    tr.addEventListener('click', function() {
      applyFocus(this.dataset.oid);
      dismissNew(this.dataset.oid);
    });
  });

  tbody.querySelectorAll('[data-action="show-all"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const allBtn = document.querySelector('.filter-chip[data-filter="todos"]');
      setFilter('todos', allBtn);
    });
  });

  tbody.querySelectorAll('[data-action="open-config"]').forEach(btn => {
    btn.addEventListener('click', toggleConfig);
  });

  tbody.querySelectorAll('[data-action="load-demo"]').forEach(btn => {
    btn.addEventListener('click', loadDemo);
  });
}

// ════════════════════════════════════════════════════════════════════════════
// ⚠️  REGRAS CSP — Content Security Policy (NÃO VIOLAR)
// ════════════════════════════════════════════════════════════════════════════
//
//  Este projeto roda sob uma CSP restrita que BLOQUEIA qualquer execução de
//  código inline no HTML. As seguintes práticas são PROIBIDAS:
//
//  ❌ PROIBIDO — atributos inline de evento no HTML:
//      <button onclick="fn()">
//      <input oninput="fn()">
//      <select onchange="fn()">
//      <img onerror="this.style.display='none'">
//      <a href="javascript:fn()">
//
//  ✅ CORRETO — registrar sempre via JavaScript:
//      document.getElementById('btn').addEventListener('click', fn);
//      document.addEventListener('error', handler, true);  // para imgs
//
//  ❌ PROIBIDO — strings de código geradas dinamicamente em HTML:
//      element.innerHTML = '<div onclick="fn()">...'
//      → Isso também se aplica ao conteúdo gerado por renderTable(),
//        buildRow(), platformBadge(), editorBadge() etc.
//        Use data-* attributes e delegação de eventos.
//
//  ✅ CORRETO — delegação via data attributes:
//      element.innerHTML = '<button data-action="abrir" data-id="123">...'
//      document.addEventListener('click', e => {
//        if (e.target.dataset.action === 'abrir') fn(e.target.dataset.id);
//      });
//
//  Os listeners delegados para conteúdo dinâmico ficam em bindDynamicEvents().
//  Os listeners de elementos estáticos ficam em bindStaticEvents().
//
// ════════════════════════════════════════════════════════════════════════════

/**
 * Verifica o DOM em busca de atributos inline de evento que violem a CSP.
 * Roda apenas uma vez no carregamento e loga um aviso para cada violação.
 * Não afeta o comportamento — apenas ajuda no desenvolvimento.
 */
function _auditarCSP() {
  const ATTRS_INLINE = [
    'onclick','ondblclick','onmousedown','onmouseup','onmouseover','onmouseout',
    'onmousemove','onkeydown','onkeyup','onkeypress','onchange','oninput',
    'onfocus','onblur','onsubmit','onreset','onselect','onload','onerror',
    'onabort','onscroll','onresize','oncontextmenu','ondrag','ondrop',
  ];
  let count = 0;
  document.querySelectorAll('*').forEach(el => {
    ATTRS_INLINE.forEach(attr => {
      if (el.hasAttribute(attr)) {
        console.warn(
          `%c[CSP AUDIT]%c Handler inline encontrado: <${el.tagName.toLowerCase()} ${attr}="${el.getAttribute(attr).slice(0, 60)}..."> — mova para addEventListener()`,
          'color:#f59e0b;font-weight:bold', 'color:#fcd34d'
        );
        count++;
      }
    });
    // Verificar href="javascript:"
    if (el.tagName === 'A' && (el.getAttribute('href') || '').startsWith('javascript:')) {
      console.warn(
        `%c[CSP AUDIT]%c Link javascript: encontrado: <a href="${el.getAttribute('href').slice(0, 60)}"> — use addEventListener()`,
        'color:#f59e0b;font-weight:bold', 'color:#fcd34d'
      );
      count++;
    }
  });
  if (count === 0) {
    console.log('%c[CSP AUDIT]%c ✓ Nenhum handler inline encontrado no HTML estático.', 'color:#34d399;font-weight:bold', 'color:#6ee7b7');
  } else {
    console.warn(`%c[CSP AUDIT]%c ${count} violação(ões) de CSP encontrada(s) no HTML estático. Veja os avisos acima.`, 'color:#f59e0b;font-weight:bold', 'color:#fcd34d');
  }
}

// ════════════════════════════════════════════════
// INIT
// ════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
  LOG.info('Monitor iniciando... versão 3.0');

  // Auditoria CSP — detecta handlers inline no HTML antes de qualquer interação
  _auditarCSP();

  // Carregar tokens seguros do chrome.storage ANTES de tudo
  await loadSecureTokens();
  _watchInstaleapTokenRevocation();
  _watchPickingTokenRevocation();

  loadConfig();
  bindStaticEvents();
  setTab(tabMode); // aplica aba padrão/salva e chama renderTable()

  // ── Restaurar foto/nome do usuário imediatamente do cache (antes do auth async) ──
  const _cachedUser = _restoreUserCache();
  if (_cachedUser?.email) {
    _applySidebarUserUI(_cachedUser);
    LOG.info('AUTH: foto/nome restaurados do cache para', _cachedUser.email);
  }

  const pulse = document.getElementById('pulse-dot');
  if (pulse) pulse.className = 'pulse-dot';

  const authObj = await ensureNexosAuthAvailable(15000, 150);

  if (authObj) {
    LOG.ok('AUTH: NexosAuth carregado na página');

    authObj.on?.('onLogin', async (user) => {
      try {
        const token = await syncSharePointTokenFromAuth();
        await onLoginSuccessFromNexos(user, token);
        LOG.info('AUTH event: onLogin recebido');
      } catch (error) {
        LOG.warn('AUTH event onLogin falhou:', error.message);
      }
    });

    authObj.on?.('onLogout', () => {
      currentAuthUser = null;

      const userPill = document.getElementById('user-pill');
      const loginBtn = document.getElementById('login-btn');
      const loginBtn2 = document.getElementById('sidebar-login-btn');

      if (userPill) userPill.style.display = 'none';
      if (loginBtn) {
        loginBtn.style.display = '';
        loginBtn.disabled = false;
        loginBtn.textContent = '🔐 Entrar com Conta Corporativa';
      }

      // Preservar il-token e pk-token — Instaleap não deve ser afetado pelo logout do Nexos
      const ilToken = secureTokens['il-token'];
      const pkToken = secureTokens['pk-token'];

      // Limpar apenas o sp-token (Microsoft/Nexos)
      secureTokens['sp-token'] = '';
      saveSecureTokens();

      // Restaurar tokens do Instaleap/Picking
      secureTokens['il-token'] = ilToken;
      secureTokens['pk-token'] = pkToken;
      saveSecureTokens();

      refreshTokenBadges();

      // Resetar guards de login para permitir novo ciclo de autenticação
      window._loginSuccessHandled = false;
      window._ilLoginPending = false;

      spCache = { siteId: null, listId: null };
      _photoCache.clear();   // ← blob URLs invalidados com o token
      _nexosUserMap = null;  // ← força recarregamento no próximo login
      _clearUserCache();  // ← remove foto/nome persistidos
      showLoginWall('logout');
      LOG.info('AUTH event: onLogout recebido — sp-token limpo; il-token e pk-token preservados');
    });

    await tryRestoreNexosSession();

    // ── Detectar reconexão via popup (flag nexos-sp-token-expired removido) ──
    // Quando o usuário clica em "Reconectar" no popup e o login é concluído,
    // o popup remove nexos-sp-token-expired e salva um novo nexos-user-session.
    // O NexosAuth já tem this.user, então não dispara onLogin — monitoramos aqui.
    if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
      chrome.storage.onChanged.addListener(async (changes, area) => {
        if (area !== 'local') return;
        // Reagir apenas quando o flag de SP expirado é explicitamente removido
        // (sinal de que o login/reconexão foi concluído com sucesso no popup ou background)
        const flagCleared = 'nexos-sp-token-expired' in changes && !changes['nexos-sp-token-expired'].newValue;
        if (!flagCleared) return;
        if (!currentAuthUser) return; // sem sessão ativa, tryRestoreNexosSession cuida disso
        try {
          LOG.info('AUTH: reconexão detectada via storage — renovando token SP...');
          const token = await syncSharePointTokenFromAuth();
          if (!token) { LOG.warn('AUTH: token SP ausente após reconexão'); return; }
          spCache = { siteId: null, listId: null }; // forçar re-init do site SP
          showToast('✅ Token renovado! Retomando sincronização...', 'success');
          await refreshAll();
        } catch (e) {
          LOG.warn('AUTH: falha ao renovar após reconexão:', e.message);
        }
      });
    }
  } else {
    LOG.error('AUTH: NexosAuth não foi encontrado após aguardar carregamento');
    showToast('Autenticação corporativa não foi carregada nesta página.', 'error');
  }

  setInterval(() => {
    if (orders.length) renderTable();
  }, 30000);

  // ── Verificação periódica de sessão (a cada 2 min) ──────────────────────
  // Detecta token expirado mesmo sem interação do usuário com o SP.
  setInterval(async () => {
    if (!currentAuthUser) return;  // sem sessão ativa, ignorar
    try {
      const auth = getNexosAuthObject();
      if (!auth || typeof auth.isAuthenticated !== 'function') return;
      const isAuth = await auth.isAuthenticated();
      if (!isAuth) {
        LOG.warn('AUTH: verificação periódica — sessão expirada');
        handleSpAuthError('Sessão expirada detectada na verificação periódica');
      }
    } catch (e) {
      LOG.warn('AUTH: verificação periódica falhou:', e.message);
    }
  }, 2 * 60 * 1000); // a cada 2 minutos

  LOG.info('Pronto. Configure as APIs ou clique em "▷ Demo".');
});