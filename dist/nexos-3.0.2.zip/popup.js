document.addEventListener('DOMContentLoaded', async function() {
  // Get state elements
  const loadingState = document.getElementById('loading-state');
  const notAuthenticatedState = document.getElementById('not-authenticated-state');
  const authenticatedState = document.getElementById('authenticated-state');
  const errorState = document.getElementById('error-state');
  const errorMessage = document.getElementById('error-message');
  
  // Get UI elements
  const loginBtn = document.getElementById('login-btn');
  const logoutBtn = document.getElementById('logout-btn');
  const activateBtn = document.getElementById('activate');
  const retryBtn = document.getElementById('retry-btn');
  const userPhoto = document.getElementById('user-photo');
  const userInitials = document.getElementById('user-initials');
  const userName = document.getElementById('user-name');
  const userEmail = document.getElementById('user-email');
  const userRolePill = document.getElementById('user-role');
  const versionSpan = document.getElementById('version');
  
  // Set version from manifest
  const manifest = chrome.runtime.getManifest();
  if (versionSpan) versionSpan.textContent = manifest.version;
  
  // Show state
  function showState(state) {
    loadingState.style.display = 'none';
    notAuthenticatedState.style.display = 'none';
    authenticatedState.style.display = 'none';
    errorState.style.display = 'none';
    
    switch (state) {
      case 'loading':
        loadingState.style.display = 'block';
        break;
      case 'not-authenticated':
        notAuthenticatedState.style.display = 'block';
        break;
      case 'authenticated':
        authenticatedState.style.display = 'block';
        break;
      case 'error':
        errorState.style.display = 'block';
        break;
    }
  }
  
  // Check authentication status
  async function checkAuthStatus() {
    try {
      showState('loading');
      
      // Check if user is authenticated via storage
      // Dois fluxos de login: popup (nexos-tokens) e picking/content (nexos-user-session)
      const result = await chrome.storage.local.get(['nexos_current_user', 'nexos-tokens', 'nexos-user-session', 'nexos-sp-token-expired']);
      
      console.log('[Nexos Popup] Storage check:', {
        hasUser: !!result.nexos_current_user,
        hasTokens: !!result['nexos-tokens'],
        hasSession: !!result['nexos-user-session'],
        spExpired: !!result['nexos-sp-token-expired'],
        user: result.nexos_current_user ? result.nexos_current_user.displayName : 'none'
      });
      
      if (result.nexos_current_user && (result['nexos-tokens'] || result['nexos-user-session'])) {
        // User is authenticated
        const user = result.nexos_current_user;
        const spTokenExpired = !!result['nexos-sp-token-expired'];
        console.log('[Nexos Popup] User authenticated:', user.displayName || user.mail);
        
        // Update UI with user info
        if (user.displayName) {
          userName.textContent = user.displayName;
        }
        if (user.mail || user.userPrincipalName) {
          userEmail.textContent = user.mail || user.userPrincipalName;
        }
        
        // Show photo or initials
        if (user.photo || user.photoUrl) {
          userPhoto.src = user.photo || user.photoUrl;
          userPhoto.style.display = 'block';
          userInitials.style.display = 'none';
        } else {
          const initials = getInitials(user);
          userInitials.textContent = initials;
          userInitials.style.display = 'inline';
          userPhoto.style.display = 'none';
        }

        // Show role pill
        const roleName = user.roleName || user.role || null;
        if (userRolePill && roleName) {
          userRolePill.textContent = roleName;
          userRolePill.style.display = 'inline-block';
        } else if (userRolePill) {
          userRolePill.style.display = 'none';
        }

        // Ajustar botão Ativar Overlay conforme estado do token SP
        if (activateBtn) {
          if (spTokenExpired) {
            activateBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg> Reconectar`;
            activateBtn.style.background = 'linear-gradient(135deg,#B45309,#92400E)';
            activateBtn.title = 'Sessão SharePoint expirada. Clique para renovar o acesso.';
          } else {
            activateBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg> Ativar Overlay`;
            activateBtn.style.background = '';
            activateBtn.title = '';
          }
        }
        
        showState('authenticated');
      } else {
        // User is not authenticated
        showState('not-authenticated');
      }
    } catch (error) {
      console.error('[Nexos Popup] Error checking auth status:', error);
      errorMessage.textContent = 'Erro ao verificar autenticação';
      showState('error');
    }
  }
  
  // Get user initials
  function getInitials(user) {
    if (!user) return '??';
    
    const name = user.displayName || user.givenName || user.surname || user.userPrincipalName || '';
    const parts = name.trim().split(' ').filter(p => p.length > 0);
    
    if (parts.length === 0) return '??';
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    
    return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
  }
  
  // Login button click
  loginBtn.addEventListener('click', async function() {
    try {
      console.log('[Nexos Popup] Login button clicked');

      // Feedback visual — spinner
      loginBtn.disabled = true;
      loginBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="animation:nx-spin .7s linear infinite"><circle cx="12" cy="12" r="10" stroke-opacity=".3"/><path d="M12 2a10 10 0 0 1 10 10" stroke-linecap="round"/></svg> Aguardando login…';

      chrome.runtime.sendMessage({ action: 'startLogin' }, function(response) {
        if (chrome.runtime.lastError) {
          console.error('[Nexos Popup] Erro:', chrome.runtime.lastError);
          loginBtn.disabled = false;
          loginBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 21 21" xmlns="http://www.w3.org/2000/svg"><rect x="1" y="1" width="9" height="9" fill="#F25022"/><rect x="11" y="1" width="9" height="9" fill="#7FBA00"/><rect x="1" y="11" width="9" height="9" fill="#00A4EF"/><rect x="11" y="11" width="9" height="9" fill="#FFB900"/></svg> Entrar com Microsoft';
          return;
        }

        if (response && response.success) {
          // Login concluído — limpar flag de SP expirado
          chrome.storage.local.remove(['nexos-sp-token-expired']);
          // checkAuthStatus vai detectar pelo storage.onChanged
          // mas forçamos a atualização imediata aqui também
          checkAuthStatus();
        } else {
          console.warn('[Nexos Popup] Login falhou:', response && response.error);
          loginBtn.disabled = false;
          loginBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 21 21" xmlns="http://www.w3.org/2000/svg"><rect x="1" y="1" width="9" height="9" fill="#F25022"/><rect x="11" y="1" width="9" height="9" fill="#7FBA00"/><rect x="1" y="11" width="9" height="9" fill="#00A4EF"/><rect x="11" y="11" width="9" height="9" fill="#FFB900"/></svg> Entrar com Microsoft';
        }
      });
    } catch (error) {
      console.error('[Nexos Popup] Error starting login:', error);
      errorMessage.textContent = 'Erro ao iniciar login';
      showState('error');
    }
  });
  
  // Logout button click
  logoutBtn.addEventListener('click', async function() {
    try {
      console.log('[Nexos Popup] Logout button clicked');
      
      // Send message to background script to logout
      chrome.runtime.sendMessage({ action: 'logout' }, function(response) {
        if (chrome.runtime.lastError) {
          console.error('[Nexos Popup] Error sending logout message:', chrome.runtime.lastError);
          return;
        }
        
        console.log('[Nexos Popup] Logout completed:', response);
        
        // Refresh popup state
        checkAuthStatus();
      });
    } catch (error) {
      console.error('[Nexos Popup] Error during logout:', error);
      errorMessage.textContent = 'Erro ao fazer logout';
      showState('error');
    }
  });
  
  // Activate overlay button click
  activateBtn.addEventListener('click', async function() {
    // Se token SP expirado, acionar re-login em vez de abrir overlay
    const res = await chrome.storage.local.get(['nexos-sp-token-expired']);
    if (res['nexos-sp-token-expired']) {
      loginBtn.click();
      return;
    }
    // Envia mensagem para o content script da aba ativa
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      // Incluir allowExternal para informar ao content script que a ativação veio do popup da extensão
      chrome.tabs.sendMessage(tabs[0].id, {action: 'activateOverlay', allowExternal: true});
    });

    // Fecha o popup após clicar
    window.close();
  });
  
  // Retry button click
  retryBtn.addEventListener('click', function() {
    checkAuthStatus();
  });
  
  // Listen for auth events
  chrome.storage.onChanged.addListener(function(changes, namespace) {
    if (namespace === 'local') {
      // Verificar mudanças em qualquer chave de sessão (popup ou picking)
      if (changes.nexos_current_user || changes['nexos-tokens'] || changes['nexos-user-session'] || changes['nexos-sp-token-expired']) {
        console.log('[Nexos Popup] Auth state changed, refreshing UI');
        checkAuthStatus();
      }
    }
  });
  
  // Initial check
  checkAuthStatus();
});
