/**
 * inject-instaleap-order-filter.js
 * Injeta badges de "Tipo de Pedido" nos pedidos do modal "Pedidos por slot"
 * em control.instaleap.io/metrics/order-status
 *
 * Estratégia:
 *  1. Interceptar /hela/api/v2/jobs → capturar headers da requisição + IDs da resposta
 *  2. Reutilizar esses mesmos headers para chamar /nebula/jobs/{id} (resolve o 422)
 *  3. Observar o DOM do modal e injetar badges coloridos por tipo
 *  4. Filtro visual por pill de tipo
 *
 * world: MAIN
 */
(function () {
  'use strict';

  if (window.__nexosSlotFilterLoaded) return;
  window.__nexosSlotFilterLoaded = true;

  // ── Estado ──────────────────────────────────────────────────────────────
  /** @type {Map<string, string>} jobId/orderNumber → tipoPedido */
  const orderTipoPedido = new Map();
  /** Tipos selecionados no filtro (vazio = mostrar todos) */
  const selectedTipos = new Set();

  // ── Paleta de cores ─────────────────────────────────────────────────────
  const TIPO_COLORS = {
    'Bora':        { bg: '#e6f7ff', border: '#91d5ff', text: '#096dd9' },
    'Rota Fixa':   { bg: '#f6ffed', border: '#b7eb8f', text: '#389e0d' },
    'Agendado':    { bg: '#fff7e6', border: '#ffd591', text: '#d46b08' },
    'Expresso':    { bg: '#fff0f6', border: '#ffadd2', text: '#c41d7f' },
    'Programado':  { bg: '#f9f0ff', border: '#d3adf7', text: '#531dab' },
  };
  const FALLBACK_PALETTE = [
    { bg: '#fafafa', border: '#d9d9d9', text: '#595959' },
    { bg: '#e8f5e9', border: '#a5d6a7', text: '#2e7d32' },
    { bg: '#fce4ec', border: '#f48fb1', text: '#880e4f' },
    { bg: '#e3f2fd', border: '#90caf9', text: '#0d47a1' },
    { bg: '#fff8e1', border: '#ffe082', text: '#e65100' },
  ];
  let _paletteIdx = 0;
  function colorForTipo(tipo) {
    if (!TIPO_COLORS[tipo]) {
      TIPO_COLORS[tipo] = FALLBACK_PALETTE[_paletteIdx++ % FALLBACK_PALETTE.length];
    }
    return TIPO_COLORS[tipo];
  }

  // ── Interceptor de fetch ─────────────────────────────────────────────────
  const _nativeFetch = window.fetch.bind(window);

  function _processJobsPayload(data) {
    try {
      if (!data || typeof data !== 'object') return;

      // Tentar todas as variações de estrutura possíveis
      const items =
        Array.isArray(data?.data)       ? data.data       :
        Array.isArray(data?.data?.data) ? data.data.data  :
        Array.isArray(data?.jobs)       ? data.jobs       :
        Array.isArray(data?.results)    ? data.results    :
        Array.isArray(data)             ? data            :
        Object.values(data ?? {}).find(v => Array.isArray(v) && v.length > 0) ?? [];

      // Só processar se tiver items com nebula_job (evita spam de APIs irrelevantes)
      const temTipo = items.some(it =>
        it?.nebula_job?.external_data?.backoffice?.['Tipo de Pedido'] ||
        it?.external_data?.backoffice?.['Tipo de Pedido']
      );
      if (items.length === 0 || !temTipo) return;

      console.log(`[NEXOS] ✅ payload com ${items.length} pedidos com Tipo de Pedido`);
      items.forEach(it => _extractFromItem(it));
      console.log(`[NEXOS] Map: ${orderTipoPedido.size} entradas`);
      _retryPendingFromCache();
      // Re-injetar em painéis já expandidos do modal
      document.querySelectorAll(
        '.ant-collapse-content-active tr[data-row-key]:not([data-nexos-badged]), ' +
        '.ant-collapse-content-box tr[data-row-key]:not([data-nexos-badged]), ' +
        '.ant-collapse-content-active .ant-list-item:not([data-nexos-badged]), ' +
        '.ant-collapse-content-box .ant-list-item:not([data-nexos-badged])'
      ).forEach(processRow);
      // Re-injetar na tabela da página /orders
      document.querySelectorAll('.home-table .ant-table-tbody tr[data-row-key]:not([data-nexos-badged])').forEach(processRow);
    } catch (e) {
      console.warn('[NEXOS] _processJobsPayload erro:', e.message);
    }
  }

  function _wrapFetch(originalFetch) {
    const wrapped = async function (...args) {
      const req = args[0];
      const url = String(typeof req === 'string' ? req : req?.url ?? '');

      // Ignorar chamadas que claramente não são APIs de dados (recursos estáticos, auth)
      const isStatic = /\.(js|css|png|jpg|svg|woff|ico)(\?|$)/i.test(url) ||
                       /googleapis\.com|google\.com|firestore|statsig|sentry|analytics|maps/i.test(url);

      const response = await originalFetch.apply(this, args);

      if (!isStatic) {
        if (typeof response?.clone === 'function') {
          response.clone().text().then(text => {
            try { _processJobsPayload(JSON.parse(text)); }
            catch (e) { /* não é JSON */ }
          }).catch(() => {});
        } else if (response && typeof response === 'object') {
          // Objeto já processado pelo token interceptor (plain object)
          try {
            const payload = response?.data ?? response;
            const parsed  = typeof payload === 'string' ? JSON.parse(payload) : payload;
            _processJobsPayload(parsed);
          } catch (e) { /* ignorar */ }
        }
      }

      return response;
    };
    wrapped._nexosWrapped = true;
    return wrapped;
  }

  function _ensureFetchIntercepted() {
    if (window.fetch && window.fetch._nexosWrapped) return;
    console.log('[NEXOS] Instalando interceptor de fetch...');
    const base = (window.fetch && !window.fetch._nexosWrapped) ? window.fetch : _nativeFetch;
    const wrapped = _wrapFetch(base);
    try { Object.defineProperty(window, 'fetch', { configurable: true, writable: true, value: wrapped }); }
    catch (_) { window.fetch = wrapped; }
  }

  _ensureFetchIntercepted();
  setTimeout(_ensureFetchIntercepted, 300);
  setTimeout(_ensureFetchIntercepted, 900);
  setTimeout(_ensureFetchIntercepted, 2500);

  // ── Interceptor de XHR — captura resposta de /jobs ──────────────────────
  const _origXHROpen      = XMLHttpRequest.prototype.open;
  const _origXHRSetHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._nexosUrl     = String(url);
    this._nexosHeaders = {};
    return _origXHROpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (this._nexosHeaders) this._nexosHeaders[name] = value;
    return _origXHRSetHeader.call(this, name, value);
  };
  const _origXHRSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (...args) {
    const url = this._nexosUrl ?? '';
    const isStatic = /\.(js|css|png|jpg|svg|woff|ico)(\?|$)/i.test(url) ||
                     /googleapis|google\.com|firestore|statsig|sentry|analytics|maps/i.test(url);
    if (!isStatic && url) {
      this.addEventListener('load', function () {
        try { _processJobsPayload(JSON.parse(this.responseText)); }
        catch (e) { /* não é JSON */ }
      });
    }
    return _origXHRSend.apply(this, args);
  };

  // ── Pendentes aguardando dado chegar via /hela/api/v2/jobs ──────────────
  const _pendingIds = new Set();

  function scheduleFetchTipos(ids) {
    ids.forEach(id => _pendingIds.add(id));
    // Nada mais a fazer aqui — o dado virá via interceptor do /hela/api/v2/jobs
    // _retryPendingFromCache() será chamado quando o payload chegar
  }

  /** Tenta resolver IDs pendentes usando o cache já preenchido */
  function _retryPendingFromCache() {
    for (const id of [..._pendingIds]) {
      const tipo = orderTipoPedido.get(id);
      if (tipo) {
        _pendingIds.delete(id);
        _refreshBadgeForId(id, tipo);
      }
    }
    // Re-varrer linhas que ainda têm placeholder "…" (timing: DOM apareceu antes da API)
    document.querySelectorAll('.nexos-tipo-pending').forEach(ph => {
      const id = ph.dataset.nexosForId;
      if (id) {
        const tipo = orderTipoPedido.get(id);
        if (tipo) ph.replaceWith(makeBadge(tipo));
      }
    });
    // Re-varrer linhas sem badge nenhum (caso o DOM tenha aparecido antes do interceptor)
    document.querySelectorAll('[data-nexos-badged]').forEach(row => {
      if (row.querySelector('.nexos-tipo-badge[data-nexos-tipo]')) return;
      const id = extractOrderId(row);
      if (!id) return;
      const tipo = orderTipoPedido.get(id);
      if (tipo) _attachBadge(row, id, tipo);
    });
    _updateFilterCounts();
    _applyFilter();
  }

  // ── Escanear payload em busca de tipo de pedido ─────────────────────────
  function scanPayload(data, hintId) {
    if (!data || typeof data !== 'object') return;
    _extractFromItem(data, hintId);
    for (const key of ['data', 'jobs', 'orders', 'items', 'results']) {
      if (Array.isArray(data[key])) data[key].forEach(it => _extractFromItem(it));
    }
    for (const key of ['job', 'nebula_job', 'order']) {
      if (data[key]) _extractFromItem(data[key], hintId);
    }
  }

  function _extractFromItem(item, hintId) {
    if (!item || typeof item !== 'object') return;

    // Caminho confirmado: data[n].nebula_job.external_data.backoffice["Tipo de Pedido"]
    const tipo =
      item?.nebula_job?.external_data?.backoffice?.['Tipo de Pedido']
      ?? item?.external_data?.backoffice?.['Tipo de Pedido']
      ?? item?.job?.external_data?.backoffice?.['Tipo de Pedido']
      ?? item?.metadata?.tipo_pedido
      ?? null;

    if (!tipo || typeof tipo !== 'string' || !tipo.trim()) return;
    const tipoClean = tipo.trim();

    // ID confirmado: data[n].id (UUID)
    // Mapear também todos os números 6+ dígitos para cobrir número do pedido no DOM
    const allIds = new Set();
    const raw = JSON.stringify(item);
    let m;
    const reNum  = /\b(\d{6,})\b/g;
    const reUuid = /\b([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\b/gi;
    while ((m = reNum.exec(raw))  !== null) allIds.add(m[1]);
    while ((m = reUuid.exec(raw)) !== null) allIds.add(m[1].toLowerCase());
    if (hintId) allIds.add(String(hintId));

    for (const id of allIds) {
      orderTipoPedido.set(id, tipoClean);
      _refreshBadgeForId(id, tipoClean);
    }

    const primary = item.id ?? [...allIds][0] ?? hintId ?? '';
    console.log(`[NEXOS] ${primary} → ${tipoClean}`);
  }

  // ── Badge ───────────────────────────────────────────────────────────────
  function makeBadge(tipo) {
    const c  = colorForTipo(tipo);
    const el = document.createElement('span');
    el.className          = 'nexos-tipo-badge';
    el.dataset.nexosTipo  = tipo;
    el.textContent        = tipo;
    el.style.cssText      = `
      display:inline-block;
      margin-left:6px;
      padding:1px 7px;
      border-radius:10px;
      font-size:11px;
      font-weight:600;
      line-height:18px;
      white-space:nowrap;
      background:${c.bg};
      border:1px solid ${c.border};
      color:${c.text};
      vertical-align:middle;
      cursor:default;
    `;
    return el;
  }

  // ── Extrair ID do pedido de um elemento ─────────────────────────────────
  const _UUID_RE    = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const _NUM_ID_RE  = /^\d{4,}$/;

  function extractOrderId(el) {
    // Prioridade 1: atributos de dados — aceita UUID e número
    for (const attr of ['data-job-id', 'data-order-id', 'data-id', 'data-row-key', 'data-jobid']) {
      const node = el.matches(`[${attr}]`) ? el : el.querySelector(`[${attr}]`);
      const v = node?.getAttribute(attr);
      if (v && (_UUID_RE.test(v) || _NUM_ID_RE.test(v))) return v;
    }
    // Prioridade 2: link com /jobs/{uuid-ou-id}
    const link = el.querySelector('a[href*="/jobs/"], a[href*="/orders/"]');
    if (link) {
      const m = link.href.match(/\/(jobs|orders)\/([\w-]+)/);
      if (m) return m[2];
    }
    // Prioridade 3: texto numérico longo isolado (≥ 6 dígitos)
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const t = node.textContent.trim();
      if (/^\d{6,}$/.test(t)) return t;
    }
    return null;
  }

  // ── Injetar badges nos pedidos de um painel aberto ──────────────────────
  function injectBadgesInPanel(panel) {
    // Tentar seletores específicos do Ant Design primeiro
    let rows = [...panel.querySelectorAll(
      '.ant-list-item:not([data-nexos-badged]), ' +
      '.ant-table-row:not([data-nexos-badged]), ' +
      'tr[data-row-key]:not([data-nexos-badged]), ' +
      '[data-job-id]:not([data-nexos-badged]), ' +
      '[data-order-id]:not([data-nexos-badged])'
    )];

    // Fallback: qualquer elemento com ID numérico de 6+ dígitos no texto
    if (rows.length === 0) {
      panel.querySelectorAll(
        'li:not([data-nexos-badged]), ' +
        'div[class*="item"]:not([data-nexos-badged]), ' +
        'div[class*="row"]:not([data-nexos-badged])'
      ).forEach(el => { if (extractOrderId(el)) rows.push(el); });
    }

    rows.forEach(processRow);
    // Atualizar chips e filtro após processar todas as linhas do painel
    _renderAllChips();
    _applyFilter();
  }

  function processRow(row) {
    if (row.dataset.nexosBadged) return;
    row.dataset.nexosBadged = '1';
    const id = extractOrderId(row);
    if (!id) return;

    console.log(`[NEXOS DOM] Linha detectada — id extraído: "${id}" | map tem: ${orderTipoPedido.has(id)} | map size: ${orderTipoPedido.size}`);

    const tipo = orderTipoPedido.get(id);
    if (tipo) {
      _attachBadge(row, id, tipo);
    } else {
      // Inserir placeholder "…"
      const anchor = _findBadgeAnchor(row);
      if (anchor && !anchor.querySelector('.nexos-tipo-pending')) {
        const ph = document.createElement('span');
        ph.className          = 'nexos-tipo-badge nexos-tipo-pending';
        ph.dataset.nexosForId = id;
        ph.textContent        = '…';
        ph.style.cssText      =
          'display:inline-block;margin-left:6px;padding:1px 7px;border-radius:10px;' +
          'font-size:11px;background:#fafafa;border:1px solid #d9d9d9;color:#aaa;vertical-align:middle;';
        anchor.appendChild(ph);
      }
      // Agendar fetch ativo com os headers da página (resolve o 422)
      scheduleFetchTipos([id]);
    }
  }

  function _findBadgeAnchor(row) {
    return (
      row.querySelector('.go-to-job-btn, td:first-child .ant-table-cell-content > div, td:first-child > div, td:first-child, .ant-list-item-meta-title, .order-id, [class*="order-id"], [class*="job-id"]')
      ?? row
    );
  }

  function _attachBadge(row, id, tipo) {
    // Substituir placeholder se existir
    const ph = row.querySelector(`.nexos-tipo-pending[data-nexos-for-id="${id}"]`);
    if (ph) { ph.replaceWith(makeBadge(tipo)); return; }
    // Evitar duplicatas
    if (row.querySelector('.nexos-tipo-badge[data-nexos-tipo]')) return;
    _findBadgeAnchor(row)?.appendChild(makeBadge(tipo));
  }

  /** Chamado pelo interceptor quando chega um tipo novo para um ID já no DOM */
  function _refreshBadgeForId(id, tipo) {
    // Atualizar placeholder pendente
    const ph = document.querySelector(`.nexos-tipo-pending[data-nexos-for-id="${id}"]`);
    if (ph) {
      ph.replaceWith(makeBadge(tipo));
      _updateFilterCounts();
      _applyFilter();
      return;
    }
    // Se a linha já está no DOM mas sem badge (raro), adicionar
    document.querySelectorAll(`[data-nexos-badged]`).forEach(row => {
      if (extractOrderId(row) === id && !row.querySelector('.nexos-tipo-badge[data-nexos-tipo]')) {
        _findBadgeAnchor(row)?.appendChild(makeBadge(tipo));
        _updateFilterCounts();
        _applyFilter();
      }
    });
  }

  function _refreshAllBadges() {
    document.querySelectorAll('.nexos-tipo-pending[data-nexos-for-id]').forEach(ph => {
      const tipo = orderTipoPedido.get(ph.dataset.nexosForId);
      if (tipo) ph.replaceWith(makeBadge(tipo));
    });
    _updateFilterCounts();
    _applyFilter();
  }

  // ── Injetar estilos globais ─────────────────────────────────────────────
  function _ensureNexosFilterStyles() {
    if (document.getElementById('nexos-filter-styles')) return;
    const s = document.createElement('style');
    s.id = 'nexos-filter-styles';
    s.textContent = `
      .nexos-hidden { display: none !important; }
      #nexos-filter-bar { position:sticky; top:0; z-index:10; }
      .nexos-filter-standalone {
        display:flex;align-items:center;gap:6px;flex-wrap:wrap;
        padding:6px 12px;background:#f0f2f5;border-bottom:1px solid #e8e8e8;
        font-size:12px; margin-bottom:4px;
      }
    `;
    (document.head || document.documentElement).appendChild(s);
  }

  // ── Filtro visual ───────────────────────────────────────────────────────
  function _applyFilter() {
    document.querySelectorAll('[data-nexos-badged]').forEach(row => {
      if (selectedTipos.size === 0) { row.classList.remove('nexos-hidden'); return; }
      const id   = extractOrderId(row);
      const tipo = id ? orderTipoPedido.get(id) : null;
      // Sem tipo mapeado → mostrar por padrão para não esconder pedidos não consultados
      row.classList.toggle('nexos-hidden', !!(tipo && !selectedTipos.has(tipo)));
    });
  }

  // ── Barra de filtro (modal OU página normal) ────────────────────────────
  function _buildFilterBar(container, insertStrategy) {
    // container: .ant-modal-content ou .home-table
    // insertStrategy: 'modal' | 'table'
    if (container.querySelector('.nexos-filter-bar')) return;

    const bar = document.createElement('div');
    bar.className     = 'nexos-filter-bar';
    bar.style.cssText =
      'display:flex;align-items:center;gap:6px;flex-wrap:wrap;' +
      'padding:6px 12px;background:#f0f2f5;border-bottom:1px solid #e8e8e8;' +
      'font-size:12px;';

    const label        = document.createElement('span');
    label.textContent  = '🏷 Tipo:';
    label.style.cssText = 'color:#666;font-weight:600;flex-shrink:0;';
    bar.appendChild(label);

    const chipsWrap        = document.createElement('div');
    chipsWrap.className    = 'nexos-tipo-chips';
    chipsWrap.style.cssText = 'display:flex;gap:4px;flex-wrap:wrap;flex:1;min-height:22px;';
    bar.appendChild(chipsWrap);

    const clearBtn        = document.createElement('button');
    clearBtn.textContent  = '✕ Limpar';
    clearBtn.style.cssText =
      'padding:2px 10px;border:1px solid #d9d9d9;border-radius:4px;' +
      'background:#fff;cursor:pointer;font-size:11px;color:#666;flex-shrink:0;';
    clearBtn.addEventListener('click', () => {
      selectedTipos.clear();
      _renderAllChips();
      _applyFilter();
    });
    bar.appendChild(clearBtn);

    if (insertStrategy === 'modal') {
      const modalHeader = container.querySelector('.ant-modal-header');
      if (modalHeader) modalHeader.insertAdjacentElement('afterend', bar);
      else container.querySelector('.ant-modal-body')?.insertAdjacentElement('beforebegin', bar);
    } else {
      // Para a tabela da página: inserir antes do ant-table-wrapper
      const tableWrapper = container.querySelector('.ant-table-wrapper');
      if (tableWrapper) tableWrapper.insertAdjacentElement('beforebegin', bar);
      else container.insertAdjacentElement('afterbegin', bar);
    }

    _renderChips(chipsWrap);
  }

  function _renderChips(container) {
    container.innerHTML = '';

    // Coletar tipos dos pedidos já mapeados no modal atual
    const tiposVisiveis = new Map(); // tipo → count
    document.querySelectorAll('[data-nexos-badged]').forEach(row => {
      const id   = extractOrderId(row);
      const tipo = id ? orderTipoPedido.get(id) : null;
      if (tipo) tiposVisiveis.set(tipo, (tiposVisiveis.get(tipo) ?? 0) + 1);
    });

    if (tiposVisiveis.size === 0) {
      const hint        = document.createElement('span');
      hint.style.color  = '#bbb';
      hint.style.fontSize = '11px';
      hint.textContent  = 'Expanda um slot para carregar os tipos…';
      container.appendChild(hint);
      return;
    }

    tiposVisiveis.forEach((count, tipo) => {
      const c        = colorForTipo(tipo);
      const isActive = selectedTipos.has(tipo);
      const chip     = document.createElement('button');

      chip.dataset.nexosTipo = tipo;
      chip.style.cssText     =
        `padding:2px 10px;border-radius:12px;font-size:11px;font-weight:600;` +
        `cursor:pointer;transition:all .15s;` +
        `background:${isActive ? c.bg  : '#fff'};` +
        `border:1px solid ${isActive ? c.border : '#d9d9d9'};` +
        `color:${isActive ? c.text : '#595959'};`;
      chip.textContent = `${tipo} (${count})`;

      chip.addEventListener('click', () => {
        if (selectedTipos.has(tipo)) selectedTipos.delete(tipo);
        else selectedTipos.add(tipo);
        _renderAllChips();
        _applyFilter();
      });

      container.appendChild(chip);
    });
  }

  function _renderAllChips() {
    document.querySelectorAll('.nexos-tipo-chips').forEach(c => _renderChips(c));
  }

  function _updateFilterCounts() {
    _renderAllChips();
  }

  // ── Observar collapse (expandir painéis) ────────────────────────────────
  function _watchCollapsePanels(modal) {
    const obs = new MutationObserver(() => {
      // Se o React removeu a barra de filtro, recriar
      if (!modal.querySelector('.nexos-filter-bar')) {
        _buildFilterBar(modal, 'modal');
      }

      modal.querySelectorAll(
        '.ant-collapse-content-active:not([data-nexos-watching]), ' +
        '.ant-collapse-content-box:not([data-nexos-watching])'
      ).forEach(panel => {
        panel.dataset.nexosWatching = '1';
        injectBadgesInPanel(panel);
        _applyFilter(); // aplicar filtro nas linhas recém-injetadas do painel aberto

        // Re-injetar se o React re-renderizar o conteúdo
        const inner = new MutationObserver(() => {
          injectBadgesInPanel(panel);
          _applyFilter(); // re-aplicar filtro após re-render do React
        });
        inner.observe(panel, { childList: true, subtree: true });
      });
    });
    obs.observe(modal, {
      childList:  true,
      subtree:    true,
      attributes: true,
      attributeFilter: ['class'],
    });
  }

  // ── Observer principal ──────────────────────────────────────────────────
  const _bodyObs = new MutationObserver(() => {
    // ── Modal "Pedidos por slot" (metrics/order-status) ──
    document.querySelectorAll('.ant-modal-content').forEach(modal => {
      const isNew = !modal.dataset.nexosModal;
      if (isNew) {
        modal.dataset.nexosModal = '1';
        _buildFilterBar(modal, 'modal');
        _watchCollapsePanels(modal);

        // Processar painéis já expandidos na abertura
        modal.querySelectorAll(
          '.ant-collapse-content-active, .ant-collapse-content-box'
        ).forEach(panel => {
          panel.dataset.nexosWatching = '1';
          injectBadgesInPanel(panel);
        });
      }
      // React pode remover a barra sem remover o modal — garantir que ela existe
      if (!modal.querySelector('.nexos-filter-bar')) {
        _buildFilterBar(modal, 'modal');
      }
      _applyFilter();
    });

    // ── Tabela da página principal (.home-table) ──
    document.querySelectorAll('.home-table:not([data-nexos-home])').forEach(homeTable => {
      homeTable.dataset.nexosHome = '1';
      _buildFilterBar(homeTable, 'table');

      const tbody = homeTable.querySelector('.ant-table-tbody');
      if (tbody) {
        tbody.querySelectorAll('tr[data-row-key]:not([data-nexos-badged])').forEach(processRow);

        // Re-injetar quando React re-renderizar linhas (paginação, scroll virtual…)
        const tableObs = new MutationObserver(() => {
          tbody.querySelectorAll('tr[data-row-key]:not([data-nexos-badged])').forEach(processRow);
          _updateFilterCounts();
          _applyFilter();
        });
        tableObs.observe(tbody, { childList: true, subtree: true });
      }
    });
  });

  _bodyObs.observe(document.body, { childList: true, subtree: true });

  _ensureNexosFilterStyles();

  console.log('[NEXOS] inject-instaleap-order-filter carregado (interceptor passivo) — aguardando dados da página…');
})();

