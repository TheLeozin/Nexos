// ===================================================================
// NEXOS - WhatsApp Helper Module
// Funcionalidades:
// 1. Consultar pedidos em plataformas parceiras (background)
// 2. Enviar links de rastreio para pedidos já solicitados
// ===================================================================

// ===================================================================
// PHASE 3: LogManager Initialization
// ===================================================================
let logManager = null;

/**
 * Obtém contexto para logs (usuário e versão)
 */
function getLogContext() {
  const version = chrome.runtime.getManifest().version;
  let user = 'Desconhecido';
  
  try {
    const emailMatch = document.cookie.match(/email=([^;]+)/);
    if (emailMatch) {
      user = emailMatch[1];
    } else {
      user = sessionStorage.getItem('nexos_user') || 
             localStorage.getItem('nexos_user') || 
             'Desconhecido';
    }
  } catch (err) {
    console.warn('[NEXOS-WHATSAPP] Não foi possível obter usuário:', err);
  }
  
  return { user, version };
}

async function initLogManager() {
  if (logManager) return logManager;
  
  try {
    if (!window.LogManager) {
      await new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = chrome.runtime.getURL('core/logging/log-manager.js');
        script.onload = () => {
          setTimeout(() => {
            if (window.LogManager) {
              resolve();
            } else {
              reject(new Error('LogManager não foi exportado para window'));
            }
          }, 100);
        };
        script.onerror = () => reject(new Error('Falha ao carregar log-manager.js'));
        document.head.appendChild(script);
      });
    }
    
    if (typeof window.LogManager !== 'function') {
      throw new Error('window.LogManager não é uma função/classe');
    }
    
    logManager = new window.LogManager();
    await logManager.initialize();
    console.log('[NEXOS-WHATSAPP] LogManager inicializado');
    return logManager;
  } catch (err) {
    console.error('[NEXOS-WHATSAPP] Erro ao inicializar LogManager:', err);
    logManager = {
      log: async (...args) => console.log('[LOG-FALLBACK]', ...args),
      warn: async (...args) => console.warn('[LOG-FALLBACK]', ...args),
      error: async (...args) => console.error('[LOG-FALLBACK]', ...args),
      initialize: async () => {}
    };
    return logManager;
  }
}

// Inicializar LogManager
initLogManager();

// ===================================================================
// PHASE 3: StorageAdapter Inline (chrome-only)
// ===================================================================
class WhatsAppStorageAdapter {
  constructor() {
    this.prefix = '__nexos_';
    console.log('[NEXOS-WHATSAPP] ✅ StorageAdapter inicializado (chrome-only)');
  }

  async get(keys) {
    try {
      if (typeof keys === 'string') keys = [keys];
      const result = await chrome.storage.local.get(keys);
      console.log('[NEXOS-WHATSAPP] Dados carregados:', Object.keys(result));
      return result;
    } catch (error) {
      console.error('[NEXOS-WHATSAPP] ❌ Erro ao carregar dados:', error);
      return {};
    }
  }

  async set(items) {
    try {
      await chrome.storage.local.set(items);
      console.log('[NEXOS-WHATSAPP] Dados salvos:', Object.keys(items));
      return true;
    } catch (error) {
      console.error('[NEXOS-WHATSAPP] ❌ Erro ao salvar dados:', error);
      return false;
    }
  }

  async remove(keys) {
    try {
      if (typeof keys === 'string') keys = [keys];
      await chrome.storage.local.remove(keys);
      console.log('[NEXOS-WHATSAPP] Dados removidos:', keys);
      return true;
    } catch (error) {
      console.error('[NEXOS-WHATSAPP] ❌ Erro ao remover dados:', error);
      return false;
    }
  }

  async list(prefix = '') {
    try {
      const all = await chrome.storage.local.get(null);
      const filtered = prefix 
        ? Object.keys(all).filter(k => k.startsWith(prefix))
        : Object.keys(all);
      return filtered;
    } catch (error) {
      console.error('[NEXOS-WHATSAPP] ❌ Erro ao listar chaves:', error);
      return [];
    }
  }

  async clear(prefix = '') {
    try {
      if (prefix) {
        const keys = await this.list(prefix);
        await this.remove(keys);
      } else {
        await chrome.storage.local.clear();
      }
      console.log('[NEXOS-WHATSAPP] Storage limpo:', prefix || 'completo');
      return true;
    } catch (error) {
      console.error('[NEXOS-WHATSAPP] ❌ Erro ao limpar storage:', error);
      return false;
    }
  }
}

// Instanciar adapter
const whatsappStorage = new WhatsAppStorageAdapter();

// Estado global do módulo WhatsApp
let whatsappOverlay = null;
let consultas = {}; // { pedido: { status, resultado, timestamp } }
let extensionContextInvalidated = false;
let extensionContextReloadPromptShown = false;
let previousActiveElement = null;

// ===================================================================
// Funções auxiliares compartilhadas
// ===================================================================

/**
 * Verifica se o contexto da extensão está disponível
 */
function ensureExtensionContextAvailable(operationLabel) {
  if (extensionContextInvalidated) {
    showExtensionContextReloadPrompt();
    return false;
  }

  try {
    if (typeof chrome === 'undefined' || !chrome.runtime) {
      throw new Error('chrome.runtime indisponível');
    }
    if (!chrome.runtime.id) {
      throw new Error('ID da extensão indisponível');
    }
    return true;
  } catch (err) {
    extensionContextInvalidated = true;
    showExtensionContextReloadPrompt();
    return false;
  }
}

/**
 * Mostra prompt de recarregamento da página
 */
function showExtensionContextReloadPrompt() {
  if (extensionContextReloadPromptShown) return;
  extensionContextReloadPromptShown = true;

  if (typeof document === 'undefined') return;

  const renderPrompt = () => {
    if (document.getElementById('nexos-reload-notice')) return;

    const banner = document.createElement('div');
    banner.id = 'nexos-reload-notice';
    banner.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 2147483711;
      max-width: 360px;
      padding: 20px;
      background: rgba(30, 32, 36, 0.98);
      border: 1px solid rgba(255, 69, 87, 0.5);
      border-radius: 16px;
      box-shadow: 0 16px 32px rgba(0, 0, 0, 0.5);
      font-family: Inter, 'Segoe UI', Roboto, Arial, sans-serif;
      color: #FFFFFF;
    `;

    const title = document.createElement('h4');
    title.textContent = 'Extensão reiniciada';
    title.style.cssText = `
      margin: 0 0 8px 0;
      font-size: 16px;
      font-weight: 700;
      color: #FF4757;
    `;

    const description = document.createElement('p');
    description.textContent = 'Recarregue a página para retomar as automações do Nexos.';
    description.style.cssText = `
      margin: 0 0 16px 0;
      font-size: 14px;
      line-height: 1.5;
      color: rgba(255, 255, 255, 0.8);
    `;

    const button = document.createElement('button');
    button.textContent = 'Recarregar página';
    button.style.cssText = `
      width: 100%;
      padding: 12px 20px;
      background: linear-gradient(135deg, #FF4757 0%, #D63031 100%);
      border: none;
      border-radius: 8px;
      color: #FFFFFF;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
    `;
    button.addEventListener('click', () => {
      try {
        window.location.reload();
      } catch (err) {
        try { window.location.href = window.location.href; } catch (e) {}
      }
    });

    banner.appendChild(title);
    banner.appendChild(description);
    banner.appendChild(button);
    document.body.appendChild(banner);
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', renderPrompt);
  } else {
    renderPrompt();
  }
}

/**
 * Exibe alerta temporário
 */
function showAlert(msg, type = 'info', durationMs) {
  document.querySelectorAll('.nexos-alert').forEach(e => e.remove());
  
  const div = document.createElement('div');
  div.className = `nexos-alert nexos-alert-${type}`;
  div.textContent = msg;
  div.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 2147483700;
    padding: 14px 18px;
    border-radius: 10px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
    opacity: 0;
    transform: translateY(-8px);
    transition: opacity 0.28s ease, transform 0.28s ease;
    font-size: 14px;
    max-width: 360px;
    word-wrap: break-word;
    font-family: Inter, 'Segoe UI', Roboto, Arial, sans-serif;
    font-weight: 500;
  `;

  if (type === 'success') {
    div.style.background = '#2ED573';
    div.style.color = '#000';
  } else if (type === 'error') {
    div.style.background = '#FF4757';
    div.style.color = '#fff';
  } else {
    div.style.background = '#3742FA';
    div.style.color = '#fff';
  }

  document.body.appendChild(div);
  setTimeout(() => {
    div.style.opacity = '1';
    div.style.transform = 'translateY(0)';
  }, 50);

  const visibleMs = (typeof durationMs === 'number' && durationMs > 0) ? durationMs : 3500;
  setTimeout(() => {
    div.style.opacity = '0';
    div.style.transform = 'translateY(-8px)';
  }, visibleMs);
  setTimeout(() => div.remove(), visibleMs + 500);
}

/**
 * Captura elemento ativo antes de abrir overlay
 */
function captureActiveElementBeforeOverlay() {
  try {
    const activeEl = document.activeElement;
    if (activeEl && activeEl !== document.body) {
      previousActiveElement = activeEl;
    }
    if (activeEl && typeof activeEl.blur === 'function') {
      activeEl.blur();
    }
  } catch (err) {}
  return previousActiveElement;
}

/**
 * Aplica focus trap ao overlay
 */
function attachFocusTrapToOverlay(overlay, skipInitialFocus = false) {
  if (!overlay) return () => {};

  overlay.setAttribute('tabindex', '-1');

  const restorePreviousFocus = () => {
    if (previousActiveElement && typeof previousActiveElement.focus === 'function' && document.contains(previousActiveElement)) {
      try { 
        previousActiveElement.focus(); 
        return; 
      } catch (err) {}
    }
    try {
      if (document.body && typeof document.body.focus === 'function') {
        document.body.focus();
      }
    } catch (err) {}
  };

  overlay.__nexosRestoreFocus = restorePreviousFocus;

  if (!skipInitialFocus) {
    try {
      overlay.focus({ preventScroll: true });
    } catch (err) {
      try { overlay.focus(); } catch (err2) {}
    }
  }

  return restorePreviousFocus;
}

/**
 * Remove overlay e restaura foco
 */
function removeOverlayAndRestoreFocus(node) {
  if (!node) return;

  const restore = typeof node.__nexosRestoreFocus === 'function' ? node.__nexosRestoreFocus : null;
  
  try { 
    node.remove(); 
  } catch (err) {}

  if (restore) {
    try { 
      restore(); 
    } catch (err) {}
  }
}

/**
 * Verifica se estamos na página do WhatsApp Web
 */
function isOnWhatsAppWeb() {
  try {
    return location && location.hostname === 'web.whatsapp.com';
  } catch (e) {
    return false;
  }
}

/**
 * Cria e exibe o overlay principal do WhatsApp Helper
 */
async function buildWhatsAppOverlay() {
  if (!ensureExtensionContextAvailable('buildWhatsAppOverlay')) {
    return;
  }

  // Remover overlay existente se houver
  if (whatsappOverlay) {
    removeOverlayAndRestoreFocus(whatsappOverlay);
    whatsappOverlay = null;
    return;
  }

  // Capturar elemento ativo antes de criar overlay
  captureActiveElementBeforeOverlay();

  // Criar overlay fixo no canto
  const overlay = document.createElement('div');
  overlay.className = 'nexos-overlay nexos-whatsapp-overlay';
  overlay.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    width: min(420px, calc(100vw - 40px));
    max-height: calc(100vh - 40px);
    background: rgba(30, 32, 36, 0.98);
    border: 1px solid rgba(0, 194, 255, 0.5);
    border-radius: 16px;
    padding: 0;
    box-shadow: 0 16px 40px rgba(0, 0, 0, 0.6);
    z-index: 2147483647;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    backdrop-filter: blur(8px);
  `;

  // Header
  const header = document.createElement('div');
  header.className = 'nexos-overlay-header';
  header.style.cssText = `
    padding: 18px 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-shrink: 0;
    background: rgba(0, 0, 0, 0.2);
  `;

  const titleContainer = document.createElement('div');
  titleContainer.style.cssText = 'display: flex; align-items: center; gap: 12px;';

  const icon = document.createElement('div');
  icon.style.cssText = `
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    box-shadow: 0 4px 12px rgba(37, 211, 102, 0.25);
    flex-shrink: 0;
  `;
  icon.textContent = '💬';

  const title = document.createElement('h2');
  title.textContent = 'WhatsApp Helper';
  title.style.cssText = `
    margin: 0;
    font-size: 18px;
    font-weight: 700;
    color: #FFFFFF;
    letter-spacing: 0.02em;
  `;

  titleContainer.appendChild(icon);
  titleContainer.appendChild(title);

  const closeBtn = document.createElement('button');
  closeBtn.className = 'nexos-btn-close';
  closeBtn.innerHTML = '✕';
  closeBtn.title = 'Fechar (Esc)';
  closeBtn.style.cssText = `
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    color: #FFFFFF;
    width: 36px;
    height: 36px;
    border-radius: 8px;
    font-size: 18px;
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
  `;
  closeBtn.addEventListener('mouseenter', () => {
    closeBtn.style.background = 'rgba(255, 69, 87, 0.2)';
    closeBtn.style.borderColor = 'rgba(255, 69, 87, 0.5)';
  });
  closeBtn.addEventListener('mouseleave', () => {
    closeBtn.style.background = 'rgba(255, 255, 255, 0.08)';
    closeBtn.style.borderColor = 'rgba(255, 255, 255, 0.15)';
  });
  closeBtn.addEventListener('click', () => {
    removeOverlayAndRestoreFocus(overlay);
    whatsappOverlay = null;
  });

  header.appendChild(titleContainer);
  header.appendChild(closeBtn);

  // Tabs
  const tabsContainer = document.createElement('div');
  tabsContainer.className = 'nexos-tabs';
  tabsContainer.style.cssText = `
    display: flex;
    padding: 0 20px;
    gap: 6px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(0, 0, 0, 0.25);
    flex-shrink: 0;
  `;

  const tabs = [
    { id: 'consulta', label: 'Consultar', icon: '🔍' },
    { id: 'rastreio', label: 'Rastreios', icon: '📦' }
  ];

  tabs.forEach((tab, index) => {
    const tabBtn = document.createElement('button');
    tabBtn.className = `nexos-tab ${index === 0 ? 'nexos-tab-active' : ''}`;
    tabBtn.dataset.tab = tab.id;
    tabBtn.innerHTML = `<span style="font-size: 14px; margin-right: 6px;">${tab.icon}</span>${tab.label}`;
    tabBtn.style.cssText = `
      padding: 12px 16px;
      background: transparent;
      border: none;
      border-bottom: 3px solid transparent;
      color: rgba(255, 255, 255, 0.6);
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      white-space: nowrap;
    `;

    if (index === 0) {
      tabBtn.style.color = '#00C2FF';
      tabBtn.style.borderBottomColor = '#00C2FF';
    }

    tabBtn.addEventListener('click', () => {
      // Remover active de todas as tabs
      tabsContainer.querySelectorAll('.nexos-tab').forEach(t => {
        t.classList.remove('nexos-tab-active');
        t.style.color = 'rgba(255, 255, 255, 0.6)';
        t.style.borderBottomColor = 'transparent';
      });
      // Ativar tab clicada
      tabBtn.classList.add('nexos-tab-active');
      tabBtn.style.color = '#00C2FF';
      tabBtn.style.borderBottomColor = '#00C2FF';

      // Mostrar conteúdo correspondente
      contentArea.querySelectorAll('.nexos-tab-content').forEach(content => {
        content.style.display = 'none';
      });
      const targetContent = contentArea.querySelector(`[data-tab-content="${tab.id}"]`);
      if (targetContent) {
        targetContent.style.display = 'block';
      }
    });

    tabsContainer.appendChild(tabBtn);
  });

  // Content Area
  const contentArea = document.createElement('div');
  contentArea.className = 'nexos-content-area';
  contentArea.style.cssText = `
    flex: 1;
    overflow-y: auto;
    padding: 20px;
    background: rgba(0, 0, 0, 0.2);
  `;

  // Tab Content: Consultar Pedidos
  const consultaContent = createConsultaTab();
  consultaContent.dataset.tabContent = 'consulta';
  contentArea.appendChild(consultaContent);

  // Tab Content: Enviar Rastreios
  const rastreioContent = createRastreioTab();
  rastreioContent.dataset.tabContent = 'rastreio';
  rastreioContent.style.display = 'none';
  contentArea.appendChild(rastreioContent);

  // Montar overlay
  overlay.appendChild(header);
  overlay.appendChild(tabsContainer);
  overlay.appendChild(contentArea);

  // Adicionar ao DOM
  document.body.appendChild(overlay);
  whatsappOverlay = overlay;

  // Aplicar focus trap
  attachFocusTrapToOverlay(overlay);

  // ESC para fechar
  const handleEscape = (e) => {
    if (e.key === 'Escape' && whatsappOverlay) {
      removeOverlayAndRestoreFocus(whatsappOverlay);
      whatsappOverlay = null;
      document.removeEventListener('keydown', handleEscape);
    }
  };
  document.addEventListener('keydown', handleEscape);
}

/**
 * Cria a aba de consulta de pedidos
 */
function createConsultaTab() {
  const container = document.createElement('div');
  container.className = 'nexos-tab-content';

  const description = document.createElement('p');
  description.style.cssText = `
    margin: 0 0 16px 0;
    color: rgba(255, 255, 255, 0.65);
    font-size: 13px;
    line-height: 1.5;
  `;
  description.textContent = 'Insira os números dos pedidos (um por linha) para consultar nas plataformas.';

  // Textarea para números de pedidos
  const inputGroup = document.createElement('div');
  inputGroup.style.cssText = 'margin-bottom: 16px;';

  const label = document.createElement('label');
  label.textContent = 'Números dos Pedidos';
  label.style.cssText = `
    display: block;
    margin-bottom: 6px;
    color: #00C2FF;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  `;

  const textarea = document.createElement('textarea');
  textarea.id = 'nexos-pedidos-input';
  textarea.placeholder = 'Ex:\n12345678\n87654321\n11223344';
  textarea.rows = 6;
  textarea.style.cssText = `
    width: 100%;
    padding: 12px;
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 8px;
    color: #FFFFFF;
    font-size: 13px;
    font-family: 'Courier New', monospace;
    resize: vertical;
    box-sizing: border-box;
    transition: all 0.2s ease;
  `;
  textarea.addEventListener('focus', () => {
    textarea.style.borderColor = '#00C2FF';
    textarea.style.background = 'rgba(0, 194, 255, 0.08)';
  });
  textarea.addEventListener('blur', () => {
    textarea.style.borderColor = 'rgba(255, 255, 255, 0.15)';
    textarea.style.background = 'rgba(255, 255, 255, 0.06)';
  });

  inputGroup.appendChild(label);
  inputGroup.appendChild(textarea);

  // Botão Consultar
  const btnConsultar = document.createElement('button');
  btnConsultar.className = 'nexos-btn nexos-btn-primary';
  btnConsultar.innerHTML = '<span style="font-size: 16px; margin-right: 8px;">🔍</span>Consultar Pedidos';
  btnConsultar.style.cssText = `
    width: 100%;
    padding: 14px 24px;
    background: linear-gradient(135deg, #00C2FF 0%, #0077B6 100%);
    border: none;
    border-radius: 10px;
    color: #FFFFFF;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 24px;
  `;
  btnConsultar.addEventListener('mouseenter', () => {
    btnConsultar.style.transform = 'translateY(-2px)';
    btnConsultar.style.boxShadow = '0 8px 20px rgba(0, 194, 255, 0.4)';
  });
  btnConsultar.addEventListener('mouseleave', () => {
    btnConsultar.style.transform = 'translateY(0)';
    btnConsultar.style.boxShadow = 'none';
  });
  btnConsultar.addEventListener('click', () => handleConsultaPedidos(textarea));

  // Área de resultados
  const resultsArea = document.createElement('div');
  resultsArea.id = 'nexos-consulta-results';
  resultsArea.style.cssText = `
    margin-top: 24px;
    padding: 20px;
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    min-height: 100px;
    display: none;
  `;

  container.appendChild(description);
  container.appendChild(inputGroup);
  container.appendChild(btnConsultar);
  container.appendChild(resultsArea);

  return container;
}

/**
 * Cria a aba de envio de rastreios
 */
function createRastreioTab() {
  const container = document.createElement('div');
  container.className = 'nexos-tab-content';

  const description = document.createElement('p');
  description.style.cssText = `
    margin: 0 0 16px 0;
    color: rgba(255, 255, 255, 0.65);
    font-size: 13px;
    line-height: 1.5;
  `;
  description.textContent = 'Pedidos com status SOLICITADO que possuem link de rastreio.';

  // Área de lista de pedidos
  const listArea = document.createElement('div');
  listArea.id = 'nexos-rastreio-list';
  listArea.style.cssText = `
    display: flex;
    flex-direction: column;
    gap: 10px;
  `;

  container.appendChild(description);
  container.appendChild(listArea);

  // Carregar pedidos automaticamente
  loadPedidosSolicitados(listArea);

  return container;
}

/**
 * Carrega pedidos com status SOLICITADO do storage
 */
async function loadPedidosSolicitados(listArea) {
  listArea.innerHTML = `
    <div style="text-align: center; padding: 40px; color: rgba(255, 255, 255, 0.5);">
      <div style="font-size: 24px; margin-bottom: 12px;">⏳</div>
      <p style="margin: 0; font-size: 13px;">Carregando pedidos...</p>
    </div>
  `;

  try {
    if (!chrome.storage || !chrome.storage.local) {
      throw new Error('Storage não disponível');
    }

    // PHASE 3: Usar whatsappStorage.get()
    const data = await whatsappStorage.get([
      'nexos-picking-data',
      'nexos-solicitacoes',
      '__nexos_uber_requests',
      '__nexos_lalamove_requests',
      '__nexos_99_requests'
    ]);
    
    // Filtro de data atual (início e fim do dia)
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    const inicioHoje = hoje.getTime();
    
    const amanha = new Date(hoje);
    amanha.setDate(amanha.getDate() + 1);
    const fimHoje = amanha.getTime();
    
    const pedidosSolicitados = [];
    
    // Busca apenas em nexos-picking-data (dados do Picking)
    const pickingData = data['nexos-picking-data'] || {};
    
    // console.log('[NEXOS DEBUG] Total de chaves em storage:', Object.keys(pickingData).length);
    // console.log('[NEXOS DEBUG] Filtro de hoje:', new Date(inicioHoje), 'até', new Date(fimHoje));
    
    for (const [chaveExterna, valor] of Object.entries(pickingData)) {
      // console.log('[NEXOS DEBUG] Analisando chave externa:', chaveExterna, valor);
      
      if (!valor || typeof valor !== 'object') {
        // console.log('[NEXOS DEBUG] ❌ Rejeitado - valor inválido');
        continue;
      }
      
      // Verifica se é estrutura aninhada (loja -> pedido -> dados)
      // ou estrutura direta (pedido -> dados)
      const isEstruturaDireta = valor.status || valor.tracking_link;
      
      if (isEstruturaDireta) {
        // Estrutura direta: { "12345": { status: "SOLICITADO", tracking_link: "..." } }
        const info = valor;
        const numeroPedido = info.pedido || info.id_uber || info.numero_pedido || chaveExterna;
        
        // console.log('[NEXOS DEBUG] → Estrutura direta, pedido:', numeroPedido);
        
        const statusNormalizado = (info.status || '').toUpperCase();
        if (statusNormalizado !== 'SOLICITADO') {
          // console.log('[NEXOS DEBUG] ❌ Status:', info.status);
          continue;
        }
        
        if (!info.tracking_link) {
          // console.log('[NEXOS DEBUG] ❌ Sem tracking_link');
          continue;
        }
        
        let timestamp = info.timestamp || info.solicitado_em || 0;
        if (!timestamp && info.horario_solicitacao) {
          try {
            const partes = info.horario_solicitacao.split(/[,\s]+/);
            const [dia, mes, ano] = partes[0].split('/');
            const [hora, min, seg] = partes[1].split(':');
            timestamp = new Date(ano, mes - 1, dia, hora, min, seg).getTime();
          } catch (e) {
            // console.log('[NEXOS DEBUG] ⚠️ Erro ao converter horario_solicitacao');
          }
        }
        
        if (timestamp < inicioHoje || timestamp >= fimHoje) {
          // console.log('[NEXOS DEBUG] ❌ Não é de hoje:', new Date(timestamp));
          continue;
        }
        
        // console.log('[NEXOS DEBUG] ✅ APROVADO');
        pedidosSolicitados.push({
          pedido: numeroPedido,
          loja: info.numero_loja || chaveExterna,
          tracking_link: info.tracking_link,
          plataforma: (info.plataforma || 'N/A').charAt(0).toUpperCase() + (info.plataforma || 'N/A').slice(1),
          cliente: info.nome_cliente || info.cliente || 'N/A',
          timestamp: timestamp,
          horario_solicitacao: info.horario_solicitacao || 'N/A',
          valor_pedido: info.valor_pedido || 'N/A'
        });
        
      } else {
        // Estrutura aninhada: { "5861": { "22412275": { status: "SOLICITADO", ... } } }
        // console.log('[NEXOS DEBUG] → Estrutura aninhada (loja/pedido)');
        
        for (const [numeroPedido, info] of Object.entries(valor)) {
          // console.log('[NEXOS DEBUG] → → Pedido interno:', numeroPedido, info);
          
          if (!info || typeof info !== 'object') continue;
          
          const statusNormalizado = (info.status || '').toUpperCase();
          if (statusNormalizado !== 'SOLICITADO') {
            // console.log('[NEXOS DEBUG] ❌ Status:', info.status);
            continue;
          }
          
          if (!info.tracking_link) {
            // console.log('[NEXOS DEBUG] ❌ Sem tracking_link');
            continue;
          }
          
          let timestamp = info.timestamp || info.solicitado_em || 0;
          if (!timestamp && info.horario_solicitacao) {
            try {
              const partes = info.horario_solicitacao.split(/[,\s]+/);
              const [dia, mes, ano] = partes[0].split('/');
              const [hora, min, seg] = partes[1].split(':');
              timestamp = new Date(ano, mes - 1, dia, hora, min, seg).getTime();
            } catch (e) {
              // console.log('[NEXOS DEBUG] ⚠️ Erro ao converter horario_solicitacao');
            }
          }
          
          if (timestamp < inicioHoje || timestamp >= fimHoje) {
            // console.log('[NEXOS DEBUG] ❌ Não é de hoje:', new Date(timestamp));
            continue;
          }
          
          // console.log('[NEXOS DEBUG] ✅ APROVADO');
          pedidosSolicitados.push({
            pedido: numeroPedido,
            loja: info.bandeira || info.loja || info.numero_loja || chaveExterna,
            tracking_link: info.tracking_link,
            plataforma: (info.plataforma || 'N/A').charAt(0).toUpperCase() + (info.plataforma || 'N/A').slice(1),
            cliente: info.nome_cliente || info.cliente || 'N/A',
            timestamp: timestamp
          });
        }
      }
    }
    
    // console.log('[NEXOS DEBUG] Total de pedidos filtrados:', pedidosSolicitados.length);

    // Ordenar por timestamp (mais recentes primeiro)
    pedidosSolicitados.sort((a, b) => b.timestamp - a.timestamp);

    if (pedidosSolicitados.length === 0) {
      listArea.innerHTML = `
        <div style="
          text-align: center;
          padding: 60px 20px;
          background: rgba(255, 255, 255, 0.03);
          border: 1px dashed rgba(255, 255, 255, 0.15);
          border-radius: 12px;
        ">
          <div style="font-size: 48px; margin-bottom: 16px;">📦</div>
          <h3 style="margin: 0 0 8px 0; color: rgba(255, 255, 255, 0.8); font-size: 16px; font-weight: 600;">
            Nenhum pedido encontrado
          </h3>
          <p style="margin: 0; color: rgba(255, 255, 255, 0.5); font-size: 13px;">
            Pedidos solicitados aparecerão aqui automaticamente
          </p>
        </div>
      `;
      return;
    }

    // Renderizar lista de pedidos
    listArea.innerHTML = '';
    pedidosSolicitados.forEach(pedidoData => {
      const card = createPedidoCard(pedidoData);
      listArea.appendChild(card);
    });

  } catch (error) {
    console.error('[NEXOS] Erro ao carregar pedidos:', error);
    listArea.innerHTML = `
      <div style="
        text-align: center;
        padding: 40px 20px;
        background: rgba(255, 69, 87, 0.1);
        border: 1px solid rgba(255, 69, 87, 0.3);
        border-radius: 12px;
      ">
        <div style="font-size: 48px; margin-bottom: 16px;">⚠️</div>
        <h3 style="margin: 0 0 8px 0; color: #FF4757; font-size: 16px; font-weight: 600;">
          Erro ao carregar pedidos
        </h3>
        <p style="margin: 0; color: rgba(255, 255, 255, 0.6); font-size: 13px;">
          ${error.message}
        </p>
      </div>
    `;
  }
}

/**
 * Cria card de pedido individual
 */
function createPedidoCard(pedidoData) {
  const card = document.createElement('div');
  card.style.cssText = `
    background: rgba(0, 194, 255, 0.08);
    border: 1px solid rgba(0, 194, 255, 0.25);
    border-radius: 10px;
    padding: 14px;
    transition: all 0.2s ease;
  `;

  card.addEventListener('mouseenter', () => {
    card.style.background = 'rgba(0, 194, 255, 0.12)';
    card.style.borderColor = 'rgba(0, 194, 255, 0.4)';
  });
  card.addEventListener('mouseleave', () => {
    card.style.background = 'rgba(0, 194, 255, 0.08)';
    card.style.borderColor = 'rgba(0, 194, 255, 0.25)';
  });

  card.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
      <div style="flex: 1;">
        <div style="font-size: 15px; font-weight: 700; color: #FFFFFF; margin-bottom: 4px;">
          📦 Pedido ${pedidoData.pedido}
        </div>
        <div style="font-size: 12px; color: rgba(255, 255, 255, 0.6); line-height: 1.6;">
          🏪 Loja ${pedidoData.loja} • 🚚 ${pedidoData.plataforma}<br/>
          🕐 ${pedidoData.horario_solicitacao} • 💰 R$ ${pedidoData.valor_pedido}
        </div>
      </div>
    </div>
    <div style="
      background: rgba(0, 0, 0, 0.25);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 6px;
      padding: 8px;
      margin-bottom: 10px;
      font-family: 'Courier New', monospace;
      font-size: 11px;
      color: #2ED573;
      word-break: break-all;
      max-height: 60px;
      overflow-y: auto;
    ">
      ${pedidoData.tracking_link}
    </div>
    <button 
      class="nexos-enviar-whatsapp-btn"
      data-pedido="${pedidoData.pedido}"
      data-link="${pedidoData.tracking_link}"
      style="
        width: 100%;
        padding: 10px 16px;
        background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
        border: none;
        border-radius: 8px;
        color: #FFFFFF;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
      "
    >
      <span style="font-size: 16px;">💬</span>
      Enviar via WhatsApp
    </button>
  `;

  // Event listener para botão de enviar
  const btnEnviar = card.querySelector('.nexos-enviar-whatsapp-btn');
  btnEnviar.addEventListener('mouseenter', () => {
    btnEnviar.style.transform = 'translateY(-1px)';
    btnEnviar.style.boxShadow = '0 4px 12px rgba(37, 211, 102, 0.4)';
  });
  btnEnviar.addEventListener('mouseleave', () => {
    btnEnviar.style.transform = 'translateY(0)';
    btnEnviar.style.boxShadow = 'none';
  });
  btnEnviar.addEventListener('click', (e) => {
    const btn = e.currentTarget;
    const pedido = btn.getAttribute('data-pedido');
    const link = btn.getAttribute('data-link');
    
    const mensagem = `🚚 *Rastreio do Pedido ${pedido}*\n\nO pedido já está a caminho! 📦\n\nAcompanhe em tempo real:\n${link}`;
    
    navigator.clipboard.writeText(mensagem).then(() => {
      showAlert('Mensagem copiada! Cole no WhatsApp para enviar.', 'success', 4000);
      btn.innerHTML = '<span style="font-size: 16px;">✅</span> Copiado!';
      setTimeout(() => {
        btn.innerHTML = '<span style="font-size: 16px;">💬</span> Enviar via WhatsApp';
      }, 2000);
    }).catch(err => {
      showAlert('Erro ao copiar mensagem.', 'error');
    });
  });

  return card;
}

/**
 * Handler para consulta de pedidos
 */
async function handleConsultaPedidos(textarea) {
  const pedidosText = textarea.value.trim();
  if (!pedidosText) {
    showAlert('Por favor, insira ao menos um número de pedido.', 'error');
    return;
  }

  const pedidos = pedidosText.split('\n').map(p => p.trim()).filter(p => p);
  if (pedidos.length === 0) {
    showAlert('Nenhum pedido válido encontrado.', 'error');
    return;
  }

  const resultsArea = document.getElementById('nexos-consulta-results');
  resultsArea.style.display = 'block';
  resultsArea.innerHTML = `
    <div style="text-align: center; color: rgba(255, 255, 255, 0.7);">
      <div style="font-size: 32px; margin-bottom: 12px;">⏳</div>
      <p style="margin: 0; font-size: 14px;">Consultando ${pedidos.length} pedido(s)...</p>
    </div>
  `;

  // Simular consulta (substituir por chamada real às plataformas)
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Resultados mockados
  const resultados = pedidos.map(pedido => ({
    pedido,
    status: Math.random() > 0.3 ? 'encontrado' : 'não encontrado',
    plataforma: ['Uber', 'Lalamove', '99'][Math.floor(Math.random() * 3)],
    link: Math.random() > 0.3 ? `https://tracking.example.com/${pedido}` : null
  }));

  // Renderizar resultados
  let html = '<div style="display: flex; flex-direction: column; gap: 12px;">';
  resultados.forEach(r => {
    const bgColor = r.status === 'encontrado' ? 'rgba(46, 213, 115, 0.15)' : 'rgba(255, 107, 107, 0.15)';
    const borderColor = r.status === 'encontrado' ? 'rgba(46, 213, 115, 0.4)' : 'rgba(255, 107, 107, 0.4)';
    const icon = r.status === 'encontrado' ? '✅' : '❌';

    html += `
      <div style="
        padding: 16px;
        background: ${bgColor};
        border: 1px solid ${borderColor};
        border-radius: 10px;
        display: flex;
        justify-content: space-between;
        align-items: center;
      ">
        <div style="flex: 1;">
          <div style="font-size: 16px; font-weight: 600; color: #FFFFFF; margin-bottom: 4px;">
            ${icon} Pedido ${r.pedido}
          </div>
          <div style="font-size: 13px; color: rgba(255, 255, 255, 0.7);">
            ${r.status === 'encontrado' ? `Encontrado em: ${r.plataforma}` : 'Não encontrado nas plataformas'}
          </div>
        </div>
        ${r.link ? `
          <button 
            class="nexos-copy-link-btn" 
            data-link="${r.link}"
            style="
              padding: 8px 16px;
              background: rgba(0, 194, 255, 0.2);
              border: 1px solid rgba(0, 194, 255, 0.5);
              border-radius: 8px;
              color: #00C2FF;
              font-size: 13px;
              font-weight: 600;
              cursor: pointer;
              transition: all 0.2s ease;
            "
          >
            📋 Copiar Link
          </button>
        ` : ''}
      </div>
    `;
  });
  html += '</div>';

  resultsArea.innerHTML = html;

  // Event listeners para botões de copiar
  resultsArea.querySelectorAll('.nexos-copy-link-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const link = btn.getAttribute('data-link');
      navigator.clipboard.writeText(link).then(() => {
        showAlert('Link copiado para área de transferência!', 'success');
      });
    });
    btn.addEventListener('mouseenter', () => {
      btn.style.background = 'rgba(0, 194, 255, 0.35)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.background = 'rgba(0, 194, 255, 0.2)';
    });
  });

  showAlert(`Consulta concluída! ${resultados.filter(r => r.status === 'encontrado').length}/${pedidos.length} pedidos encontrados.`, 'success');
}



// Inicialização quando estiver no WhatsApp Web
if (isOnWhatsAppWeb()) {
  console.log('[NEXOS] WhatsApp Helper carregado');

  // Adicionar botão flutuante
  setTimeout(() => {
    if (document.getElementById('nexos-whatsapp-float-btn')) return;

    const floatBtn = document.createElement('button');
    floatBtn.id = 'nexos-whatsapp-float-btn';
    floatBtn.innerHTML = '💬';
    floatBtn.title = 'WhatsApp Helper (Alt+W)';
    floatBtn.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
      border: 3px solid rgba(255, 255, 255, 0.2);
      color: #FFFFFF;
      font-size: 28px;
      cursor: pointer;
      box-shadow: 0 8px 24px rgba(37, 211, 102, 0.4);
      z-index: 2147483646;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
    `;

    floatBtn.addEventListener('mouseenter', () => {
      floatBtn.style.transform = 'scale(1.1) rotate(5deg)';
      floatBtn.style.boxShadow = '0 12px 32px rgba(37, 211, 102, 0.6)';
    });
    floatBtn.addEventListener('mouseleave', () => {
      floatBtn.style.transform = 'scale(1) rotate(0deg)';
      floatBtn.style.boxShadow = '0 8px 24px rgba(37, 211, 102, 0.4)';
    });
    floatBtn.addEventListener('click', buildWhatsAppOverlay);

    document.body.appendChild(floatBtn);
  }, 1000);

  // Atalho Alt+W
  document.addEventListener('keydown', (e) => {
    if (e.altKey && e.key.toLowerCase() === 'w') {
      e.preventDefault();
      buildWhatsAppOverlay();
    }
  });

  console.log('[NEXOS WhatsApp Helper] 📱 Módulo carregado. Atalho: Alt+W (abrir overlay)');
}
