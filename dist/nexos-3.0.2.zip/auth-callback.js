/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - AUTH CALLBACK HANDLER
 * Processa callback OAuth do Azure AD e comunica com janela principal
 * ═══════════════════════════════════════════════════════════════════════════
 */

(function() {
    'use strict';
    
    const elements = {
        title: document.getElementById('title'),
        spinner: document.getElementById('spinner'),
        status: document.getElementById('status'),
        message: document.getElementById('message'),
        closeBtn: document.getElementById('close-btn')
    };
    
    // ═══════════════════════════════════════════════════════════════════════════
    // UI HELPERS
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Exibe tela de sucesso
     */
    function showSuccess() {
        elements.title.textContent = 'Autenticação Concluída!';
        elements.spinner.outerHTML = '<div class="success">✓</div>';
        elements.status.textContent = 'Você foi autenticado com sucesso.';
        elements.message.textContent = 'Esta janela será fechada automaticamente...';
        elements.closeBtn.style.display = 'inline-block';
        
        // Fechar automaticamente após 2 segundos
        setTimeout(() => {
            window.close();
        }, 2000);
    }
    
    /**
     * Exibe tela de erro
     * @param {string} errorMessage - Mensagem de erro
     */
    function showError(errorMessage) {
        elements.title.textContent = 'Erro de Autenticação';
        elements.spinner.outerHTML = '<div class="error">✗</div>';
        elements.status.textContent = 'Não foi possível completar a autenticação.';
        elements.message.textContent = errorMessage || 'Por favor, tente novamente.';
        elements.closeBtn.style.display = 'inline-block';
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // OAUTH CALLBACK PROCESSING
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Processa callback OAuth do Azure AD
     */
    async function processOAuthCallback() {
        try {
            console.log('[AuthCallback] Processando callback OAuth...');
            console.log('[AuthCallback] URL:', window.location.href);
            
            // Extrair parâmetros da URL (query string e hash fragment)
            const urlParams = new URLSearchParams(window.location.search);
            const urlHash = new URLSearchParams(window.location.hash.substring(1));
            
            console.log('[AuthCallback] Query params:', Array.from(urlParams.entries()));
            console.log('[AuthCallback] Hash params:', Array.from(urlHash.entries()));
            
            // Verificar erro
            const error = urlParams.get('error') || urlHash.get('error');
            const errorDescription = urlParams.get('error_description') || urlHash.get('error_description');
            
            if (error) {
                console.error('[AuthCallback] Erro OAuth:', error, errorDescription);
                
                // Enviar erro para iframe parent (se existir)
                try {
                    if (window.parent && window.parent !== window) {
                        window.parent.postMessage({
                            type: 'AUTH_ERROR',
                            error: errorDescription || error
                        }, '*');
                        console.log('[AuthCallback] ✅ Erro enviado para parent via postMessage');
                    }
                } catch (e) {
                    console.warn('[AuthCallback] Não foi possível enviar erro para parent:', e);
                }
                
                showError(errorDescription || error);
                return;
            }
            
            // Extrair access token (Azure AD retorna no hash fragment para response_type=token)
            const accessToken = urlHash.get('access_token');
            const tokenType = urlHash.get('token_type');
            const expiresIn = urlHash.get('expires_in');
            const code = urlParams.get('code') || urlHash.get('code');
            const state = urlParams.get('state') || urlHash.get('state');
            
            console.log('[AuthCallback] Access Token:', accessToken ? `${accessToken.substring(0, 20)}...` : 'null');
            console.log('[AuthCallback] Code:', code ? `${code.substring(0, 20)}...` : 'null');
            console.log('[AuthCallback] State:', state);
            
            if (!accessToken && !code) {
                console.error('[AuthCallback] Nem token nem código recebidos');
                
                // Enviar erro para iframe parent
                try {
                    if (window.parent && window.parent !== window) {
                        window.parent.postMessage({
                            type: 'AUTH_ERROR',
                            error: 'Token ou código de autorização não recebidos'
                        }, '*');
                    }
                } catch (e) {
                    console.warn('[AuthCallback] Não foi possível enviar erro para parent:', e);
                }
                
                showError('Token ou código de autorização não recebidos.');
                return;
            }
            
            // Criar mensagem de callback
            const callbackData = {
                type: 'nexos-oauth-callback',
                accessToken,
                tokenType,
                expiresIn,
                code,
                state
            };
            
            console.log('[AuthCallback] Enviando callback data...');
            
            // ════════════════════════════════════════════════════════════════════
            // PRIORIDADE 1: SALVAR NO STORAGE (iframe sandbox sem allow-same-origin)
            // ════════════════════════════════════════════════════════════════════
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                try {
                    console.log('[AuthCallback] 💾 Salvando em chrome.storage (PRIORIDADE 1)...');
                    await chrome.storage.local.set({
                        'nexos-oauth-pending': callbackData
                    });
                    console.log('[AuthCallback] ✅ Salvo em chrome.storage - Overlay detectará via polling');
                    showSuccess();
                    return;
                } catch (e) {
                    console.error('[AuthCallback] ❌ Erro ao salvar em storage:', e);
                }
            }
            
            // ════════════════════════════════════════════════════════════════════
            // FALLBACK 2: TENTAR PARENT (só funciona se NÃO estiver em sandbox)
            // ════════════════════════════════════════════════════════════════════
            try {
                if (window.parent && window.parent !== window) {
                    console.log('[AuthCallback] 🖼️ Tentando postMessage para PARENT (iframe)...');
                    window.parent.postMessage({
                        type: 'AUTH_SUCCESS',
                        token: accessToken,
                        tokenType,
                        expiresIn
                    }, '*');
                    console.log('[AuthCallback] ✅ PostMessage enviado para parent (pode não funcionar com sandbox)');
                    showSuccess();
                    return;
                }
            } catch (e) {
                console.warn('[AuthCallback] ⚠️ Erro ao enviar para parent (esperado com sandbox):', e);
            }
            
            // ════════════════════════════════════════════════════════════════════
            // FALLBACK 3: Enviar para OPENER (popup tradicional)
            // ════════════════════════════════════════════════════════════════════
            if (window.opener && !window.opener.closed) {
                console.log('[AuthCallback] 🪟 Enviando postMessage para OPENER (popup)...');
                window.opener.postMessage(callbackData, '*');
                console.log('[AuthCallback] ✅ PostMessage enviado para opener');
                showSuccess();
                return;
            }
            
            // ════════════════════════════════════════════════════════════════════
            // FALLBACK 4: Comunicar com background script
            // ════════════════════════════════════════════════════════════════════
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                try {
                    console.log('[AuthCallback] 📡 Enviando mensagem para background script...');
                    await chrome.runtime.sendMessage(callbackData);
                    console.log('[AuthCallback] ✅ Mensagem enviada para background script');
                    showSuccess();
                    return;
                } catch (e) {
                    console.error('[AuthCallback] ❌ Erro ao enviar para background:', e);
                }
            }
            
            // Se chegou aqui, pelo menos storage deve ter funcionado (fallback 1)
            console.log('[AuthCallback] ℹ️ Callback processado via storage, aguardando polling do overlay');
            showSuccess();
            
        } catch (error) {
            console.error('[AuthCallback] ❌ Erro inesperado:', error);
            showError('Erro inesperado ao processar autenticação.');
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // EVENT LISTENERS
    // ═══════════════════════════════════════════════════════════════════════════
    
    // Botão de fechar
    elements.closeBtn.addEventListener('click', () => {
        console.log('[AuthCallback] Fechando janela manualmente...');
        window.close();
    });
    
    // ═══════════════════════════════════════════════════════════════════════════
    // INICIALIZAÇÃO
    // ═══════════════════════════════════════════════════════════════════════════
    
    console.log('[AuthCallback] Script carregado, iniciando processamento...');
    processOAuthCallback();
    
})();
