// ===================================================================
// NEXOS - Dashboard em Tempo Real
// Atualização de dados sem reload de página
// ===================================================================

/**
 * Classe para gerenciamento de atualizações em tempo real do dashboard
 */
class LiveDashboard {
  constructor() {
    this.updateInterval = null;
    this.refreshRate = 5000; // 5 segundos padrão
    this.lastUpdateTimestamp = 0;
    this.isUpdating = false;
    this.logManager = null;
    this.currentPanel = null;
    this.initialized = false;
    
    // Cache de dados para detectar mudanças
    this.cache = {
      logs: [],
      stats: null,
      users: [],
      notifications: []
    };
  }
  
  /**
   * Inicializa o sistema de atualização em tempo real
   */
  async initialize(logManager, refreshRate = 5000) {
    if (this.initialized) return;
    
    this.logManager = logManager;
    this.refreshRate = refreshRate;
    this.initialized = true;
    
    console.log('[LiveDashboard] ✅ Inicializado com refresh rate:', refreshRate, 'ms');
  }
  
  /**
   * Inicia atualizações automáticas
   */
  start(panelName) {
    if (this.updateInterval) {
      this.stop();
    }
    
    this.currentPanel = panelName;
    console.log('[LiveDashboard] Iniciando atualizações para painel:', panelName);
    
    // Primeira atualização imediata
    this._update();
    
    // Agendar atualizações periódicas
    this.updateInterval = setInterval(() => {
      this._update();
    }, this.refreshRate);
  }
  
  /**
   * Para atualizações automáticas
   */
  stop() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
      console.log('[LiveDashboard] Atualizações pausadas');
    }
  }
  
  /**
   * Atualiza painel atual sem recarregar página
   */
  async _update() {
    if (this.isUpdating) {
      console.log('[LiveDashboard] Atualização já em andamento, pulando...');
      return;
    }
    
    this.isUpdating = true;
    const startTime = Date.now();
    
    try {
      switch (this.currentPanel) {
        case 'overview':
          await this._updateOverviewPanel();
          break;
        case 'logs':
          await this._updateLogsPanel();
          break;
        case 'statistics':
          await this._updateStatisticsPanel();
          break;
        case 'users':
          await this._updateUsersPanel();
          break;
        case 'alerts':
          await this._updateAlertsPanel();
          break;
        default:
          console.log('[LiveDashboard] Painel não requer atualização:', this.currentPanel);
      }
      
      this.lastUpdateTimestamp = Date.now();
      
      // Atualizar indicador de "última atualização"
      this._updateLastRefreshIndicator();
      
      const duration = Date.now() - startTime;
      console.log(`[LiveDashboard] ✅ Atualização concluída em ${duration}ms`);
      
    } catch (error) {
      console.error('[LiveDashboard] Erro ao atualizar:', error);
    } finally {
      this.isUpdating = false;
    }
  }
  
  // ===================================================================
  // ATUALIZAÇÃO DE PAINÉIS ESPECÍFICOS
  // ===================================================================
  
  /**
   * Helper para buscar logs (usa searchLogs do LogManager)
   */
  async _getLogs() {
    try {
      const result = await this.logManager.searchLogs({ limit: 10000 });
      return result.logs || [];
    } catch (error) {
      console.error('[LiveDashboard] Erro ao buscar logs:', error);
      return [];
    }
  }
  
  /**
   * Atualiza painel Overview (cards de estatísticas principais)
   */
  async _updateOverviewPanel() {
    console.log('[LiveDashboard] Atualizando Overview...');
    
    const logs = await this._getLogs();
    
    // Calcular estatísticas
    const totalLogs = logs.length;
    const errorLogs = logs.filter(log => log.level === 'ERROR').length;
    const last24h = logs.filter(log => log.timestamp > Date.now() - 86400000).length;
    
    // Usuários únicos
    const uniqueUsers = new Set(logs.map(log => log.user).filter(Boolean));
    const activeUsers = uniqueUsers.size;
    
    // Taxa de sucesso
    const successLogs = logs.filter(log => log.metadata?.status === 'success').length;
    const totalOperations = logs.filter(log => log.metadata?.status).length;
    const successRate = totalOperations > 0 ? ((successLogs / totalOperations) * 100).toFixed(1) : 0;
    
    // Atualizar cards com animação
    this._updateCardValue('#total-logs', totalLogs);
    this._updateCardValue('#error-logs', errorLogs);
    this._updateCardValue('#logs-24h', last24h);
    this._updateCardValue('#active-users', activeUsers);
    this._updateCardValue('#success-rate', successRate, '%');
    
    // Detectar mudanças para highlight
    if (totalLogs > (this.cache.stats?.totalLogs || 0)) {
      this._highlightCard('#total-logs');
    }
    if (errorLogs > (this.cache.stats?.errorLogs || 0)) {
      this._highlightCard('#error-logs', 'error');
    }
    
    // Atualizar cache
    this.cache.stats = { totalLogs, errorLogs, last24h, activeUsers, successRate };
  }
  
  /**
   * Atualiza painel de Logs (adiciona novos logs sem recriar tabela)
   */
  async _updateLogsPanel() {
    console.log('[LiveDashboard] Atualizando Logs...');
    
    const logs = await this._getLogs();
    
    // Encontrar logs novos (não estão no cache)
    const cachedIds = new Set(this.cache.logs.map(log => log.id));
    const newLogs = logs.filter(log => !cachedIds.has(log.id));
    
    if (newLogs.length === 0) {
      console.log('[LiveDashboard] Nenhum log novo');
      return;
    }
    
    console.log('[LiveDashboard] Encontrados', newLogs.length, 'novos logs');
    
    // Adicionar novos logs no topo da tabela com animação
    const tbody = document.querySelector('#logs-table tbody');
    if (tbody) {
      newLogs.reverse().forEach(log => {
        const row = this._createLogRow(log);
        row.classList.add('log-entry-new'); // Classe para animação
        tbody.insertBefore(row, tbody.firstChild);
        
        // Remover classe de animação após 2s
        setTimeout(() => {
          row.classList.remove('log-entry-new');
        }, 2000);
      });
      
      // Limitar a 100 linhas visíveis para performance
      while (tbody.children.length > 100) {
        tbody.removeChild(tbody.lastChild);
      }
      
      // Atualizar contador de logs
      const totalLogsElement = document.querySelector('#logs-total-count');
      if (totalLogsElement) {
        totalLogsElement.textContent = logs.length;
      }
    }
    
    // Atualizar cache
    this.cache.logs = logs;
  }
  
  /**
   * Atualiza painel de Estatísticas (gráficos e números)
   */
  async _updateStatisticsPanel() {
    console.log('[LiveDashboard] Atualizando Statistics...');
    
    const logs = await this._getLogs();
    
    // Por módulo
    const byModule = {};
    logs.forEach(log => {
      byModule[log.module] = (byModule[log.module] || 0) + 1;
    });
    
    // Por nível
    const byLevel = { INFO: 0, WARN: 0, ERROR: 0, DEBUG: 0 };
    logs.forEach(log => {
      byLevel[log.level] = (byLevel[log.level] || 0) + 1;
    });
    
    // Por plataforma
    const byPlatform = {};
    logs.forEach(log => {
      if (log.metadata?.platform) {
        byPlatform[log.metadata.platform] = (byPlatform[log.metadata.platform] || 0) + 1;
      }
    });
    
    // Atualizar elementos no DOM
    this._updateStatCard('#stat-info-logs', byLevel.INFO);
    this._updateStatCard('#stat-warn-logs', byLevel.WARN);
    this._updateStatCard('#stat-error-logs', byLevel.ERROR);
    this._updateStatCard('#stat-debug-logs', byLevel.DEBUG);
    
    // Atualizar contadores por módulo
    Object.entries(byModule).forEach(([module, count]) => {
      this._updateStatCard(`#stat-module-${module}`, count);
    });
    
    // Atualizar contadores por plataforma
    Object.entries(byPlatform).forEach(([platform, count]) => {
      this._updateStatCard(`#stat-platform-${platform}`, count);
    });
  }
  
  /**
   * Atualiza painel de Usuários (lista de sessões ativas)
   */
  async _updateUsersPanel() {
    console.log('[LiveDashboard] Atualizando Users...');
    
    const logs = await this._getLogs();
    
    // Agrupar por usuário
    const userMap = {};
    logs.forEach(log => {
      if (!log.user) return;
      
      if (!userMap[log.user]) {
        userMap[log.user] = {
          email: log.user,
          firstSeen: log.timestamp,
          lastSeen: log.timestamp,
          operations: 0,
          errors: 0
        };
      }
      
      const user = userMap[log.user];
      user.operations++;
      if (log.level === 'ERROR') user.errors++;
      if (log.timestamp < user.firstSeen) user.firstSeen = log.timestamp;
      if (log.timestamp > user.lastSeen) user.lastSeen = log.timestamp;
    });
    
    // Determinar status (online se última ação < 5 min)
    const now = Date.now();
    const users = Object.values(userMap).map(user => ({
      ...user,
      status: (now - user.lastSeen) < 300000 ? 'online' : 'offline'
    }));
    
    // Atualizar apenas os status que mudaram
    users.forEach(user => {
      const cachedUser = this.cache.users.find(u => u.email === user.email);
      if (!cachedUser || cachedUser.status !== user.status) {
        this._updateUserStatus(user.email, user.status);
      }
      
      // Atualizar contadores se mudaram
      if (!cachedUser || cachedUser.operations !== user.operations) {
        this._updateUserOperations(user.email, user.operations);
      }
    });
    
    // Atualizar cache
    this.cache.users = users;
  }
  
  /**
   * Atualiza painel de Alertas (notificações não lidas)
   */
  async _updateAlertsPanel() {
    console.log('[LiveDashboard] Atualizando Alerts...');
    
    // Buscar notificações não lidas
    if (window.notificationManager) {
      const unreadNotifications = await window.notificationManager.getUnreadNotifications();
      
      // Verificar se há novas notificações
      const cachedIds = new Set(this.cache.notifications.map(n => n.id));
      const newNotifications = unreadNotifications.filter(n => !cachedIds.has(n.id));
      
      if (newNotifications.length > 0) {
        console.log('[LiveDashboard] Novas notificações:', newNotifications.length);
        
        // Adicionar ao painel com animação
        const alertsContainer = document.querySelector('#alerts-list');
        if (alertsContainer) {
          newNotifications.forEach(notification => {
            const alertElement = this._createAlertElement(notification);
            alertElement.classList.add('alert-new');
            alertsContainer.insertBefore(alertElement, alertsContainer.firstChild);
            
            setTimeout(() => {
              alertElement.classList.remove('alert-new');
            }, 2000);
          });
        }
        
        // Atualizar badge de alertas
        this._updateAlertBadge(unreadNotifications.length);
      }
      
      // Atualizar cache
      this.cache.notifications = unreadNotifications;
    }
  }
  
  // ===================================================================
  // HELPERS DE ATUALIZAÇÃO DE DOM
  // ===================================================================
  
  /**
   * Atualiza valor de um card com animação de contagem
   */
  _updateCardValue(selector, newValue, suffix = '') {
    const element = document.querySelector(selector);
    if (!element) return;
    
    const currentValue = parseInt(element.textContent) || 0;
    if (currentValue === newValue) return;
    
    // Animação de contagem
    this._animateCounter(element, currentValue, newValue, suffix);
  }
  
  /**
   * Anima contador de número aumentando/diminuindo
   */
  _animateCounter(element, from, to, suffix = '') {
    const duration = 500; // 0.5s
    const steps = 20;
    const increment = (to - from) / steps;
    let current = from;
    let step = 0;
    
    const timer = setInterval(() => {
      step++;
      current += increment;
      
      if (step >= steps) {
        element.textContent = to + suffix;
        clearInterval(timer);
      } else {
        element.textContent = Math.round(current) + suffix;
      }
    }, duration / steps);
  }
  
  /**
   * Destaca um card com animação
   */
  _highlightCard(selector, type = 'info') {
    const card = document.querySelector(selector)?.closest('.stat-card');
    if (!card) return;
    
    card.classList.add(`highlight-${type}`);
    setTimeout(() => {
      card.classList.remove(`highlight-${type}`);
    }, 1000);
  }
  
  /**
   * Atualiza card de estatística
   */
  _updateStatCard(selector, value) {
    const element = document.querySelector(selector);
    if (element) {
      const currentValue = parseInt(element.textContent) || 0;
      if (currentValue !== value) {
        this._animateCounter(element, currentValue, value);
      }
    }
  }
  
  /**
   * Cria linha de log para tabela
   */
  _createLogRow(log) {
    const row = document.createElement('tr');
    const levelClass = `badge-${log.level.toLowerCase()}`;
    
    row.innerHTML = `
      <td>${new Date(log.timestamp).toLocaleString('pt-BR')}</td>
      <td><span class="badge ${levelClass}">${log.level}</span></td>
      <td>${log.module}</td>
      <td>${log.message}</td>
      <td>${log.user || '-'}</td>
    `;
    
    return row;
  }
  
  /**
   * Atualiza status de usuário no painel
   */
  _updateUserStatus(email, status) {
    const userRow = document.querySelector(`[data-user-email="${email}"]`);
    if (userRow) {
      const statusBadge = userRow.querySelector('.user-status');
      if (statusBadge) {
        statusBadge.className = `user-status badge badge-${status === 'online' ? 'success' : 'error'}`;
        statusBadge.textContent = status === 'online' ? 'Online' : 'Offline';
      }
    }
  }
  
  /**
   * Atualiza contador de operações de usuário
   */
  _updateUserOperations(email, operations) {
    const userRow = document.querySelector(`[data-user-email="${email}"]`);
    if (userRow) {
      const opsElement = userRow.querySelector('.user-operations');
      if (opsElement) {
        this._animateCounter(opsElement, parseInt(opsElement.textContent) || 0, operations);
      }
    }
  }
  
  /**
   * Cria elemento de alerta
   */
  _createAlertElement(notification) {
    const div = document.createElement('div');
    div.className = `alert alert-${notification.type.toLowerCase()}`;
    div.innerHTML = `
      <div class="alert-header">
        <strong>${notification.title}</strong>
        <span class="alert-time">${new Date(notification.timestamp).toLocaleTimeString('pt-BR')}</span>
      </div>
      <div class="alert-body">${notification.message}</div>
    `;
    return div;
  }
  
  /**
   * Atualiza badge de alertas não lidos
   */
  _updateAlertBadge(count) {
    const badge = document.querySelector('#alerts-badge');
    if (badge) {
      badge.textContent = count;
      badge.style.display = count > 0 ? 'inline-block' : 'none';
    }
  }
  
  /**
   * Atualiza indicador de "última atualização"
   */
  _updateLastRefreshIndicator() {
    const indicator = document.querySelector('#last-refresh-time');
    if (indicator) {
      const now = new Date();
      indicator.textContent = now.toLocaleTimeString('pt-BR');
      
      // Animação de pulse
      indicator.classList.add('pulse');
      setTimeout(() => {
        indicator.classList.remove('pulse');
      }, 500);
    }
  }
  
  /**
   * Altera taxa de refresh
   */
  setRefreshRate(milliseconds) {
    this.refreshRate = milliseconds;
    
    // Reiniciar timer se estiver ativo
    if (this.updateInterval) {
      const currentPanel = this.currentPanel;
      this.stop();
      this.start(currentPanel);
    }
    
    console.log('[LiveDashboard] Refresh rate alterado para:', milliseconds, 'ms');
  }
}

// ===================================================================
// EXPORT
// ===================================================================

if (typeof window !== 'undefined') {
  window.LiveDashboard = LiveDashboard;
  console.log('[LiveDashboard] ✅ Exportado para window');
}

if (typeof globalThis !== 'undefined') {
  globalThis.LiveDashboard = LiveDashboard;
}
