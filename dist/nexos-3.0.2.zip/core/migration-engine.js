/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - MIGRATION ENGINE
 * Motor inteligente de migração de dados
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Funcionalidades:
 * - Migração automática de dados locais para SharePoint
 * - Conversão de formatos legados para novos schemas
 * - Sincronização incremental e idempotente
 * - Validação de integridade de dados
 * - Mapeamento automático de campos
 * - Tratamento de conflitos e duplicatas
 * - Relatórios detalhados de migração
 */

class MigrationEngine {
  constructor(graphClient, config = {}) {
    this.graphClient = graphClient;
    this.config = {
      batchSize: config.batchSize || 20,
      validateBeforeMigration: config.validateBeforeMigration !== false,
      skipDuplicates: config.skipDuplicates !== false,
      generateReport: config.generateReport !== false,
      ...config
    };
    
    this.migrationStatus = {
      inProgress: false,
      phase: null,
      progress: 0,
      total: 0,
      errors: [],
      warnings: [],
      migrated: 0,
      skipped: 0,
      failed: 0
    };
    
    this.log('info', '🔄 MigrationEngine inicializado');
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // LOGGING
  // ═══════════════════════════════════════════════════════════════════════════
  
  log(level, message, data = {}) {
    const prefix = '[MigrationEngine]';
    const color = {
      debug: '#888',
      info: '#00C2FF',
      warn: '#FFA502',
      error: '#FF4757',
      success: '#2ED573'
    }[level] || '#FFF';
    
    console.log(`%c${prefix} ${message}`, `color: ${color}`, data);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // MIGRAÇÃO PRINCIPAL
  // ═══════════════════════════════════════════════════════════════════════════
  
  async migrate() {
    if (this.migrationStatus.inProgress) {
      this.log('warn', '⚠️ Migração já em andamento');
      return this.migrationStatus;
    }
    
    this.migrationStatus.inProgress = true;
    this.migrationStatus.startedAt = Date.now();
    
    this.log('info', '═══════════════════════════════════════════════════════════════');
    this.log('info', '🚀 INICIANDO MIGRAÇÃO DE DADOS');
    this.log('info', '═══════════════════════════════════════════════════════════════');
    
    const report = {
      startedAt: Date.now(),
      phases: [],
      summary: {}
    };
    
    try {
      // FASE 1: Coleta de dados locais
      this.updatePhase('collect', 'Coletando dados locais...');
      const localData = await this.collectLocalData();
      report.phases.push({
        phase: 'collect',
        success: true,
        itemsFound: this.countTotalItems(localData),
        timestamp: Date.now()
      });
      
      // FASE 2: Validação
      if (this.config.validateBeforeMigration) {
        this.updatePhase('validate', 'Validando dados...');
        const validation = await this.validateData(localData);
        
        if (!validation.isValid) {
          throw new Error(`Validação falhou: ${validation.errors.length} erros encontrados`);
        }
        
        report.phases.push({
          phase: 'validate',
          success: true,
          warnings: validation.warnings.length,
          timestamp: Date.now()
        });
      }
      
      // FASE 3: Transformação
      this.updatePhase('transform', 'Transformando dados...');
      const transformedData = await this.transformData(localData);
      report.phases.push({
        phase: 'transform',
        success: true,
        itemsTransformed: this.countTotalItems(transformedData),
        timestamp: Date.now()
      });
      
      // FASE 4: Upload para SharePoint
      this.updatePhase('upload', 'Enviando para SharePoint...');
      const uploadResults = await this.uploadToSharePoint(transformedData);
      report.phases.push({
        phase: 'upload',
        success: true,
        migrated: this.migrationStatus.migrated,
        skipped: this.migrationStatus.skipped,
        failed: this.migrationStatus.failed,
        timestamp: Date.now()
      });
      
      // FASE 5: Verificação pós-migração
      this.updatePhase('verify', 'Verificando integridade...');
      const verification = await this.verifyMigration(transformedData, uploadResults);
      report.phases.push({
        phase: 'verify',
        success: verification.success,
        verified: verification.verified,
        issues: verification.issues.length,
        timestamp: Date.now()
      });
      
      // FASE 6: Limpeza e finalização
      this.updatePhase('finalize', 'Finalizando...');
      await this.finalizeMigration(localData);
      report.phases.push({
        phase: 'finalize',
        success: true,
        timestamp: Date.now()
      });
      
      // Gerar relatório
      report.completedAt = Date.now();
      report.duration = report.completedAt - report.startedAt;
      report.summary = {
        total: this.migrationStatus.total,
        migrated: this.migrationStatus.migrated,
        skipped: this.migrationStatus.skipped,
        failed: this.migrationStatus.failed,
        errors: this.migrationStatus.errors,
        warnings: this.migrationStatus.warnings
      };
      
      if (this.config.generateReport) {
        await this.saveReport(report);
      }
      
      this.log('success', '═══════════════════════════════════════════════════════════════');
      this.log('success', `✨ MIGRAÇÃO CONCLUÍDA EM ${report.duration}ms`);
      this.log('success', `📊 ${this.migrationStatus.migrated} migrados, ${this.migrationStatus.skipped} ignorados, ${this.migrationStatus.failed} falhas`);
      this.log('success', '═══════════════════════════════════════════════════════════════');
      
      return {
        success: true,
        report
      };
      
    } catch (error) {
      this.log('error', '═══════════════════════════════════════════════════════════════');
      this.log('error', '❌ MIGRAÇÃO FALHOU', { error: error.message });
      this.log('error', '═══════════════════════════════════════════════════════════════');
      
      report.completedAt = Date.now();
      report.duration = report.completedAt - report.startedAt;
      report.error = {
        message: error.message,
        stack: error.stack
      };
      
      await this.saveReport(report);
      
      return {
        success: false,
        error: error.message,
        report
      };
      
    } finally {
      this.migrationStatus.inProgress = false;
    }
  }
  
  updatePhase(phase, message) {
    this.migrationStatus.phase = phase;
    this.log('info', `📌 ${message}`);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // COLETA DE DADOS LOCAIS
  // ═══════════════════════════════════════════════════════════════════════════
  
  async collectLocalData() {
    this.log('debug', '📦 Coletando dados do chrome.storage e localStorage...');
    
    const data = {
      pedidos: [],
      logs: [],
      configuracoes: {},
      usuario: {},
      metadata: {
        collectedAt: Date.now()
      }
    };
    
    try {
      // 1. Coletar dados de picking (chrome.storage)
      const pickingData = await this.getStorageItem('nexos-picking-data');
      
      if (pickingData) {
        data.pedidos = this.extractPedidosFromPickingData(pickingData);
        this.log('success', `✅ ${data.pedidos.length} pedidos coletados`);
      }
      
      // 2. Coletar logs (localStorage)
      const logs = this.getLocalStorageItem('nexos-logs');
      
      if (logs) {
        data.logs = Array.isArray(logs) ? logs : [];
        this.log('success', `✅ ${data.logs.length} logs coletados`);
      }
      
      // 3. Coletar dados do usuário
      const userName = await this.getStorageItem('nexos-user-full-name');
      const userEmail = await this.getStorageItem('nexos-user-email');
      
      if (userName || userEmail) {
        data.usuario = {
          nome: userName,
          email: userEmail
        };
        this.log('success', `✅ Dados do usuário: ${userName || userEmail}`);
      }
      
      // 4. Coletar configurações
      const config = this.getLocalStorageItem('nexos-config');
      
      if (config) {
        data.configuracoes = config;
        this.log('success', '✅ Configurações coletadas');
      }
      
      // 5. Coletar dados do Google Sheets (se houver)
      const sheetsData = await this.getStorageItem('nexos-sheets-data');
      
      if (sheetsData) {
        data.sheetsData = sheetsData;
        this.log('success', '✅ Dados Google Sheets coletados');
      }
      
      this.migrationStatus.total = data.pedidos.length + data.logs.length;
      
      this.log('success', `📊 Total coletado: ${data.pedidos.length} pedidos, ${data.logs.length} logs`);
      
      return data;
      
    } catch (error) {
      this.log('error', 'Erro ao coletar dados', { error: error.message });
      throw error;
    }
  }
  
  extractPedidosFromPickingData(pickingData) {
    const pedidos = [];
    
    try {
      for (const loja in pickingData) {
        for (const pedidoNum in pickingData[loja]) {
          const pedidoData = pickingData[loja][pedidoNum];
          
          pedidos.push({
            _source: 'picking-data',
            loja,
            numeroPedido: pedidoNum,
            ...pedidoData
          });
        }
      }
    } catch (error) {
      this.log('error', 'Erro ao extrair pedidos', { error: error.message });
    }
    
    return pedidos;
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // VALIDAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  async validateData(data) {
    this.log('debug', '✔️ Validando dados...');
    
    const validation = {
      isValid: true,
      errors: [],
      warnings: []
    };
    
    // Validar pedidos
    for (const pedido of data.pedidos) {
      // Campos obrigatórios
      if (!pedido.loja) {
        validation.errors.push({
          type: 'missing_field',
          item: pedido,
          field: 'loja',
          message: 'Pedido sem número da loja'
        });
      }
      
      if (!pedido.numeroPedido) {
        validation.errors.push({
          type: 'missing_field',
          item: pedido,
          field: 'numeroPedido',
          message: 'Pedido sem número'
        });
      }
      
      // Validar formato de loja (deve ser numérico)
      if (pedido.loja && !/^\d+$/.test(pedido.loja.toString())) {
        validation.warnings.push({
          type: 'invalid_format',
          item: pedido,
          field: 'loja',
          message: `Formato de loja inválido: ${pedido.loja}`
        });
      }
    }
    
    // Validar logs
    for (const log of data.logs) {
      if (!log.timestamp && !log.data && !log.created_at) {
        validation.warnings.push({
          type: 'incomplete_log',
          item: log,
          message: 'Log sem timestamp'
        });
      }
    }
    
    validation.isValid = validation.errors.length === 0;
    
    if (validation.errors.length > 0) {
      this.log('error', `❌ ${validation.errors.length} erros de validação`, validation.errors);
    }
    
    if (validation.warnings.length > 0) {
      this.log('warn', `⚠️ ${validation.warnings.length} avisos`, validation.warnings);
    }
    
    if (validation.isValid) {
      this.log('success', '✅ Validação passou');
    }
    
    this.migrationStatus.errors.push(...validation.errors);
    this.migrationStatus.warnings.push(...validation.warnings);
    
    return validation;
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // TRANSFORMAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  async transformData(data) {
    this.log('debug', '🔄 Transformando dados para formato SharePoint...');
    
    const transformed = {
      pedidos: [],
      logs: [],
      notificacoes: [],
      auditLog: []
    };
    
    // Transformar pedidos
    for (const pedido of data.pedidos) {
      try {
        const transformedPedido = this.transformPedido(pedido);
        transformed.pedidos.push(transformedPedido);
      } catch (error) {
        this.log('error', `Erro ao transformar pedido ${pedido.numeroPedido}`, { error: error.message });
        this.migrationStatus.errors.push({
          type: 'transform_error',
          item: pedido,
          error: error.message
        });
      }
    }
    
    // Transformar logs
    for (const log of data.logs) {
      try {
        const transformedLog = this.transformLog(log);
        transformed.logs.push(transformedLog);
      } catch (error) {
        this.log('error', 'Erro ao transformar log', { error: error.message });
      }
    }
    
    // Criar registro de auditoria da migração
    transformed.auditLog.push({
      Acao: 'Migração de Dados',
      Usuario: data.usuario?.nome || 'Sistema',
      Detalhes: `Migração automática: ${transformed.pedidos.length} pedidos, ${transformed.logs.length} logs`,
      Timestamp: new Date().toISOString(),
      Origem: 'MigrationEngine'
    });
    
    this.log('success', `✅ Transformados: ${transformed.pedidos.length} pedidos, ${transformed.logs.length} logs`);
    
    return transformed;
  }
  
  transformPedido(pedido) {
    // Mapear campos antigos para novo schema SharePoint
    return {
      PedidoID: `${pedido.loja}-${pedido.numeroPedido}`,
      Loja: pedido.loja.toString(),
      NumeroPedido: pedido.numeroPedido.toString(),
      Status: this.mapStatus(pedido.status || pedido.estado),
      Plataforma: pedido.plataforma || pedido.platform || 'Desconhecido',
      OrderUUID: pedido.order_uuid || pedido.uuid || null,
      ValorSolicitacao: this.parseValor(pedido.valor_solicitacao || pedido.valor),
      NomeCliente: pedido.nome_cliente || pedido.customer_name || null,
      EnderecoCompleto: pedido.endereco_completo || pedido.address || null,
      TelefoneCliente: pedido.celular_cliente || pedido.telefone_cliente || pedido.phone || null,
      TrackingLink: pedido.link_rastreio || pedido.tracking_link || null,
      Usuario: pedido.usuario || 'Migrado',
      DataCriacao: this.parseDate(pedido.created_at || pedido.data_criacao) || new Date().toISOString(),
      DataAtualizacao: this.parseDate(pedido.updated_at || pedido.data_atualizacao) || new Date().toISOString(),
      Observacoes: this.buildObservacoes(pedido),
      _migrated: true,
      _migratedAt: new Date().toISOString(),
      _originalData: JSON.stringify(pedido)
    };
  }
  
  transformLog(log) {
    return {
      TipoLog: log.type || log.level || 'Info',
      Mensagem: log.message || log.msg || JSON.stringify(log),
      Dados: JSON.stringify(log.data || log),
      Usuario: log.usuario || log.user || 'Sistema',
      Timestamp: this.parseDate(log.timestamp || log.created_at) || new Date().toISOString(),
      _migrated: true
    };
  }
  
  mapStatus(status) {
    const statusMap = {
      'novo': 'Novo',
      'pendente': 'Pendente',
      'em_progresso': 'EmProgresso',
      'solicitado': 'Solicitado',
      'entregue': 'Entregue',
      'cancelado': 'Cancelado',
      'erro': 'Erro'
    };
    
    return statusMap[status?.toLowerCase()] || status || 'Novo';
  }
  
  parseValor(valor) {
    if (!valor) return null;
    
    if (typeof valor === 'number') return valor;
    
    // Remover símbolos de moeda e converter
    const cleaned = valor.toString().replace(/[R$\s]/g, '').replace(',', '.');
    const parsed = parseFloat(cleaned);
    
    return isNaN(parsed) ? null : parsed;
  }
  
  parseDate(date) {
    if (!date) return null;
    
    try {
      const d = new Date(date);
      return isNaN(d.getTime()) ? null : d.toISOString();
    } catch {
      return null;
    }
  }
  
  buildObservacoes(pedido) {
    const parts = ['Dados migrados da versão local'];
    
    if (pedido.observacoes) {
      parts.push(pedido.observacoes);
    }
    
    if (pedido.notas) {
      parts.push(pedido.notas);
    }
    
    return parts.join('; ');
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // UPLOAD PARA SHAREPOINT
  // ═══════════════════════════════════════════════════════════════════════════
  
  async uploadToSharePoint(data) {
    this.log('debug', '☁️ Enviando dados para SharePoint...');
    
    const results = {
      pedidos: [],
      logs: [],
      auditLog: []
    };
    
    // Upload de pedidos em lotes
    if (data.pedidos.length > 0) {
      results.pedidos = await this.uploadInBatches(
        'Nexos_StatusPedidos',
        data.pedidos,
        'pedidos'
      );
    }
    
    // Upload de logs em lotes
    if (data.logs.length > 0) {
      results.logs = await this.uploadInBatches(
        'Nexos_Logs',
        data.logs,
        'logs'
      );
    }
    
    // Upload de audit log
    if (data.auditLog.length > 0) {
      results.auditLog = await this.uploadInBatches(
        'Nexos_AuditLog',
        data.auditLog,
        'audit'
      );
    }
    
    return results;
  }
  
  async uploadInBatches(listName, items, type) {
    this.log('info', `📤 Enviando ${items.length} ${type} para ${listName}...`);
    
    const results = [];
    const batches = this.createBatches(items, this.config.batchSize);
    
    for (let i = 0; i < batches.length; i++) {
      const batch = batches[i];
      
      this.log('debug', `Batch ${i + 1}/${batches.length}: ${batch.length} itens`);
      
      const batchResults = await this.uploadBatch(listName, batch);
      results.push(...batchResults);
      
      // Atualizar progresso
      this.migrationStatus.progress = results.length;
      
      // Pequeno delay entre batches para não sobrecarregar
      if (i < batches.length - 1) {
        await this.sleep(500);
      }
    }
    
    this.log('success', `✅ ${results.filter(r => r.success).length}/${items.length} ${type} enviados`);
    
    return results;
  }
  
  async uploadBatch(listName, items) {
    const results = [];
    
    for (const item of items) {
      try {
        // Verificar duplicata
        if (this.config.skipDuplicates) {
          const exists = await this.checkDuplicate(listName, item);
          
          if (exists) {
            this.log('debug', `⏭️ Ignorando duplicata: ${item.PedidoID || item.Mensagem}`);
            this.migrationStatus.skipped++;
            results.push({
              success: true,
              skipped: true,
              item
            });
            continue;
          }
        }
        
        // Criar item no SharePoint
        const created = await this.graphClient.createListItem(listName, item);
        
        this.migrationStatus.migrated++;
        results.push({
          success: true,
          item,
          sharePointId: created.id
        });
        
      } catch (error) {
        this.log('error', `❌ Erro ao enviar item`, { error: error.message, item });
        
        this.migrationStatus.failed++;
        this.migrationStatus.errors.push({
          type: 'upload_error',
          listName,
          item,
          error: error.message
        });
        
        results.push({
          success: false,
          item,
          error: error.message
        });
      }
    }
    
    return results;
  }
  
  async checkDuplicate(listName, item) {
    try {
      // Verificar por PedidoID (para pedidos)
      if (item.PedidoID) {
        const existing = await this.graphClient.getListItems(listName, {
          filter: `PedidoID eq '${item.PedidoID}'`,
          top: 1,
          cache: false
        });
        
        return existing.length > 0;
      }
      
      return false;
      
    } catch (error) {
      this.log('warn', 'Erro ao verificar duplicata, prosseguindo...', { error: error.message });
      return false;
    }
  }
  
  createBatches(items, batchSize) {
    const batches = [];
    
    for (let i = 0; i < items.length; i += batchSize) {
      batches.push(items.slice(i, i + batchSize));
    }
    
    return batches;
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // VERIFICAÇÃO PÓS-MIGRAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  async verifyMigration(transformedData, uploadResults) {
    this.log('debug', '🔍 Verificando integridade da migração...');
    
    const verification = {
      success: true,
      verified: 0,
      issues: []
    };
    
    // Contar itens migrados com sucesso
    const successfulPedidos = uploadResults.pedidos.filter(r => r.success && !r.skipped).length;
    const successfulLogs = uploadResults.logs.filter(r => r.success && !r.skipped).length;
    
    verification.verified = successfulPedidos + successfulLogs;
    
    // Verificar se há discrepâncias
    const expectedPedidos = transformedData.pedidos.length;
    const expectedLogs = transformedData.logs.length;
    
    if (successfulPedidos < expectedPedidos) {
      verification.issues.push({
        type: 'incomplete_migration',
        category: 'pedidos',
        expected: expectedPedidos,
        actual: successfulPedidos,
        missing: expectedPedidos - successfulPedidos
      });
    }
    
    if (successfulLogs < expectedLogs) {
      verification.issues.push({
        type: 'incomplete_migration',
        category: 'logs',
        expected: expectedLogs,
        actual: successfulLogs,
        missing: expectedLogs - successfulLogs
      });
    }
    
    verification.success = verification.issues.length === 0;
    
    if (verification.success) {
      this.log('success', `✅ Verificação OK: ${verification.verified} itens confirmados`);
    } else {
      this.log('warn', `⚠️ ${verification.issues.length} problemas encontrados`, verification.issues);
    }
    
    return verification;
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // FINALIZAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  async finalizeMigration(localData) {
    this.log('debug', '🏁 Finalizando migração...');
    
    try {
      // Marcar dados locais como migrados (não deletar, apenas marcar)
      await this.markLocalDataAsMigrated();
      
      // Salvar metadados da migração
      await this.saveMigrationMetadata({
        completedAt: Date.now(),
        totalMigrated: this.migrationStatus.migrated,
        totalSkipped: this.migrationStatus.skipped,
        totalFailed: this.migrationStatus.failed
      });
      
      this.log('success', '✅ Migração finalizada');
      
    } catch (error) {
      this.log('error', 'Erro ao finalizar migração', { error: error.message });
      throw error;
    }
  }
  
  async markLocalDataAsMigrated() {
    await this.saveToStorage('nexos-data-migrated', {
      migrated: true,
      timestamp: Date.now()
    });
  }
  
  async saveMigrationMetadata(metadata) {
    await this.saveToStorage('nexos-migration-metadata', metadata);
  }
  
  async saveReport(report) {
    this.log('info', '📄 Salvando relatório de migração...');
    
    try {
      await this.saveToStorage('nexos-migration-report', report);
      
      this.log('success', '✅ Relatório salvo');
      
    } catch (error) {
      this.log('error', 'Erro ao salvar relatório', { error: error.message });
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // UTILITÁRIOS
  // ═══════════════════════════════════════════════════════════════════════════
  
  countTotalItems(data) {
    let count = 0;
    
    if (data.pedidos) count += data.pedidos.length;
    if (data.logs) count += data.logs.length;
    if (data.notificacoes) count += data.notificacoes.length;
    if (data.auditLog) count += data.auditLog.length;
    
    return count;
  }
  
  async getStorageItem(key) {
    try {
      const result = await chrome.storage.local.get([key]);
      return result[key] || null;
    } catch (error) {
      return null;
    }
  }
  
  getLocalStorageItem(key) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      return null;
    }
  }
  
  async saveToStorage(key, value) {
    try {
      await chrome.storage.local.set({ [key]: value });
    } catch (error) {
      try {
        localStorage.setItem(key, JSON.stringify(value));
      } catch (e) {
        this.log('error', `Falha ao salvar ${key}`, { error: e.message });
      }
    }
  }
  
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  getStatus() {
    return { ...this.migrationStatus };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════════════════════════════════════

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { MigrationEngine };
}

if (typeof window !== 'undefined') {
  window.MigrationEngine = MigrationEngine;
}
