/**
 * ════════════════════════════════════════════════════════════════════════════
 * PICKING LOCK MANAGER - Sistema de Travamento de Pedidos
 * ════════════════════════════════════════════════════════════════════════════
 * 
 * Responsável por:
 * - Travar pedidos durante edição/envio
 * - Impedir conflitos entre usuários
 * - Auto-unlock após timeout
 * - Notificações de locks ativos
 */

class PickingLockManager {
  constructor(stateManager) {
    this.stateManager = stateManager;
    this.LOCK_TIMEOUT = 5 * 60 * 1000; // 5 minutos
    
    // Lock Manager inicializado silenciosamente
  }
  
  /**
   * Tentar travar um pedido
   * @returns {Object} { success: boolean, lock?: LockInfo, reason?: string }
   */
  async tryLock(pedidoId, action = 'editing') {
    const currentUser = this.stateManager.getCurrentUser();
    
    if (!currentUser) {
      return {
        success: false,
        reason: 'Usuário não autenticado'
      };
    }
    
    // Verificar se já está travado
    const existingLock = this.stateManager.state.locks[pedidoId];
    
    if (existingLock) {
      // Verificar se é o mesmo usuário
      if (existingLock.userId === currentUser.id) {
        // Renovar lock
        existingLock.timestamp = Date.now();
        existingLock.action = action;
        await this.stateManager.saveToStorage();
        
        console.log(`[PickingLock] 🔄 Lock renovado: ${pedidoId}`);
        
        return {
          success: true,
          lock: existingLock
        };
      }
      
      // Verificar se expirou
      const elapsed = Date.now() - existingLock.timestamp;
      if (elapsed > this.LOCK_TIMEOUT) {
        // Lock expirado, pode travar
        console.log(`[PickingLock] ⏰ Lock expirado removido: ${pedidoId}`);
      } else {
        // Outro usuário está usando
        const remainingMin = Math.ceil((this.LOCK_TIMEOUT - elapsed) / 60000);
        
        return {
          success: false,
          reason: `Pedido em uso por ${existingLock.userName}`,
          lock: existingLock,
          remainingMinutes: remainingMin
        };
      }
    }
    
    // Criar novo lock
    const lock = {
      pedidoId,
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      action,
      timestamp: Date.now(),
      expiresAt: Date.now() + this.LOCK_TIMEOUT
    };
    
    this.stateManager.state.locks[pedidoId] = lock;
    await this.stateManager.saveToStorage();
    
    // Adicionar evento na timeline
    this.stateManager.addTimelineEvent(pedidoId, {
      type: 'locked',
      user: currentUser.name,
      message: `Pedido travado para ${action}`
    });
    
    this.stateManager.notifyListeners('order_locked', { pedidoId, lock });
    
    console.log(`[PickingLock] ✅ Lock criado: ${pedidoId} por ${currentUser.name}`);
    
    return {
      success: true,
      lock
    };
  }
  
  /**
   * Destravar um pedido
   */
  async unlock(pedidoId, force = false) {
    const currentUser = this.stateManager.getCurrentUser();
    const existingLock = this.stateManager.state.locks[pedidoId];
    
    if (!existingLock) {
      console.log(`[PickingLock] ℹ️ Pedido não estava travado: ${pedidoId}`);
      return { success: true };
    }
    
    // Verificar permissão
    if (!force && currentUser && existingLock.userId !== currentUser.id) {
      return {
        success: false,
        reason: 'Você não tem permissão para destravar este pedido'
      };
    }
    
    // Remover lock
    delete this.stateManager.state.locks[pedidoId];
    await this.stateManager.saveToStorage();
    
    // Adicionar evento na timeline
    this.stateManager.addTimelineEvent(pedidoId, {
      type: 'unlocked',
      user: currentUser?.name || 'Sistema',
      message: force ? 'Destravado forçadamente' : 'Pedido destravado'
    });
    
    this.stateManager.notifyListeners('order_unlocked', { pedidoId });
    
    console.log(`[PickingLock] 🔓 Lock removido: ${pedidoId}`);
    
    return { success: true };
  }
  
  /**
   * Verificar se um pedido está travado
   */
  isLocked(pedidoId) {
    const lock = this.stateManager.state.locks[pedidoId];
    
    if (!lock) return false;
    
    // Verificar se expirou
    const elapsed = Date.now() - lock.timestamp;
    if (elapsed > this.LOCK_TIMEOUT) {
      return false;
    }
    
    return true;
  }
  
  /**
   * Obter informações do lock
   */
  getLockInfo(pedidoId) {
    const lock = this.stateManager.state.locks[pedidoId];
    
    if (!lock) return null;
    
    // Verificar se expirou
    const elapsed = Date.now() - lock.timestamp;
    if (elapsed > this.LOCK_TIMEOUT) {
      return null;
    }
    
    return {
      ...lock,
      elapsed,
      remaining: this.LOCK_TIMEOUT - elapsed,
      remainingMinutes: Math.ceil((this.LOCK_TIMEOUT - elapsed) / 60000)
    };
  }
  
  /**
   * Verificar se o usuário atual possui o lock
   */
  hasLock(pedidoId) {
    const currentUser = this.stateManager.getCurrentUser();
    if (!currentUser) return false;
    
    const lock = this.getLockInfo(pedidoId);
    if (!lock) return false;
    
    return lock.userId === currentUser.id;
  }
  
  /**
   * Renovar lock automaticamente
   */
  async renewLock(pedidoId) {
    const lock = this.stateManager.state.locks[pedidoId];
    
    if (!lock) {
      return { success: false, reason: 'Lock não existe' };
    }
    
    const currentUser = this.stateManager.getCurrentUser();
    if (!currentUser || lock.userId !== currentUser.id) {
      return { success: false, reason: 'Sem permissão' };
    }
    
    lock.timestamp = Date.now();
    lock.expiresAt = Date.now() + this.LOCK_TIMEOUT;
    
    await this.stateManager.saveToStorage();
    
    console.log(`[PickingLock] 🔄 Lock renovado: ${pedidoId}`);
    
    return { success: true, lock };
  }
  
  /**
   * Obter todos os locks ativos
   */
  getActiveLocks() {
    const now = Date.now();
    const active = {};
    
    for (const [pedidoId, lock] of Object.entries(this.stateManager.state.locks)) {
      const elapsed = now - lock.timestamp;
      if (elapsed <= this.LOCK_TIMEOUT) {
        active[pedidoId] = {
          ...lock,
          elapsed,
          remaining: this.LOCK_TIMEOUT - elapsed
        };
      }
    }
    
    return active;
  }
  
  /**
   * Limpar todos os locks do usuário atual
   */
  async clearUserLocks() {
    const currentUser = this.stateManager.getCurrentUser();
    if (!currentUser) return;
    
    let cleared = 0;
    
    for (const [pedidoId, lock] of Object.entries(this.stateManager.state.locks)) {
      if (lock.userId === currentUser.id) {
        await this.unlock(pedidoId);
        cleared++;
      }
    }
    
    console.log(`[PickingLock] 🧹 ${cleared} locks do usuário removidos`);
    
    return cleared;
  }
  
  /**
   * Mostrar aviso de lock (UI helper)
   */
  showLockWarning(lockInfo) {
    if (typeof window.NexosUI === 'undefined') return;
    
    const message = `Este pedido está sendo processado por ${lockInfo.userName}. Aguarde ${lockInfo.remainingMinutes} minuto(s) ou force o destravamento.`;
    
    window.NexosUI.showToast(message, 'warning', 5000);
  }
  
  /**
   * Confirmar force unlock (UI helper)
   */
  async confirmForceUnlock(pedidoId, lockInfo) {
    if (typeof window.showCentralConfirm === 'undefined') {
      return window.confirm(`Forçar destravamento do pedido em uso por ${lockInfo.userName}?`);
    }
    
    return await window.showCentralConfirm(
      `Este pedido está travado por ${lockInfo.userName} há ${Math.floor(lockInfo.elapsed / 60000)} minuto(s). Deseja forçar o destravamento?`,
      {
        title: '⚠️ Forçar Destravamento',
        confirmText: 'Forçar',
        cancelText: 'Cancelar'
      }
    );
  }
}

// Exportar
window.PickingLockManager = PickingLockManager;

console.log('[PickingLock] 🔒 Módulo carregado');
