/**
 * 🔐 NEXOS ADMIN POPUP - LAUNCHER SEGURO
 * 
 * Funcionalidade:
 * - Botão flutuante ⚙️ para abrir admin
 * - Verificação de acesso antes de abrir
 * - Popup isolado com controle de role
 * - Logging automático de abertura
 */

class AdminPanelLauncher {
    constructor() {
        this.buttonId = 'nexos-admin-button';
        this.popupWidth = 1400;
        this.popupHeight = 900;
        this.POPUP_KEY = 'nexos-admin-popup-window';
    }

    // ═════════════════════════════════════════════════════════════
    // INICIALIZAÇÃO
    // ═════════════════════════════════════════════════════════════

    async init() {
        console.log('[ADMIN-LAUNCHER] ⚠️ Botão admin desabilitado por padrão');
        
        // ✅ Remover botão se já existir no DOM
        const existingButton = document.getElementById(this.buttonId);
        if (existingButton) {
            existingButton.remove();
            console.log('[ADMIN-LAUNCHER] 🗑️ Botão admin removido do DOM');
        }
        
        // ❌ DESABILITADO: Botão admin não será criado automaticamente
        // Para habilitar, descomente o código abaixo:
        
        /*
        try {
            // Verificar acesso
            const hasAccess = await this.checkAccess();
            
            if (hasAccess) {
                // Criar botão flutuante
                this.createFloatingButton();
                console.log('[ADMIN-LAUNCHER] ✅ Botão admin criado');
            } else {
                console.log('[ADMIN-LAUNCHER] Usuário sem permissão para admin');
            }
        } catch (e) {
            console.error('[ADMIN-LAUNCHER] Erro:', e);
        }
        */
    }

    // ═════════════════════════════════════════════════════════════
    // VERIFICAÇÃO DE ACESSO
    // ═════════════════════════════════════════════════════════════

    async checkAccess() {
        try {
            // Se temos o módulo de controle de acesso
            if (typeof AdminAccessControl !== 'undefined') {
                return await AdminAccessControl.canAccessAdmin();
            }

            // Fallback: verificar do storage
            const stored = await chrome.storage.local.get('nexos-current-user');
            const user = stored['nexos-current-user'];
            
            if (!user) return false;
            
            const adminRoles = ['admin', 'gerente', 'supervisor'];
            return adminRoles.includes(user.role?.toLowerCase());
        } catch (e) {
            console.error('[ADMIN-LAUNCHER] Erro ao verificar acesso:', e);
            return false;
        }
    }

    // ═════════════════════════════════════════════════════════════
    // BOTÃO FLUTUANTE
    // ═════════════════════════════════════════════════════════════

    createFloatingButton() {
        // Não criar se já existe
        if (document.getElementById(this.buttonId)) {
            return;
        }

        const button = document.createElement('button');
        button.id = this.buttonId;
        button.title = 'Painel Admin Nexos (Admin/Gerente)';
        button.innerHTML = '⚙️';
        
        button.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 56px;
            height: 56px;
            border-radius: 50%;
            border: none;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-size: 24px;
            cursor: pointer;
            z-index: 2147483647;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        `;

        button.addEventListener('mouseenter', () => {
            button.style.transform = 'scale(1.1)';
            button.style.boxShadow = '0 6px 20px rgba(102, 126, 234, 0.6)';
        });

        button.addEventListener('mouseleave', () => {
            button.style.transform = 'scale(1)';
            button.style.boxShadow = '0 4px 12px rgba(102, 126, 234, 0.4)';
        });

        button.addEventListener('click', () => this.openAdminPanel());

        document.body.appendChild(button);
        console.log('[ADMIN-LAUNCHER] Botão adicionado ao DOM');
    }

    // ═════════════════════════════════════════════════════════════
    // ABRIR PAINEL
    // ═════════════════════════════════════════════════════════════

    async openAdminPanel() {
        try {
            console.log('[ADMIN-LAUNCHER] Abrindo painel admin...');

            // Verificar acesso novamente
            const hasAccess = await this.checkAccess();
            
            if (!hasAccess) {
                alert('❌ Você não tem permissão para acessar o painel admin.\nAcesso restrito a Administradores e Gerentes.');
                return;
            }

            // Registrar abertura
            if (typeof AdminAccessControl !== 'undefined') {
                await AdminAccessControl.auditAction(
                    'ADMIN_PANEL_OPENED',
                    'Painel admin aberto',
                    { timestamp: new Date().toISOString() }
                );
            }

            // Obter URL do arquivo admin.html
            const adminUrl = chrome.runtime.getURL('admin.html');

            // Tentar usar chrome.windows (se disponível)
            if (chrome.windows) {
                chrome.windows.create({
                    url: adminUrl,
                    type: 'panel',
                    width: this.popupWidth,
                    height: this.popupHeight,
                    focused: true
                }, (window) => {
                    if (chrome.runtime.lastError) {
                        console.warn('[ADMIN-LAUNCHER] Erro ao criar janela:', chrome.runtime.lastError);
                        this.openAdminPopup(adminUrl);
                    } else {
                        console.log('[ADMIN-LAUNCHER] ✅ Janela admin aberta');
                    }
                });
            } else {
                // Fallback: abrir em popup/tab
                this.openAdminPopup(adminUrl);
            }

        } catch (e) {
            console.error('[ADMIN-LAUNCHER] Erro ao abrir painel:', e);
            alert('❌ Erro ao abrir painel admin: ' + e.message);
        }
    }

    openAdminPopup(url) {
        const features = `
            width=${this.popupWidth},
            height=${this.popupHeight},
            left=100,
            top=100,
            menubar=no,
            toolbar=no,
            location=no,
            status=no,
            scrollbars=yes
        `.replace(/\s+/g, '');

        window.open(url, 'NexosAdmin', features);
        console.log('[ADMIN-LAUNCHER] ✅ Popup admin aberto');
    }
}

// ═════════════════════════════════════════════════════════════
// AUTO-INIT
// ═════════════════════════════════════════════════════════════

const adminLauncher = new AdminPanelLauncher();

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        // Esperar um pouco para tudo estar carregado
        setTimeout(() => adminLauncher.init(), 2000);
    });
} else {
    setTimeout(() => adminLauncher.init(), 2000);
}

// Module loaded silently
