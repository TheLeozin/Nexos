/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - PICKING SHAREPOINT MANAGER
 * Gerencia armazenamento de pedidos extraídos no SharePoint com travamento
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * FUNCIONALIDADES:
 * - Salva pedidos extraídos do Picking diretamente no SharePoint
 * - Sistema de travamento para evitar duplicação
 * - Validação de dados antes de salvar
 * - Geração de ID único para cada pedido
 * - Integração com Graph API
 * 
 * @version 1.0.0
 * @date 2026-01-06
 */

(function() {
  'use strict';

  // ═══════════════════════════════════════════════════════════════════════════
  // CONFIGURAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  const CONFIG = {
    LIST_NAME: 'Nexos_StatusPedidos', // ✅ Nome correto da lista no SharePoint
    LOCK_TIMEOUT_MINUTES: 10, // Timeout automático de bloqueio (10 minutos)
    RETRY_ATTEMPTS: 3,
    RETRY_DELAY_MS: 1000,
    AUTO_LOCK_ON_EXTRACT: true // Trava automaticamente após extração
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // CLASSE PRINCIPAL
  // ═══════════════════════════════════════════════════════════════════════════

  class PickingSharePointManager {
    constructor() {
      this.graphClient = null;
      this.currentUser = null;
      this.isInitialized = false;
    }

    /**
     * Inicializa o manager com cliente Graph API
     */
    async initialize() {
      try {
        
        // Aguardar graph-client-init.js carregar
        if (typeof window !== 'undefined' && !window.graphClient) {
          
          await new Promise((resolve) => {
            let timeout;
            
            const onReady = () => {
              clearTimeout(timeout);
              resolve();
            };
            
            // Esperar pelo evento
            window.addEventListener('nexos-graphclient-ready', onReady, { once: true });
            
            // Timeout de 15 segundos
            timeout = setTimeout(() => {
              window.removeEventListener('nexos-graphclient-ready', onReady);
              resolve();
            }, 15000);
            
            // Se já estiver pronto, resolver imediatamente
            if (window.graphClient) {
              window.removeEventListener('nexos-graphclient-ready', onReady);
              clearTimeout(timeout);
              resolve();
            }
          });
        }
        
        // Obter Graph Client (usa o mesmo que já está configurado)
        if (typeof window !== 'undefined' && window.graphClient) {
          this.graphClient = window.graphClient;
        } else if (typeof chrome !== 'undefined' && chrome.runtime) {
          // Tentar obter via background
          try {
            const response = await chrome.runtime.sendMessage({ action: 'getGraphClient' });
            if (response && response.success) {
              this.graphClient = response.graphClient;
            }
          } catch (e) {
            console.warn('[PickingSharePoint] Não foi possível obter via chrome.runtime:', e.message);
          }
        }

        if (!this.graphClient) {
          console.warn('[PickingSharePoint] ⚠️ Graph Client não disponível - modo offline');
          console.warn('[PickingSharePoint] ⚠️ Salvamento no SharePoint desabilitado');
          console.warn('[PickingSharePoint] ℹ️ Pedidos serão salvos apenas localmente');
          console.warn('[PickingSharePoint] ℹ️ Pedidos serão salvos apenas localmente');
          
          // Não lançar erro - apenas avisar que está em modo offline
          this.isInitialized = false;
          return false;
        }

        // Obter usuário atual
        this.currentUser = await this.getCurrentUser();
        
        // ✅ VALIDAÇÃO: Verificar se lista existe
        try {
          const listInfo = await this.graphClient.getListByName(CONFIG.LIST_NAME);
        } catch (error) {
          console.error('[PickingSharePoint] ❌ Lista não encontrada:', CONFIG.LIST_NAME);
          console.error('[PickingSharePoint] 💡 Tente criar a lista no SharePoint ou verifique o nome');
          
          // Listar todas as listas disponíveis
          try {
            const allLists = await this.graphClient.getLists();
          } catch (e) {
            console.error('[PickingSharePoint] ❌ Erro ao listar listas:', e.message);
          }
        }
        
        this.isInitialized = true;
        
        return true;
      } catch (error) {
        console.error('[PickingSharePoint] ❌ Erro ao inicializar:', error);
        this.isInitialized = false;
        return false;
      }
    }

    /**
     * Obtém informações do usuário atual
     */
    async getCurrentUser() {
      try {
        // 1. Tentar obter do window (graph-client-init.js já carregou)
        if (typeof window !== 'undefined' && window.currentUser) {
          return {
            email: window.currentUser.userPrincipalName || window.currentUser.mail,
            name: window.currentUser.displayName,
            id: window.currentUser.id
          };
        }

        // 2. Tentar obter do storage (cache)
        const stored = await this.getFromStorage('nexos-current-user');
        if (stored && stored.email) {
          return stored;
        }

        // 3. Tentar obter via AuthHelper
        if (window.authHelper) {
          const user = await window.authHelper.getCurrentUser();
          if (user && user.userPrincipalName) {
            const userObj = {
              email: user.userPrincipalName || user.mail,
              name: user.displayName,
              id: user.id
            };
            // Salvar no storage para próximas vezes
            await this.saveToStorage('nexos-current-user', userObj);
            return userObj;
          }
        }

        // 4. Fallback: retornar usuário padrão
        console.warn('[PickingSharePoint] ⚠️ Não foi possível obter usuário, usando fallback');
        return { email: 'operador@gpabr.com', name: 'Operador' };
      } catch (error) {
        console.error('[PickingSharePoint] ❌ Erro ao obter usuário:', error);
        return { email: 'operador@gpabr.com', name: 'Operador' };
      }
    }

    /**
     * Obtém cargo/role do usuário atual
     */
    async getUserRole() {
      try {
        // Tentar obter do storage primeiro
        const stored = await this.getFromStorage('nexos-user-role');
        if (stored) {
          return stored;
        }

        // Buscar do sistema de permissões
        if (typeof window !== 'undefined' && window.UserRoleManager) {
          const roleManager = new window.UserRoleManager();
          const role = await roleManager.getUserRole(this.currentUser?.email);
          
          // Salvar no storage
          await this.saveToStorage('nexos-user-role', role);
          return role;
        }

        // Fallback: tentar obter do chrome.storage
        const userData = await this.getFromStorage('nexos-user-data');
        if (userData && userData.role) {
          return userData.role;
        }

        return 'operador'; // Default
      } catch (error) {
        console.error('[PickingSharePoint] Erro ao obter role:', error);
        return 'operador';
      }
    }

    /**
     * Salva pedido extraído no SharePoint
     * @param {Object} pedidoData - Dados do pedido extraído
     * @returns {Promise<Object>} Resultado da operação
     */
    async savePedidoExtraido(pedidoData) {
      // ═══════════════════════════════════════════════════════════════
      // AUTO-LOGIN: Detecta falta de autenticação e solicita login
      // ═══════════════════════════════════════════════════════════════
      if (window.autoLoginHandler) {
        return await window.autoLoginHandler.withAutoLogin(
          () => this._savePedidoExtraidoInternal(pedidoData),
          'Salvar pedido no SharePoint'
        );
      } else {
        // Fallback se auto-login não disponível
        return await this._savePedidoExtraidoInternal(pedidoData);
      }
    }

    /**
     * Método interno de salvamento (não usar diretamente)
     */
    async _savePedidoExtraidoInternal(pedidoData) {
      // ═══════════════════════════════════════════════════════════════
      // TIMEOUT GLOBAL: 5 SEGUNDOS PARA TODO O SALVAMENTO
      // ═══════════════════════════════════════════════════════════════
      
      const timeoutPromise = new Promise((resolve) => {
        setTimeout(() => {
          console.warn('[PickingSharePoint] ⏰ Timeout de 5s atingido - retornando modo offline');
          resolve({
            success: true, // TRUE porque salvamento local já foi feito
            offline: true,
            message: 'SharePoint está demorando - pedido salvo localmente',
            pedidoID: pedidoData.pedido || `TIMEOUT-${Date.now()}`,
            locked: false,
            timeout: true
          });
        }, 5000); // 5 segundos
      });

      const savePromise = (async () => {
        try {

          if (!this.isInitialized) {
            
            // Timeout na inicialização também
            const initTimeoutPromise = new Promise((resolve) => {
              setTimeout(() => resolve(false), 3000); // 3 segundos para init
            });
            
            const initialized = await Promise.race([
              this.initialize(),
              initTimeoutPromise
            ]);
            
            // Se não conseguir inicializar, retornar resultado offline
            if (!initialized) {
              console.warn('[PickingSharePoint] ⚠️ Inicialização falhou - modo offline');
              return {
                success: true, // TRUE porque salvamento local já foi feito
                offline: true,
                message: 'SharePoint não disponível - pedido salvo localmente',
                pedidoID: pedidoData.pedido || `OFFLINE-${Date.now()}`,
                locked: false
              };
            }
          }

          // 1. Validar dados obrigatórios
          const validation = this.validatePedidoData(pedidoData);
          if (!validation.isValid) {
            return {
              success: false,
              error: 'Dados inválidos',
              details: validation.errors
            };
          }

          // 2. Gerar ID único do pedido
          const pedidoID = this.generatePedidoID(pedidoData);

          // 3. SKIP verificação de existência (pode demorar e travar)
          // TODO: Implementar verificação em background após salvar
          
          /* DESABILITADO TEMPORARIAMENTE - PODE TRAVAR
          const exists = await this.checkPedidoExists(pedidoID);
          if (exists.exists) {
            console.warn('[PickingSharePoint] ⚠️ Pedido já existe:', pedidoID);
            return {
              success: false,
              error: 'Pedido já existe',
              pedidoID,
              existingData: exists.data
            };
          }
          */

          // 4. Preparar dados para SharePoint (COM TRAVAMENTO AUTOMÁTICO)
          const sharePointData = this.prepareSharePointData(pedidoData, pedidoID, true); // true = auto-lock

          // 5. Tentar salvar no SharePoint com retries
        const result = await this.saveWithRetry(sharePointData);

        if (result.success) {
          
          // Registrar no log
          this.logAction('PEDIDO_EXTRAIDO_SALVO', {
            pedidoID,
            nomeCliente: pedidoData.nome_cliente,
            status: pedidoData.status,
            bloqueado: true,
            bloqueadoPor: this.currentUser?.email,
            sharePointItemId: result.itemId
          });
          
          return {
            success: true,
            pedidoID,
            itemId: result.itemId,
            locked: true,
            lockedBy: this.currentUser?.email,
            lockToken: result.lockToken,
            message: 'Pedido salvo e travado com sucesso no SharePoint'
          };
        } else {
          // SharePoint falhou, mas salvamento local já foi feito
          console.warn('[PickingSharePoint] ⚠️ SharePoint falhou, mas pedido salvo localmente');
          console.warn('[PickingSharePoint] ⚠️ Erro:', result.error);
          
          return {
            success: true, // TRUE porque salvou localmente
            offline: true,
            pedidoID,
            locked: false,
            error: result.error,
            message: 'SharePoint não disponível - pedido salvo apenas localmente'
          };
        }

        } catch (error) {
          console.error('[PickingSharePoint] ❌ Erro crítico ao salvar pedido:', error);
          return {
            success: true, // TRUE porque salvamento local já foi feito antes
            offline: true,
            error: error.message,
            stack: error.stack,
            pedidoID: pedidoData.pedido || `OFFLINE-${Date.now()}`,
            message: 'SharePoint não disponível - pedido salvo localmente'
          };
        }
      })(); // Fim do savePromise

      // ═══════════════════════════════════════════════════════════════
      // RACE: Timeout vs Salvamento Real
      // ═══════════════════════════════════════════════════════════════
      return Promise.race([savePromise, timeoutPromise]);
    }

    /**
     * Valida dados do pedido antes de salvar
     */
    validatePedidoData(data) {
      const errors = [];

      // Campos obrigatórios
      const requiredFields = [
        'nome_cliente',
        'telefone',
        'endereco',
        'numero',
        'bairro',
        'cidade',
        'uf',
        'status'
      ];

      for (const field of requiredFields) {
        if (!data[field] || data[field].trim() === '') {
          errors.push(`Campo obrigatório ausente ou vazio: ${field}`);
        }
      }

      return {
        isValid: errors.length === 0,
        errors
      };
    }

    /**
     * Gera ID único do pedido
     */
    generatePedidoID(data) {
      // Formato: PICKING-NUMERO ou PICKING-TIMESTAMP se número não disponível
      const numero = data.numero_pedido || data.orderUUID || Date.now().toString();
      return `PICKING-${numero}`;
    }

    /**
     * Verifica se pedido já existe no SharePoint
     */
    async checkPedidoExists(pedidoID) {
      try {
        const listName = CONFIG.LIST_NAME;
        
        
        // Timeout de 2 segundos para verificação
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error('Timeout ao verificar existência (2s)')), 2000);
        });
        
        // Buscar item por PedidoID
        const itemPromise = this.graphClient.findListItemByField(listName, 'PedidoID', pedidoID);
        
        const item = await Promise.race([itemPromise, timeoutPromise]);

        if (item) {
          return {
            exists: true,
            data: item
          };
        }

        return { exists: false };
      } catch (error) {
        console.warn('[PickingSharePoint] ⚠️ Erro ao verificar existência:', error.message);
        // Em caso de erro/timeout, assume que não existe para não bloquear
        return { exists: false };
      }
    }

    /**
     * Prepara dados para formato SharePoint
     * @param {Object} pedidoData - Dados do pedido
     * @param {string} pedidoID - ID único do pedido
     * @param {boolean} autoLock - Se deve travar automaticamente (default: true)
     */
    prepareSharePointData(pedidoData, pedidoID, autoLock = true) {
      // Formatar endereço completo
      const enderecoCompleto = this.formatEnderecoCompleto(pedidoData);

      // Gerar token de bloqueio se auto-lock ativado
      const lockToken = autoLock ? this.generateLockToken() : null;

      // Extrair ID único do pedido GPA (formato: 2400-12345)
      const pedidoGPAID = this.extractPedidoGPAID(pedidoData);

      // Montar objeto SharePoint com CAMPOS v3.0.0
      const sharePointItem = {
        fields: {
          // ═══════════════════════════════════════════════════════════════
          // IDENTIFICAÇÃO (v3.0.0 - NOVO CAMPO PedidoGPAID)
          // ═══════════════════════════════════════════════════════════════
          PedidoID: pedidoID, // ID único gerado (GUID)
          PedidoGPAID: pedidoGPAID, // ✅ NOVO v3.0.0 - ID do pedido no sistema GPA
          NumeroPedido: pedidoData.numero_pedido || 'N/A',
          OrderUUID: pedidoData.orderUUID || '',

          // ═══════════════════════════════════════════════════════════════
          // SISTEMA DE TRAVAMENTO (campos corretos do schema)
          // ═══════════════════════════════════════════════════════════════
          Bloqueado: autoLock,
          QuemProcessa: autoLock ? (this.currentUser?.email || 'unknown@gpabr.com') : null, // ✅ Nome correto
          BloqueadoEm: autoLock ? new Date().toISOString() : null,
          TokenBloqueio: lockToken,
          LockExpiry: autoLock ? this.getLockExpiry(CONFIG.LOCK_TIMEOUT_MINUTES) : null, // ✅ NOVO

          // ═══════════════════════════════════════════════════════════════
          // CAMPOS v3.0.0 - TIMELINE E QUEUE
          // ═══════════════════════════════════════════════════════════════
          StatusPicking: pedidoData.status, // ✅ Status original no momento da extração
          TotalTentativas: 0, // ✅ NOVO - Inicializa zerado
          UltimaTentativaID: null, // ✅ NOVO - Será preenchido quando houver tentativa
          StatusConsolidado: 'Pendente', // ✅ NOVO - Status inicial
          TemItemsNaFila: false, // ✅ NOVO - Sem items na fila inicialmente
          DataUltimaAtualizacao: new Date().toISOString(), // ✅ NOVO

          // ═══════════════════════════════════════════════════════════════
          // DADOS DO CLIENTE
          // ═══════════════════════════════════════════════════════════════
          NomeCliente: pedidoData.nome_cliente,
          TelefoneCliente: pedidoData.telefone,

          // ═══════════════════════════════════════════════════════════════
          // ENDEREÇO
          // ═══════════════════════════════════════════════════════════════
          Endereco: pedidoData.endereco,
          Numero: pedidoData.numero,
          Complemento: pedidoData.complemento || '',
          Bairro: pedidoData.bairro,
          Cidade: pedidoData.cidade,
          UF: pedidoData.uf,
          EnderecoCompleto: enderecoCompleto,

          // ═══════════════════════════════════════════════════════════════
          // VALORES
          // ═══════════════════════════════════════════════════════════════
          ValorPedido: this.parseValue(pedidoData.valor),
          ValorEntrega: this.parseValue(pedidoData.valor_entrega),
          ValorSolicitacao: null, // ✅ Será preenchido quando solicitar transporte

          // ═══════════════════════════════════════════════════════════════
          // STATUS E PLATAFORMA
          // ═══════════════════════════════════════════════════════════════
          Status: 'Aguardando Transporte', // ✅ Status do workflow
          Bandeira: pedidoData.bandeira || '',
          Formato: pedidoData.formato || '',
          Plataforma: null, // ✅ Nome correto (será preenchido na solicitação)

          // ═══════════════════════════════════════════════════════════════
          // LOJA
          // ═══════════════════════════════════════════════════════════════
          Loja: pedidoData.loja || 'Torre 1',
          CodigoLoja: pedidoData.codigo_loja || 'torre1',

          // ═══════════════════════════════════════════════════════════════
          // OPERADORES
          // ═══════════════════════════════════════════════════════════════
          QuemEnviou: null, // ✅ NOVO - Quem solicitou transporte
          HorarioEnvio: null, // ✅ NOVO - Quando foi solicitado
          QuantasVezesEnviado: 0, // ✅ NOVO - Contador de envios

          // ═══════════════════════════════════════════════════════════════
          // RASTREAMENTO
          // ═══════════════════════════════════════════════════════════════
          TrackingLink: null, // ✅ Link de rastreamento

          // ═══════════════════════════════════════════════════════════════
          // LOG E METADADOS
          // ═══════════════════════════════════════════════════════════════
          LogOperacoes: this.createLogEntry('EXTRAIDO', {
            usuario: this.currentUser?.email,
            status: pedidoData.status,
            timestamp: new Date().toISOString()
          }), // ✅ NOVO - Log estruturado
          
          DadosCompletos: JSON.stringify(pedidoData),
          Observacoes: pedidoData.observacoes || '',
          DataCriacao: new Date().toISOString(),
          DataModificacao: new Date().toISOString()
        },
        // Retornar token no resultado para referência
        _lockToken: lockToken,
        _pedidoGPAID: pedidoGPAID
      };

      return sharePointItem;
    }

    /**
     * Extrai ID único do pedido GPA (formato: 2400-12345)
     * ✅ NOVO v3.0.0 - Usado para agrupar múltiplas tentativas
     */
    extractPedidoGPAID(pedidoData) {
      // Tentar extrair do número do pedido
      if (pedidoData.numero_pedido && pedidoData.numero_pedido !== 'N/A') {
        return pedidoData.numero_pedido;
      }
      
      // Tentar extrair do pedido
      if (pedidoData.pedido) {
        return pedidoData.pedido;
      }
      
      // Fallback: usar loja + timestamp
      const loja = pedidoData.loja || 'torre1';
      const timestamp = Date.now();
      return `${loja}-${timestamp}`;
    }

    /**
     * Calcula data de expiração do lock
     * ✅ NOVO v3.0.0 - Locks expiram automaticamente
     */
    getLockExpiry(minutes) {
      const now = new Date();
      now.setMinutes(now.getMinutes() + minutes);
      return now.toISOString();
    }

    /**
     * Cria entrada de log estruturada
     * ✅ NOVO v3.0.0 - Log em formato JSON para append
     */
    createLogEntry(action, data) {
      const entry = {
        action,
        timestamp: new Date().toISOString(),
        usuario: this.currentUser?.email || 'system',
        ...data
      };
      return JSON.stringify([entry]); // Array com 1 entrada inicial
    }

    /**
     * Adiciona entrada ao log existente
     * ✅ NOVO v3.0.0 - Append ao log sem sobrescrever
     */
    appendToLogOperacoes(existingLog, action, data) {
      try {
        const logs = existingLog ? JSON.parse(existingLog) : [];
        const newEntry = {
          action,
          timestamp: new Date().toISOString(),
          usuario: this.currentUser?.email || 'system',
          ...data
        };
        logs.push(newEntry);
        return JSON.stringify(logs);
      } catch (e) {
        console.error('[PickingSharePoint] Erro ao adicionar log:', e);
        return this.createLogEntry(action, data);
      }
    }

    /**
     * Formata endereço completo
     */
    formatEnderecoCompleto(data) {
      const parts = [
        data.endereco,
        data.numero,
        data.complemento,
        data.bairro,
        data.cidade,
        data.uf
      ].filter(p => p && p.trim() !== '');

      return parts.join(', ');
    }

    /**
     * Converte valor string para número
     */
    parseValue(value) {
      if (!value) return 0;
      if (typeof value === 'number') return value;
      
      // Remove símbolos e converte
      const cleaned = value.toString().replace(/[R$\s]/g, '').replace(',', '.');
      const parsed = parseFloat(cleaned);
      
      return isNaN(parsed) ? 0 : parsed;
    }

    /**
     * Salva no SharePoint com retry
     */
    async saveWithRetry(data, attempt = 1) {
      try {
        const listName = CONFIG.LIST_NAME;
        
        // Extrair token de bloqueio (se existir)
        const lockToken = data._lockToken;
        delete data._lockToken; // Remover antes de enviar
        
        
        // Criar item na lista SharePoint com TIMEOUT de 10 segundos
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error('Timeout ao salvar no SharePoint (10s)')), 10000);
        });
        
        const savePromise = this.graphClient.createListItem(listName, data.fields);
        
        // Race: primeiro que resolver/rejeitar vence
        const response = await Promise.race([savePromise, timeoutPromise]);

        
        return {
          success: true,
          itemId: response.id,
          lockToken: lockToken // Retornar token para referência
        };
      } catch (error) {
        console.error(`[PickingSharePoint] ❌ Tentativa ${attempt}/${CONFIG.RETRY_ATTEMPTS} falhou:`, error);
        
        // ✅ LOG DETALHADO: Mostrar mais informações sobre o erro
        if (error.status === 404) {
          console.error(`[PickingSharePoint] 🔍 HTTP 404: Lista "${listName}" não encontrada!`);
          console.error('[PickingSharePoint] 🔍 Verifique se a lista existe no SharePoint');
          console.error('[PickingSharePoint] 🔍 URL esperada:', `sites/${this.graphClient?.config?.siteId}/lists/${listName}/items`);
        } else if (error.status === 401) {
          console.error('[PickingSharePoint] 🔑 HTTP 401: Token expirado ou inválido');
          
          // ✅ CRÍTICO: Limpar caches inválidos IMEDIATAMENTE
          if (window.unifiedAuth) {
            window.unifiedAuth.tokenCache = null;
            window.unifiedAuth.tokenExpiryTime = 0;
          }
          if (window.tokenInterceptor) {
            await window.tokenInterceptor.clearToken();
          }
          if (window.tokenStorageScanner) {
            await window.tokenStorageScanner.clearToken();
          }
          
          // ✅ VERIFICAR se já está autenticado ANTES de forçar login
          if (window.authHelper) {
            
            try {
              // Verificar se já tem autenticação válida
              const isAuthenticated = await window.authHelper.isAuthenticated();
              
              if (isAuthenticated) {
                // Forçar renovação do token (pode estar expirado)
                await window.authHelper.renewTokens();
              } else {
                await window.authHelper.login();
              }
            } catch (loginError) {
              console.error('[PickingSharePoint] ❌ Erro no login:', loginError);
              throw new Error('Login falhou ou foi cancelado pelo usuário');
            }
          } else {
            console.error('[PickingSharePoint] ❌ AuthHelper não disponível');
            throw new Error('Sistema de autenticação não inicializado');
          }
          
          // Se não é a última tentativa, lançar erro para retry
          if (attempt < CONFIG.RETRY_ATTEMPTS) {
            throw new Error('HTTP 401: Token inválido - requer novo login');
          }
        } else if (error.status === 403) {
          console.error('[PickingSharePoint] 🚫 HTTP 403: Sem permissão para acessar a lista');
        }

        if (attempt < CONFIG.RETRY_ATTEMPTS) {
          // Aguardar antes de tentar novamente (backoff exponencial)
          const delay = CONFIG.RETRY_DELAY_MS * attempt;
          await this.sleep(delay);
          return this.saveWithRetry(data, attempt + 1);
        }

        console.error('[PickingSharePoint] ❌ Todas as tentativas falharam');
        
        return {
          success: false,
          error: error.message
        };
      }
    }

    /**
     * Trava um pedido para processamento
     * @param {string} pedidoID - ID do pedido
     * @returns {Promise<Object>} Token de bloqueio se sucesso
     */
    async lockPedido(pedidoID) {
      try {

        // 1. Buscar pedido atual
        const pedido = await this.getPedidoByID(pedidoID);
        if (!pedido) {
          return { success: false, error: 'Pedido não encontrado' };
        }

        // 2. Verificar se já está bloqueado
        if (pedido.fields.Bloqueado === true) {
          // Verificar se bloqueio expirou
          const bloqueadoEm = new Date(pedido.fields.BloqueadoEm);
          const agora = new Date();
          const diffMinutes = (agora - bloqueadoEm) / 1000 / 60;

          if (diffMinutes < CONFIG.LOCK_TIMEOUT_MINUTES) {
            return {
              success: false,
              error: 'Pedido já está bloqueado',
              bloqueadoPor: pedido.fields.BloqueadoPor,
              bloqueadoEm: pedido.fields.BloqueadoEm
            };
          }
          
        }

        // 3. Gerar token único de bloqueio
        const token = this.generateLockToken();

        // 4. Atualizar pedido com bloqueio
        const updateData = {
          fields: {
            Bloqueado: true,
            BloqueadoPor: this.currentUser?.email,
            BloqueadoEm: new Date().toISOString(),
            TokenBloqueio: token,
            DataModificacao: new Date().toISOString()
          }
        };

        const siteUrl = window.SHAREPOINT_CONFIG?.siteUrl || 'https://gpabr.sharepoint.com/sites/Nexos';
        const listName = CONFIG.LIST_NAME;
        const endpoint = `/sites/${this.getSiteId(siteUrl)}/lists/${listName}/items/${pedido.id}`;

        await this.graphClient.api(endpoint).patch(updateData);


        return {
          success: true,
          token,
          pedidoID,
          message: 'Pedido travado com sucesso'
        };

      } catch (error) {
        console.error('[PickingSharePoint] ❌ Erro ao travar pedido:', error);
        return {
          success: false,
          error: error.message
        };
      }
    }

    /**
     * Libera um pedido travado
     * @param {string} pedidoID - ID do pedido
     * @param {string} token - Token de bloqueio (opcional para Admin/Encarregado)
     * @param {boolean} forceUnlock - Forçar desbloqueio (apenas Admin/Encarregado)
     */
    async unlockPedido(pedidoID, token = null, forceUnlock = false) {
      try {

        // 1. Buscar pedido atual
        const pedido = await this.getPedidoByID(pedidoID);
        if (!pedido) {
          return { success: false, error: 'Pedido não encontrado' };
        }

        // 2. Verificar permissões do usuário
        const userRole = await this.getUserRole();
        const isAdminOrManager = ['admin', 'gerente', 'encarregado'].includes(userRole?.toLowerCase());
        
        // 3. Verificar se pode desbloquear
        if (pedido.fields.Bloqueado === true) {
          const isOwner = pedido.fields.BloqueadoPor === this.currentUser?.email;
          const hasValidToken = pedido.fields.TokenBloqueio === token;
          
          // Verificar timeout (10 minutos)
          const bloqueadoEm = new Date(pedido.fields.BloqueadoEm);
          const agora = new Date();
          const diffMinutes = (agora - bloqueadoEm) / 1000 / 60;
          const isExpired = diffMinutes >= CONFIG.LOCK_TIMEOUT_MINUTES;
          
          // Pode desbloquear se:
          // - É o dono E tem token válido
          // - OU é Admin/Encarregado E usa forceUnlock
          // - OU timeout expirou
          const canUnlock = (isOwner && hasValidToken) || 
                           (isAdminOrManager && forceUnlock) || 
                           isExpired;
          
          if (!canUnlock) {
            return {
              success: false,
              error: 'Sem permissão para liberar este pedido',
              reason: isExpired ? 'timeout_expired' : 
                      isAdminOrManager ? 'needs_force_unlock' : 
                      'invalid_token_or_owner',
              bloqueadoPor: pedido.fields.BloqueadoPor,
              bloqueadoEm: pedido.fields.BloqueadoEm,
              minutesRemaining: Math.max(0, CONFIG.LOCK_TIMEOUT_MINUTES - diffMinutes)
            };
          }
          
          if (isExpired) {
          }
          
          if (isAdminOrManager && forceUnlock) {
          }
        }

        // 4. Atualizar pedido removendo bloqueio
        const updateData = {
          fields: {
            Bloqueado: false,
            BloqueadoPor: null,
            BloqueadoEm: null,
            TokenBloqueio: null,
            DataModificacao: new Date().toISOString(),
            Observacoes: forceUnlock && isAdminOrManager ? 
              `Desbloqueado manualmente por ${this.currentUser?.email} (${userRole})` : 
              pedido.fields.Observacoes
          }
        };

        const siteUrl = window.SHAREPOINT_CONFIG?.siteUrl || 'https://gpabr.sharepoint.com/sites/Nexos';
        const listName = CONFIG.LIST_NAME;
        const endpoint = `/sites/${this.getSiteId(siteUrl)}/lists/${listName}/items/${pedido.id}`;

        await this.graphClient.api(endpoint).patch(updateData);

        
        // Log da ação
        this.logAction('PEDIDO_DESBLOQUEADO', {
          pedidoID,
          forceUnlock,
          userRole,
          previousOwner: pedido.fields.BloqueadoPor
        });

        return {
          success: true,
          pedidoID,
          message: 'Pedido liberado com sucesso'
        };

      } catch (error) {
        console.error('[PickingSharePoint] ❌ Erro ao liberar pedido:', error);
        return {
          success: false,
          error: error.message
        };
      }
    }

    /**
     * Marca pedido como processado (após carregar em plataforma)
     * @param {string} pedidoID - ID do pedido
     * @param {string} plataforma - Plataforma usada (Uber, 99app, Lalamove)
     * @param {string} token - Token de bloqueio (opcional se for dono)
     */
    async markPedidoProcessado(pedidoID, plataforma, token = null) {
      try {

        // 1. Buscar pedido
        const pedido = await this.getPedidoByID(pedidoID);
        if (!pedido) {
          return { success: false, error: 'Pedido não encontrado' };
        }

        // 2. Verificar se é o dono do pedido (quem extraiu)
        const isOwner = pedido.fields.ExtraidoPor === this.currentUser?.email;
        const hasValidToken = pedido.fields.TokenBloqueio === token;
        
        // 3. Verificar se está bloqueado e se pode processar
        if (pedido.fields.Bloqueado !== true) {
          return {
            success: false,
            error: 'Pedido não está bloqueado. Já foi processado por outra pessoa?'
          };
        }
        
        // Pode processar se:
        // - É o dono (quem extraiu) E tem token válido
        // - OU é o dono E o pedido ainda está bloqueado por ele
        const canProcess = isOwner && (hasValidToken || pedido.fields.BloqueadoPor === this.currentUser?.email);
        
        if (!canProcess) {
          return {
            success: false,
            error: 'Você não tem permissão para processar este pedido',
            bloqueadoPor: pedido.fields.BloqueadoPor,
            extraidoPor: pedido.fields.ExtraidoPor
          };
        }

        // 4. Atualizar com dados de processamento e liberar
        const updateData = {
          fields: {
            ProcessadoPor: this.currentUser?.email,
            ProcessadoEm: new Date().toISOString(),
            PlataformaEnvio: plataforma,
            Bloqueado: false,
            BloqueadoPor: null,
            BloqueadoEm: null,
            TokenBloqueio: null,
            DataModificacao: new Date().toISOString()
          }
        };

        const siteUrl = window.SHAREPOINT_CONFIG?.siteUrl || 'https://gpabr.sharepoint.com/sites/Nexos';
        const listName = CONFIG.LIST_NAME;
        const endpoint = `/sites/${this.getSiteId(siteUrl)}/lists/${listName}/items/${pedido.id}`;

        await this.graphClient.api(endpoint).patch(updateData);

        
        // Log da ação
        this.logAction('PEDIDO_PROCESSADO', {
          pedidoID,
          plataforma,
          processadoPor: this.currentUser?.email
        });

        return {
          success: true,
          pedidoID,
          message: `Pedido processado com sucesso via ${plataforma}`
        };

      } catch (error) {
        console.error('[PickingSharePoint] ❌ Erro ao marcar como processado:', error);
        return {
          success: false,
          error: error.message
        };
      }
    }

    /**
     * Busca pedido por ID
     */
    async getPedidoByID(pedidoID) {
      try {
        const siteUrl = window.SHAREPOINT_CONFIG?.siteUrl || 'https://gpabr.sharepoint.com/sites/Nexos';
        const listName = CONFIG.LIST_NAME;
        
        const filter = `fields/PedidoID eq '${pedidoID}'`;
        const endpoint = `/sites/${this.getSiteId(siteUrl)}/lists/${listName}/items?$filter=${filter}&$select=id,fields`;

        const response = await this.graphClient.api(endpoint).get();

        if (response && response.value && response.value.length > 0) {
          return response.value[0];
        }

        return null;
      } catch (error) {
        console.error('[PickingSharePoint] Erro ao buscar pedido:', error);
        return null;
      }
    }

    /**
     * Gera token único para bloqueio
     */
    generateLockToken() {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    }

    /**
     * Extrai Site ID da URL
     */
    getSiteId(siteUrl) {
      // Simplificado - em produção usar Graph API para obter Site ID real
      return siteUrl.replace('https://', '').replace(/\//g, ',');
    }

    /**
     * Registra ação no log
     */
    async logAction(action, details) {
      try {
        if (window.logManager && typeof window.logManager.info === 'function') {
          window.logManager.info(action, details);
        }
      } catch (error) {
        console.warn('[PickingSharePoint] Erro ao registrar log:', error);
      }
    }

    /**
     * Helpers de storage
     */
    async getFromStorage(key) {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        return new Promise((resolve) => {
          chrome.storage.local.get([key], (result) => {
            resolve(result[key] || null);
          });
        });
      }
      return null;
    }

    async saveToStorage(key, value) {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        return new Promise((resolve) => {
          chrome.storage.local.set({ [key]: value }, () => {
            resolve(true);
          });
        });
      }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // MÉTODOS v3.0.0 - TIMELINE, QUEUE E LOCK MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Marca pedido como enviado (transporte solicitado)
     * @param {string} itemId - ID do item no SharePoint
     * @param {string} plataforma - Plataforma utilizada (Uber, Lalamove, 99)
     * @param {number} valor - Valor da solicitação
     * @param {string} trackingLink - Link de rastreamento
     * @returns {Object} Resultado da operação
     */
    async marcarPedidoComoEnviado(itemId, plataforma, valor, trackingLink = null) {
      try {

        if (!this.graphClient) {
          return { success: false, error: 'Graph Client não disponível' };
        }

        // Buscar dados atuais
        const currentItem = await this.graphClient.getListItem(CONFIG.LIST_NAME, itemId);
        const currentFields = currentItem?.fields || {};

        // Preparar atualização
        const updateData = {
          fields: {
            Status: 'Transporte Solicitado',
            Plataforma: plataforma,
            ValorSolicitacao: valor,
            TrackingLink: trackingLink ? String(trackingLink) : null,
            QuemEnviou: this.currentUser?.email || 'system',
            HorarioEnvio: new Date().toISOString(),
            QuantasVezesEnviado: (currentFields.QuantasVezesEnviado || 0) + 1,
            TotalTentativas: (currentFields.TotalTentativas || 0) + 1,
            DataUltimaAtualizacao: new Date().toISOString(),
            LogOperacoes: this.appendToLogOperacoes(
              currentFields.LogOperacoes,
              'ENVIADO',
              {
                plataforma,
                valor,
                trackingLink
              }
            )
          }
        };

        // Atualizar no SharePoint
        await this.graphClient.updateListItem(CONFIG.LIST_NAME, itemId, updateData.fields);


        // Registrar na timeline se disponível
        if (window.pickingTimelineSharePoint) {
          await window.pickingTimelineSharePoint.registrarTentativa({
            pedidoGPAID: currentFields.PedidoGPAID,
            numeroTentativa: currentFields.TotalTentativas,
            tipoEvento: window.TIMELINE_TIPO_EVENTO.SOLICITACAO,
            plataforma: plataforma,
            statusAnterior: currentFields.Status,
            statusNovo: 'Transporte Solicitado',
            sucesso: true,
            valorSolicitado: valor,
            trackingLink: id_uber
          });
        }

        return {
          success: true,
          message: 'Pedido marcado como enviado com sucesso'
        };

      } catch (error) {
        console.error('[PickingSharePoint] ❌ Erro ao marcar como enviado:', error);
        return {
          success: false,
          error: error.message
        };
      }
    }

    /**
     * Desbloqueia pedido (remove lock)
     * @param {string} itemId - ID do item no SharePoint
     * @returns {Object} Resultado da operação
     */
    async desbloquearPedido(itemId) {
      try {

        if (!this.graphClient) {
          return { success: false, error: 'Graph Client não disponível' };
        }

        // Buscar dados atuais
        const currentItem = await this.graphClient.getListItem(CONFIG.LIST_NAME, itemId);
        const currentFields = currentItem?.fields || {};

        // Preparar atualização
        const updateData = {
          fields: {
            Bloqueado: false,
            QuemProcessa: null,
            TokenBloqueio: null,
            LockExpiry: null,
            DataUltimaAtualizacao: new Date().toISOString(),
            LogOperacoes: this.appendToLogOperacoes(
              currentFields.LogOperacoes,
              'DESBLOQUEADO',
              {
                motivo: 'Manual',
                usuario: this.currentUser?.email || 'system'
              }
            )
          }
        };

        // Atualizar no SharePoint
        await this.graphClient.updateListItem(CONFIG.LIST_NAME, itemId, updateData.fields);


        return {
          success: true,
          message: 'Pedido desbloqueado com sucesso'
        };

      } catch (error) {
        console.error('[PickingSharePoint] ❌ Erro ao desbloquear pedido:', error);
        return {
          success: false,
          error: error.message
        };
      }
    }

    /**
     * Limpa locks expirados de todos os pedidos
     * @returns {Object} Resultado com quantidade de locks limpos
     */
    async limparLocksExpirados() {
      try {

        if (!this.graphClient) {
          return { success: false, error: 'Graph Client não disponível' };
        }

        const now = new Date().toISOString();

        // Buscar pedidos com lock expirado
        // Filtro: Bloqueado=true AND LockExpiry < now
        const filter = `fields/Bloqueado eq true and fields/LockExpiry lt datetime'${now}'`;
        
        const response = await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items`)
          .filter(filter)
          .expand('fields')
          .top(100)
          .get();

        const expiredItems = response.value || [];
        let cleaned = 0;

        // Desbloquear cada item
        for (const item of expiredItems) {
          try {
            const updateData = {
              fields: {
                Bloqueado: false,
                QuemProcessa: null,
                TokenBloqueio: null,
                LockExpiry: null,
                DataUltimaAtualizacao: new Date().toISOString(),
                LogOperacoes: this.appendToLogOperacoes(
                  item.fields.LogOperacoes,
                  'LOCK_EXPIRADO',
                  {
                    quemProcessava: item.fields.QuemProcessa,
                    expiraEm: item.fields.LockExpiry
                  }
                )
              }
            };

            await this.graphClient.updateListItem(CONFIG.LIST_NAME, item.id, updateData.fields);
            cleaned++;

          } catch (err) {
            console.warn('[PickingSharePoint] Erro ao limpar lock do item:', item.id, err);
          }
        }

        if (cleaned > 0) {
        } else {
        }

        return {
          success: true,
          cleaned: cleaned,
          total: expiredItems.length,
          message: `${cleaned} locks limpos de ${expiredItems.length} encontrados`
        };

      } catch (error) {
        console.error('[PickingSharePoint] ❌ Erro ao limpar locks:', error);
        return {
          success: false,
          error: error.message,
          cleaned: 0
        };
      }
    }

    sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // EXPORT
  // ═══════════════════════════════════════════════════════════════════════════

  // Criar instância global
  if (typeof window !== 'undefined') {
    window.pickingSharePointManager = new PickingSharePointManager();
    
  }

  // Export para módulos
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = PickingSharePointManager;
  }

})();
