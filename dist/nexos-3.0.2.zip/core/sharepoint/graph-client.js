/**
 * Nexos Torre - Microsoft Graph Client
 * Cliente para interagir com SharePoint via Microsoft Graph API
 * 
 * Features:
 * - Upload/download de arquivos
 * - Listagem de arquivos e pastas
 * - Batch requests para performance
 * - Retry automático com backoff
 * - Cache de responses (opcional)
 * 
 * @example
 * const graphClient = new GraphClient({
 *   authHelper: authHelperInstance
 * });
 * 
 * await graphClient.uploadFile('/sites/Nexos/logs.json', data);
 * const file = await graphClient.downloadFile('/sites/Nexos/logs.json');
 */

class GraphClient {
  constructor(options = {}) {
    this.authHelper = options.authHelper;
    this.baseUrl = 'https://graph.microsoft.com/v1.0';
    this.siteId = options.siteId || null; // Será resolvido automaticamente
    this.maxRetries = options.maxRetries || 3;
    this.retryDelay = options.retryDelay || 1000;
    this.cache = new Map();
    this.cacheTimeout = options.cacheTimeout || 60000; // 1 min
    
    console.log('[GraphClient] Inicializado');
  }
  
  /**
   * Resolve site ID do SharePoint
   * @private
   */
  async _resolveSiteId() {
    if (this.siteId) {
      return this.siteId;
    }
    
    try {
      // Extrair hostname e site path da URL
      const siteUrl = 'https://gpabr.sharepoint.com/sites/Nexos';
      const url = new URL(siteUrl);
      const hostname = url.hostname;
      const sitePath = url.pathname;
      
      // Buscar site ID
      const endpoint = `${this.baseUrl}/sites/${hostname}:${sitePath}`;
      const response = await this._makeRequest(endpoint);
      
      this.siteId = response.id;
      console.log('[GraphClient] Site ID resolvido:', this.siteId);
      return this.siteId;
      
    } catch (error) {
      console.error('[GraphClient] Erro ao resolver site ID:', error);
      throw error;
    }
  }
  
  /**
   * Upload de arquivo para SharePoint
   * @param {string} filePath - Caminho relativo do arquivo (ex: '/Shared Documents/data.json')
   * @param {any} content - Conteúdo do arquivo (objeto será JSON.stringify)
   * @param {Object} options - Opções de upload
   * @returns {Promise<Object>} Metadados do arquivo criado
   */
  async uploadFile(filePath, content, options = {}) {
    try {
      const siteId = await this._resolveSiteId();
      
      // Preparar conteúdo
      const body = typeof content === 'string' ? content : JSON.stringify(content, null, 2);
      const blob = new Blob([body], { type: 'application/json' });
      
      // Normalizar path (remover / inicial se existir)
      const normalizedPath = filePath.startsWith('/') ? filePath.substring(1) : filePath;
      
      // Escolher método baseado no tamanho
      if (blob.size < 4 * 1024 * 1024) { // < 4MB: upload simples
        return await this._simpleUpload(siteId, normalizedPath, blob, options);
      } else { // >= 4MB: upload em sessão
        return await this._sessionUpload(siteId, normalizedPath, blob, options);
      }
      
    } catch (error) {
      console.error('[GraphClient] Erro no upload:', error);
      throw error;
    }
  }
  
  /**
   * Upload simples (< 4MB)
   * @private
   */
  async _simpleUpload(siteId, filePath, blob, options = {}) {
    const endpoint = `${this.baseUrl}/sites/${siteId}/drive/root:/${filePath}:/content`;
    
    const response = await this._makeRequest(endpoint, {
      method: 'PUT',
      body: blob,
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    console.log(`[GraphClient] ✅ Upload concluído: ${filePath}`);
    return response;
  }
  
  /**
   * Upload em sessão (>= 4MB)
   * @private
   */
  async _sessionUpload(siteId, filePath, blob, options = {}) {
    // 1. Criar sessão de upload
    const createSessionEndpoint = `${this.baseUrl}/sites/${siteId}/drive/root:/${filePath}:/createUploadSession`;
    const session = await this._makeRequest(createSessionEndpoint, {
      method: 'POST',
      body: JSON.stringify({
        item: {
          '@microsoft.graph.conflictBehavior': options.conflictBehavior || 'replace'
        }
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    // 2. Upload em chunks
    const chunkSize = 320 * 1024; // 320KB por chunk (recomendado)
    const uploadUrl = session.uploadUrl;
    let uploadedBytes = 0;
    
    while (uploadedBytes < blob.size) {
      const chunk = blob.slice(uploadedBytes, uploadedBytes + chunkSize);
      const chunkEnd = Math.min(uploadedBytes + chunkSize, blob.size);
      
      await this._makeRequest(uploadUrl, {
        method: 'PUT',
        body: chunk,
        headers: {
          'Content-Range': `bytes ${uploadedBytes}-${chunkEnd - 1}/${blob.size}`,
          'Content-Type': 'application/octet-stream'
        },
        skipAuth: true // Upload URL já tem token embutido
      });
      
      uploadedBytes = chunkEnd;
      console.log(`[GraphClient] Upload progress: ${Math.round(uploadedBytes / blob.size * 100)}%`);
    }
    
    console.log(`[GraphClient] ✅ Upload em sessão concluído: ${filePath}`);
    return { uploaded: true, size: blob.size };
  }
  
  /**
   * Download de arquivo do SharePoint
   * @param {string} filePath - Caminho relativo do arquivo
   * @param {Object} options - Opções de download
   * @returns {Promise<any>} Conteúdo do arquivo (parsed se JSON)
   */
  async downloadFile(filePath, options = {}) {
    try {
      const siteId = await this._resolveSiteId();
      const normalizedPath = filePath.startsWith('/') ? filePath.substring(1) : filePath;
      
      // Obter metadados primeiro
      const metadataEndpoint = `${this.baseUrl}/sites/${siteId}/drive/root:/${normalizedPath}`;
      const metadata = await this._makeRequest(metadataEndpoint);
      
      // Download do conteúdo
      const contentEndpoint = `${this.baseUrl}/sites/${siteId}/drive/items/${metadata.id}/content`;
      const content = await this._makeRequest(contentEndpoint, { raw: true });
      
      // Parse se JSON
      if (filePath.endsWith('.json')) {
        const parsed = JSON.parse(content);
        console.log(`[GraphClient] ✅ Download concluído: ${filePath}`);
        return parsed;
      }
      
      console.log(`[GraphClient] ✅ Download concluído: ${filePath}`);
      return content;
      
    } catch (error) {
      if (error.status === 404) {
        console.log(`[GraphClient] ⚠️ Arquivo não encontrado: ${filePath}`);
        return null;
      }
      console.error('[GraphClient] Erro no download:', error);
      throw error;
    }
  }
  
  /**
   * Deleta arquivo do SharePoint
   * @param {string} filePath - Caminho relativo do arquivo
   * @returns {Promise<void>}
   */
  async deleteFile(filePath) {
    try {
      const siteId = await this._resolveSiteId();
      const normalizedPath = filePath.startsWith('/') ? filePath.substring(1) : filePath;
      
      const endpoint = `${this.baseUrl}/sites/${siteId}/drive/root:/${normalizedPath}`;
      await this._makeRequest(endpoint, { method: 'DELETE' });
      
      console.log(`[GraphClient] ✅ Arquivo deletado: ${filePath}`);
      
    } catch (error) {
      if (error.status === 404) {
        console.log(`[GraphClient] ⚠️ Arquivo já não existe: ${filePath}`);
        return;
      }
      console.error('[GraphClient] Erro ao deletar:', error);
      throw error;
    }
  }
  
  /**
   * Lista arquivos de uma pasta
   * @param {string} folderPath - Caminho da pasta
   * @param {Object} options - Opções de listagem
   * @returns {Promise<Array>} Lista de arquivos
   */
  async listFiles(folderPath, options = {}) {
    try {
      const siteId = await this._resolveSiteId();
      const normalizedPath = folderPath.startsWith('/') ? folderPath.substring(1) : folderPath;
      
      const endpoint = `${this.baseUrl}/sites/${siteId}/drive/root:/${normalizedPath}:/children`;
      const response = await this._makeRequest(endpoint);
      
      const files = response.value || [];
      console.log(`[GraphClient] ✅ Listados ${files.length} itens em: ${folderPath}`);
      
      return files.map(file => ({
        name: file.name,
        path: `${folderPath}/${file.name}`,
        size: file.size,
        createdDateTime: file.createdDateTime,
        lastModifiedDateTime: file.lastModifiedDateTime,
        isFolder: !!file.folder,
        id: file.id
      }));
      
    } catch (error) {
      if (error.status === 404) {
        console.log(`[GraphClient] ⚠️ Pasta não encontrada: ${folderPath}`);
        return [];
      }
      console.error('[GraphClient] Erro ao listar:', error);
      throw error;
    }
  }
  
  /**
   * Cria pasta no SharePoint
   * @param {string} folderPath - Caminho da nova pasta
   * @returns {Promise<Object>} Metadados da pasta criada
   */
  async createFolder(folderPath) {
    try {
      const siteId = await this._resolveSiteId();
      
      // Separar parent path e folder name
      const parts = folderPath.split('/').filter(p => p);
      const folderName = parts.pop();
      const parentPath = parts.join('/');
      
      const endpoint = `${this.baseUrl}/sites/${siteId}/drive/root${parentPath ? ':/' + parentPath : ''}:/children`;
      
      const response = await this._makeRequest(endpoint, {
        method: 'POST',
        body: JSON.stringify({
          name: folderName,
          folder: {},
          '@microsoft.graph.conflictBehavior': 'fail'
        }),
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      console.log(`[GraphClient] ✅ Pasta criada: ${folderPath}`);
      return response;
      
    } catch (error) {
      if (error.status === 409) {
        console.log(`[GraphClient] ⚠️ Pasta já existe: ${folderPath}`);
        return null;
      }
      console.error('[GraphClient] Erro ao criar pasta:', error);
      throw error;
    }
  }
  
  /**
   * Batch request (múltiplas operações em uma chamada)
   * @param {Array} requests - Array de requisições
   * @returns {Promise<Array>} Respostas
   */
  async batch(requests) {
    try {
      const endpoint = `${this.baseUrl}/$batch`;
      
      const batchBody = {
        requests: requests.map((req, index) => ({
          id: String(index + 1),
          method: req.method || 'GET',
          url: req.url.replace(this.baseUrl, ''),
          headers: req.headers || {},
          body: req.body
        }))
      };
      
      const response = await this._makeRequest(endpoint, {
        method: 'POST',
        body: JSON.stringify(batchBody),
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      console.log(`[GraphClient] ✅ Batch concluído (${requests.length} requests)`);
      return response.responses;
      
    } catch (error) {
      console.error('[GraphClient] Erro no batch:', error);
      throw error;
    }
  }

  // ==================== SharePoint Lists ====================

  /**
   * Cria a lista Nexos_PedidosConcluidos com todos os campos necessários
   * para o Dashboard Financeiro
   * @returns {Promise<Object>} Informações da lista criada (siteId, listId)
   */
  async createCompletedOrdersList() {
    try {
      console.log('[GraphClient] 🚀 Iniciando criação da lista Nexos_PedidosConcluidos...');
      
      // 1. Obter Site ID
      const siteId = await this._resolveSiteId();
      console.log('[GraphClient] ✅ Site ID obtido:', siteId);
      
      // 2. Verificar se lista já existe
      try {
        const existingLists = await this._makeRequest(`${this.baseUrl}/sites/${siteId}/lists`);
        const existingList = existingLists.value.find(l => l.name === 'Nexos_PedidosConcluidos');
        
        if (existingList) {
          console.log('[GraphClient] ⚠️ Lista já existe:', existingList.id);
          return {
            siteId,
            listId: existingList.id,
            status: 'already_exists',
            message: 'Lista Nexos_PedidosConcluidos já existe'
          };
        }
      } catch (error) {
        console.warn('[GraphClient] Não foi possível verificar listas existentes:', error);
      }
      
      // 3. Criar lista
      const listBody = {
        displayName: 'Nexos_PedidosConcluidos',
        list: {
          template: 'genericList'
        }
      };
      
      const listResponse = await this._makeRequest(`${this.baseUrl}/sites/${siteId}/lists`, {
        method: 'POST',
        body: JSON.stringify(listBody),
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      const listId = listResponse.id;
      console.log('[GraphClient] ✅ Lista criada:', listId);
      
      // 4. Atualizar descrição
      try {
        await this._makeRequest(`${this.baseUrl}/sites/${siteId}/lists/${listId}`, {
          method: 'PATCH',
          body: JSON.stringify({
            description: 'Histórico completo de pedidos concluídos para análise financeira e relatórios'
          }),
          headers: {
            'Content-Type': 'application/json'
          }
        });
        console.log('[GraphClient] ✅ Descrição atualizada');
      } catch (error) {
        console.warn('[GraphClient] Falha ao atualizar descrição:', error);
      }
      
      // 5. Adicionar campos críticos
      const fields = [
        // Identificação
        {
          name: 'PedidoID',
          displayName: 'Pedido ID',
          required: true,
          indexed: true,
          text: { allowMultipleLines: false, maxLength: 255 }
        },
        {
          name: 'OrderUUID',
          displayName: 'Order UUID',
          text: { allowMultipleLines: false, maxLength: 255 }
        },
        {
          name: 'NumeroPedido',
          displayName: 'Número Pedido',
          text: { allowMultipleLines: false, maxLength: 255 }
        },
        
        // Plataforma e Loja
        {
          name: 'Plataforma',
          displayName: 'Plataforma',
          required: true,
          indexed: true,
          choice: {
            allowTextEntry: false,
            choices: ['Uber', '99app', 'Lalamove', 'Picking', 'Orkestra']
          }
        },
        {
          name: 'Loja',
          displayName: 'Loja',
          required: true,
          indexed: true,
          text: { allowMultipleLines: false, maxLength: 255 }
        },
        {
          name: 'CodigoLoja',
          displayName: 'Código Loja',
          text: { allowMultipleLines: false, maxLength: 100 }
        },
        
        // Financeiro ⚠️ CRÍTICO
        {
          name: 'CustoEntrega',
          displayName: 'Custo Entrega',
          required: true,
          indexed: true,
          currency: { locale: 'pt-BR' }
        },
        {
          name: 'ValorPedido',
          displayName: 'Valor Pedido',
          currency: { locale: 'pt-BR' }
        },
        {
          name: 'TaxaServico',
          displayName: 'Taxa Serviço',
          currency: { locale: 'pt-BR' }
        },
        {
          name: 'Desconto',
          displayName: 'Desconto',
          currency: { locale: 'pt-BR' }
        },
        
        // Datas
        {
          name: 'DataSolicitacao',
          displayName: 'Data Solicitação',
          required: true,
          indexed: true,
          dateTime: { displayAs: 'default', format: 'dateTime' }
        },
        {
          name: 'DataConclusao',
          displayName: 'Data Conclusão',
          required: true,
          indexed: true,
          dateTime: { displayAs: 'default', format: 'dateTime' }
        },
        {
          name: 'TempoConclusao',
          displayName: 'Tempo Conclusão (min)',
          number: { decimalPlaces: 0, minimum: 0 }
        },
        
        // Operador
        {
          name: 'OperadorEmail',
          displayName: 'Operador Email',
          required: true,
          indexed: true,
          text: { allowMultipleLines: false, maxLength: 255 }
        },
        {
          name: 'OperadorNome',
          displayName: 'Operador Nome',
          required: true,
          text: { allowMultipleLines: false, maxLength: 255 }
        },
        {
          name: 'OperadorCargo',
          displayName: 'Operador Cargo',
          choice: {
            allowTextEntry: false,
            choices: ['Admin', 'Gerente', 'Coordenador', 'Operador']
          }
        },
        
        // Status
        {
          name: 'StatusFinal',
          displayName: 'Status Final',
          required: true,
          indexed: true,
          choice: {
            allowTextEntry: false,
            choices: ['Concluído', 'Cancelado', 'Falhou']
          }
        },
        {
          name: 'StatusPicking',
          displayName: 'Status Picking',
          indexed: true,
          text: { allowMultipleLines: false, maxLength: 500 }
        },
        {
          name: 'MotivoCancelamento',
          displayName: 'Motivo Cancelamento',
          text: { allowMultipleLines: true }
        },
        
        // Rastreamento
        {
          name: 'TrackingLink',
          displayName: 'Link Rastreamento',
          hyperlinkOrPicture: { format: 'hyperlink' }
        },
        
        // Cliente
        {
          name: 'NomeCliente',
          displayName: 'Nome Cliente',
          text: { allowMultipleLines: false, maxLength: 255 }
        },
        {
          name: 'EnderecoCompleto',
          displayName: 'Endereço Completo',
          text: { allowMultipleLines: true }
        },
        {
          name: 'Bairro',
          displayName: 'Bairro',
          text: { allowMultipleLines: false, maxLength: 100 }
        },
        {
          name: 'Cidade',
          displayName: 'Cidade',
          text: { allowMultipleLines: false, maxLength: 100 }
        },
        {
          name: 'DistanciaKm',
          displayName: 'Distância (km)',
          number: { decimalPlaces: 2, minimum: 0 }
        },
        
        // Entregador
        {
          name: 'NomeEntregador',
          displayName: 'Nome Entregador',
          text: { allowMultipleLines: false, maxLength: 255 }
        },
        {
          name: 'VeiculoTipo',
          displayName: 'Tipo Veículo',
          choice: {
            allowTextEntry: false,
            choices: ['Moto', 'Carro', 'Bicicleta', 'Caminhão', 'A pé']
          }
        },
        
        // Metadados
        {
          name: 'Observacoes',
          displayName: 'Observações',
          text: { allowMultipleLines: true }
        },
        {
          name: 'Tags',
          displayName: 'Tags',
          text: { allowMultipleLines: false, maxLength: 500 }
        },
        {
          name: 'AvaliacaoCliente',
          displayName: 'Avaliação Cliente',
          number: { decimalPlaces: 0, minimum: 1, maximum: 5 }
        }
      ];
      
      console.log(`[GraphClient] 📝 Adicionando ${fields.length} campos...`);
      
      let addedCount = 0;
      let skippedCount = 0;
      const errors = [];
      
      for (const field of fields) {
        try {
          await this._makeRequest(`${this.baseUrl}/sites/${siteId}/lists/${listId}/columns`, {
            method: 'POST',
            body: JSON.stringify(field),
            headers: {
              'Content-Type': 'application/json'
            }
          });
          
          addedCount++;
          console.log(`[GraphClient] ✅ Campo criado: ${field.name}`);
          
        } catch (error) {
          if (error.status === 400 && error.message?.includes('already exists')) {
            skippedCount++;
            console.warn(`[GraphClient] ⚠️ Campo já existe: ${field.name}`);
          } else {
            errors.push({ field: field.name, error: error.message });
            console.error(`[GraphClient] ❌ Erro ao criar campo ${field.name}:`, error);
          }
        }
      }
      
      console.log(`[GraphClient] 📊 Resumo: ${addedCount} adicionados, ${skippedCount} pulados, ${errors.length} erros`);
      
      // 6. Retornar resultado
      return {
        siteId,
        listId,
        status: 'created',
        message: '✅ Lista Nexos_PedidosConcluidos criada com sucesso!',
        stats: {
          fieldsAdded: addedCount,
          fieldsSkipped: skippedCount,
          errors: errors.length
        },
        errors: errors.length > 0 ? errors : undefined
      };
      
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao criar lista:', error);
      throw error;
    }
  }

  /**
   * Adiciona item de exemplo na lista de pedidos concluídos
   * @param {string} listId - ID da lista
   * @returns {Promise<Object>} Item criado
   */
  async addSampleCompletedOrder(listId) {
    try {
      const siteId = await this._resolveSiteId();
      
      const sampleOrder = {
        fields: {
          PedidoID: '#UBER-TEST001',
          Plataforma: 'Uber',
          Loja: 'Torre 1',
          CodigoLoja: 'torre1',
          CustoEntrega: 125.50,
          ValorPedido: 850.00,
          TaxaServico: 15.00,
          Desconto: 0,
          DataSolicitacao: new Date(Date.now() - 3600000).toISOString(), // 1h atrás
          DataConclusao: new Date().toISOString(),
          TempoConclusao: 60,
          OperadorEmail: 'leonardo.miguel@gpabr.com',
          OperadorNome: 'Leonardo Miguel',
          OperadorCargo: 'Admin',
          StatusFinal: 'Concluído',
          StatusPicking: 'Entregue',
          NomeCliente: 'João Silva',
          Bairro: 'Centro',
          Cidade: 'São Paulo',
          DistanciaKm: 5.2,
          NomeEntregador: 'Carlos Santos',
          VeiculoTipo: 'Moto',
          Tags: 'teste,exemplo',
          AvaliacaoCliente: 5
        }
      };
      
      const response = await this._makeRequest(`${this.baseUrl}/sites/${siteId}/lists/${listId}/items`, {
        method: 'POST',
        body: JSON.stringify(sampleOrder),
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      console.log('[GraphClient] ✅ Pedido de exemplo adicionado');
      return response;
      
    } catch (error) {
      console.error('[GraphClient] Erro ao adicionar exemplo:', error);
      throw error;
    }
  }
  
  // ==================== Métodos Privados ====================
  
  /**
   * Faz requisição HTTP com retry e autenticação
   * @private
   */
  async _makeRequest(url, options = {}, retryCount = 0) {
    try {
      // Obter access token
      let headers = { ...options.headers };
      
      if (!options.skipAuth) {
        const token = await this.authHelper.getAccessToken();
        headers['Authorization'] = `Bearer ${token}`;
      }
      
      // Fazer requisição — rotear pelo background em páginas de terceiros para contornar CSP
      const _fetchProxy = (() => {
        try {
          const h = window.location.hostname;
          const isThirdParty = h !== 'picking-admin.backoffice.gpa.digital' &&
                               !h.endsWith('.chromiumapp.org') &&
                               !window.location.protocol.startsWith('chrome-extension');
          if (isThirdParty && typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) {
            return (u, o) => new Promise((res, rej) => {
              chrome.runtime.sendMessage({ action: 'nexos_fetch', url: u, method: o.method || 'GET', headers: o.headers || {}, body: o.body }, (r) => {
                if (chrome.runtime.lastError) return rej(new Error(chrome.runtime.lastError.message));
                if (!r) return rej(new Error('Sem resposta do background'));
                res({ ok: r.ok, status: r.status, statusText: String(r.status),
                  text: () => Promise.resolve(r.body || ''),
                  json: () => { try { return Promise.resolve(JSON.parse(r.body || '{}')); } catch(e) { return Promise.reject(e); } }
                });
              });
            });
          }
        } catch (e) {}
        return fetch;
      })();
      const response = await _fetchProxy(url, {
        method: options.method || 'GET',
        headers,
        body: options.body
      });
      
      // Tratar erros HTTP
      if (!response.ok) {
        const error = new Error(`HTTP ${response.status}: ${response.statusText}`);
        error.status = response.status;
        error.response = response;
        
        // ✅ CRÍTICO: Limpar caches inválidos quando detectar HTTP 401
        if (response.status === 401) {
          console.error('[GraphClient] 🔑 HTTP 401: Token inválido - limpando caches...');
          
          if (window.unifiedAuth) {
            window.unifiedAuth.tokenCache = null;
            window.unifiedAuth.tokenExpiryTime = 0;
          }
          if (window.tokenInterceptor) {
            window.tokenInterceptor.lastToken = null;
            window.tokenInterceptor.lastTokenTime = null;
          }
          if (window.tokenStorageScanner) {
            window.tokenStorageScanner.lastToken = null;
            window.tokenStorageScanner.lastScanTime = null;
          }
          
          console.log('[GraphClient] ✅ Caches limpos - próximo request usará novo token');
        }
        
        // Retry em erros 429 (throttling) ou 5xx
        if ((response.status === 429 || response.status >= 500) && retryCount < this.maxRetries) {
          const retryAfter = response.headers.get('Retry-After') || this.retryDelay;
          const delay = typeof retryAfter === 'string' ? parseInt(retryAfter) * 1000 : retryAfter;
          
          console.warn(`[GraphClient] Retry ${retryCount + 1}/${this.maxRetries} após ${delay}ms`);
          await this._sleep(delay);
          return this._makeRequest(url, options, retryCount + 1);
        }
        
        throw error;
      }
      
      // Retornar raw ou JSON
      if (options.raw) {
        return await response.text();
      }
      
      // No content (204)
      if (response.status === 204) {
        return { success: true };
      }
      
      return await response.json();
      
    } catch (error) {
      // Retry em erros de rede
      if (error.name === 'TypeError' && retryCount < this.maxRetries) {
        console.warn(`[GraphClient] Erro de rede, retry ${retryCount + 1}/${this.maxRetries}`);
        await this._sleep(this.retryDelay * Math.pow(2, retryCount));
        return this._makeRequest(url, options, retryCount + 1);
      }
      
      throw error;
    }
  }
  
  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  /**
   * Limpa cache de responses
   */
  clearCache() {
    this.cache.clear();
    console.log('[GraphClient] Cache limpo');
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SHAREPOINT LISTS METHODS (para Nexos_PedidosExtraidos)
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Lista todas as listas disponíveis no site (útil para debug)
   * @returns {Promise<Array>} Array de listas
   */
  async getLists() {
    try {
      const siteId = await this._resolveSiteId();
      const url = `${this.baseUrl}/sites/${siteId}/lists`;
      
      const response = await this._makeRequest(url);
      console.log('[GraphClient] ✅ Listas obtidas:', response.value?.length || 0);
      
      return response.value || [];
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao listar listas:', error);
      throw error;
    }
  }

  /**
   * Busca uma lista pelo nome (útil para obter o ID correto)
   * @param {string} listName - Nome da lista
   * @returns {Promise<Object>} Informações da lista
   */
  async getListByName(listName) {
    try {
      const siteId = await this._resolveSiteId();
      const url = `${this.baseUrl}/sites/${siteId}/lists/${listName}`;
      
      const response = await this._makeRequest(url);
      console.log('[GraphClient] ✅ Lista encontrada:', listName, '| ID:', response.id);
      
      return response;
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao buscar lista:', listName, error);
      throw error;
    }
  }

  /**
   * Cria um item em uma lista do SharePoint
   * @param {string} listName - Nome da lista
   * @param {Object} fields - Campos do item
   * @returns {Promise<Object>} Item criado
   */
  async createListItem(listName, fields) {
    try {
      const siteId = await this._resolveSiteId();
      
      // ✅ CORREÇÃO: Obter List ID primeiro (Graph API precisa do ID, não do nome)
      console.log('[GraphClient] 🔍 Obtendo ID da lista:', listName);
      const list = await this.getListByName(listName);
      
      if (!list || !list.id) {
        throw new Error(`Lista "${listName}" não encontrada no SharePoint`);
      }
      
      console.log('[GraphClient] ✅ Lista encontrada - ID:', list.id);
      
      const url = `${this.baseUrl}/sites/${siteId}/lists/${list.id}/items`;
      
      const body = {
        fields: fields
      };

      console.log('[GraphClient] 📤 Criando item na lista...');
      const response = await this._makeRequest(url, {
        method: 'POST',
        body: JSON.stringify(body)
      });

      console.log('[GraphClient] ✅ Item criado na lista:', listName, '| Item ID:', response.id);
      return response;
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao criar item na lista:', listName);
      console.error('[GraphClient] 💡 Verifique se a lista existe e se você tem permissão de escrita');
      console.error('[GraphClient] Erro:', error.message);
      throw error;
    }
  }

  /**
   * Atualiza um item em uma lista do SharePoint
   * @param {string} listName - Nome da lista (display name)
   * @param {string} itemId - ID do item
   * @param {Object} fields - Campos a atualizar
   * @returns {Promise<Object>} Item atualizado
   */
  async updateListItem(listName, itemId, fields) {
    try {
      const siteId = await this._resolveSiteId();
      
      // ✅ CORREÇÃO: Obter List ID primeiro
      console.log('[GraphClient] 🔍 Obtendo ID da lista:', listName);
      const list = await this.getListByName(listName);
      
      if (!list || !list.id) {
        throw new Error(`Lista "${listName}" não encontrada no SharePoint`);
      }
      
      const url = `${this.baseUrl}/sites/${siteId}/lists/${list.id}/items/${itemId}`;
      
      const body = {
        fields: fields
      };

      console.log('[GraphClient] 📤 Atualizando item:', itemId);
      const response = await this._makeRequest(url, {
        method: 'PATCH',
        body: JSON.stringify(body)
      });

      console.log('[GraphClient] ✅ Item atualizado:', itemId);
      return response;
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao atualizar item:', error);
      throw error;
    }
  }

  /**
   * Cria ou atualiza item na lista (upsert baseado em campo de match)
   * @param {string} listName - Nome da lista
   * @param {Object} itemData - Dados do item
   * @param {Object} options - Opções de match
   * @param {string} options.matchField - Campo para buscar item existente
   * @param {*} options.matchValue - Valor do campo de match
   * @returns {Promise<Object>} Item criado ou atualizado
   */
  async createOrUpdateListItem(listName, itemData, options = {}) {
    try {
      const { matchField, matchValue } = options;
      
      if (!matchField || matchValue === undefined) {
        // Sem match field, cria item novo
        console.log('[GraphClient] ➕ Criando novo item (sem match field)');
        return await this.createListItem(listName, itemData);
      }
      
      // Buscar item existente com filter
      console.log(`[GraphClient] 🔍 Buscando item com ${matchField}='${matchValue}'`);
      const filter = `fields/${matchField} eq '${matchValue}'`;
      const items = await this.getListItems(listName, { filter, top: 1 });
      
      if (items && items.length > 0) {
        // Atualizar item existente
        const existingItem = items[0];
        console.log('[GraphClient] ♻️ Item encontrado, atualizando:', existingItem.id);
        return await this.updateListItem(listName, existingItem.id, itemData);
      } else {
        // Criar novo item
        console.log('[GraphClient] ➕ Item não encontrado, criando novo');
        return await this.createListItem(listName, itemData);
      }
    } catch (error) {
      console.error('[GraphClient] ❌ Erro em createOrUpdateListItem:', error);
      throw error;
    }
  }

  /**
   * Busca itens de uma lista do SharePoint
   * @param {string} listName - Nome da lista
   * @param {Object} options - Opções de query
   * @param {string} options.filter - Filtro OData
   * @param {string} options.select - Campos a selecionar
   * @param {string} options.orderBy - Ordenação
   * @param {number} options.top - Limite de resultados
   * @returns {Promise<Array>} Lista de itens
   */
  async getListItems(listName, options = {}) {
    try {
      const siteId = await this._resolveSiteId();
      
      // ✅ CORREÇÃO: Obter List ID primeiro
      const list = await this.getListByName(listName);
      
      if (!list || !list.id) {
        throw new Error(`Lista "${listName}" não encontrada no SharePoint`);
      }
      
      let url = `${this.baseUrl}/sites/${siteId}/lists/${list.id}/items?$expand=fields`;
      
      // Adicionar parâmetros de query
      if (options.filter) {
        url += `&$filter=${encodeURIComponent(options.filter)}`;
      }
      if (options.select) {
        url += `&$select=${options.select}`;
      }
      if (options.orderBy) {
        url += `&$orderby=${options.orderBy}`;
      }
      if (options.top) {
        url += `&$top=${options.top}`;
      }

      const response = await this._makeRequest(url);

      console.log('[GraphClient] ✅ Itens obtidos:', response.value?.length || 0);
      
      // Extrair campos dos itens (Graph retorna em .fields)
      const items = (response.value || []).map(item => ({
        id: item.id,
        ...item.fields
      }));
      
      return items;
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao buscar itens:', error);
      throw error;
    }
  }

  /**
   * Alias para getListItems (compatibilidade AuthTokenService)
   */
  async queryList(listName, options = {}) {
    return this.getListItems(listName, options);
  }

  /**
   * Busca um item específico por ID
   * @param {string} listName - Nome da lista
   * @param {string} itemId - ID do item
   * @returns {Promise<Object>} Item encontrado
   */
  async getListItem(listName, itemId) {
    try {
      const siteId = await this._resolveSiteId();
      const url = `${this.baseUrl}/sites/${siteId}/lists/${listName}/items/${itemId}?$expand=fields`;

      const response = await this._makeRequest(url);

      console.log('[GraphClient] ✅ Item obtido:', itemId);
      return response;
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao buscar item:', error);
      throw error;
    }
  }

  /**
   * Deleta um item de uma lista
   * @param {string} listName - Nome da lista
   * @param {string} itemId - ID do item
   * @returns {Promise<boolean>} Sucesso
   */
  async deleteListItem(listName, itemId) {
    try {
      const siteId = await this._resolveSiteId();
      const url = `${this.baseUrl}/sites/${siteId}/lists/${listName}/items/${itemId}`;

      await this._makeRequest(url, {
        method: 'DELETE'
      });

      console.log('[GraphClient] ✅ Item deletado:', itemId);
      return true;
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao deletar item:', error);
      throw error;
    }
  }

  /**
   * Busca item por campo específico (ex: PedidoID)
   * @param {string} listName - Nome da lista
   * @param {string} fieldName - Nome do campo
   * @param {string} value - Valor a buscar
   * @returns {Promise<Object|null>} Item encontrado ou null
   */
  async findListItemByField(listName, fieldName, value) {
    try {
      const filter = `fields/${fieldName} eq '${value}'`;
      const items = await this.getListItems(listName, { 
        filter,
        top: 1 
      });

      return items.length > 0 ? items[0] : null;
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao buscar item por campo:', error);
      return null;
    }
  }
}

// Export para uso em módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = GraphClient;
}

// Export global para content scripts
if (typeof window !== 'undefined') {
  window.GraphClient = GraphClient;
  console.log('[GraphClient] ✅ Disponível globalmente');
}
