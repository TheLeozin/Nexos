/**
 * ════════════════════════════════════════════════════════════════════════════
 * PICKING SHAREPOINT MANAGER - Gerenciamento de Pedidos no SharePoint
 * ════════════════════════════════════════════════════════════════════════════
 * 
 * 🆕 V3.0: SharePoint como fonte única de verdade para pedidos
 * 
 * Responsável por:
 * - CRUD de pedidos no SharePoint
 * - Gerenciar locks de edição (concorrência)
 * - Salvar timeline de eventos
 * - Gerenciar fila de jobs
 * - Sincronização entre múltiplos usuários
 * - Logs operacionais e auditoria
 * 
 * Estrutura SharePoint (LISTAS REAIS):
 * 
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ 📋 LISTA: Nexos_StatusPedidos (Solicitações/Tentativas de Envio)       │
 * │ URL: /sites/Nexos/Lists/Nexos_StatusPedidos                             │
 * ├─────────────────────────────────────────────────────────────────────────┤
 * │ ✅ CAMPOS (Status e Controle de Envio):                                 │
 * │   - OrderID (texto)              - ID único: "LOJA-PEDIDO-TENT" (idx)  │
 * │   - IDPedidoGPA (texto)          - 🔗 FK para Nexos_Pedidos            │
 * │   - StatusPicking (texto)        - pendente/solicitado/cancelado/...   │
 * │   - PlataformadeEnvio (opção)    - Uber/Lalamove/99/WhatsApp/Manual    │
 * │   - UltimaAtualizacao (data)     - Timestamp da última modificação     │
 * │   - ProcessandoPor (pessoa)      - Usuário processando                 │
 * │   - EnviadoPor (pessoa)          - Usuário que enviou                  │
 * │   - HorariodeEnvio (data)        - Quando foi enviado                  │
 * │   - LogdeOperacoes (texto ML)    - Log de ações desta tentativa        │
 * │   - LockExpiration (data)        - Expiração do lock                   │
 * │   - TrackingLink (texto)          - URL de tracking                     │
 * │   - StatusConsolidado (opção)    - Status consolidado                  │
 * │   - TotalTentativas (número)     - Contador de tentativas              │
 * │   - IDUltimaTentativa (número)   - ID da última tentativa              │
 * │   - TemItensFila (Sim/Não)       - Flag para jobs pendentes            │
 * │   - Pedido (lookup)              - 🔗 Lookup para Nexos_Pedidos        │
 * └─────────────────────────────────────────────────────────────────────────┘
 * 
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ 📦 LISTA: Nexos_Pedidos (Dados Únicos dos Pedidos)                      │
 * │ URL: /sites/Nexos/Lists/Nexos_Pedidos                                   │
 * ├─────────────────────────────────────────────────────────────────────────┤
 * │ ✅ CAMPOS (Dados Imutáveis do Picking):                                 │
 * │   🔑 IDENTIFICAÇÃO:                                                      │
 * │   - IDPedidoGPA (título/PK)      - ID único do pedido (indexed)        │
 * │   - CodigoLoja (texto)           - Código da loja (PA1406)             │
 * │   - DataExtracao (data)          - Quando foi extraído                 │
 * │   - VersaoExtracao (texto)       - Versão da lógica (v3.1.0)           │
 * │   - OrigemDados (texto)          - Picking Admin                       │
 * │   - HashPedido (texto)           - MD5 para detectar mudanças          │
 * │   👤 CLIENTE:                                                            │
 * │   - NomeCliente (texto)          - Nome completo                       │
 * │   - TelefoneCliente (texto)      - Telefone com código                 │
 * │   - CelularCliente (texto)       - Celular formatado                   │
 * │   🏠 ENDEREÇO:                                                           │
 * │   - EnderecoCompleto (texto ML)  - Endereço formatado completo         │
 * │   - EnderecoLogradouro (texto)   - Rua/Av                              │
 * │   - NumeroLogradouro (texto)     - Número                              │
 * │   - Complemento (texto)          - Apto, bloco                         │
 * │   - Bairro (texto)               - Bairro                              │
 * │   - Cidade (texto)               - Município                           │
 * │   - UF (texto)                   - Estado                              │
 * │   - CEP (texto)                  - Código postal                       │
 * │   💰 FINANCEIRO:                                                         │
 * │   - ValorPedido (moeda)          - Valor total                         │
 * │   - BandeiraPagamento (texto)    - Mastercard/Visa/PIX                 │
 * │   - SemCobranca (Sim/Não)        - Flag sem cobrança                   │
 * │   📦 VOLUMETRIA:                                                         │
 * │   - VolumetriaJSON (texto ML)    - Array JSON com itens                │
 * │   - TotalItens (número)          - Soma de quantidades                 │
 * │   - TiposItens (número)          - Quantidade de tipos diferentes      │
 * │   📊 METADADOS:                                                          │
 * │   - StatusPedidoOriginal (opção) - Status no momento da extração       │
 * │   - FlagEntregue (opção)         - Reenvio/Retirada/Ida e volta        │
 * │   - DataColeta (data)            - Data da coleta                      │
 * │   - Observacoes (texto ML)       - Observações gerais                  │
 * └─────────────────────────────────────────────────────────────────────────┘
 * 
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ 🔄 LISTA: Nexos_FilaPedidos (Fila de Envio)                             │
 * │ URL: /sites/Nexos/Lists/Nexos_FilaPedidos                               │
 * ├─────────────────────────────────────────────────────────────────────────┤
 * │ Campos principais:                                                       │
 * │   - Title (text)                 - Título do job                         │
 * │   - JobID (text, indexed)        - ID único do job                      │
 * │   - OrderID (text, indexed)      - Referência ao pedido                 │
 * │   - JobType (choice)             - send_to_platform/retry/cleanup      │
 * │   - Platform (choice)            - uber/lalamove/99/whatsapp           │
 * │   - Status (choice)              - pending/processing/completed/failed │
 * │   - Priority (number)            - Prioridade (1=alta, 5=baixa)        │
 * │   - CreatedAt (datetime)         - Data de criação                     │
 * │   - ProcessedAt (datetime)       - Quando foi processado               │
 * │   - RetryCount (number)          - Número de tentativas                │
 * │   - MaxRetries (number)          - Máximo de tentativas (padrão: 3)   │
 * │   - ErrorMessage (text)          - Mensagem de erro (se falhou)        │
 * │   - Result (text)                - Resultado do processamento          │
 * └─────────────────────────────────────────────────────────────────────────┘
 * 
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ 📜 LISTA: Nexos_TimelinePedidos (Timeline de Eventos)                   │
 * │ URL: /sites/Nexos/Lists/Nexos_TimelinePedidos                           │
 * ├─────────────────────────────────────────────────────────────────────────┤
 * │ Campos principais:                                                       │
 * │   - Title (text)                 - Título do evento                      │
 * │   - EventID (text, indexed)      - ID único do evento                   │
 * │   - OrderID (text, indexed)      - Referência ao pedido                 │
 * │   - EventType (choice)           - extracted/status_change/sent/...    │
 * │   - EventData (text)             - JSON com detalhes do evento         │
 * │   - Timestamp (datetime)         - Data/hora do evento                 │
 * │   - UserEmail (text)             - Email do usuário                    │
 * │   - UserName (text)              - Nome do usuário                     │
 * │   - Message (text)               - Mensagem descritiva                 │
 * └─────────────────────────────────────────────────────────────────────────┘
 * 
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ 📊 LISTA: Nexos_Logs (Logs Operacionais)                                │
 * │ URL: /sites/Nexos/Lists/Nexos_Logs                                      │
 * ├─────────────────────────────────────────────────────────────────────────┤
 * │ Campos principais:                                                       │
 * │   - Title (text)                 - Título do log                         │
 * │   - LogLevel (choice)            - info/warning/error/debug            │
 * │   - Category (choice)            - picking/auth/sync/platform          │
 * │   - Message (text)               - Mensagem do log                      │
 * │   - Details (text)               - Detalhes adicionais (JSON)          │
 * │   - Timestamp (datetime)         - Data/hora do log                    │
 * │   - UserEmail (text)             - Email do usuário                    │
 * │   - OrderID (text)               - Referência ao pedido (opcional)     │
 * └─────────────────────────────────────────────────────────────────────────┘
 * 
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ 🔐 LISTA: Nexos_AuditLog (Logs de Auditoria)                            │
 * │ URL: /sites/Nexos/Lists/Nexos_AuditLog                                  │
 * ├─────────────────────────────────────────────────────────────────────────┤
 * │ Campos principais:                                                       │
 * │   - Title (text)                 - Título da operação                    │
 * │   - Operation (choice)           - create/read/update/delete           │
 * │   - EntityType (choice)          - order/lock/timeline/queue           │
 * │   - EntityID (text)              - ID da entidade afetada              │
 * │   - UserEmail (text)             - Email do usuário                    │
 * │   - UserName (text)              - Nome do usuário                     │
 * │   - Timestamp (datetime)         - Data/hora da operação               │
 * │   - BeforeValue (text)           - Valor antes (JSON)                  │
 * │   - AfterValue (text)            - Valor depois (JSON)                 │
 * │   - Success (boolean)            - Se a operação foi bem-sucedida      │
 * │   - ErrorMessage (text)          - Mensagem de erro (se falhou)        │
 * │   - IPAddress (text)             - IP do usuário                       │
 * │   - UserAgent (text)             - User agent do navegador             │
 * └─────────────────────────────────────────────────────────────────────────┘
 */

class PickingSharePointManager {
  constructor() {
    this.graphUrl = 'https://graph.microsoft.com/v1.0';
    this.siteId = null;
    this.listIds = {
      orders: null,        // Nexos_StatusPedidos (solicitações/tentativas)
      pedidos: null,       // 🆕 Nexos_Pedidos (dados únicos dos pedidos)
      lojas: null,         // 🆕 Nexos_Lojas (cadastro de lojas)
      queue: null,         // Nexos_FilaPedidos
      timeline: null,      // Nexos_TimelinePedidos
      logs: null,          // Nexos_Logs
      auditLog: null       // Nexos_AuditLog
    };
    this.listNames = {
      orders: 'Nexos_StatusPedidos',
      pedidos: 'Nexos_Pedidos',  // 🆕 Nova lista de pedidos
      lojas: 'Nexos_Lojas',      // 🆕 Nova lista de lojas
      queue: 'Nexos_FilaPedidos',
      timeline: 'Nexos_TimelinePedidos',
      logs: 'Nexos_Logs',
      auditLog: 'Nexos_AuditLog'
    };
    this.lojasCache = new Map(); // Cache de lojas por código
    this.externalToken = null;
    this.initialized = false;
    this.initPromise = null; // Para evitar múltiplas inicializações simultâneas
    // ⏱️ Offset entre relógio local e servidor (ms). Evita erros por relógio local errado.
    this._serverTimeOffset = 0;
  }

  /**
   * ⏱️ Sincronizar relógio local com o servidor (Graph API UTC).
   * Computa _serverTimeOffset = serverTime - Date.now().
   * Silencioso: se falhar, mantém offset = 0 (usa relógio local).
   */
  async _syncServerTime() {
    try {
      // Tentar via background (evita CSP de páginas terceiras)
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        const result = await new Promise((resolve) => {
          try {
            chrome.runtime.sendMessage({ action: 'nexos_get_server_time' }, (res) => {
              if (chrome.runtime.lastError) { resolve(null); return; }
              resolve(res || null);
            });
          } catch (_e) { resolve(null); } // Extension context invalidated
        });
        if (result && result.ok && result.serverMs) {
          this._serverTimeOffset = result.serverMs - result.localMs;
          console.log(`[PickingSharePoint] ⏱️ Offset servidor: ${this._serverTimeOffset > 0 ? '+' : ''}${Math.round(this._serverTimeOffset / 1000)}s`);
          return;
        }
      }
      // Fallback direto — APENAS em contextos sem CSP restritiva (extensão ou backoffice)
      const isThirdPartyHost = (() => {
        try {
          const h = window.location.hostname;
          return h !== 'picking-admin.backoffice.gpa.digital' &&
                 !h.endsWith('.chromiumapp.org') &&
                 !window.location.protocol.startsWith('chrome-extension');
        } catch (_) { return true; }
      })();
      if (isThirdPartyHost) {
        // Página com CSP restritiva — não tentar fetch direto ao graph.microsoft.com
        return;
      }
      const t0 = Date.now();
      const res = await fetch('https://graph.microsoft.com/v1.0/', { method: 'HEAD' });
      const dateHeader = res.headers.get('Date') || res.headers.get('date');
      if (dateHeader) {
        const serverMs = new Date(dateHeader).getTime();
        this._serverTimeOffset = serverMs - t0;
        console.log(`[PickingSharePoint] ⏱️ Offset servidor (fallback): ${this._serverTimeOffset > 0 ? '+' : ''}${Math.round(this._serverTimeOffset / 1000)}s`);
      }
    } catch (e) {
      // Silencioso — sem acesso ao servidor, offset permanece 0
      console.warn('[PickingSharePoint] ⚠️ _syncServerTime falhou, usando relógio local:', e?.message);
    }
  }

  /**
   * ⏱️ Retorna "agora" em ms corrigido pelo offset do servidor (UTC real).
   * Use sempre no lugar de Date.now() para comparações de lock.
   */
  _nowUtcMs() {
    return Date.now() + this._serverTimeOffset;
  }

  /**
   * Garantir que exista um BroadcastChannel persistente em window.__nexosBC
   * Retorna o canal ou null
   */
  _ensureBroadcastChannel() {
    try {
      if (typeof BroadcastChannel === 'undefined') return null;
      if (window && window.__nexosBC) return window.__nexosBC;

      try {
        window.__nexosBC = new BroadcastChannel('nexos-picking');
        // Listener padrão (caso overlay não esteja ativo)
        window.__nexosBC.addEventListener('message', (ev) => {
          try {
            const payload = ev?.data || {};
            if (payload && (payload.reason === 'pedido_updated' || payload.pedidoId)) {
              if (typeof window.refreshOrdersList === 'function') {
                window.refreshOrdersList();
              }
            }
            // sinaliza que o canal está operacional
            try { if (typeof window.__nexos_update_bc_status_badge === 'function') window.__nexos_update_bc_status_badge('green'); } catch(e) {}
          } catch (e) {
            // ignore
          }
        });

        window.__nexosBC_operational = true;
        try { if (typeof window.__nexos_update_bc_status_badge === 'function') window.__nexos_update_bc_status_badge('green'); } catch(e) {}
        return window.__nexosBC;
      } catch (createErr) {
        console.warn('[PickingSharePoint] ⚠️ Falha ao criar BroadcastChannel persistente:', createErr?.message || createErr);
        window.__nexosBC = null;
        window.__nexosBC_operational = false;
        try { if (typeof window.__nexos_update_bc_status_badge === 'function') window.__nexos_update_bc_status_badge('yellow'); } catch(e) {}
        return null;
      }
    } catch (e) {
      return null;
    }
  }

  /**
   * Envia mensagem de notificação entre abas de forma robusta.
   * Tenta: (1) reusar canal persistente; (2) criar persistente; (3) usar canal temporário; (4) fallback localStorage
   */
  _postBroadcastMessage(payload) {
    try {
      // 1) Tentar reusar canal persistente já existente
      if (window && window.__nexosBC) {
        try {
          window.__nexosBC.postMessage(payload);
          try { if (typeof window.__nexos_update_bc_status_badge === 'function') window.__nexos_update_bc_status_badge('green'); } catch(e) {}
          return;
        } catch (e) {
          console.warn('[PickingSharePoint] ⚠️ Erro ao postar no BroadcastChannel persistente:', e?.message || e);
          // tentar recriar abaixo
        }
      }

      // 2) Tentar criar/reusar persistent channel
      const persistent = this._ensureBroadcastChannel();
      if (persistent) {
        try {
          persistent.postMessage(payload);
          try { if (typeof window.__nexos_update_bc_status_badge === 'function') window.__nexos_update_bc_status_badge('green'); } catch(e) {}
          return;
        } catch (e) {
          console.warn('[PickingSharePoint] ⚠️ Erro ao postar no BroadcastChannel recém-criado:', e?.message || e);
        }
      }

      // 3) Criar canal temporário, postar e fechar
      if (typeof BroadcastChannel !== 'undefined') {
        try {
          const temp = new BroadcastChannel('nexos-picking');
          temp.postMessage(payload);
          try { temp.close(); } catch(e) {}
          try { if (typeof window.__nexos_update_bc_status_badge === 'function') window.__nexos_update_bc_status_badge('green'); } catch(e) {}
          return;
        } catch (tempErr) {
          console.warn('[PickingSharePoint] ⚠️ Erro ao usar BroadcastChannel temporário:', tempErr?.message || tempErr);
        }
      }

      // 4) Fallback: localStorage ping
      try {
        localStorage.setItem('nexos-picking-refresh', JSON.stringify({ ts: Date.now(), payload }));
        try { if (typeof window.__nexos_update_bc_status_badge === 'function') window.__nexos_update_bc_status_badge('yellow'); } catch(e) {}
      } catch (lsErr) {
        console.warn('[PickingSharePoint] ⚠️ Falha ao gravar localStorage como fallback de notificação:', lsErr?.message || lsErr);
      }
    } catch (e) {
      // não propagar erro principal
      console.warn('[PickingSharePoint] ⚠️ _postBroadcastMessage falhou silenciosamente:', e?.message || e);
    }
  }

  /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 🔧 INICIALIZAÇÃO
   * ═══════════════════════════════════════════════════════════════════════════
   */

  /**
   * Inicializar com MSAL (obtém token automaticamente)
   */
  async initialize() {
    if (this.initPromise) {
      return this.initPromise;
    }

    this.initPromise = this._doInitialize();
    return this.initPromise;
  }

  async _doInitialize() {

    try {
      // ═══════════════════════════════════════════════════════════════════════
      // Obter token sem chamadas de rede (evita CSP em páginas de terceiros)
      // Prioridade: memória → chrome.storage.local → localStorage → MSAL
      // A chamada MSAL (getMSALToken) pode disparar acquireTokenSilent que
      // faz fetch para login.microsoftonline.com — bloqueado pelo CSP do Uber.
      // ═══════════════════════════════════════════════════════════════════════
      let token = null;

      // 1) NexosAuth em memória (sem rede)
      if (!token && window.NexosAuth?.getToken) {
        try { token = await window.NexosAuth.getToken(); } catch (_) {}
      }

      // 2) chrome.storage.local — não exige rede, funciona em qualquer página
      if (!token && typeof chrome !== 'undefined' && chrome.storage?.local) {
        try {
          const r = await new Promise(res =>
            chrome.storage.local.get(['nexos-user-session'], res)
          );
          const sess = r['nexos-user-session'];
          if (sess?.user?.accessToken) {
            token = sess.user.accessToken;
            // Restaurar usuário em memória para consultas futuras
            if (window.NexosAuth && !window.NexosAuth.getCurrentUser()) {
              try { window.NexosAuth._restoreUser?.(sess.user); } catch (_) {}
            }
          }
        } catch (_) {}
      }

      // 3) localStorage (fallback rápido)
      if (!token) {
        try {
          const raw = localStorage.getItem('nexos-user-session');
          if (raw) {
            const d = JSON.parse(raw);
            if (d?.user?.accessToken) token = d.user.accessToken;
          }
        } catch (_) {}
        if (!token) {
          try {
            const raw2 = localStorage.getItem('access-token');
            if (raw2) {
              try { const d = JSON.parse(raw2); token = d?.access_token || null; } catch (_) { token = raw2; }
            }
          } catch (_) {}
        }
      }

      // 4) Fallback: getMSALToken (pode fazer chamadas de rede; último recurso)
      if (!token) {
        if (!window.unifiedAuth) {
          throw new Error('Sem token disponível e UnifiedAuth não encontrado. Faça login na extensão.');
        }
        try { token = await window.unifiedAuth.getMSALToken(); } catch (_) {}
      }

      if (!token) {
        throw new Error('Não foi possível obter token. Faça login na extensão Nexos primeiro.');
      }

      return await this.initializeWithToken(token);

    } catch (error) {
      console.error('[PickingSharePoint] ❌ Erro na inicialização:', error);
      this.initialized = false;
      this.initPromise = null;
      
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Inicializar com token externo
   */
  async initializeWithToken(accessToken) {

    try {
      if (!accessToken) {
        throw new Error('Access token não fornecido');
      }

      this.externalToken = accessToken;

      // Obter Site ID
      const siteResponse = await this._fetch(
        `${this.graphUrl}/sites/gpabr.sharepoint.com:/sites/Nexos`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (!siteResponse.ok) {
        const errorText = await siteResponse.text();
        
        // 🔥 Detectar token expirado (401 + "expired")
        if (siteResponse.status === 401 && errorText.includes('expired')) {
          // Criar erro específico para token expirado (log suprimido — tratado acima pela camada de overlay)
          const expiredError = new Error('TOKEN_EXPIRED');
          expiredError.isTokenExpired = true;
          expiredError.userMessage = 'Sua sessão expirou. Por favor, faça login novamente para continuar.';
          throw expiredError;
        }
        
        // 🔒 Detectar erro de permissão (403)
        if (siteResponse.status === 403) {
          console.error('[PickingSharePoint] 🔒 ACESSO NEGADO (HTTP 403)');
          const permissionError = new Error(`HTTP 403 accessDenied - Você não tem permissão para acessar o site SharePoint: ${this.sitePath}`);
          permissionError.statusCode = 403;
          throw permissionError;
        }
        
        throw new Error(`Erro ao acessar site: HTTP ${siteResponse.status} - ${errorText}`);
      }

      const siteData = await siteResponse.json();
      this.siteId = siteData.id;

      // Obter IDs de todas as listas
      for (const [key, listName] of Object.entries(this.listNames)) {
        const listId = await this._getListId(listName);
        this.listIds[key] = listId;
      }

      this.initialized = true;
      // ⏱️ Sincronizar relógio com o servidor (corrige máquinas com horário errado)
      this._syncServerTime().catch(() => {}); // fire-and-forget, não bloqueia
      // Tentar criar o BroadcastChannel persistente para comunicações cross-tab
      try {
        this._ensureBroadcastChannel();
      } catch (e) {
        console.warn('[PickingSharePoint] ⚠️ Não foi possível inicializar BroadcastChannel:', e?.message || e);
      }
      // Atualizar badge de status do SharePoint (overlay pode exibir)
      try { if (typeof window.__nexos_update_sp_status_badge === 'function') window.__nexos_update_sp_status_badge('green'); } catch(e) {}

      return {
        success: true,
        siteId: this.siteId,
        listIds: this.listIds
      };

    } catch (error) {
      // ✅ Token expirado é um caso esperado, não é erro crítico
      if (error.message === 'TOKEN_EXPIRED' || error.isTokenExpired) {
        try { if (typeof window.__nexos_update_sp_status_badge === 'function') window.__nexos_update_sp_status_badge('yellow'); } catch(e) {}
      } else {
        console.error('[PickingSharePoint] ❌ Erro na inicialização:', error);
        try { if (typeof window.__nexos_update_sp_status_badge === 'function') window.__nexos_update_sp_status_badge('red'); } catch(e) {}
        
        // 🔍 Se for erro 403, executar diagnóstico detalhado
        if (error.message.includes('403') || error.message.includes('accessDenied')) {
          await this._diagnosePermissions();
        }
      }
      
      this.initialized = false;
      this.initPromise = null;
      
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Obter ID de uma lista pelo nome
   */
  async _getListId(listName) {
    const accessToken = await this._getAccessToken();
    
    const response = await this._fetch(
      `${this.graphUrl}/sites/${this.siteId}/lists?$filter=displayName eq '${listName}'`,
      {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Erro ao buscar lista ${listName}: HTTP ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    
    if (!data.value || data.value.length === 0) {
      throw new Error(`Lista ${listName} não encontrada! Execute o setup primeiro.`);
    }

    return data.value[0].id;
  }

  /**
   * Proxy de fetch que contorna CSP de páginas hospedeiras.
   * Em páginas de terceiros (Uber, Lalamove, etc.) roteia a requisição pelo
   * background service worker, que não está sujeito à CSP da página.
   * Em páginas da extensão / backoffice, usa o fetch nativo diretamente.
   */
  async _fetch(url, options = {}) {
    // Detectar se estamos em página de terceiros que pode ter CSP restritiva
    const isThirdParty = (() => {
      try {
        const host = window.location.hostname;
        return host !== 'picking-admin.backoffice.gpa.digital' &&
               !host.endsWith('.chromiumapp.org') &&
               !window.location.protocol.startsWith('chrome-extension');
      } catch (e) { return false; }
    })();

    if (isThirdParty && typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      return new Promise((resolve, reject) => {
        try {
          chrome.runtime.sendMessage({
            action: 'nexos_fetch',
            url,
            method: options.method || 'GET',
            headers: options.headers || {},
            body: options.body || undefined
          }, (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
              return;
            }
            if (!response) {
              reject(new Error('Sem resposta do background (proxy fetch)'));
              return;
            }
            // Emular interface Response suficiente para o código existente
            resolve({
              ok: response.ok,
              status: response.status,
              text: () => Promise.resolve(response.body || ''),
              json: () => {
                try { return Promise.resolve(JSON.parse(response.body || '{}')); }
                catch (e) { return Promise.reject(new Error('JSON inválido: ' + response.body)); }
              }
            });
          });
        } catch (_e) {
          // Extension context invalidated — cair no fetch direto
          reject(new Error('Extension context invalidated'));
        }
      });
    }

    // Contexto sem CSP restritiva — fetch nativo
    return fetch(url, options);
  }

  /**
   * Obter token de acesso (externo ou via MSAL)
   */
  async _getAccessToken() {
    // 🔥 SEMPRE buscar token fresco do UnifiedAuth (auto-renova se expirado)
    if (window.unifiedAuth && window.unifiedAuth.getMSALToken) {
      try {
        const token = await window.unifiedAuth.getMSALToken();
        if (token) {
          // Atualizar token em cache
          this.externalToken = token;
          return token;
        }
      } catch (error) {
        console.error('[PickingSharePoint] ❌ Erro ao obter token do UnifiedAuth:', error);
      }
    }
    
    // Fallback: usar token em cache (pode estar expirado)
    if (this.externalToken) {
      console.warn('[PickingSharePoint] ⚠️ Usando token em cache (pode estar expirado)');
      return this.externalToken;
    }

    throw new Error('Nenhum token disponível! Execute initialize() primeiro.');
  }

  /**
   * 🔍 Diagnosticar permissões do usuário no SharePoint
   * Chamado automaticamente quando detectar erro 403
   */
  async _diagnosePermissions() {
    
    try {
      // 1️⃣ Verificar usuário autenticado
      const currentUser = window.NexosAuth?.getCurrentUser();
      if (!currentUser) {
        console.error('❌ Nenhum usuário autenticado encontrado');
        return;
      }
      
      
      // 2️⃣ Verificar token e scopes
      const token = this.externalToken;
      if (!token) {
        console.error('❌ Nenhum token disponível');
        return;
      }
      
      // Decodificar token JWT (base64)
      try {
        const tokenParts = token.split('.');
        const payload = JSON.parse(atob(tokenParts[1]));
        
        
        // Verificar se tem os scopes necessários
        const scopes = payload.scp || payload.roles || '';
        const requiredScopes = ['Sites.ReadWrite.All', 'Sites.Manage.All', 'Sites.FullControl.All'];
        const hasRequiredScope = requiredScopes.some(scope => scopes.includes(scope));
        
        if (!hasRequiredScope) {
          console.error('❌ TOKEN NÃO TEM PERMISSÕES NECESSÁRIAS!');
          console.error('   Scopes atuais:', scopes);
          console.error('   Scopes necessários:', requiredScopes.join(' OU '));
        } else {
        }
        
      } catch (decodeError) {
        console.warn('⚠️ Não foi possível decodificar token:', decodeError);
      }
      
      // 3️⃣ Testar acesso ao site
      
      try {
        const siteResponse = await this._fetch(
          `${this.graphUrl}/sites/${this.sitePath}`,
          {
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            }
          }
        );
        
        if (siteResponse.ok) {
          const siteData = await siteResponse.json();
        } else {
          const errorText = await siteResponse.text();
          console.error(`❌ Erro ao acessar site: HTTP ${siteResponse.status}`);
          console.error('   Resposta:', errorText);
          
          if (siteResponse.status === 403) {
            console.error('🔒 DIAGNÓSTICO DO ERRO 403:');
            console.error('   1. Você não tem permissão no site SharePoint');
            console.error('   2. Verifique se você está no grupo de usuários autorizados');
            console.error('   3. URL do site: https://gpabr.sharepoint.com/sites/Nexos');
            console.error('   4. Solicite acesso ao administrador do SharePoint');
          }
        }
        
      } catch (fetchError) {
        console.error('❌ Erro ao testar acesso ao site:', fetchError);
      }
      
    } catch (error) {
      console.error('❌ Erro no diagnóstico:', error);
    }
    
  }

  /**
   * Garantir que está inicializado
   */
  _ensureInitialized() {
    if (!this.initialized) {
      throw new Error('PickingSharePointManager não inicializado! Chame initialize() primeiro.');
    }
  }

  /**
   * Gerar Order ID único e exclusivo para cada extração
   * Formato: NEXOS-{timestamp}-{loja}-{pedido_id}
   * Exemplo: NEXOS-1738261200000-1602-21360515
   */
  generateUniqueOrderID(loja, pedido_id) {
    // ✅ Formato com timestamp para permitir múltiplas tentativas
    const timestamp = Date.now();
    return `NEXOS-${timestamp}-${loja}-${pedido_id}`;
  }

  /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 📦 CRUD DE PEDIDOS
   * ═══════════════════════════════════════════════════════════════════════════
   */

  /**
   * 💾 CACHE: Obter LookupId do usuário autenticado
   * Busca no cache local primeiro, se não encontrar busca do Graph API (userData.id)
   * @param {string} email - Email do usuário
   * @returns {string|null} ID do SharePoint Site User como STRING
   */
  async _getCachedUserLookupId(email) {
    if (!email) return null;
    
    try {
      // 1️⃣ Tentar obter do cache local (chrome.storage)
      const cacheKey = `nexos-user-lookupid-${email}`;
      const cached = await chrome.storage.local.get(cacheKey);
      
      if (cached[cacheKey]) {
        return String(cached[cacheKey]);
      }
      
      // 2️⃣ Tentar obter do NexosAuth (userData.id do Graph API)
      if (window.NexosAuth) {
        const currentUser = window.NexosAuth.getCurrentUser();
        if (currentUser && currentUser.id && currentUser.email === email) {
          const lookupId = String(currentUser.id);
          
          // Salvar no cache para próxima vez
          await chrome.storage.local.set({ [cacheKey]: lookupId });
          
          return lookupId;
        }
      }
      
      // 3️⃣ Fallback: buscar do Graph API /me (se estiver autenticado)
      const accessToken = await this._getAccessToken();
      if (!accessToken) return null;
      
      const response = await this._fetch('https://graph.microsoft.com/v1.0/me', {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      
      if (response.ok) {
        const userData = await response.json();
        if (userData.id && userData.mail === email) {
          const lookupId = String(userData.id);
          
          // Salvar no cache
          await chrome.storage.local.set({ [cacheKey]: lookupId });
          
          return lookupId;
        }
      }
      
      console.warn(`[PickingSharePoint] ⚠️ Não foi possível obter LookupId para: ${email}`);
      return null;
      
    } catch (error) {
      console.error(`[PickingSharePoint] ❌ Erro ao obter LookupId:`, error);
      return null;
    }
  }

  /**
   * Obter Request Digest Token para SharePoint REST API
   * Necessário para operações POST via REST API
   */
  async _getRequestDigest() {
    try {
      const digestUrl = 'https://gpabr.sharepoint.com/sites/NexosTorre/_api/contextinfo';
      
      const response = await this._fetch(digestUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.accessToken}`,
          'Accept': 'application/json;odata=verbose',
          'Content-Length': '0'
        }
      });
      
      if (!response.ok) {
        console.warn(`[PickingSharePoint] ⚠️ Erro ao obter digest: ${response.status}`);
        return null;
      }
      
      const data = await response.json();
      const digest = data.d?.GetContextWebInformation?.FormDigestValue;
      
      if (digest) {
        return digest;
      }
      
      return null;
    } catch (error) {
      console.warn(`[PickingSharePoint] ⚠️ Erro ao obter digest:`, error);
      return null;
    }
  }

  /**
   * 🔍 Obter ID numérico do usuário via ensureUser (SharePoint REST API)
   * Converte email para LookupId necessário para campos Person/Grupo
   * @param {string} email - Email do usuário
   * @returns {string|null} ID numérico como STRING ("15") ou null se falhar
   */
  async _getUserLookupIdViaEnsureUser(email) {
    if (!email) return null;
    
    try {
      
      // 1️⃣ Obter Request Digest Token
      const digest = await this._getRequestDigest();
      if (!digest) {
        console.warn(`[PickingSharePoint] ⚠️ Não foi possível obter Request Digest`);
        return null;
      }
      
      // 2️⃣ Chamar ensureUser com formato correto de logonName
      const ensureUserUrl = 'https://gpabr.sharepoint.com/sites/NexosTorre/_api/web/ensureUser';
      const logonName = `i:0#.f|membership|${email}`;
      
      const response = await this._fetch(ensureUserUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.accessToken}`,
          'Accept': 'application/json;odata=verbose',
          'Content-Type': 'application/json;odata=verbose',
          'X-RequestDigest': digest
        },
        body: JSON.stringify({
          logonName: logonName
        })
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.warn(`[PickingSharePoint] ⚠️ Erro ensureUser (${response.status}):`, errorText);
        return null;
      }
      
      const data = await response.json();
      const userId = data.d?.Id;
      
      if (userId) {
        return String(userId); // Retorna como STRING "15"
      }
      
      console.warn(`[PickingSharePoint] ⚠️ ensureUser não retornou ID para: ${email}`);
      return null;
      
    } catch (error) {
      console.warn(`[PickingSharePoint] ⚠️ Erro ao chamar ensureUser:`, error);
      return null;
    }
  }

  /**
   * 🔍 Formatar email para campo Person/Grupo do SharePoint
   * Usa ensureUser para obter LookupId necessário
   * @param {string} email - Email do usuário
   * @returns {Promise<string|null>} LookupId como STRING ou null
   */
  async _formatPersonField(email) {
    if (!email) return null;
    
    // Obter LookupId via ensureUser
    const lookupId = await this._getUserLookupIdViaEnsureUser(email);
    
    if (lookupId) {
      return lookupId; // Retorna STRING "15"
    }
    
    console.warn(`[PickingSharePoint] ⚠️ Não foi possível obter LookupId para: ${email}`);
    return null;
  }

  /**
   * Criar novo pedido no SharePoint
   */
  async createOrder(orderData) {
    this._ensureInitialized();


    const {
      loja,
      pedido_id,
      status = 'pendente',
      platform = 'manual',
      data = {},
      orderID = null, // Permitir passar OrderID externo (se já foi gerado)
      pedidoItemId = null // 🔗 ID do item em Nexos_Pedidos (para campo Lookup)
    } = orderData;

    if (!loja || !pedido_id) {
      throw new Error('loja e pedido_id são obrigatórios');
    }

    // 🆔 Gerar OrderID único com timestamp se não foi passado
    const uniqueOrderID = orderID || this.generateUniqueOrderID(loja, pedido_id);
    const now = new Date(this._nowUtcMs()).toISOString(); // ⏱️ Usa UTC real (offset do servidor)

    // ℹ️ Campos "Criado por" e "Modificado por" serão preenchidos automaticamente pelo SharePoint
    if (pedidoItemId) {
    }


    const item = {
      fields: {
        // ✅ Campos obrigatórios e principais
        Title: uniqueOrderID,                                  // Título único (OrderID exclusivo)
        PedidoGPAID: String(pedido_id),                       // ID Pedido GPA
        StatusPicking: status,                                 // Status Picking (pendente/solicitado/finalizado)
        
        // ✅ Plataforma e envio
        Plataforma: platform || 'manual',                     // Plataforma de Envio (nome interno: Plataforma)
        HorarioEnvio: data.horario_envio || null,             // Horário de Envio
        // Modalidade só enviada quando preenchida (evita 400 com null/vazio)
        ...(data.modalidade ? { Modalidade: data.modalidade } : {}),
        
        // ℹ️ NOTA: Campos "Criado por" e "Modificado por" são preenchidos automaticamente pelo SharePoint
        
        // ✅ Dados e observações
        Observacoes: JSON.stringify(data).substring(0, 4000), // Observações (limite 4000 chars)
        LogOperacoes: data.log || '',                         // Log de Operações
        DadosPedidoLookupId: pedidoItemId ? String(pedidoItemId) : null, // 🔗 Lookup para Nexos_Pedidos (Item ID)
        
        // ✅ Tentativas e status consolidado
        TotalTentativas: data.total_tentativas || 1,          // Total de Tentativas (começa em 1)
        UltimaTentativaID: data.ultima_tentativa_id || null,  // ID da Última Tentativa
        StatusConsolidado: status,                            // Status Consolidado (mesmo que StatusPicking por enquanto)
        
        // ✅ Timestamps
        DataCriacao: now,                                      // Data de Criação
        UltimaAtualizacao: now,                                // Última Atualização
        DataUltimaAtualizacao: now,                           // Data Última Atualização (campo OBRIGATÓRIO)
        
        // ✅ Fila e rastreamento
        TemItemsNaFila: data.tem_items_fila || false,         // Tem Items na Fila (OBRIGATÓRIO)
        // TrackingLink: ID da plataforma como string simples (Text column no SP)
        ...(data.tracking_link ? { TrackingLink: String(data.tracking_link) } : {}),
        
        // ✅ Dados de solicitação
        ValorSolicitacao: data.valor || null,                 // Valor da Solicitação
        EnderecoCompleto: data.endereco || null               // Endereço Completo
      }
    };


    const accessToken = await this._getAccessToken();
    const response = await this._fetch(
      `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(item)
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      
      // 🔥 LOG DETALHADO DO ERRO PARA DEBUG
      console.error('[PickingSharePoint] ❌ Erro HTTP ao criar pedido:', {
        status: response.status,
        statusText: response.statusText,
        errorBody: errorText,
        sentBody: item
      });
      
      // 🔥 Detectar token expirado
      if (response.status === 401 || errorText.includes('InvalidAuthenticationToken') || errorText.includes('token is expired')) {
        console.error('[PickingSharePoint] ⚠️ Token expirado detectado em createOrder!');
        throw Object.assign(
          new Error(`HTTP ${response.status}: ${errorText}`),
          { isTokenExpired: true }
        );
      }
      
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const created = await response.json();

    // PATCH isolado para Modalidade após criar o item
    if (data.modalidade && created.id) {
      const patchUrl = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items/${created.id}/fields`;
      try {
        const mr = await this._fetch(patchUrl, {
          method: 'PATCH',
          headers: { 'Authorization': `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ ModalidadedeEnvio: String(data.modalidade) })
        });
        if (!mr.ok) console.warn('[PickingSharePoint] ⚠️ Falha ao salvar ModalidadedeEnvio em createOrder:', await mr.text());
      } catch (e) { console.warn('[PickingSharePoint] ⚠️ Erro ao salvar ModalidadedeEnvio:', e?.message); }
    }

    return {
      success: true,
      itemId: created.id,
      orderID: uniqueOrderID,
      data: created
    };
  }

  /**
   * 🔒 TRAVAR PEDIDO
   * Marca pedido como "em andamento" e trava para o usuário atual
   */
  async lockOrder(loja, pedido_id) {
    this._ensureInitialized();
    
    const orderID = `${loja}-${pedido_id}`;
    
    // Obter usuário atual
    const currentUser = window.NexosAuth?.getCurrentUser();
    if (!currentUser || !currentUser.email) {
      throw new Error('Usuário não autenticado - impossível travar pedido');
    }
    
    const userEmail = currentUser.email;
    const now = new Date().toISOString();
    
    // 1️⃣ Buscar pedido atual
    const order = await this.getOrder(loja, pedido_id);
    if (!order || !order.id) {
      throw new Error(`Pedido ${orderID} não encontrado`);
    }
    
    // 2️⃣ Verificar se já está travado por outro usuário
    const lockedBy = order.TravadoPor;
    const lockedAt = order.TravadoEm;
    
    if (lockedBy && lockedBy !== userEmail) {
      // Verificar timeout (ex: 30 minutos)
      const lockTimeout = 30 * 60 * 1000; // 30 min
      const lockAge = Date.now() - new Date(lockedAt).getTime();
      
      if (lockAge < lockTimeout) {
        throw new Error(`Pedido travado por ${lockedBy} há ${Math.round(lockAge / 60000)} minutos`);
      }
      
    }
    
    // 3️⃣ Travar pedido
    const accessToken = await this._getAccessToken();
    const response = await this._fetch(
      `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items/${order.id}`,
      {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          fields: {
            StatusPicking: 'em_andamento',
            TravadoPor: userEmail,
            TravadoEm: now,
            UltimaAtualizacao: now
          }
        })
      }
    );
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }
    
    
    return {
      success: true,
      orderID,
      lockedBy: userEmail,
      lockedAt: now
    };
  }

  /**
   * 🔓 DESTRAVAR PEDIDO
   * Remove trava do pedido
   */
  async unlockOrder(loja, pedido_id, forceUnlock = false) {
    this._ensureInitialized();
    
    const orderID = `${loja}-${pedido_id}`;
    
    // Obter usuário atual
    const currentUser = window.NexosAuth?.getCurrentUser();
    const userEmail = currentUser?.email || 'unknown@nexos.com';
    
    // 1️⃣ Buscar pedido atual
    const order = await this.getOrder(loja, pedido_id);
    if (!order || !order.id) {
      throw new Error(`Pedido ${orderID} não encontrado`);
    }
    
    // 2️⃣ Verificar permissão (só quem travou pode destravar, exceto forceUnlock)
    const lockedBy = order.TravadoPor;
    if (!forceUnlock && lockedBy && lockedBy !== userEmail) {
      throw new Error(`Pedido travado por ${lockedBy} - você não pode destravá-lo`);
    }
    
    // 3️⃣ Destravar
    const accessToken = await this._getAccessToken();
    const now = new Date().toISOString();
    
    const response = await this._fetch(
      `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items/${order.id}`,
      {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          fields: {
            TravadoPor: null,
            TravadoEm: null,
            UltimaAtualizacao: now
          }
        })
      }
    );
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }
    
    
    return {
      success: true,
      orderID,
      unlockedBy: userEmail
    };
  }

  /**
   * 🔍 VERIFICAR SE PEDIDO ESTÁ TRAVADO
   */
  async isOrderLocked(loja, pedido_id) {
    this._ensureInitialized();
    
    const order = await this.getOrder(loja, pedido_id);
    if (!order) {
      return { locked: false };
    }
    
    const lockedBy = order.TravadoPor;
    const lockedAt = order.TravadoEm;
    
    if (!lockedBy || !lockedAt) {
      return { locked: false };
    }
    
    // Verificar timeout (30 min)
    const lockTimeout = 30 * 60 * 1000;
    const lockAge = Date.now() - new Date(lockedAt).getTime();
    
    if (lockAge >= lockTimeout) {
      return {
        locked: false,
        expired: true,
        lockedBy,
        lockedAt,
        lockAge: Math.round(lockAge / 60000) // em minutos
      };
    }
    
    // Obter usuário atual
    const currentUser = window.NexosAuth?.getCurrentUser();
    const isCurrentUser = currentUser?.email === lockedBy;
    
    return {
      locked: true,
      lockedBy,
      lockedAt,
      lockAge: Math.round(lockAge / 60000),
      isCurrentUser
    };
  }

  /**
   * Buscar pedido por OrderID
   */
  async getOrder(loja, pedido_id, options = {}) {
    this._ensureInitialized();

    const maxRetries = options.maxRetries || 3;
    const retryDelay = options.retryDelay || 1000;

    const orderID = `${loja}-${pedido_id}`;


    const accessToken = await this._getAccessToken();
    
    // Função interna para buscar
    const fetchOrder = async () => {
      // ⚠️ Preferencialmente buscamos por LinkTitle (formato antigo/consistente)
      const url = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items?$expand=fields&$filter=fields/LinkTitle eq '${orderID}'`;
      
      const response = await this._fetch(url, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      return await response.json();
    };

    // Retry loop
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const data = await fetchOrder();
        
        // Se encontrou resultado por LinkTitle, retorna imediatamente
        if (data.value && data.value.length > 0) {
          const item = data.value[0];
          
          
          // Parse ObservacoesField JSON (dados completos do pedido)
          let orderData = {};
          try {
            if (item.fields.ObservacoesField) {
              orderData = JSON.parse(item.fields.ObservacoesField);
            }
          } catch (parseError) {
            console.warn('[PickingSharePoint] ⚠️ Erro ao parsear ObservacoesField:', parseError);
          }
          
          return {
            success: true,
            id: item.id,
            itemId: item.id,
            orderID: item.fields.LinkTitle,                                   // ⚠️ Campo correto: LinkTitle
            loja: item.fields.LinkTitle?.split('-')[0] || 'desconhecida',    // Extrair loja do OrderID
            pedido_id: item.fields.PedidoGPAID,                              // ⚠️ Campo correto: PedidoGPAID
            status: item.fields.StatusPicking,
            platform: item.fields.PlataformadeEnvio,
            TravadoPor: item.fields.TravadoPor || null,
            TravadoEm: item.fields.TravadoEm || null,
            data: orderData,
            createdAt: item.createdDateTime,
            updatedAt: item.fields.UltimaAtualizacao,
            raw: item
          };
        }
        
        // Não encontrado por LinkTitle → tentar fallback por PedidoGPAID
        if ((!data.value || data.value.length === 0)) {
          try {
            const fallbackUrl = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items?$expand=fields&$filter=fields/PedidoGPAID eq '${pedido_id}'`;
            const fallbackResp = await this._fetch(fallbackUrl, {
              method: 'GET',
              headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
                'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
              }
            });

            if (fallbackResp.ok) {
              const fallbackData = await fallbackResp.json();
              if (fallbackData.value && fallbackData.value.length > 0) {
                const item = fallbackData.value[0];
                return {
                  success: true,
                  id: item.id,
                  itemId: item.id,
                  orderID: item.fields.LinkTitle || item.fields.Title,
                  loja: item.fields.LinkTitle?.split('-')[0] || 'desconhecida',
                  pedido_id: item.fields.PedidoGPAID,
                  status: item.fields.StatusPicking,
                  platform: item.fields.PlataformadeEnvio,
                  TravadoPor: item.fields.TravadoPor || null,
                  TravadoEm: item.fields.TravadoEm || null,
                  data: (function(){ try { return item.fields.ObservacoesField ? JSON.parse(item.fields.ObservacoesField) : {}; } catch(e){ return {}; } })(),
                  createdAt: item.createdDateTime,
                  updatedAt: item.fields.UltimaAtualizacao,
                  raw: item
                };
              }
            }
          } catch (fallbackErr) {
            // Ignorar e seguir para retry normal
            console.warn('[PickingSharePoint] ⚠️ Erro no fallback PedidoGPAID:', fallbackErr.message || fallbackErr);
          }
        }

        // Não encontrado - fazer retry
        if (attempt < maxRetries) {
          const waitTime = retryDelay * Math.pow(2, attempt - 1);
          await new Promise(resolve => setTimeout(resolve, waitTime));
        }
        
      } catch (error) {
        if (attempt === maxRetries) {
          throw error;
        }
        const waitTime = retryDelay * Math.pow(2, attempt - 1);
        await new Promise(resolve => setTimeout(resolve, waitTime));
      }
    }
    
    
    return {
      success: false,
      notFound: true,
      orderID: orderID
    };
  }

  /**
   * Atualizar pedido existente
   */
  async updateOrder(loja, pedido_id, updates) {
    this._ensureInitialized();

    const orderID = `${loja}-${pedido_id}`;

    // Se o caller já tem o itemId (ex: encontrado via fallback getOrdersFromStatus), usar diretamente
    let existing;
    if (updates && updates.itemId) {
      existing = { success: true, itemId: updates.itemId, orderID };
    } else {
      // Buscar pedido existente
      existing = await this.getOrder(loja, pedido_id);
      if (!existing.success) {
        // Tentar fallback por PedidoGPAID antes de lançar erro
        try {
          const fallback = await this.getOrdersFromStatus(null, { filter: `fields/PedidoGPAID eq '${pedido_id}'`, limit: 1, silent: true });
          if (fallback && fallback.success && fallback.orders && fallback.orders.length > 0) {
            existing = { success: true, itemId: fallback.orders[0].itemId, orderID };
            console.log('[PickingSharePoint] 🔎 updateOrder: itemId resolvido via fallback PedidoGPAID');
          } else {
            throw new Error(`Pedido não encontrado: ${orderID}`);
          }
        } catch (e2) {
          throw new Error(`Pedido não encontrado: ${orderID}`);
        }
      }
    }

    const now = new Date().toISOString();
    const currentUser = window.NexosAuth?.getCurrentUser();
    const userEmail = currentUser?.email || 'unknown@nexos.com';

    const fields = {
      UltimaAtualizacao: now
    };

    // Atualizar campos fornecidos
    if (updates.status) {
      fields.StatusPicking = updates.status;
    }
    // "Link de Rastreamento" — nome interno real: TrackingLink (Text no SP — armazena ID da plataforma)
    if (updates.tracking_link !== undefined && updates.tracking_link !== null && updates.tracking_link !== '') {
      fields.TrackingLink = String(updates.tracking_link);
    }
    if (updates.valor_transporte !== undefined && updates.valor_transporte !== null && updates.valor_transporte !== '') {
      fields.ValorSolicitacao = String(updates.valor_transporte);
    }
    // "Plataforma de Envio" — nome interno SP para ESCRITA: Plataforma (coluna renomeada, interno não muda)
    if (updates.platform || updates.plataforma) {
      fields.Plataforma = String(updates.platform || updates.plataforma);
    }
    // "Modalidade de Envio" — nome interno real no SP: ModalidadedeEnvio
    // Separado do payload principal para não bloquear o PATCH dos outros campos.
    const modalidadeParaSalvar = updates.modalidade ? String(updates.modalidade) : null;

    // VeiculoSolicitado removido: coluna não existe na lista Nexos_StatusPedidos
    if (updates.timestamp_carregamento) {
      fields.HorarioEnvio = new Date(updates.timestamp_carregamento).toISOString();
    }


    const accessToken = await this._getAccessToken();
    const response = await this._fetch(
      `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items/${existing.itemId}/fields`,
      {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(fields)
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const updated = await response.json();

    // PATCH isolado para ModalidadedeEnvio (nome interno real no SP)
    // Separado para não contaminar o PATCH principal se o campo não existir.
    if (modalidadeParaSalvar && existing.itemId) {
      const patchUrl = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items/${existing.itemId}/fields`;
      try {
        const mr = await this._fetch(patchUrl, {
          method: 'PATCH',
          headers: { 'Authorization': `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ ModalidadedeEnvio: modalidadeParaSalvar })
        });
        if (!mr.ok) console.warn('[PickingSharePoint] ⚠️ Falha ao salvar ModalidadedeEnvio em updateOrder:', await mr.text());
      } catch (e) { console.warn('[PickingSharePoint] ⚠️ Erro ao salvar ModalidadedeEnvio:', e?.message); }
    }

    return {
      success: true,
      itemId: existing.itemId,
      orderID: orderID,
      data: updated
    };
  }

  /**
   * Deletar pedido (soft delete - marcar como inativo)
   */
  async deleteOrder(loja, pedido_id, hardDelete = false) {
    this._ensureInitialized();

    const orderID = `${loja}-${pedido_id}`;

    // Buscar pedido existente
    const existing = await this.getOrder(loja, pedido_id);
    if (!existing.success) {
      // Pedido já não existe no SP — considerar como sucesso silencioso
      console.warn(`[PickingSharePoint] ⚠️ deleteOrder: pedido não encontrado no SP (já removido?): ${orderID}`);
      return { success: true, deleted: false, notFound: true, orderID };
    }

    const accessToken = await this._getAccessToken();

    if (hardDelete) {
      // Exclusão permanente
      
      const response = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items/${existing.itemId}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        // 404 = item já foi deletado — não é erro crítico
        if (response.status === 404 || errorText.includes('itemNotFound')) {
          console.warn(`[PickingSharePoint] ⚠️ deleteOrder: item já não existe no SP (404): ${orderID}`);
          return { success: true, deleted: false, notFound: true, orderID };
        }
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      return {
        success: true,
        deleted: true,
        orderID: orderID
      };
    } else {
      // Soft delete - marcar como inativo
      return await this.updateOrder(loja, pedido_id, {
        status: 'inativo'
      });
    }
  }

  /**
   * 🗑️ Deletar pedido por Item ID (mais rápido, sem busca prévia)
   * Usado para limpeza de locks expirados
   */
  async deleteOrderByItemId(itemId, hardDelete = false) {
    this._ensureInitialized();


    const accessToken = await this._getAccessToken();

    if (hardDelete) {
      // Exclusão permanente
      const response = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items/${itemId}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        
        // 404 = item já foi deletado — não é erro crítico
        if (response.status === 404 || (errorText && errorText.includes('itemNotFound'))) {
          console.warn(`[PickingSharePoint] ⚠️ deleteOrderByItemId: item ${itemId} já não existe (404) — ignorando`);
          return { success: true, deleted: false, notFound: true, itemId };
        }
        
        // 🔥 Detectar token expirado
        if (response.status === 401 || errorText.includes('InvalidAuthenticationToken') || errorText.includes('token is expired')) {
          console.error('[PickingSharePoint] ⚠️ Token expirado detectado em deleteOrderByItemId!');
          throw Object.assign(
            new Error(`HTTP ${response.status}: ${errorText}`),
            { isTokenExpired: true }
          );
        }
        
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }


      return {
        success: true,
        deleted: true,
        itemId: itemId
      };
    } else {
      // Soft delete não suportado sem orderID
      throw new Error('Soft delete requer loja e pedido_id - use deleteOrder() em vez disso');
    }
  }

  /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 📋 OPERAÇÕES EM LOTE
   * ═══════════════════════════════════════════════════════════════════════════
   */

  /**
   * 🆕 Buscar pedidos da lista Nexos_StatusPedidos filtrados por status
   * Esta é a função correta para carregar pedidos nas abas Pendentes/Solicitados/Finalizados
   */
  async getOrdersFromStatus(statusFilter = null, options = {}) {
    this._ensureInitialized();

    const {
      limit = 100,
      orderBy = 'fields/DataCriacao desc', // Ordenar por data de criação
      silent = true, // 🔇 Silencioso por padrão (apenas logar erros)
      filter: customFilter = null // ✅ Permitir filtros customizados adicionais
    } = options;

    const accessToken = await this._getAccessToken();
    
    // 🔍 Construir filtro
    let filterParts = [];
    
    if (statusFilter) {
      if (Array.isArray(statusFilter)) {
        const statusConditions = statusFilter.map(s => `fields/StatusPicking eq '${s}'`).join(' or ');
        filterParts.push(`(${statusConditions})`);
      } else {
        filterParts.push(`fields/StatusPicking eq '${statusFilter}'`);
      }
    }
    
    if (customFilter) {
      filterParts.push(`(${customFilter})`);
    }
    
    const filter = filterParts.length > 0 ? filterParts.join(' and ') : '';
    const useOrderBy = !customFilter;
    
    const url = filter 
      ? `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items?$expand=fields&$filter=${filter}${useOrderBy ? `&$orderby=${orderBy}` : ''}&$top=${limit}`
      : `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items?$expand=fields&$orderby=${orderBy}&$top=${limit}`;
    
    try {
      const response = await this._fetch(url, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly' // ✅ Header para campos não indexados
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        
        // 🔥 Detectar token expirado
        if (response.status === 401 || errorText.includes('InvalidAuthenticationToken') || errorText.includes('token is expired')) {
          console.error('[PickingSharePoint] ⚠️ Token expirado detectado em getOrdersFromStatus!');
          throw Object.assign(
            new Error(`HTTP ${response.status}: ${errorText}`),
            { isTokenExpired: true }
          );
        }
        
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      
      const ordersWithDetails = await Promise.all(data.value.map(async (item) => {
        // 🔍 Extrair dados do extrator das Observações (JSON)
        // Observacoes contém JSON.stringify(data) completo salvo em createOrder — inclui TODOS os dados do cliente
        let extraidoPor = null;
        let extraidoPorEmail = null;
        let pedidoCompleto = {};
        let obsData = {};

        try {
          obsData = JSON.parse(item.fields.Observacoes || '{}');
          extraidoPor      = obsData.extraido_por || obsData.usuario || null;
          extraidoPorEmail = obsData.usuario || null;
        } catch (e) {
          // Ignorar erro de parse
        }

        // 🔗 Buscar dados completos do pedido em Nexos_Pedidos
        // Se falhar (SP 500 / 429 / pedido ainda não replicado), usa Observacoes como fallback
        try {
          const pedidoResult = await this.getPedido(item.fields.PedidoGPAID, { silent }); // Propagar flag silent
          if (pedidoResult.success) {
            pedidoCompleto = pedidoResult.data;
          }
        } catch (e) {
          if (!silent) {
            console.warn(`[PickingSharePoint] ⚠️ Erro ao buscar pedido ${item.fields.PedidoGPAID} — usando Observacoes como fallback:`, e.message || e);
          }
        }

        // ✅ Fallback: se Nexos_Pedidos não retornou dados, ler de Observacoes (sempre disponível)
        const nomeCliente    = pedidoCompleto.nomeCliente    || obsData.nome_cliente    || obsData.nomeCliente    || null;
        const telefone       = pedidoCompleto.celularCliente || obsData.celular_cliente || obsData.telefone_cliente || obsData.telefone || null;
        const enderecoCompl  = pedidoCompleto.enderecoCompleto || item.fields.EnderecoCompleto || obsData.endereco_completo || obsData.enderecoCompleto || obsData.endereco || null;
        
        return {
          id: item.id,
          itemId: item.id,                               // ✅ Item ID do SharePoint (para delete/update)
          orderID: item.fields.Title,                    // OrderID único (NEXOS-timestamp-loja-pedido)
          pedido_id: item.fields.PedidoGPAID,           // ID Pedido GPA
          loja: item.fields.Title?.split('-')[2] || pedidoCompleto.loja || '', // Extrair loja do OrderID ou do pedido
          status: item.fields.StatusPicking,
          platform: item.fields.PlataformadeEnvio || item.fields.Plataforma,
          modalidade_envio: item.fields.ModalidadedeEnvio || item.fields.Modalidade || null, // ✅ Nível raiz para acesso direto no overlay
          // ✅ Usar createdDateTime (campo de sistema SP, SEMPRE preenchido) como fonte primária.
          // DataCriacao (campo customizado) pode ser null se SP ignorou o valor no POST.
          created: item.fields.DataCriacao || item.createdDateTime || null,
          lockExpires: item.fields.LockExpires || null,  // ✅ Usado por cleanExpiredLocks para checar expiração do lock
          updated: item.fields.UltimaAtualizacao,
          extractedBy: extraidoPor,                      // 👤 Quem extraiu (nome)
          extractedByEmail: extraidoPorEmail,            // 📧 Email de quem extraiu
          
          // 🔗 Dados do cliente — Nexos_Pedidos tem prioridade; Observacoes como fallback automático
          nome_cliente: nomeCliente,
          telefone: telefone,
          cpf: pedidoCompleto.raw?.fields?.CPFCliente || obsData.cpf || null,
          email: pedidoCompleto.raw?.fields?.EmailCliente || obsData.email || null,
          endereco: pedidoCompleto.raw?.fields?.Endere_x00e7_oLogradouro || obsData.endereco || obsData.logradouro || null,
          numero: pedidoCompleto.raw?.fields?.N_x00fa_meroLogradouro || obsData.numero || null,
          complemento: pedidoCompleto.raw?.fields?.Complemento || item.fields.Complemento || obsData.complemento || null,
          bairro: pedidoCompleto.raw?.fields?.Bairro || obsData.bairro || null,
          cidade: pedidoCompleto.raw?.fields?.Cidade || obsData.cidade || null,
          estado: pedidoCompleto.raw?.fields?.UF || obsData.estado || obsData.uf || null,
          cep: pedidoCompleto.raw?.fields?.CEP || obsData.cep || null,
          valor: pedidoCompleto.valorPedido || item.fields.ValorSolicitacao || obsData.valor || null,
          endereco_completo: enderecoCompl,

          data: {
            // ✅ obsData como base garante que TODO dado de Observacoes está disponível
            ...obsData,
            observacoes: item.fields.Observacoes,
            log: item.fields.LogOperacoes,
            total_tentativas: item.fields.TotalTentativas,
            status_consolidado: item.fields.StatusConsolidado,
            tracking_link: (typeof item.fields.TrackingLink === 'string' ? item.fields.TrackingLink : item.fields.TrackingLink?.Url) || item.fields.LinkdeRastreamento || obsData.tracking_link || null,
            valor: item.fields.ValorSolicitacao || pedidoCompleto.valorPedido || obsData.valor,
            endereco: item.fields.EnderecoCompleto || enderecoCompl,
            quem_enviou: item.createdBy?.user?.email || 'unknown',           // ✅ Campo padrão "Criado por"
            horario_envio: item.fields.HorarioEnvio,
            modalidade_envio: item.fields.ModalidadedeEnvio || item.fields.Modalidade || null, // ✅ Veículo: Moto/Carro/Utilitário
            extraido_por: extraidoPor,
            extraido_por_email: extraidoPorEmail,
            // Dados adicionais do pedido completo sobrescrevem obs onde há conflito
            ...pedidoCompleto
          },
          raw: item
        };
      }));

      // 🔇 Log silencioso em sync automático
      if (!silent) {
      }

      return {
        success: true,
        orders: ordersWithDetails,
        count: ordersWithDetails.length
      };

    } catch (error) {
      console.error('[PickingSharePoint] ❌ Erro ao buscar pedidos:', error);
      
      // Propagar erro de token expirado
      if (error.isTokenExpired) {
        throw error;
      }
      
      return {
        success: false,
        error: error.message,
        orders: []
      };
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 📡 DELTA QUERY — só retorna itens alterados desde a última chamada
  // ═══════════════════════════════════════════════════════════════════════════
  /**
   * Busca apenas os itens que mudaram desde o último deltaToken.
   * Na primeira chamada (sem token) faz full-fetch e armazena o token.
   * Nas chamadas seguintes retorna só os deltas — payload mínimo mesmo com polling curto.
   *
   * @param {Object} options
   * @param {string} [options.deltaToken]       - token da chamada anterior (null = full-fetch)
   * @param {string} [options.todayFilter]      - filtro OData de data mínima (para o full-fetch inicial)
   * @returns {{ items: Array, nextDeltaToken: string, isFullFetch: boolean }}
   */
  async getOrdersDelta({ deltaToken = null, todayFilter = null } = {}) {
    this._ensureInitialized();
    const token = await this._getAccessToken();
    const baseList = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}`;

    // Monta URL: delta com token armazenado OU full-fetch inicial
    let url;
    if (deltaToken) {
      // Usar o deltaToken diretamente — SP retorna só o que mudou
      url = deltaToken;
    } else {
      // Full-fetch com filtro de hoje para limitar volume inicial
      const filterParam = todayFilter ? `&$filter=${encodeURIComponent(todayFilter)}` : '';
      url = `${baseList}/items/delta?$expand=fields&$top=500${filterParam}`;
    }

    const allItems = [];
    let nextLink = url;
    let finalDeltaLink = null;

    // Paginar até esgotar (SP retorna @odata.nextLink enquanto há mais páginas
    // e @odata.deltaLink na última página — guarda esse como próximo token)
    while (nextLink) {
      const resp = await this._fetch(nextLink, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
        }
      });

      if (!resp.ok) {
        const body = await resp.text();
        // deltaToken expirado (SP expira tokens após alguns dias) → sinalizar reset
        if (resp.status === 410) {
          console.warn('[PickingSharePoint] ⚠️ Delta token expirado (410) — próximo ciclo fará full-fetch');
          return { items: [], nextDeltaToken: null, isFullFetch: false, tokenExpired: true };
        }
        if (resp.status === 401 || body.includes('InvalidAuthenticationToken')) {
          throw Object.assign(new Error(`HTTP ${resp.status}: ${body}`), { isTokenExpired: true });
        }
        throw new Error(`getOrdersDelta HTTP ${resp.status}: ${body}`);
      }

      const data = await resp.json();
      allItems.push(...(data.value || []));

      // @odata.nextLink → há mais páginas neste ciclo
      nextLink = data['@odata.nextLink'] || null;
      // @odata.deltaLink → token para o próximo ciclo (última página)
      if (data['@odata.deltaLink']) finalDeltaLink = data['@odata.deltaLink'];
    }

    return {
      items: allItems,
      nextDeltaToken: finalDeltaLink,   // guardar para o próximo poll
      isFullFetch: !deltaToken,
    };
  }

  /**
   * Buscar todos os pedidos de uma loja (DEPRECADO - use getOrdersFromStatus)
   * @deprecated Use getOrdersFromStatus() para carregar pedidos nas abas
   */
  async getOrdersByStore(loja, options = {}) {
    this._ensureInitialized();

    const {
      status = null,
      limit = 100,
      orderBy = 'fields/Created desc'  // ✅ Campo sistema "Data de Criação" (nome interno: Created)
    } = options;

    // console.log('[PickingSharePoint] 📋 Buscando pedidos da loja:', loja);  // ❌ REMOVIDO: log repetitivo

    const accessToken = await this._getAccessToken();
    
    // ✅ Filtrar pelo OrderID que começa com "LOJA-"
    // ⚠️ Campo correto: LinkTitle (não OrderID)
    let filter = `startswith(fields/LinkTitle,'${loja}-')`;
    if (status) {
      filter += ` and fields/StatusPicking eq '${status}'`;
    }
    
    const url = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items?$expand=fields&$filter=${filter}&$orderby=${orderBy}&$top=${limit}`;
    
    const response = await this._fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      
      // 🔥 Detectar token expirado
      if (response.status === 401 || errorText.includes('InvalidAuthenticationToken') || errorText.includes('token is expired')) {
        console.error('[PickingSharePoint] ⚠️ Token expirado detectado em getOrdersByStore!');
        throw Object.assign(
          new Error(`HTTP ${response.status}: ${errorText}`),
          { isTokenExpired: true }
        );
      }
      
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const data = await response.json();
    
    const orders = data.value.map(item => {
      let orderData = {};
      try {
        if (item.fields.ObservacoesField) {
          orderData = JSON.parse(item.fields.ObservacoesField);
        }
      } catch (parseError) {
        console.warn('[PickingSharePoint] ⚠️ Erro ao parsear ObservacoesField:', parseError);
      }
      
      return {
        itemId: item.id,
        orderID: item.fields.LinkTitle,                                   // ⚠️ Campo correto: LinkTitle
        loja: item.fields.LinkTitle?.split('-')[0] || 'desconhecida',
        pedido_id: item.fields.PedidoGPAID,                              // ⚠️ Campo correto: PedidoGPAID
        status: item.fields.StatusPicking,
        platform: item.fields.PlataformadeEnvio,
        TravadoPor: item.fields.TravadoPor || null,
        TravadoEm: item.fields.TravadoEm || null,
        data: orderData,
        createdAt: item.createdDateTime,
        updatedAt: item.fields.UltimaAtualizacao
      };
    });

    // console.log('[PickingSharePoint] ✅ Encontrados', orders.length, 'pedidos');  // ❌ REMOVIDO: log repetitivo

    return {
      success: true,
      count: orders.length,
      orders: orders
    };
  }

  /**
   * ═══════════════════════════════════════════════════════════════════════════
   * � GERENCIAMENTO DE PEDIDOS (Nexos_Pedidos - Dados Únicos)
   * ═══════════════════════════════════════════════════════════════════════════
   */

  /**
   * Criar ou atualizar pedido na lista Nexos_Pedidos
   * @param {object} pickingData - Dados extraídos do Picking Admin
   * @returns {Promise<{success: boolean, pedidoId?: string, created?: boolean}>}
   */
  async upsertPedido(pickingData) {
    this._ensureInitialized();


    const { pedido_id, loja } = pickingData;

    if (!pedido_id) {
      throw new Error('pedido_id é obrigatório');
    }

    // Fallback: se CEP não foi passado no pickingData, tentar obter do storage local
    try {
      if (!pickingData.cep && typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        // Ler todo o objeto salvo pelo overlay para usar como fallback para vários campos
        const storageObj = await new Promise((resolve) => {
          try {
            chrome.storage.local.get(['nexos-picking-data'], (res) => {
              try { resolve(res && res['nexos-picking-data'] ? res['nexos-picking-data'] : null); } catch(e){ resolve(null); }
            });
          } catch (e) { resolve(null); }
        });

        // Helper para normalizar CEP
        const normalizeCep = (v) => {
          if (!v && v !== 0) return null;
          const digits = String(v).replace(/\D/g, '');
          if (digits.length === 7) return '0' + digits.slice(0,5) + '-' + digits.slice(5);
          if (digits.length === 8) return digits.slice(0,5) + '-' + digits.slice(5);
          if (digits.length === 0) return null;
          // Se já estiver no formato 00000-000, manter
          if (/^\d{5}-?\d{3}$/.test(String(v))) {
            const d = String(v).replace(/\D/g, '');
            return d.length === 8 ? d.slice(0,5) + '-' + d.slice(5) : String(v);
          }
          return String(v);
        };

        // Aplicar CEP se encontrado no storageObj
        const cepFromStorage = storageObj && (storageObj.cep || storageObj.CEP || storageObj.cep_coleta || storageObj.cepColeta || null);
        if (cepFromStorage) {
          pickingData.cep = normalizeCep(cepFromStorage);
        } else {
          // Fallback adicional: tentar extrair CEP do elemento específico (XPath/CSS) fornecido pelo usuário
          try {
            // Priorizar seletor/CSS e XPath específicos antes de varrer todo o texto da página
            const userCss = '#layoutWrapper > div.ant-layout > div.defaultpage.ant-layout-content > div > div > div > div > div.orderForm > div:nth-child(3) > div > div:nth-child(3) > div:nth-child(3) > p:nth-child(2)';
            const userXpath = '/html/body/div[1]/main/div/div/div[2]/div[3]/div/div/div/div/div[1]/div[3]/div/div[2]/div[3]/p[2]';
            let candidateText = null;

            try {
              const el = (typeof document !== 'undefined') ? document.querySelector(userCss) : null;
              if (el && el.innerText) candidateText = String(el.innerText).trim();
            } catch (e) { /* ignore css errors */ }

            if (!candidateText) {
              try {
                if (typeof document !== 'undefined') {
                  const xp = document.evaluate(userXpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
                  const node = xp && xp.singleNodeValue;
                  if (node && node.textContent) candidateText = String(node.textContent).trim();
                }
              } catch (e) { /* ignore xpath errors */ }
            }

            const chooseAndNormalize = (text) => {
              if (!text) return null;
              const matches = Array.from(text.matchAll(/(\d{5}-?\d{3}|\d{7,8})/g)).map(m => m[1]);
              if (!matches.length) return null;

              // Heurística: preferir match próximo de 'CEP', senão preferir 8 dígitos, senão último
              const lower = text.toLowerCase();
              let chosen = null;
              const cepIdx = lower.indexOf('cep');
              if (cepIdx !== -1) {
                let best = Infinity;
                for (const m of matches) {
                  const pos = text.indexOf(m);
                  const score = Math.abs(pos - cepIdx);
                  if (score < best) { best = score; chosen = m; }
                }
              }
              if (!chosen) {
                for (const m of matches) {
                  const raw = String(m).replace(/\D/g, '');
                  if (raw.length === 8) { chosen = m; break; }
                }
              }
              if (!chosen) chosen = matches[matches.length - 1];

              let raw = String(chosen).replace(/\D/g, '');
              if (raw.length === 7) raw = '0' + raw;
              if (raw.length === 8) return raw.slice(0,5) + '-' + raw.slice(5);
              return chosen;
            };

            let cepFromNode = chooseAndNormalize(candidateText);
            if (cepFromNode) {
              pickingData.cep = cepFromNode;
            } else {
              // último recurso: varrer todo o texto da página
              try {
                if (typeof document !== 'undefined' && document && document.body && document.body.innerText) {
                  const pageText = String(document.body.innerText || '');
                  const cepFromPage = chooseAndNormalize(pageText);
                  if (cepFromPage) {
                    pickingData.cep = cepFromPage;
                  }
                }
              } catch (e) {
                console.warn('[PickingSharePoint] ⚠️ Fallback de CEP em document falhou:', e && e.message ? e.message : e);
              }
            }
          } catch (e) {
            console.warn('[PickingSharePoint] ⚠️ Falha no fallback de CEP (XPath/CSS):', e && e.message ? e.message : e);
          }
        }

        // Anexar storageObj para uso posterior (fallback em outros campos)
        pickingData.__nexos_storage = storageObj || null;
      }
    } catch (e) {
      console.warn('[PickingSharePoint] ⚠️ Falha ao obter CEP do storage local:', e && e.message ? e.message : e);
    }

    try {
      // 🔒 LOCK AUTOMÁTICO: Verificar se pedido já está travado por outro usuário
      const currentUser = window.NexosAuth?.getCurrentUser();
      const usuario = currentUser?.email || 'Sistema';
      const userName = currentUser?.displayName || currentUser?.name || currentUser?.email?.split('@')[0] || 'Sistema';

      // ♻️ Flag para detectar re-extração de pedido finalizado
      let isReExtraction = false;
      let statusAnterior = '';

      const existingStatus = await this.getOrdersFromStatus(`pendente`, {
        filter: `fields/PedidoGPAID eq '${pedido_id}'`,
        limit: 1,
        silent: false // ✅ Log ativo para debug
      });
      
      
      // 🚨 VERIFICAR SE JÁ EXISTE PEDIDO PENDENTE (TRAVADO)
      if (existingStatus.success && existingStatus.orders.length > 0) {
        const existingOrder = existingStatus.orders[0];
        const existingStatusPicking = (existingOrder.status || '').toLowerCase();

        // ✅ Se o registro existente já está finalizado (entregue/cancelado), ignorar e permitir nova extração
        const isFinished = existingStatusPicking === 'entregue' || existingStatusPicking === 'cancelado'
          || existingStatusPicking === 'finalizado' || existingStatusPicking === 'concluido';

        if (!isFinished) {
          const lockedBy = existingOrder.extractedByEmail;
          const lockedAt = existingOrder.created;
          
          // Se travado por outro usuário
          if (lockedBy && lockedBy !== usuario) {
            const lockAge = Date.now() - new Date(lockedAt).getTime();
            const lockMinutes = Math.round(lockAge / 60000);
            
            
            // 🔥 Retornar notificação amigável em vez de erro
            return {
              success: false,
              locked: true,
              lockedBy: existingOrder.extractedBy || lockedBy,
              lockedByEmail: lockedBy,
              lockedAt: lockedAt,
              lockMinutes: lockMinutes,
              message: `✅ Pedido já foi extraído por ${existingOrder.extractedBy || lockedBy} há ${lockMinutes} minuto(s)`
            };
          }
          
          // Se travado pelo mesmo usuário, permitir mas avisar
        
        // ✅ ATUALIZAR dados do pedido em Nexos_Pedidos (caso tenha mudado modalidade, valor, etc)
        // Construir objeto de updates com fallback para várias convenções de nomes
        const storageFallback = pickingData.__nexos_storage || null;
        const pickField = (...candidates) => {
          for (const c of candidates) {
            if (pickingData && pickingData[c] !== undefined && pickingData[c] !== null) return pickingData[c];
            if (storageFallback && storageFallback[c] !== undefined && storageFallback[c] !== null) return storageFallback[c];
          }
          return null;
        };
        const normalizeCepLocal = (v) => {
          if (!v && v !== 0) return null;
          const digits = String(v).replace(/\D/g, '');
          if (digits.length === 7) return '0' + digits.slice(0,5) + '-' + digits.slice(5);
          if (digits.length === 8) return digits.slice(0,5) + '-' + digits.slice(5);
          return v;
        };

        const updateResult = await this.updatePedido(pedido_id, {
          __skipTimeline: true,  // 🔇 Não gerar evento 'atualizacao' — chamada interna de sincronização
          nome_cliente: pickField('nome_cliente', 'nomeCliente', 'nome'),
          telefone: pickField('telefone', 'telefoneCliente', 'telefone_cliente', 'celularCliente', 'celular_cliente'),
          endereco: pickField('endereco', 'enderecoCompleto', 'endereco_completo', 'enderecoLogradouro', 'endereco_logradouro'),
          numero: pickField('numero', 'numeroLogradouro', 'numero_logradouro', 'N_x00fa_meroLogradouro'),
          complemento: pickField('complemento'),
          bairro: pickField('bairro'),
          cidade: pickField('cidade'),
          uf: pickField('uf', 'estado', 'UF'),
          cep: normalizeCepLocal(pickField('cep', 'CEP', 'cep_coleta', 'cepColeta')),
          flagEntregue: pickField('flagEntregue', 'entregue_flag', 'entregueFlag'), // ✅ Atualizar modalidade!
          modalidade: pickField('modalidade', 'tipo_entrega', 'tipoEntrega', 'entrega_modalidade'),
          volume: pickField('volume', 'volumetria', 'VolumetriaJSON'),
          valorFrete: pickField('valorFrete', 'valor_frete'),
          observacao: pickField('observacao', 'observacoes', 'Observacoes')
        });
        
        if (updateResult.success) {
        }
        
        // ✅ Retornar o registro existente
          return {
            success: true,
            pedidoId: pedido_id,
            orderID: existingOrder.orderID,
            itemId: existingOrder.itemId,
            created: false,
            alreadyExtracted: true,
            locked: true,
            lockExpiresIn: 10,
            message: 'Você já extraiu este pedido. Usando registro existente.'
          };
        } // fim if (!isFinished)

        // isFinished = true → pedido finalizado, queda para nova extração abaixo
        isReExtraction = true;
        statusAnterior = existingStatusPicking;
        console.log(`[PickingSharePoint] ♻️ Pedido ${pedido_id} estava ${existingStatusPicking} — permitindo nova extração`);
      } // fim if (existingStatus.success && ...)
      
      // Verificar se pedido já existe em Nexos_Pedidos
      const existing = await this.getPedido(pedido_id);
      
      if (existing.success) {
        
        // 🆔 Gerar OrderID ÚNICO com timestamp para esta tentativa
        const uniqueOrderID = this.generateUniqueOrderID(loja, pedido_id);
        
        // Antes de criar o status, tentar atualizar o registro existente em Nexos_Pedidos
        try {
          const toUpdate = {
            nome_cliente: pickingData.nome_cliente,
            telefone: pickingData.telefone,
            endereco: pickingData.endereco,
            numero: pickingData.numero,
            complemento: pickingData.complemento,
            bairro: pickingData.bairro,
            cidade: pickingData.cidade,
            uf: pickingData.uf,
            cep: pickingData.cep
          };
          // Chamar updatePedido para garantir o CEP e demais campos no item pai
          const upd = await this.updatePedido(pedido_id, { __skipTimeline: true, ...toUpdate });
          if (upd && upd.success) {
          }
        } catch (e) {
          console.warn('[PickingSharePoint] ⚠️ Falha ao atualizar pedido existente antes de criar status:', e && e.message ? e.message : e);
        }

        // ✅ Criar novo registro de status em Nexos_StatusPedidos com LOCK automático (10 min)
        const statusResult = await this.createOrder({
          loja: loja,
          pedido_id: pedido_id,
          status: 'pendente',
          platform: 'manual',
          orderID: uniqueOrderID, // OrderID único com timestamp
          pedidoItemId: existing.itemId, // 🔗 ID do item existente em Nexos_Pedidos
          data: {
            origem: 'extracao_existente',
            usuario: usuario,
            extraido_por: userName
          }
        });
        
        // ✅ Registrar na timeline a extração
        const currentUser = window.NexosAuth?.getCurrentUser();
        
        // 🆕 Buscar foto do usuário (com cache)
        let userPhoto = currentUser?.photo || null;
        if (!userPhoto && window.NexosUserManager && usuario) {
          try {
            const userData = await window.NexosUserManager.getUserByEmail(usuario);
            if (userData && userData.FotoURL) {
              userPhoto = userData.FotoURL;
            }
          } catch (error) {
            console.warn('[PickingSharePoint] ⚠️ Erro ao buscar foto:', error);
          }
        }
        
        await this.addTimelineEvent(pedido_id, isReExtraction ? 'reextracao' : 'extracao', {
          usuario: usuario,
          detalhes: isReExtraction
            ? `♻️ Pedido re-extraído por ${userName} (anterior: ${statusAnterior})`
            : `Pedido extraído do Picking Admin por ${userName}`,
          loja: loja,
          orderID: uniqueOrderID,
          usuario_nome: userName,
          usuario_email: currentUser?.email || usuario,
          usuario_foto: userPhoto,
          ...(isReExtraction ? { status_anterior: statusAnterior } : {})
        });
        
        return {
          success: true,
          pedidoId: pedido_id,
          orderID: uniqueOrderID,
          itemId: statusResult.itemId || statusResult.id,
          created: false,
          locked: true,
          lockExpiresIn: 10,
          message: 'Pedido registrado com sucesso'
        };
      } else {
        
        // 🆔 Gerar OrderID ÚNICO com timestamp
        const uniqueOrderID = this.generateUniqueOrderID(loja, pedido_id);
        
        const result = await this._createPedido(pickingData);
        
        // ✅ Criar registro de status em Nexos_StatusPedidos com LOCK automático (10 min)
        const statusResult = await this.createOrder({
          loja: loja,
          pedido_id: pedido_id,
          status: 'pendente',
          platform: 'manual',
          orderID: uniqueOrderID, // Passar OrderID gerado
          pedidoItemId: result.itemId, // 🔗 ID do item criado em Nexos_Pedidos (para campo Lookup)
          data: {
            origem: 'extracao_novo',
            usuario: usuario,
            extraido_por: userName
          }
        });
        
        // ✅ Registrar na timeline a extração (com mesmo OrderID)
        const currentUser = window.NexosAuth?.getCurrentUser();
        
        // 🆕 Buscar foto do usuário (com cache)
        let userPhoto = currentUser?.photo || null;
        if (!userPhoto && window.NexosUserManager && usuario) {
          try {
            const userData = await window.NexosUserManager.getUserByEmail(usuario);
            if (userData && userData.FotoURL) {
              userPhoto = userData.FotoURL;
            }
          } catch (error) {
            console.warn('[PickingSharePoint] ⚠️ Erro ao buscar foto:', error);
          }
        }
        
        await this.addTimelineEvent(pedido_id, isReExtraction ? 'reextracao' : 'extracao', {
          usuario: usuario,
          detalhes: isReExtraction
            ? `♻️ Pedido re-extraído por ${userName} (anterior: ${statusAnterior})`
            : `Pedido extraído do Picking Admin por ${userName}`,
          loja: loja,
          orderID: uniqueOrderID, // Mesmo OrderID do status
          usuario_nome: userName,
          usuario_email: currentUser?.email || usuario,
          usuario_foto: userPhoto,
          ...(isReExtraction ? { status_anterior: statusAnterior } : {})
        });
        
        return {
          ...result,
          orderID: uniqueOrderID,
          itemId: statusResult.itemId,
          locked: true,
          lockExpiresIn: 10 // minutos
        };
      }
    } catch (error) {
      // 🔥 Detectar erro de token expirado
      if (error.isTokenExpired) {
        console.error('[PickingSharePoint] 🔐 Token expirado durante upsertPedido');
        
        // Notificar PickingState para exibir modal (agora é async)
        if (window.PickingStateManager && typeof window.PickingStateManager._handleTokenExpired === 'function') {
          await window.PickingStateManager._handleTokenExpired();
        }
        
        return {
          success: false,
          error: 'TOKEN_EXPIRED',
          userMessage: 'Sua sessão expirou. Por favor, faça login novamente.'
        };
      }
      
      // Erro genérico
      throw error;
    }
  }

  /**
   * Criar novo pedido em Nexos_Pedidos
   */
  async _createPedido(pickingData) {
    const now = new Date().toISOString();
    
    // Calcular hash dos dados para detectar mudanças futuras
    const dataString = JSON.stringify({
      nome: pickingData.nomeCliente,
      endereco: pickingData.enderecoCompleto,
      volumetria: pickingData.volumetria
    });
    const hash = await this._calculateHash(dataString);

    const item = {
      fields: {
        // 🔑 IDENTIFICAÇÃO
        Title: String(pickingData.pedido_id),              // IDPedidoGPA (PK)
        C_x00f3_digoLoja: pickingData.loja || '',          // ⚠️ Campo correto: C_x00f3_digoLoja (não C_x00f3_digo_x0020_Loja)
        DataExtra_x00e7__x00e3_o: now,                     // ⚠️ Campo correto: DataExtra_x00e7__x00e3_o
        Vers_x00e3_oExtra_x00e7__x00e3_o: 'v3.1.0',       // ⚠️ Campo correto: Vers_x00e3_oExtra_x00e7__x00e3_o
        OrigemDados: 'Picking Admin',                      // ⚠️ Campo correto: OrigemDados
        HashPedido: hash,                                  // ⚠️ Campo correto: HashPedido
        
        // 👤 CLIENTE
        NomedoCliente: pickingData.nomeCliente || '',      // ⚠️ Campo correto: NomedoCliente
        TelefoneCliente: pickingData.telefoneCliente || '',// ⚠️ Campo correto: TelefoneCliente
        CelularCliente: pickingData.celularCliente || '', // ⚠️ Campo correto: CelularCliente
        
        // 🏠 ENDEREÇO
        Endere_x00e7_oCompleto: pickingData.enderecoCompleto || '',           // ⚠️ Campo correto: Endere_x00e7_oCompleto
        Endere_x00e7_oLogradouro: pickingData.enderecoLogradouro || '',      // ⚠️ Campo correto: Endere_x00e7_oLogradouro
        N_x00fa_meroLogradouro: pickingData.numeroLogradouro || '',          // ⚠️ Campo correto: N_x00fa_meroLogradouro
        Complemento: pickingData.complemento || '',
        Bairro: pickingData.bairro || '',
        Cidade: pickingData.cidade || '',
        UF: pickingData.uf || '',
        CEP: pickingData.cep || '',
        
        // 💰 FINANCEIRO
        ValorPedido: parseFloat(pickingData.valorPedido) || 0,               // ⚠️ Campo correto: ValorPedido
        BandeiraPagamento: pickingData.bandeiraPagamento || '',              // ⚠️ Campo correto: BandeiraPagamento
        SemCobran_x00e7_a: pickingData.semCobranca || false,                 // ⚠️ Campo correto: SemCobran_x00e7_a
        // 🚚 MODALIDADE (Express / Pra Já / etc) — só enviada quando preenchida
        ...(pickingData.modalidade ? { Modalidade: pickingData.modalidade } : {}),
        
        // 📦 VOLUMETRIA
        VolumetriaJSON: JSON.stringify(pickingData.volumetria || []),        // ⚠️ Campo correto: VolumetriaJSON
        TotalItens: pickingData.totalItens || 0,                             // ⚠️ Campo correto: TotalItens
        TiposItens: pickingData.tiposItens || 0,                             // ⚠️ Campo correto: TiposItens
        
        // 📊 METADADOS
        StatusPedidoOriginal: pickingData.statusOriginal || '',               // ⚠️ Campo correto: StatusPedidoOriginal
        FlagEntregue: pickingData.flagEntregue || null,                       // ⚠️ Campo correto: FlagEntregue
        DataColeta: pickingData.dataColeta || null,                           // ⚠️ Campo correto: DataColeta
        Observa_x00e7__x00f5_es: pickingData.observacoes || ''                // ⚠️ Campo correto: Observa_x00e7__x00f5_es
      }
    };


    const accessToken = await this._getAccessToken();
    const response = await this._fetch(
      `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.pedidos}/items`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(item)
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const created = await response.json();

    return {
      success: true,
      pedidoId: pickingData.pedido_id,
      itemId: created.id,
      created: true
    };
  }

  /**
   * Atualizar pedido existente em Nexos_Pedidos
   */
  async _updatePedido(itemId, pickingData) {
    const now = new Date().toISOString();
    
    const dataString = JSON.stringify({
      nome: pickingData.nomeCliente,
      endereco: pickingData.enderecoCompleto,
      volumetria: pickingData.volumetria
    });
    const hash = await this._calculateHash(dataString);

    const fields = {
      DataExtra_x00e7__x00e3_o: now,                    // ✅ Campo correto: DataExtra_x00e7__x00e3_o
      Vers_x00e3_oExtra_x00e7__x00e3_o: 'v3.1.0',       // ✅ Campo correto: Vers_x00e3_oExtra_x00e7__x00e3_o
      HashPedido: hash,                                  // ✅ Campo correto: HashPedido
      
      // Atualizar apenas campos que podem mudar
      NomedoCliente: pickingData.nomeCliente || '',              // ✅ Campo correto: NomedoCliente
      TelefoneCliente: pickingData.telefoneCliente || '',        // ✅ Campo correto: TelefoneCliente
      CelularCliente: pickingData.celularCliente || '',          // ✅ Campo correto: CelularCliente
      Endere_x00e7_oCompleto: pickingData.enderecoCompleto || '',// ✅ Campo correto: Endere_x00e7_oCompleto
      ValorPedido: parseFloat(pickingData.valorPedido) || 0,     // ✅ Campo correto: ValorPedido
      // 🚚 Atualizar modalidade se disponível — só quando preenchida
      ...(pickingData.modalidade ? { Modalidade: pickingData.modalidade } : {}),
      VolumetriaJSON: JSON.stringify(pickingData.volumetria || []), // ✅ Campo correto: VolumetriaJSON
      TotalItens: pickingData.totalItens || 0,                   // ✅ Campo correto: TotalItens
      TiposItens: pickingData.tiposItens || 0                    // ✅ Campo correto: TiposItens
    };


    const accessToken = await this._getAccessToken();
    const response = await this._fetch(
      `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.pedidos}/items/${itemId}/fields`,
      {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(fields)
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }


    return {
      success: true,
      pedidoId: pickingData.pedido_id,
      itemId: itemId,
      created: false
    };
  }

  /**
   * Buscar pedido em Nexos_Pedidos
   * @param {string} pedido_id - ID do pedido GPA
   * @param {object} options - Opções (silent)
   * @returns {Promise<{success: boolean, itemId?: string, data?: object}>}
   */
  async getPedido(pedido_id, options = {}) {
    this._ensureInitialized();

    const { silent = false } = options;

    if (!silent) {
    }

    const accessToken = await this._getAccessToken();
    // Nexos_Pedidos usa Title como identificador primário (= pedido_id)
    let url = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.pedidos}/items?$expand=fields&$filter=fields/Title eq '${pedido_id}'`;
    let response = await this._fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    let data = await response.json();

    // Fallback: tentar por PedidoGPAID (pedidos migrados ou com formato diferente)
    if (!data.value || data.value.length === 0) {
      try {
        url = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.pedidos}/items?$expand=fields&$filter=fields/PedidoGPAID eq '${pedido_id}'&$top=1`;
        response = await this._fetch(url, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
            'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
          }
        });
        if (response.ok) {
          data = await response.json();
        }
      } catch (e) {
        // ignorar — retornar "não encontrado"
      }
    }

    if (data && data.value && data.value.length > 0) {
      const item = data.value[0];
      
      if (!silent) {
      }
      
      // Parse volumetria JSON
      let volumetria = [];
      try {
        if (item.fields.VolumetriaJSON) {
          volumetria = JSON.parse(item.fields.VolumetriaJSON);
        }
      } catch (e) {
        console.warn('[PickingSharePoint] ⚠️ Erro ao parsear VolumetriaJSON:', e);
      }
      
      return {
        success: true,
        itemId: item.id,
        pedido: {
          // IDs
          pedido: item.fields.PedidoGPAID || item.fields.Title,
          pedido_id: item.fields.PedidoGPAID || item.fields.Title,
          orderID: item.fields.OrderID || item.fields.Title,  // ← NOVO: Order ID único
          loja: item.fields.CodigoLoja || item.fields.C_x00f3_digoLoja,
          
          // Dados do cliente
          nomeCliente: item.fields.NomeCliente || item.fields.NomedoCliente,
          celularCliente: item.fields.CelularCliente,
          
          // Endereço de entrega (campos separados - com fallbacks para nomes encoded)
          endereco: item.fields.Endere_x00e7_oLogradouro || item.fields.Endereco || item.fields.Endere_x00e7_o,
          numero: item.fields.N_x00fa_meroLogradouro || item.fields.Numero || item.fields.N_x00fa_mero,
          complemento: item.fields.Complemento,
          bairro: item.fields.Bairro,
          cidade: item.fields.Cidade,
          estado: item.fields.Estado || item.fields.UF,
          uf: item.fields.UF || item.fields.Estado,
          cep: item.fields.CEP,
          pais: item.fields.Pais || item.fields.Pa_x00ed_s || 'Brasil',
          
          // Endereço completo (concatenado)
          enderecoCompleto: item.fields.EnderecoCompleto || item.fields.Endere_x00e7_oCompleto,
          
          // Outros dados
          valorPedido: item.fields.ValorPedido,
          volumetria: volumetria,
          totalItens: item.fields.TotalItens,
          hash: item.fields.HashPedido,
          flagEntregue: item.fields.FlagEntregue,
          modalidade: item.fields.ModalidadedeEnvio || item.fields.Modalidade,
          statusPicking: item.fields.StatusPicking,
          plataforma: item.fields.Plataforma,
          
          // Metadados
          extractedBy: item.fields.ExtraidoPor,
          extractedByEmail: item.fields.ExtraidoPorEmail,
          
          // Raw data
          raw: item.fields,
          _itemId: item.id
        },
        // Manter compatibilidade com código antigo
        data: {
          pedido_id: item.fields.PedidoGPAID || item.fields.Title,
          orderID: item.fields.OrderID || item.fields.Title,  // ← NOVO: Order ID na estrutura data
          loja: item.fields.CodigoLoja || item.fields.C_x00f3_digoLoja,
          nomeCliente: item.fields.NomeCliente || item.fields.NomedoCliente,
          celularCliente: item.fields.CelularCliente,
          enderecoCompleto: item.fields.EnderecoCompleto || item.fields.Endere_x00e7_oCompleto,
          valorPedido: item.fields.ValorPedido,
          volumetria: volumetria,
          totalItens: item.fields.TotalItens,
          hash: item.fields.HashPedido,
          flagEntregue: item.fields.FlagEntregue,
          modalidade: item.fields.ModalidadedeEnvio || item.fields.Modalidade,
          raw: item
        }
      };
    }

    return {
      success: false,
      error: 'Pedido não encontrado'
    };
  }

  /**
   * Atualiza campos de um pedido existente em Nexos_Pedidos
   * @param {string} pedido_id - ID do pedido
   * @param {object} updates - Objeto com campos a serem atualizados
   * @returns {Promise<object>}
   */
  async updatePedido(pedido_id, updates) {
    this._ensureInitialized();


    try {
      // 1. Buscar pedido existente
      const existing = await this.getPedido(pedido_id, { silent: true });
      
      if (!existing.success) {
        console.error('[PickingSharePoint] ❌ Pedido não encontrado:', pedido_id);
        return {
          success: false,
          error: 'Pedido não encontrado'
        };
      }


      // 2. Construir payload de atualização (apenas campos que mudaram)
      // Extrair flags de controle e motivo humano (se enviados pelo caller) antes do mapeamento
      let motivo = null;
      let skipTimeline = false;
      try {
        if (updates && typeof updates === 'object') {
          if (Object.prototype.hasOwnProperty.call(updates, '__motivo')) {
            motivo = updates.__motivo;
            delete updates.__motivo;
          }
          if (Object.prototype.hasOwnProperty.call(updates, '__skipTimeline')) {
            skipTimeline = !!updates.__skipTimeline;
            delete updates.__skipTimeline;
          }
        }
      } catch (e) {
        // ignore
      }

      const fields = {};
      
      // Mapear campos do picking para campos do SharePoint
      const fieldMap = {
        // O nome do campo interno correto é 'NomedoCliente' (algumas listas antigas têm 'NomeCliente' para compatibilidade)
        nome_cliente: 'NomedoCliente',
        // Normalizar variantes de telefone/celular para os campos reais do SharePoint
        telefone: 'TelefoneCliente',
        telefoneCliente: 'TelefoneCliente',
        telefone_cliente: 'TelefoneCliente',
        Telefone: 'TelefoneCliente',
        celular: 'CelularCliente',
        celularCliente: 'CelularCliente',
        celular_cliente: 'CelularCliente',
  endereco: 'Endere_x00e7_oLogradouro',  // ✅ CORRIGIDO: campo real do SharePoint
        numero: 'N_x00fa_meroLogradouro',      // ✅ CORRIGIDO: campo real do SharePoint
        complemento: 'Complemento',
  modalidade: 'Modalidade',
        bairro: 'Bairro',
        cidade: 'Cidade',
        uf: 'UF',
        estado: 'Estado',
        cep: 'CEP',
        // pais: 'Pais', // ❌ Campo não existe na lista
        endereco_coleta: 'EnderecoColeta',
        numero_coleta: 'NumeroColeta',
        complemento_coleta: 'ComplementoColeta',
        bairro_coleta: 'BairroColeta',
        cidade_coleta: 'CidadeColeta',
        uf_coleta: 'UFColeta',
        estado_coleta: 'EstadoColeta',
        cep_coleta: 'CEPColeta',
        // pais_coleta: 'PaisColeta', // ❌ Campo não existe na lista
        flagEntregue: 'FlagEntregue',
        volume: 'VolumetriaJSON',
        valorFrete: 'ValorFrete',
        // Campo correto para observações (interno com encoding): Observa_x00e7__x00f5_es
        observacao: 'Observa_x00e7__x00f5_es',
        // 🆕 Campos de confirmação de envio (atualizados após pedido enviado para plataforma)
        ultima_atualizacao: 'UltimaAtualizacao',
        status_atual:        'StatusAtual',
        ultima_plataforma:   'Plataforma',
        ultimo_valor_transporte: 'ValorTransporte',
        ultimo_veiculo:      'VeiculoSolicitado',
        // ⚠️ TrackingLink NÃO existe em Nexos_Pedidos — campo apenas em Nexos_StatusPedidos
        // ultimo_tracking e tracking_link são omitidos intencionalmente deste mapa
        ultimo_veiculo_alt:  'VeiculoSolicitado'  // alias extra — não usado atualmente
      };

      // Aplicar apenas campos que foram fornecidos
      for (const [key, value] of Object.entries(updates)) {
        if (value !== undefined && value !== null && fieldMap[key]) {
          // Não sobrescrever tracking_link/TrackingLink com string vazia
          if ((key === 'tracking_link' || key === 'ultimo_tracking') && String(value).trim() === '') continue;

          const sharePointField = fieldMap[key];
          
          // Tratamento especial para VolumetriaJSON
          if (key === 'volume') {
            if (typeof value === 'object') {
              fields[sharePointField] = JSON.stringify(value);
            } else {
              fields[sharePointField] = value;
            }
          } else {
            fields[sharePointField] = value;
          }
          
        }
      }

      if (Object.keys(fields).length === 0) {
        console.warn('[PickingSharePoint] ⚠️ Nenhum campo válido para atualizar');
        return {
          success: true,
          message: 'Nenhum campo alterado'
        };
      }

      // 3. Fazer update no SharePoint
      const accessToken = await this._getAccessToken();
      const url = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.pedidos}/items/${existing.itemId}`;
      
      
      const response = await this._fetch(url, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ fields })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('[PickingSharePoint] ❌ Erro ao atualizar:', errorText);
        console.error('[PickingSharePoint] 🔍 Status:', response.status);
        console.error('[PickingSharePoint] 🔍 URL tentada:', url);
        console.error('[PickingSharePoint] 🔍 Item ID:', existing.itemId);
        return {
          success: false,
          error: `HTTP ${response.status}: ${errorText}`
        };
      }

      const result = await response.json();

      // ✅ Registrar evento na timeline com detalhes before/after (apenas para edições voluntárias)
      if (!skipTimeline) try {
        const changedKeys = Object.keys(fields);

        // Mapa para transformar campos SharePoint em chaves amigáveis
        const friendlyMap = {
          'Endere_x00e7_oLogradouro': 'endereco',
          'Endereco': 'endereco',
          'EnderecoCompleto': 'endereco_completo',
          'Endere_x00e7_oCompleto': 'endereco_completo',
          'N_x00fa_meroLogradouro': 'numero',
          'Numero': 'numero',
          'Complemento': 'complemento',
          'Bairro': 'bairro',
          'Cidade': 'cidade',
          'UF': 'uf',
          'Estado': 'uf',
          'CEP': 'cep'
        };

        const before = {};
        const after = {};

        // Helper para obter valor antigo de vários candidatos
        const lookupOld = (spField) => {
          // tentar exatamente pelo campo
          let v = existing.raw?.fields?.[spField];
          if (v !== undefined && v !== null && v !== '') return v;

          // fallback comum: tentar nomes alternativos
          const alternates = {
            'Endere_x00e7_oLogradouro': ['Endereco', 'Endere_x00e7_o'],
            'Endereco': ['Endere_x00e7_oLogradouro'],
            'N_x00fa_meroLogradouro': ['Numero', 'N_x00fa_mero'],
            'Numero': ['N_x00fa_meroLogradouro'],
            'EnderecoCompleto': ['Endere_x00e7_oCompleto', 'EnderecoCompleto'],
            'Endere_x00e7_oCompleto': ['EnderecoCompleto']
          };

          const candidates = alternates[spField] || [];
          for (const c of candidates) {
            const vv = existing.raw?.fields?.[c];
            if (vv !== undefined && vv !== null && vv !== '') return vv;
          }

          // Por fim, tentar extrair via existing.pedido (mapeado em getPedido)
          const friendly = friendlyMap[spField];
          if (friendly && existing.pedido && existing.pedido[friendly] !== undefined) {
            return existing.pedido[friendly];
          }

          return null;
        };

        changedKeys.forEach(k => {
          const friendlyKey = friendlyMap[k] || k;

          const oldVal = lookupOld(k);
          before[friendlyKey] = oldVal;

          // novo valor (o que foi enviado no PATCH)
          after[friendlyKey] = fields[k];
        });

        // If caller provided a human-readable motivo (extracted earlier), include it in the timeline
        if (motivo) {
          // attach to event payload
        }

        // 🆔 Tentar obter o Nexos orderID (formato NEXOS-ts-loja-pedido) do stateManager em memória
        const nexosOrderIDForTimeline = (() => {
          try {
            const sm = window.Picking30?.stateManager || window.PickingStateManager;
            if (sm?.state?.orders) {
              for (const lojaKey of Object.keys(sm.state.orders)) {
                const o = sm.state.orders[lojaKey]?.[pedido_id];
                if (o?.orderID && String(o.orderID).startsWith('NEXOS-')) return o.orderID;
              }
            }
          } catch { }
          return null;
        })();

        // 👤 Obter dados do usuário atual para padronizar com o evento de extração
        const _updCurrentUser = window.NexosAuth?.getCurrentUser();
        const _updUserName    = _updCurrentUser?.name || _updCurrentUser?.email || 'Desconhecido';
        const _updUserEmail   = _updCurrentUser?.email || '';

        await this.addTimelineEvent(pedido_id, 'atualizacao', Object.assign({
          orderID:          nexosOrderIDForTimeline,   // 🆔 Nexos ID se disponível
          loja:             loja,                      // 🏪 Código da loja
          detalhes:         `Campos atualizados: ${changedKeys.join(', ')}`,
          campos_alterados: changedKeys.join(', '),
          valores_anteriores: before,
          valores_novos:    after,
          usuario:          _updUserName,              // ✅ Padrão extração
          usuario_nome:     _updUserName,
          usuario_email:    _updUserEmail
        }, motivo ? { motivo } : {}));
      } catch (timelineErr) {
        console.warn('[PickingSharePoint] ⚠️ Falha ao registrar timeline após update:', timelineErr.message || timelineErr);
      }

  // Tentar forçar atualização imediata da UI e notificar listeners
      try {
        // Atualizar a UI localmente (se disponível)
        if (typeof window.refreshOrdersList === 'function') {
          window.refreshOrdersList();
        }

        // Ping via localStorage para acionar storage event em outras abas
        try {
          localStorage.setItem('nexos-picking-refresh', JSON.stringify({ ts: Date.now(), pedidoId: pedido_id }));
        } catch (lsErr) {
          // Falha em escrever localStorage não deve bloquear
          console.warn('[PickingSharePoint] ⚠️ Não foi possível gravar localStorage de refresh:', lsErr?.message || lsErr);
        }

        // Notificar outras abas usando o helper centralizado (BroadcastChannel persistente / fallback)
        try {
          this._postBroadcastMessage({ ts: Date.now(), pedidoId: pedido_id, reason: 'pedido_updated' });
        } catch (e) {
          console.warn('[PickingSharePoint] ⚠️ Falha ao notificar outras abas:', e?.message || e);
        }

        // Disparar evento custom para listeners na mesma aba
        window.dispatchEvent(new CustomEvent('nexos-picking-refresh', { detail: { reason: 'pedido_updated', pedidoId: pedido_id } }));
        // Indicar que o SP sincronizou com sucesso
        try { if (typeof window.__nexos_update_sp_status_badge === 'function') window.__nexos_update_sp_status_badge('green'); } catch(e) {}
      } catch (e) {
        // Não falhar o fluxo principal se a UI não puder ser atualizada
        console.warn('[PickingSharePoint] ⚠️ Falha ao disparar refresh após update:', e?.message || e);
      }

      return {
        success: true,
        itemId: existing.itemId,
        pedidoId: pedido_id,
        updated: Object.keys(fields)
      };

    } catch (error) {
      console.error('[PickingSharePoint] ❌ Erro ao atualizar pedido:', error);
      try { if (typeof window.__nexos_update_sp_status_badge === 'function') window.__nexos_update_sp_status_badge('red'); } catch(e) {}
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Calcular hash MD5 dos dados
   */
  async _calculateHash(dataString) {
    try {
      const msgBuffer = new TextEncoder().encode(dataString);
      const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      return hashHex.substring(0, 64);
    } catch (e) {
      console.warn('[PickingSharePoint] ⚠️ Erro ao calcular hash:', e);
      return Date.now().toString(36); // Fallback: timestamp
    }
  }

  /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 🏪 GERENCIAMENTO DE LOJAS (Nexos_Lojas)
   * ═══════════════════════════════════════════════════════════════════════════
   */

  /**
   * Buscar dados de uma loja por código
   * @param {string} codigoLoja - Código da loja (ex: "0001", "1602")
   * @param {Object} options - Opções adicionais
   * @returns {Promise<Object|null>} Dados da loja ou null se não encontrada
   */
  async getLoja(codigoLoja, options = {}) {
    const { useCache = true, includeHubs = false } = options;

    if (!this.listIds.lojas) {
      return null; // SharePoint não inicializado (token expirado ou sem auth)
    }

    // Normalizar código da loja (adicionar zeros à esquerda se necessário)
    const normalizedCode = String(codigoLoja).padStart(4, '0');

    // Verificar cache persistido
    if (useCache && this.lojasCache.has(normalizedCode)) {
      return this.lojasCache.get(normalizedCode);
    }

    // 🛡️ In-flight dedup: se já há uma requisição em andamento para esta loja
    // (ex: múltiplos cards renderizando ao mesmo tempo), reutiliza o mesmo Promise.
    // Isso evita N requests paralelos ao SP para a mesma loja → reduz risco de 429.
    if (!this._lojaInFlight) this._lojaInFlight = new Map();
    if (this._lojaInFlight.has(normalizedCode)) {
      return this._lojaInFlight.get(normalizedCode);
    }

    const fetchPromise = this._fetchLoja(normalizedCode, includeHubs, useCache);
    this._lojaInFlight.set(normalizedCode, fetchPromise);
    fetchPromise.finally(() => this._lojaInFlight.delete(normalizedCode));
    return fetchPromise;
  }

  async _fetchLoja(normalizedCode, includeHubs, useCache) {
    try {

      const token = await this._getAccessToken();
      const filterQuery = `fields/CodigoLoja eq '${normalizedCode}'`;
      
      const url = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.lojas}/items?` +
                  `$filter=${encodeURIComponent(filterQuery)}&` +
                  `$expand=fields&` +
                  `$top=1`;

      const response = await this._fetch(url, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (!response.ok) {
        console.error(`[PickingSharePoint] ❌ Erro ao buscar loja: HTTP ${response.status}`);
        return null;
      }

      const data = await response.json();

      if (!data.value || data.value.length === 0) {
        // Log silencioso - loja não cadastrada não é erro
        return null;
      }

      const item = data.value[0];
      const fields = item.fields;

      // Montar objeto da loja
      const lojaData = {
        id: item.id,
        codigo: fields.CodigoLoja,
        nome: fields.NomeLoja,
        bandeira: fields.Bandeira,
        status: fields.Status,
        endereco: {
          logradouro: fields.Endereco,
          numero: fields.Numero,
          bairro: fields.Bairro,
          cidade: fields.Cidade,
          uf: fields.UF,
          cep: fields.CEP,
          completo: fields.EnderecoCompleto
        },
        coordenadas: {
          lat: fields.Latitude,
          lng: fields.Longitude
        },
        contatos: {
          email_responsavel: fields.EmailResponsavel
        },
        hub: fields.Hub,
        cnpj: fields.CNPJ,
        isHub: fields.IsHub || false,
        lojasHub: fields.LojasHub ? fields.LojasHub.split(',').map(c => c.trim()) : []
      };

      // Se incluir hubs e esta loja está em um hub, buscar dados do hub
      if (includeHubs && !lojaData.isHub && lojaData.hub) {
        const hubData = await this.getLoja(lojaData.hub, { useCache, includeHubs: false });
        if (hubData) {
          lojaData.hubData = hubData;
        }
      }

      // Salvar no cache
      this.lojasCache.set(normalizedCode, lojaData);

      return lojaData;

    } catch (error) {
      console.error('[PickingSharePoint] ❌ Erro ao buscar loja:', error);
      return null;
    }
  }

  /**
   * Buscar múltiplas lojas por códigos
   * @param {Array<string>} codigos - Array de códigos de lojas
   * @param {Object} options - Opções adicionais
   * @returns {Promise<Map>} Map com código => dados da loja
   */
  async getLojas(codigos, options = {}) {
    const { useCache = true } = options;
    const resultMap = new Map();


    // Buscar em paralelo (limitando a 10 requests simultâneos)
    const chunks = [];
    for (let i = 0; i < codigos.length; i += 10) {
      chunks.push(codigos.slice(i, i + 10));
    }

    for (const chunk of chunks) {
      const promises = chunk.map(codigo => this.getLoja(codigo, { useCache }));
      const results = await Promise.all(promises);
      
      results.forEach((lojaData, index) => {
        const codigo = chunk[index];
        if (lojaData) {
          resultMap.set(codigo, lojaData);
        }
      });
    }

    return resultMap;
  }

  /**
   * Limpar cache de lojas
   */
  clearLojasCache() {
    const cacheSize = this.lojasCache.size;
    this.lojasCache.clear();
  }

  /**
   * Pré-carregar todas as lojas no cache
   * @returns {Promise<number>} Número de lojas carregadas
   */
  async preloadLojas() {
    if (!this.listIds.lojas) {
      return 0; // SharePoint não inicializado
    }

    try {

      const token = await this._getAccessToken();
      const url = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.lojas}/items?` +
                  `$expand=fields&` +
                  `$top=1000`;

      const response = await this._fetch(url, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (!response.ok) {
        console.error(`[PickingSharePoint] ❌ Erro ao pré-carregar lojas: HTTP ${response.status}`);
        return 0;
      }

      const data = await response.json();
      let loadedCount = 0;

      for (const item of data.value) {
        const fields = item.fields;
        const codigo = fields.CodigoLoja;

        const lojaData = {
          id: item.id,
          codigo: codigo,
          nome: fields.NomeLoja,
          bandeira: fields.Bandeira,
          status: fields.Status,
          endereco: {
            logradouro: fields.Endereco,
            numero: fields.Numero,
            bairro: fields.Bairro,
            cidade: fields.Cidade,
            uf: fields.UF,
            cep: fields.CEP,
            completo: fields.EnderecoCompleto
          },
          coordenadas: {
            lat: fields.Latitude,
            lng: fields.Longitude
          },
          contatos: {
            email_responsavel: fields.EmailResponsavel
          },
          hub: fields.Hub,
          cnpj: fields.CNPJ,
          isHub: fields.IsHub || false,
          lojasHub: fields.LojasHub ? fields.LojasHub.split(',').map(c => c.trim()) : []
        };

        this.lojasCache.set(codigo, lojaData);
        loadedCount++;
      }

      return loadedCount;

    } catch (error) {
      console.error('[PickingSharePoint] ❌ Erro ao pré-carregar lojas:', error);
      return 0;
    }
  }

  /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 🔒 GERENCIAMENTO DE LOCKS (Nexos_StatusPedidos)
   * ═══════════════════════════════════════════════════════════════════════════
   */

  /**
   * Adquirir lock de um pedido
   * @param {string} loja - Código da loja
   * @param {string} pedido_id - ID do pedido
   * @param {number} durationMinutes - Duração do lock em minutos (padrão: 5)
   * @returns {Promise<{success: boolean, lockId?: string, error?: string}>}
   */
  async acquireLock(loja, pedido_id, durationMinutes = 5) {
    this._ensureInitialized();


    const orderID = `${loja}-${pedido_id}`;

    try {
      // 1. Buscar pedido existente
      const existing = await this.getOrder(loja, pedido_id, { maxRetries: 1 });
      if (!existing.success) {
        throw new Error(`Pedido não encontrado: ${orderID}`);
      }

      // 2. Verificar se já está travado
      if (existing.raw.fields.IsLocked) {
        const lockedBy = existing.raw.fields.LockedBy;
        const expiresAt = new Date(existing.raw.fields.LockExpires);
        const nowUtc = new Date(this._nowUtcMs()); // ⏱️ UTC real

        // Se lock ainda válido
        if (expiresAt > nowUtc) {
          console.warn('[PickingSharePoint] ⚠️ Pedido já está travado por:', lockedBy);
          return {
            success: false,
            error: `Pedido travado por ${lockedBy} até ${expiresAt.toLocaleString()}`,
            lockedBy: lockedBy,
            expiresAt: expiresAt
          };
        }

      }

      // 3. Obter usuário atual
      const currentUser = window.NexosAuth?.getCurrentUser();
      const userEmail = currentUser?.email || 'unknown@nexos.com';

      // 4. Calcular expiração usando UTC real do servidor
      const now = new Date(this._nowUtcMs());
      const expiresAt = new Date(this._nowUtcMs() + durationMinutes * 60000);

      // 5. Atualizar pedido com lock
      const fields = {
        IsLocked: true,
        LockedBy: userEmail,
        LockedAt: now.toISOString(),
        LockExpires: expiresAt.toISOString()
        // ✅ UpdatedAt removido - SharePoint atualiza 'Modified' automaticamente
      };


      const accessToken = await this._getAccessToken();
      const response = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items/${existing.itemId}/fields`,
        {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(fields)
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error('[PickingSharePoint] ❌ Erro ao deletar pedido:', errorText);
        // Se o item já não existir, não propagar exceção severa — retornar notFound para o caller tratar
        if (response.status === 404 || (errorText && errorText.includes('itemNotFound'))) {
          console.warn('[PickingSharePoint] ⚠️ Item não encontrado ao tentar deletar (404). Pode já ter sido removido. Item ID:', existing.itemId);
          return {
            success: false,
            notFound: true,
            error: `HTTP ${response.status}: ${errorText}`
          };
        }

        // Detectar token expirado e sinalizar ao caller
        if (response.status === 401 || errorText.includes('InvalidAuthenticationToken') || errorText.includes('token is expired')) {
          console.error('[PickingSharePoint] ⚠️ Token expirado detectado em deleteOrder!');
          throw Object.assign(
            new Error(`HTTP ${response.status}: ${errorText}`),
            { isTokenExpired: true }
          );
        }

        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }


      // 6. Registrar no AuditLog
      await this._logAudit('lock', 'order', orderID, userEmail, null, { locked: true, expiresAt });

      return {
        success: true,
        lockId: existing.itemId,
        orderID: orderID,
        lockedBy: userEmail,
        expiresAt: expiresAt
      };

    } catch (error) {
      console.error('[PickingSharePoint] ❌ Erro ao adquirir lock:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Liberar lock de um pedido
   */
  async releaseLock(loja, pedido_id) {
    this._ensureInitialized();


    const orderID = `${loja}-${pedido_id}`;

    try {
      const existing = await this.getOrder(loja, pedido_id, { maxRetries: 1 });
      if (!existing.success) {
        throw new Error(`Pedido não encontrado: ${orderID}`);
      }

      const now = new Date(this._nowUtcMs()); // ⏱️ UTC real
      const fields = {
        IsLocked: false,
        LockedBy: null,
        LockedAt: null,
        LockExpires: null
        // ✅ UpdatedAt removido - SharePoint atualiza 'Modified' automaticamente
      };


      const accessToken = await this._getAccessToken();
      const response = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.orders}/items/${existing.itemId}/fields`,
        {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(fields)
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }


      const currentUser = window.NexosAuth?.getCurrentUser();
      const userEmail = currentUser?.email || 'unknown@nexos.com';
      await this._logAudit('unlock', 'order', orderID, userEmail, { locked: true }, { locked: false });

      return { success: true };

    } catch (error) {
      console.error('[PickingSharePoint] ❌ Erro ao liberar lock:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Verificar se pedido está travado
   */
  async checkLock(loja, pedido_id) {
    this._ensureInitialized();

    try {
      const existing = await this.getOrder(loja, pedido_id, { maxRetries: 1 });
      if (!existing.success) {
        return { success: false, locked: false };
      }

      const isLocked = existing.raw.fields.IsLocked || false;
      const lockedBy = existing.raw.fields.LockedBy;
      const expiresAt = existing.raw.fields.LockExpires ? new Date(existing.raw.fields.LockExpires) : null;

      // Verificar se lock expirou usando UTC real do servidor
      if (isLocked && expiresAt && expiresAt.getTime() < this._nowUtcMs()) {
        await this.releaseLock(loja, pedido_id);
        return { success: true, locked: false, expired: true };
      }

      return {
        success: true,
        locked: isLocked,
        lockedBy: lockedBy,
        expiresAt: expiresAt
      };

    } catch (error) {
      console.error('[PickingSharePoint] ❌ Erro ao verificar lock:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 📜 GERENCIAMENTO DE TIMELINE (Nexos_TimelinePedidos)
   * ═══════════════════════════════════════════════════════════════════════════
   */

  /**
   * Adicionar evento na timeline
   */
  async addTimelineEvent(pedidoGPAID, eventType, eventData = {}) {
    this._ensureInitialized();

    // 🔒 IMUTABILIDADE: Esta função SOMENTE cria novos registros (POST).
    // Registros da timeline NUNCA devem ser modificados ou excluídos após a criação.
    // Não existe updateTimelineEvent nem deleteTimelineEvent por design.


    try {
      const currentUser = window.NexosAuth?.getCurrentUser();
      const userEmail = currentUser?.email || 'unknown@nexos.com';
      const now = new Date().toISOString();
      
      // Buscar ID do usuário na tabela Nexos_Usuarios (para lookup)
      let usuarioLookupId = null;
      let userPhotoUrl = '';
      try {
        const accessToken = await this._getAccessToken();
        
        // Obter List ID de Nexos_Usuarios
        const listResponse = await this._fetch(
          `${this.graphUrl}/sites/${this.siteId}/lists?$filter=displayName eq 'Nexos_Usuarios'`,
          { headers: { 'Authorization': `Bearer ${accessToken}` } }
        );
        
        if (listResponse.ok) {
          const listData = await listResponse.json();
          
          if (listData.value && listData.value.length > 0) {
            const usuariosListId = listData.value[0].id;
            
            // Buscar usuário por email
            const userResponse = await this._fetch(
              `${this.graphUrl}/sites/${this.siteId}/lists/${usuariosListId}/items?$expand=fields&$filter=fields/Email eq '${userEmail}'`,
              { headers: { 'Authorization': `Bearer ${accessToken}` } }
            );
            
            if (userResponse.ok) {
              const userData = await userResponse.json();
              if (userData.value && userData.value.length > 0) {
                usuarioLookupId = userData.value[0].id; // 🆕 ID do registro para lookup
                if (userData.value[0].fields.FotoURL) {
                  userPhotoUrl = userData.value[0].fields.FotoURL;
                }
              }
            }
          }
        }
      } catch (photoError) {
        console.warn('[PickingSharePoint] ⚠️ Erro ao buscar usuário:', photoError.message);
      }
      
      // 🆔 Usar OrderID se foi passado em eventData, senão usar pedidoGPAID
      const orderIDToUse = eventData.orderID || pedidoGPAID;
      
      // 🔢 Tentativa (padrão 1 para extração)
      const numeroTentativa = eventData.tentativa || (eventType === 'extracao' ? 1 : null);
      
      // ℹ️ NOTA: Campo "Criado por" será preenchido automaticamente pelo SharePoint

      const item = {
        fields: {
          Title: orderIDToUse,                                                    // ✅ Só o OrderID único (sem tipo do evento)
          'ID_x0020_Pedido_x0020_GPA': String(pedidoGPAID),                     // ✅ ID Pedido GPA (número real)
          'C_x00f3_digo_x0020_Loja': eventData.loja || '',                      // ✅ Código Loja
          TipoEvento: eventType,                                                  // ✅ Tipo de Evento
          // Incluir motivo diretamente na descrição se houver
          'Descri_x00e7__x00e3_o': (eventData.detalhes || `Evento: ${eventType}`) + (eventData.motivo ? ` — Motivo: ${eventData.motivo}` : ''), // ✅ Descrição
          DadosAdicionais: (() => {
            // 🔒 Garantir que userEmail e userPhotoUrl fiquem no início (não serão cortados)
            const coreData = {
              userEmail: userEmail,
              userPhotoUrl: userPhotoUrl,
              orderID: orderIDToUse,
              tipo_evento: eventType
            };
            const fullData = { ...coreData, ...eventData };
            const jsonStr = JSON.stringify(fullData);
            // Se maior que 4000, cortar mas manter JSON válido
            if (jsonStr.length > 4000) {
              return JSON.stringify(coreData); // Manter só dados essenciais
            }
            return jsonStr;
          })(),                                                                   // ✅ Dados Adicionais (JSON)
          TimestampEvento: now,                                                   // ✅ Timestamp Evento - OBRIGATÓRIO
          Plataforma: eventData.plataforma || null,                               // ✅ Plataforma (se envio)
          NumeroTentativa: numeroTentativa,                                       // ✅ Nº Tentativa - OBRIGATÓRIO (1 para extração)
          Sucesso: eventData.sucesso !== false,                                   // ✅ Sucesso (padrão true) - OBRIGATÓRIO
          StatusResultado: eventData.sucesso === false ? 'erro' : 'sucesso',      // ✅ Status Resultado
          UsuarioLookupId: usuarioLookupId                                        // 🆕 Lookup para Nexos_Usuarios (auto-preenche Usuario: FotoURL)
        }
      };


      const accessToken = await this._getAccessToken();
      const url = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.timeline}/items`;
      
      
      const response = await this._fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(item)
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('[PickingSharePoint] ❌ Erro HTTP ao criar timeline:', response.status);
        console.error('[PickingSharePoint] 📄 Resposta de erro:', errorText);
        console.error('[PickingSharePoint] 🔍 Payload enviado:', JSON.stringify(item, null, 2));
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const created = await response.json();

      // Atualizar também o StateManager em memória para refletir imediatamente na UI
      try {
        if (typeof window.PickingStateManager !== 'undefined' && window.PickingStateManager && typeof window.PickingStateManager.addTimelineEvent === 'function') {
          const memEvent = {
            type: eventType,
            details: (eventData.detalhes || eventData.descricao || eventData.message || '') + (eventData.motivo ? ` — Motivo: ${eventData.motivo}` : ''),
            dados: eventData,
            user: currentUser?.name || currentUser?.email || userEmail,
            timestamp: new Date(now).getTime(),
            id: `sp_event_${created.id}`
          };
          try {
            window.PickingStateManager.addTimelineEvent(pedidoGPAID, memEvent);
          } catch (e) {
            console.warn('[PickingSharePoint] ⚠️ Falha ao espelhar evento na memória:', e?.message || e);
          }
        }
      } catch (mirrorErr) {
        console.warn('[PickingSharePoint] ⚠️ Erro ao tentar atualizar StateManager com o evento de timeline:', mirrorErr?.message || mirrorErr);
      }

      return {
        success: true,
        itemId: created.id,
        orderID: orderIDToUse
      };

    } catch (error) {
      console.error('[PickingSharePoint] ❌ Erro ao adicionar evento:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Buscar timeline de um pedido pelo ID Pedido GPA
   * @param {string} pedidoGPAID - ID do pedido GPA (ex: "21360515")
   */
  async getTimeline(pedidoGPAID, options = {}) {
    this._ensureInitialized();

    const { limit = 50, orderBy = 'TimestampEvento desc', orderID = null } = options;


    try {
      const accessToken = await this._getAccessToken();
      
      // ✅ Preferir filtro por Title (campo orderID, sempre indexado no SP) quando disponível.
      // Evita o problema do HonorNonIndexedQueriesWarningMayFailRandomly que pode retornar
      // todos os eventos da lista quando ID_x0020_Pedido_x0020_GPA não está indexado.
      let filterExpr;
      let requestHeaders;
      if (orderID && orderID !== 'N/A' && orderID !== pedidoGPAID) {
        // 🔑 Filtro pelo Title (= Nexos orderID) — campo Title é sempre indexado no SharePoint
        filterExpr = `fields/Title eq '${orderID}'`;
        requestHeaders = {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
          // Sem o header Prefer — campo é indexado, não precisa
        };
        console.log(`[PickingSharePoint] 🔍 getTimeline — filtro por Title (orderID): ${orderID}`);
      } else {
        // ⚠️ Fallback: filtro pelo ID_x0020_Pedido_x0020_GPA (pode não estar indexado)
        filterExpr = `fields/ID_x0020_Pedido_x0020_GPA eq '${pedidoGPAID}'`;
        requestHeaders = {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
        };
        console.warn(`[PickingSharePoint] ⚠️ getTimeline — usando filtro não indexado por GPA ID: ${pedidoGPAID}. Forneça orderID para filtro confiável.`);
      }

      const url = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.timeline}/items?$expand=fields&$filter=${encodeURIComponent(filterExpr)}&$orderby=fields/${orderBy}&$top=${limit}`;

      const response = await this._fetch(url, {
        method: 'GET',
        headers: requestHeaders
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      const events = data.value.map(item => {
        let dadosAdicionais = {};
        try {
          if (item.fields.DadosAdicionais) {
            dadosAdicionais = JSON.parse(item.fields.DadosAdicionais);
          }
        } catch (parseError) {
          console.warn('[PickingSharePoint] ⚠️ Erro ao parsear DadosAdicionais:', parseError);
        }

        return {
          id: item.id,
          orderID: item.fields.Title,                              // OrderID único
          pedidoGPAID: item.fields['ID_x0020_Pedido_x0020_GPA'],  // ID Pedido GPA
          loja: item.fields['C_x00f3_digo_x0020_Loja'],           // Código Loja
          eventType: item.fields.TipoEvento,                       // Tipo de Evento
          description: item.fields['Descri_x00e7__x00e3_o'],      // Descrição
          dadosAdicionais: dadosAdicionais,                        // Dados Adicionais (JSON) - contém userPhotoUrl
          userEmail: item.createdBy?.user?.email || 'unknown',    // ✅ Campo padrão "Criado por"
          timestamp: new Date(item.fields.TimestampEvento).getTime(), // Timestamp em milissegundos
          platform: item.fields.Plataforma,                        // Plataforma
          tentativa: item.fields.NumeroTentativa,                  // Nº Tentativa
          sucesso: item.fields.Sucesso,                            // Sucesso
          statusResultado: item.fields.StatusResultado             // Status Resultado
        };
      });


      return {
        success: true,
        count: events.length,
        events: events
      };

    } catch (error) {
      console.error('[PickingSharePoint] ❌ Erro ao buscar timeline:', error);
      return {
        success: false,
        error: error.message,
        events: []
      };
    }
  }

  /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 🔄 GERENCIAMENTO DE FILA (Nexos_FilaPedidos)
   * ═══════════════════════════════════════════════════════════════════════════
   */

  /**
   * Adicionar job na fila
   */
  async queueJob(orderID, jobType, platform, options = {}) {
    this._ensureInitialized();


    try {
      const now = new Date().toISOString();
      const jobID = `job-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const { priority = 3, maxRetries = 3 } = options;

      const item = {
        fields: {
          Title: `${jobType} - ${orderID}`,
          JobID: jobID,
          OrderID: orderID,
          JobType: jobType,
          Platform: platform || 'manual',
          Status: 'pending',
          Priority: priority,
          CreatedAt: now,
          RetryCount: 0,
          MaxRetries: maxRetries
        }
      };

      const accessToken = await this._getAccessToken();
      const response = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.queue}/items`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(item)
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const created = await response.json();

      return {
        success: true,
        jobId: created.id,
        jobID: jobID
      };

    } catch (error) {
      console.error('[PickingSharePoint] ❌ Erro ao adicionar job:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 📊 LOGS E AUDITORIA
   * ═══════════════════════════════════════════════════════════════════════════
   */

  /**
   * Registrar log operacional (Nexos_Logs)
   */
  async log(level, category, message, details = {}) {
    if (!this.initialized) return; // Não bloquear se SharePoint não disponível

    try {
      const currentUser = window.NexosAuth?.getCurrentUser();
      const userEmail = currentUser?.email || 'system@nexos.com';
      const now = new Date().toISOString();

      const item = {
        fields: {
          Title: `[${level.toUpperCase()}] ${category}`,
          LogLevel: level,
          Category: category,
          Message: message,
          Details: JSON.stringify(details).substring(0, 4000),
          Timestamp: now,
          UserEmail: userEmail,
          OrderID: details.orderID || null
        }
      };

      const accessToken = await this._getAccessToken();
      await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.logs}/items`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(item)
        }
      );

    } catch (error) {
      console.warn('[PickingSharePoint] ⚠️ Erro ao registrar log:', error.message);
    }
  }

  /**
   * Registrar auditoria (Nexos_AuditLog) - PRIVADO
   */
  async _logAudit(operation, entityType, entityID, userEmail, beforeValue, afterValue) {
    if (!this.initialized) return;

    try {
      const now = new Date().toISOString();

      const item = {
        fields: {
          Title: `${operation.toUpperCase()} ${entityType} - ${entityID}`,
          Operation: operation,
          EntityType: entityType,
          EntityID: entityID,
          UserEmail: userEmail,
          UserName: window.NexosAuth?.getCurrentUser()?.name || 'Unknown',
          Timestamp: now,
          BeforeValue: beforeValue ? JSON.stringify(beforeValue).substring(0, 4000) : null,
          AfterValue: afterValue ? JSON.stringify(afterValue).substring(0, 4000) : null,
          Success: true
        }
      };

      const accessToken = await this._getAccessToken();
      await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listIds.auditLog}/items`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(item)
        }
      );

    } catch (error) {
      console.warn('[PickingSharePoint] ⚠️ Erro ao registrar auditoria:', error.message);
    }
  }

  /**
   * 🔔 Buscar alertas recentes do tipo 'alerta_usuario' na Nexos_TimelinePedidos.
   * Retorna apenas alertas criados após `sinceMs` e direcionados a `targetEmail`.
   * @param {string} targetEmail   - e-mail do usuário receptor
   * @param {number} sinceMs       - timestamp em ms (busca apenas itens mais recentes)
   * @returns {Promise<Array>}     - lista de alertas { pedidoId, from, message, createdAt }
   */
  async getRecentAlerts(targetEmail, sinceMs) {
    this._ensureInitialized();
    try {
      const accessToken = await this._getAccessToken();
      const listId = await this._getListId(this.listNames.timeline);
      const sinceIso = new Date(sinceMs).toISOString();

      // Filtrar eventos do tipo alerta_usuario criados após sinceMs
      const url = `${this.graphUrl}/sites/${this.siteId}/lists/${listId}/items`
        + `?$expand=fields`
        + `&$filter=fields/TipoEvento eq 'alerta_usuario' and fields/Created gt '${sinceIso}'`
        + `&$orderby=fields/Created desc`
        + `&$top=20`;

      const resp = await this._fetch(url, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      if (!resp.ok) return [];

      const data = await resp.json();
      const alerts = [];
      for (const item of (data.value || [])) {
        const f = item.fields || {};
        let extra = {};
        try { extra = JSON.parse(f.DadosAdicionais || '{}'); } catch (_) {}
        // Só retornar se direcionado ao usuário atual
        if (extra.targetEmail && extra.targetEmail.toLowerCase() !== (targetEmail || '').toLowerCase()) continue;
        alerts.push({
          pedidoId: f['ID_x0020_Pedido_x0020_GPA'] || extra.pedidoId || '',
          from: extra.fromName || extra.userEmail || '',
          message: extra.alertMessage || f['Descri_x00e7__x00e3_o'] || '🔔 Você recebeu um alerta',
          createdAt: new Date(f.Created || item.createdDateTime || 0).getTime()
        });
      }
      return alerts;
    } catch (e) {
      console.warn('[PickingSharePoint] ⚠️ Erro ao buscar alertas:', e?.message || e);
      return [];
    }
  }
}

// Exportar para window
if (typeof window !== 'undefined') {
  window.PickingSharePointManager = PickingSharePointManager;
}
