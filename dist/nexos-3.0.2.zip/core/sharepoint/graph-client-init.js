/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - GRAPH CLIENT INITIALIZATION
 * Inicialização automática do Graph Client para uso em content scripts
 * ═══════════════════════════════════════════════════════════════════════════
 */

(async function initGraphClient() {
  'use strict';
  
  // console.log('[GraphClientInit] 🚀 Inicializando Graph Client...');
  
  try {
    // Aguardar dependências estarem disponíveis
    const waitForDependencies = async () => {
      const maxAttempts = 100; // 10 segundos
      for (let i = 0; i < maxAttempts; i++) {
        const hasAuthHelper = typeof window.AuthHelper !== 'undefined';
        const hasGraphClient = typeof window.GraphClient !== 'undefined';
        const hasConfig = typeof window.SHAREPOINT_CONFIG !== 'undefined' || typeof window.AZURE_AD_CONFIG !== 'undefined';
        
        // if (i % 10 === 0) { // Log a cada 1 segundo
        //   console.log('[GraphClientInit] Aguardando dependências...', {
        //     attempt: i + 1,
        //     'window.AuthHelper': hasAuthHelper,
        //     'window.GraphClient': hasGraphClient,
        //     'Config': hasConfig
        //   });
        // }
        
        if (hasAuthHelper && hasGraphClient && hasConfig) {
          // console.log('[GraphClientInit] ✅ Todas dependências carregadas!');
          return true;
        }
        
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      
      console.error('[GraphClientInit] ❌ Timeout aguardando dependências');
      return false;
    };
    
    const dependenciesReady = await waitForDependencies();
    
    if (!dependenciesReady) {
      console.warn('[GraphClientInit] ⚠️ Dependências não carregadas - modo offline');
      window.graphClient = null;
      window.authHelper = null;
      return;
    }
    
    // console.log('[GraphClientInit] ✅ Dependências carregadas');
    
    // Criar AuthHelper (usa window.AZURE_AD_CONFIG automaticamente)
    const authHelper = new window.AuthHelper();
    // console.log('[GraphClientInit] ✅ AuthHelper criado');
    
    // Criar GraphClient com configuração do SharePoint
    const siteUrl = window.SHAREPOINT_CONFIG?.siteUrl || 'gpabr.sharepoint.com';
    const sitePath = window.SHAREPOINT_CONFIG?.sitePath || '/sites/TorreDeControle';
    
    const graphClient = new window.GraphClient(authHelper, siteUrl, sitePath);
    // console.log('[GraphClientInit] ✅ GraphClient criado');
    
    // Exportar para window IMEDIATAMENTE
    window.authHelper = authHelper;
    window.graphClient = graphClient;
    
    // console.log('[GraphClientInit] ✅ Exportado: window.authHelper, window.graphClient');
    
    // Disparar evento IMEDIATAMENTE (antes de verificar auth)
    window.dispatchEvent(new CustomEvent('nexos-graphclient-ready', { 
      detail: { 
        graphClient, 
        authHelper, 
        isAuthenticated: null // Será verificado depois
      } 
    }));
    
    // console.log('[GraphClientInit] 🎉 Evento disparado! GraphClient disponível');
    
    // Verificar autenticação DEPOIS (assíncrono, não bloqueia)
    (async () => {
      try {
        // Timeout de 30 segundos para verificação de autenticação (renovação pode demorar)
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error('Timeout na verificação de autenticação (30s)')), 30000);
        });
        
        const authPromise = authHelper.isAuthenticated();
        
        const isAuthenticated = await Promise.race([authPromise, timeoutPromise]);
        
        // console.log('[GraphClientInit] 🔐 Autenticado:', isAuthenticated);
        
        // Se autenticado, obter informações do usuário
        if (isAuthenticated) {
          try {
            const user = await authHelper.getCurrentUser();
            if (user) {
              window.currentUser = user;
              // console.log('[GraphClientInit] ✅ Usuário:', user.displayName, `(${user.userPrincipalName})`);
            }
          } catch (error) {
            console.warn('[GraphClientInit] ⚠️ Não foi possível obter dados do usuário:', error.message);
          }
        } else {
          // console.log('[GraphClientInit] ℹ️ Usuário não autenticado - login necessário');
        }
      } catch (error) {
        console.warn('[GraphClientInit] ⚠️ Erro/timeout ao verificar autenticação:', error.message);
        // console.log('[GraphClientInit] ℹ️ GraphClient disponível em modo offline (autenticação será resolvida em background)');
      }
    })();
    
    // console.log('[GraphClientInit] ✅ Inicialização completa!');
    
  } catch (error) {
    console.error('[GraphClientInit] ❌ Erro na inicialização:', error);
    console.error('[GraphClientInit] Stack:', error.stack);
    
    // Modo offline - não quebrar a extensão
    window.graphClient = null;
    window.authHelper = null;
    
    console.warn('[GraphClientInit] ⚠️ Extensão em modo OFFLINE - SharePoint desabilitado');
  }
})();

// Exportar flag de disponibilidade
if (typeof window !== 'undefined') {
  window.NEXOS_GRAPHCLIENT_LOADING = true;
}

// console.log('[GraphClientInit] 📦 Módulo carregado');
