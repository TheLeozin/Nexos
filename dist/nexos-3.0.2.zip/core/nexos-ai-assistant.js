/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS AI ASSISTANT - ASSISTENTE IA
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Componente de chat com IA integrado no overlay Picking.
 * Substitui o painel de login e fica encostado no footer dentro do aside.
 * 
 * @version 2.0.0
 * @author Nexos Team
 */

(function() {
  'use strict';

  // Verifica se estamos em contexto válido para rodar
  const hasValidContext = typeof window !== 'undefined' && typeof document !== 'undefined';
  
  if (!hasValidContext) {
    console.warn('[AI Assistant] ⚠️ Contexto inválido, abortando inicialização');
    return;
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     CLASSE AI ASSISTANT
     ══════════════════════════════════════════════════════════════════════════ */

  class NexosAIAssistant {
    constructor(overlayContainer = null) {
      this.isOpen = false;
      this.messages = [];
      this.container = overlayContainer; // Container do overlay (aside)
      this.chatWindow = null;
      this.storesData = null; // Dados de lojas carregados
      this.lastMentionedStore = null; // 🔥 Contexto de conversação (última loja mencionada)
      this.previousActiveElement = null; // Para restaurar foco
      this.focusTrapHandler = null; // Handler do focus trap
      
      // NÃO inicializar automaticamente - será chamado manualmente após login
      console.log('[AI Assistant] 💡 Instância criada (não inicializada)');
    }

    /**
     * Inicializa o assistente (chamado manualmente após login)
     * @param {HTMLElement} containerElement - Elemento aside do overlay
     */
    async init(containerElement) {
      console.log('[AI Assistant] 🤖 Inicializando assistente IA no overlay...');
      
      if (!containerElement) {
        console.error('[AI Assistant] ❌ Container não fornecido!');
        return false;
      }
      
      this.container = containerElement;
      
      await this.loadStoresData(); // Carrega dados de lojas
      await this.loadSmartSearch(); // Carrega SmartSearch
      this.createChatPanel(); // Cria painel dentro do aside
      this.loadHistory();
      
      console.log('[AI Assistant] ✅ Assistente inicializado com sucesso');
      return true;
    }

        /**
     * Carrega dados de lojas do stores.json
     * Main World usa bridge, Content Script usa chrome.runtime direto
     */
    async loadStoresData() {
      try {
        console.log('[AI Assistant] 📡 Carregando dados de lojas...');
        
        // Detectar contexto
        const hasChrome = typeof chrome !== 'undefined';
        const hasChromeRuntime = hasChrome && chrome.runtime && chrome.runtime.getURL;
        const isMainWorld = hasChrome && !hasChromeRuntime;
        
        console.log('[AI Assistant] 🔍 Contexto:', isMainWorld ? 'MAIN WORLD (bridge)' : 'CONTENT SCRIPT (direto)');
        
        // MAIN WORLD: Usar bridge
        if (isMainWorld) {
          console.log('[AI Assistant] 🌉 Enviando via bridge...');
          
          const response = await new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
              reject(new Error('Timeout: content script não respondeu'));
            }, 5000);
            
            const listener = (event) => {
              if (event.detail && event.detail.type === 'STORES_DATA_RESPONSE') {
                clearTimeout(timeout);
                document.removeEventListener('nexos-response', listener);
                resolve(event.detail);
              }
            };
            
            document.addEventListener('nexos-response', listener);
            
            document.dispatchEvent(new CustomEvent('nexos-request', {
              detail: {
                type: 'GET_STORES_DATA',
                timestamp: Date.now()
              }
            }));
          });
          
          if (response.success && response.data) {
            this.storesData = response.data;
            console.log('[AI Assistant] ✅ Dados via bridge:', this.storesData.stores.length - 1, 'lojas');
            return;
          } else {
            console.error('[AI Assistant] ❌ Bridge retornou erro:', response.error);
          }
        }
        
        // CONTENT SCRIPT ou FALLBACK
        else {
          // Tentar storage
          if (chrome.storage && chrome.storage.local) {
            const stored = await chrome.storage.local.get('nexos-stores-data');
            if (stored && stored['nexos-stores-data'] && stored['nexos-stores-data'].stores) {
              this.storesData = stored['nexos-stores-data'];
              console.log('[AI Assistant] ✅ Dados do storage:', this.storesData.stores.length - 1, 'lojas');
              return;
            }
          }
          
          // Tentar stores.json
          if (chrome.runtime && chrome.runtime.getURL) {
            const storesUrl = chrome.runtime.getURL('stores.json');
            const response = await fetch(storesUrl);
            
            if (response.ok) {
              const data = await response.json();
              // 🔥 FIX: Carregar DADOS COMPLETOS (stores + details)
              this.storesData = {
                stores: data.stores || data,
                details: data.details || {}, // ← IMPORTANTE: Carregar detalhes!
                version: data.version,
                total_lojas: data.total_lojas,
                source: 'stores-json',
                lastUpdate: Date.now()
              };
              console.log('[AI Assistant] ✅ Dados do stores.json:', this.storesData.stores.length - 1, 'lojas');
              console.log('[AI Assistant] 📋 Detalhes carregados:', Object.keys(this.storesData.details).length, 'lojas com info completa');
              
              if (chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({ 'nexos-stores-data': this.storesData });
              }
              return;
            }
          }
        }
        
        // FALLBACK
        console.error('[AI Assistant] ❌ Não foi possível carregar stores.json');
        this.storesData = { stores: ['TOTAL'], source: 'fallback', lastUpdate: Date.now() };
        
      } catch (error) {
        console.error('[AI Assistant] ❌ Erro crítico:', error);
        this.storesData = { stores: ['TOTAL'], source: 'error', lastUpdate: Date.now() };
      }
    }

    /**
     * Carrega e inicializa SmartSearch (substituindo Ollama)
     */
    async loadSmartSearch() {
      try {
        console.log('[AI Assistant] 📚 Carregando base de conhecimento...');
        
        // Verificar se SmartSearch já está disponível, senão aguardar
        if (typeof SmartSearch === 'undefined') {
          console.warn('[AI Assistant] ⏳ SmartSearch não carregado, aguardando...');
          
          // Aguardar até 5 segundos pelo carregamento do SmartSearch
          let attempts = 0;
          const maxAttempts = 50; // 50 * 100ms = 5s
          
          while (typeof SmartSearch === 'undefined' && attempts < maxAttempts) {
            await new Promise(resolve => setTimeout(resolve, 100));
            attempts++;
          }
          
          if (typeof SmartSearch === 'undefined') {
            console.error('[AI Assistant] ❌ SmartSearch não carregado após 5s');
            this.smartSearch = null;
            return;
          }
          
          console.log('[AI Assistant] ✅ SmartSearch carregado após ' + (attempts * 100) + 'ms');
        }
        
        // Carregar knowledge base
        const kbUrl = chrome.runtime.getURL('core/knowledge-base.json');
        const response = await fetch(kbUrl);
        
        if (!response.ok) {
          throw new Error(`Failed to load knowledge base: ${response.status}`);
        }
        
        const knowledgeBase = await response.json();
        
        // Inicializar SmartSearch
        this.smartSearch = new SmartSearch(knowledgeBase);
        
        console.log('[AI Assistant] ✅ SmartSearch inicializado');
        console.log('[AI Assistant] 📊 Índice:', this.smartSearch.index.size, 'termos');
        
      } catch (error) {
        console.error('[AI Assistant] ❌ Erro ao carregar SmartSearch:', error);
        this.smartSearch = null;
      }
    }


    /**
     * Cria botão flutuante
     */
    /**
     * Cria painel de chat dentro do aside do overlay
     * Substitui o painel de login e fica encostado ao footer
     */
    createChatPanel() {
      console.log('[AI Assistant] 🎨 Criando painel de chat...');
      
      if (!this.container) {
        console.error('[AI Assistant] ❌ Container (aside) não definido!');
        return;
      }
      
      // Painel principal que ocupará todo o aside
      this.chatWindow = document.createElement('div');
      this.chatWindow.className = 'nexos-ai-chat-panel';
      this.chatWindow.style.cssText = `
        display: flex;
        flex-direction: column;
        height: 100%;
        width: 100%;
        background: var(--nexos-bg-primary, #ffffff);
        position: relative;
      `;

      // Header do chat (simplificado, sem botão fechar)
      const header = document.createElement('div');
      header.style.cssText = `
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 12px 16px;
        display: flex;
        align-items: center;
        gap: 12px;
        flex-shrink: 0;
      `;

      const title = document.createElement('div');
      title.style.cssText = `
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 600;
        font-size: 15px;
        flex: 1;
      `;
      title.innerHTML = `
        <span style="font-size: 22px;">🤖</span>
        <div>
          <div>Assistente IA</div>
          <div style="font-size: 11px; opacity: 0.9; font-weight: 400;">Nexos</div>
        </div>
      `;

      header.appendChild(title);
      
      // Área de mensagens
      this.messagesContainer = document.createElement('div');
      this.messagesContainer.className = 'nexos-ai-messages';
      this.messagesContainer.style.cssText = `
        flex: 1;
        overflow-y: auto;
        padding: 12px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        background: var(--nexos-bg-secondary, #f9fafb);
      `;

      // Input area (encostado no footer)
      const inputArea = document.createElement('div');
      inputArea.style.cssText = `
        padding: 12px;
        background: var(--nexos-bg-primary, #ffffff);
        border-top: 1px solid var(--nexos-border, #e5e7eb);
        display: flex;
        gap: 10px;
        flex-shrink: 0;
      `;

      this.input = document.createElement('input');
      this.input.type = 'text';
      this.input.id = 'nexos-ai-input'; // ID para os botões de ajuda preencherem
      this.input.placeholder = 'Digite sua mensagem...';
      this.input.style.cssText = `
        flex: 1;
        padding: 10px 14px;
        border: 1px solid var(--nexos-border, #e5e7eb);
        border-radius: 20px;
        font-size: 13px;
        outline: none;
        transition: border-color 0.2s;
        background: var(--nexos-bg-primary, #ffffff);
        color: var(--nexos-text-primary, #1f2937);
      `;

      this.input.addEventListener('focus', () => {
        this.input.style.borderColor = '#667eea';
      });

      this.input.addEventListener('blur', () => {
        this.input.style.borderColor = 'var(--nexos-border, #e5e7eb)';
      });

      this.input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && this.input.value.trim()) {
          this.sendMessage(this.input.value.trim());
        }
      });

      const sendBtn = document.createElement('button');
      sendBtn.innerHTML = '📤';
      sendBtn.style.cssText = `
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border: none;
        color: white;
        font-size: 18px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.2s;
        flex-shrink: 0;
      `;

      sendBtn.addEventListener('mouseenter', () => {
        sendBtn.style.transform = 'scale(1.1)';
      });

      sendBtn.addEventListener('mouseleave', () => {
        sendBtn.style.transform = 'scale(1)';
      });

      sendBtn.addEventListener('click', () => {
        if (this.input.value.trim()) {
          this.sendMessage(this.input.value.trim());
        }
      });

      inputArea.appendChild(this.input);
      inputArea.appendChild(sendBtn);

      this.chatWindow.appendChild(header);
      this.chatWindow.appendChild(this.messagesContainer);
      this.chatWindow.appendChild(inputArea);

      // Adicionar ao container (aside do overlay), não ao body
      this.container.appendChild(this.chatWindow);

      console.log('[AI Assistant] ✅ Painel adicionado ao aside do overlay');

      // Mensagem de boas-vindas variada
      const welcomeMessages = [
        'Oi! 👋 Tudo bem? Sou o Nexos, seu assistente pra gestão de lojas! Me pergunta qualquer coisa sobre as lojas ou digita "ajuda" pra ver o que eu sei fazer! 😊',
        'E aí! 🙌 Beleza? Aqui é o Nexos! Precisa de informações sobre alguma loja? É só me falar! Ou digita "ajuda" pra eu te mostrar o que eu consigo fazer!',
        'Olá! ✨ Como vai? Me chamo Nexos e estou aqui pra te ajudar com as lojas! Quer consultar, adicionar ou remover alguma? É só pedir! Digite "ajuda" pra saber mais!',
        'Opa! 💼 Tudo certo? Sou o assistente de lojas do Nexos! Me pergunta sobre qualquer loja ou digita "ajuda" pra eu te mostrar minhas funções!'
      ];
      const randomWelcome = welcomeMessages[Math.floor(Math.random() * welcomeMessages.length)];
      this.addMessage('assistant', randomWelcome);
    }

    /**
     * Adiciona mensagem ao chat
     */
    addMessage(sender, text) {
      const message = document.createElement('div');
      message.style.cssText = `
        display: flex;
        gap: 10px;
        animation: messageSlideIn 0.3s ease-out;
        ${sender === 'user' ? 'flex-direction: row-reverse; margin-left: 30px;' : 'margin-right: 30px;'}
      `;

      const avatar = document.createElement('div');
      avatar.style.cssText = `
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        flex-shrink: 0;
        overflow: hidden;
        ${sender === 'user' 
          ? 'background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: 2px solid #667eea;' 
          : 'background: var(--nexos-bg-elevated, #f3f4f6);'}
      `;
      
      // Se for usuário, tentar carregar foto
      if (sender === 'user') {
        const user = window.NexosAuth?.getCurrentUser?.();
        if (user?.photo) {
          const img = document.createElement('img');
          img.src = user.photo;
          img.style.cssText = 'width: 100%; height: 100%; object-fit: cover;';
          img.onerror = () => {
            // Fallback para emoji se foto não carregar
            avatar.textContent = '👤';
          };
          avatar.appendChild(img);
        } else {
          avatar.textContent = '👤';
        }
      } else {
        avatar.textContent = '🤖';
      }

      const bubble = document.createElement('div');
      bubble.style.cssText = `
        padding: 10px 14px;
        border-radius: 14px;
        font-size: 13px;
        line-height: 1.4;
        white-space: pre-wrap;
        word-wrap: break-word;
        overflow-wrap: break-word;
        max-width: 100%;
        ${sender === 'user'
          ? 'background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;'
          : 'background: var(--nexos-bg-primary, #ffffff); color: var(--nexos-text-primary, #1f2937); border: 1px solid var(--nexos-border, #e5e7eb);'}
      `;
      
      // Renderizar Markdown simples (negrito, listas, etc)
      bubble.innerHTML = this.renderMarkdown(text);

      message.appendChild(avatar);
      message.appendChild(bubble);

      this.messagesContainer.appendChild(message);
      this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;

      // Salva no histórico
      this.messages.push({ sender, text, timestamp: Date.now() });
      this.saveHistory();
    }

    /**
     * Renderiza Markdown simples para HTML
     */
    renderMarkdown(text) {
      if (!text) return '';
      
      // Escapar HTML perigoso
      let html = text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
      
      // [Links](url) - DEVE VIR ANTES de negrito/itálico para evitar conflitos
      html = html.replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" style="color: #667eea; text-decoration: underline; cursor: pointer;">$1</a>');
      
      // **Negrito**
      html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
      
      // *Itálico*
      html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
      
      // `Código inline`
      html = html.replace(/`(.+?)`/g, '<code style="background: var(--nexos-bg-elevated, #f3f4f6); padding: 2px 6px; border-radius: 4px; font-family: monospace; font-size: 13px;">$1</code>');
      
      // Quebras de linha
      html = html.replace(/\n/g, '<br>');
      
      // Listas com bullets • ou -
      html = html.replace(/^[•\-]\s+(.+)$/gm, '<div style="margin-left: 16px;">• $1</div>');
      
      return html;
    }

    /**
     * Adiciona mensagem com HTML e botões (para ajuda e menus interativos)
     */
    addRichMessage(sender, htmlContent) {
      const message = document.createElement('div');
      message.style.cssText = `
        display: flex;
        gap: 10px;
        animation: messageSlideIn 0.3s ease-out;
        ${sender === 'user' ? 'flex-direction: row-reverse; margin-left: 30px;' : 'margin-right: 30px;'}
      `;

      const avatar = document.createElement('div');
      avatar.style.cssText = `
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        flex-shrink: 0;
        overflow: hidden;
        background: var(--nexos-bg-elevated, #f3f4f6);
      `;
      avatar.textContent = '🤖';

      const bubble = document.createElement('div');
      bubble.style.cssText = `
        padding: 14px;
        border-radius: 14px;
        font-size: 13px;
        line-height: 1.4;
        background: var(--nexos-bg-primary, #ffffff);
        color: var(--nexos-text-primary, #1f2937);
        border: 1px solid var(--nexos-border, #e5e7eb);
        max-width: 100%;
        word-wrap: break-word;
        overflow-wrap: break-word;
      `;
      bubble.innerHTML = htmlContent;

      message.appendChild(avatar);
      message.appendChild(bubble);

      this.messagesContainer.appendChild(message);
      this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    }

    /**
     * Envia mensagem
     */
    async sendMessage(text) {
      // Adiciona mensagem do usuário
      this.addMessage('user', text);
      this.input.value = '';

      // Mostra indicador de digitação
      const typingIndicator = this.showTypingIndicator();

      try {
        // Simula delay de resposta (aqui você integraria com sua API de IA)
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Remove indicador
        typingIndicator.remove();

        // Resposta da IA (por enquanto simulada)
        const response = await this.getAIResponse(text);
        this.addMessage('assistant', response);

      } catch (error) {
        typingIndicator.remove();
        this.addMessage('assistant', 'Desculpe, ocorreu um erro. Tente novamente.');
        console.error('[AI Assistant] Erro:', error);
      }
    }

    /**
     * Mostra indicador de digitação
     */
    showTypingIndicator() {
      const indicator = document.createElement('div');
      indicator.style.cssText = `
        display: flex;
        gap: 12px;
        margin-right: 40px;
      `;

      const avatar = document.createElement('div');
      avatar.style.cssText = `
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: var(--nexos-bg-elevated, #f3f4f6);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        flex-shrink: 0;
      `;
      avatar.textContent = '🤖';

      const bubble = document.createElement('div');
      bubble.style.cssText = `
        padding: 12px 16px;
        border-radius: 16px;
        background: var(--nexos-bg-primary, #ffffff);
        border: 1px solid var(--nexos-border, #e5e7eb);
      `;
      bubble.innerHTML = `
        <div style="display: flex; gap: 4px;">
          <span style="animation: typingDot 1.4s infinite;">●</span>
          <span style="animation: typingDot 1.4s infinite 0.2s;">●</span>
          <span style="animation: typingDot 1.4s infinite 0.4s;">●</span>
        </div>
      `;

      indicator.appendChild(avatar);
      indicator.appendChild(bubble);

      this.messagesContainer.appendChild(indicator);
      this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;

      return indicator;
    }

    /**
     * Obtém resposta da IA (conversação natural)
     * Agora usa Ollama (LLM local) quando disponível para conversação inteligente
     */
    async getAIResponse(userMessage) {
      const message = userMessage.toLowerCase().trim();

      // ══════════════════════════════════════════════════════════════════════
      // SISTEMA DE BUSCA INTELIGENTE (PRIORIDADE MÁXIMA - INSTANTÂNEO)
      // ══════════════════════════════════════════════════════════════════════
      
      if (this.storesData?.details) {
        const intelligentResponse = await this.intelligentStoreSearch(userMessage, message);
        if (intelligentResponse) {
          return intelligentResponse;
        }
      }

      // ══════════════════════════════════════════════════════════════════════
      // SMARTSEARCH (BUSCA INTELIGENTE INSTANTÂNEA)
      // ══════════════════════════════════════════════════════════════════════
      
      console.log('[AI Assistant] 🔍 Tentando SmartSearch...');
      const smartResponse = await this.trySmartSearch(userMessage);
      if (smartResponse) {
        console.log('[AI Assistant] ✅ Usando resposta do SmartSearch');
        return smartResponse;
      }

      // ══════════════════════════════════════════════════════════════════════
      // FALLBACK: REGRAS SIMPLES
      // ══════════════════════════════════════════════════════════════════════

      console.log('[AI Assistant] 💡 SmartSearch não retornou resposta, usando regras simples');

      // ══════════════════════════════════════════════════════════════════════
      // SAUDAÇÕES E CONVERSAS NATURAIS
      // ══════════════════════════════════════════════════════════════════════

      if (message.match(/^(oi|olá|ola|hey|e aí|eai|opa|salve)/i)) {
        const greetings = [
          'Oi! 👋 Tudo bem? Sou o assistente do Nexos. No que posso te ajudar hoje?',
          'E aí! 😊 Beleza? Pode me chamar pra qualquer coisa relacionada às lojas!',
          'Olá! Como vai? Estou aqui pra te ajudar com informações das lojas. Só perguntar!',
          'Opa! 🙌 Tudo certo? Precisa de alguma informação sobre as lojas?'
        ];
        return greetings[Math.floor(Math.random() * greetings.length)];
      }

      if (message.match(/tudo bem|como (vai|está|esta)|beleza/i)) {
        return 'Tô ótimo, obrigado por perguntar! 😄 E você, como tá? Precisa de alguma ajuda com as lojas?';
      }

      if (message.match(/obrigad[oa]|valeu|vlw|thanks/i)) {
        const thanks = [
          'Por nada! 😊 Qualquer coisa é só chamar!',
          'Disponha! Se precisar de mais alguma coisa, tô por aqui! 👍',
          'Sempre às ordens! 🤝'
        ];
        return thanks[Math.floor(Math.random() * thanks.length)];
      }

      if (message.match(/tchau|até logo|até|flw|falou/i)) {
        return 'Até logo! 👋 Qualquer coisa é só me chamar de novo!';
      }

      // ══════════════════════════════════════════════════════════════════════
      // CONVERSAÇÃO SOBRE LOJAS (NATURAL)
      // ══════════════════════════════════════════════════════════════════════

      // Quantas lojas / Total de lojas (conversação natural)
      if (message.match(/quantas? lojas?|total de lojas?|tem quantas? lojas?|número de lojas?/i)) {
        if (!this.storesData || !this.storesData.stores || this.storesData.stores.length <= 1) {
          return '⚠️ **Ops! Os dados das lojas não carregaram**\n\n' +
                 'Isso pode acontecer quando a extensão não consegue acessar o arquivo `stores.json`.\n\n' +
                 '**Possíveis soluções:**\n' +
                 '1. Recarregue a página (F5)\n' +
                 '2. Recarregue a extensão em `chrome://extensions`\n' +
                 '3. Verifique se o arquivo `stores.json` está na raiz da extensão\n\n' +
                 'Se o erro persistir, me chama que eu ajudo! 😊';
        }
        const count = this.storesData.stores.length - 1;
        return `Atualmente temos **${count} lojas** cadastradas! 📊\n\n` +
               `Quer saber sobre alguma loja específica? É só me falar o número dela!`;
      }

      // Buscar loja (conversação natural)
      const searchPatterns = [
        /(?:qual|quero|me fala|mostra|procur(?:o|ar?)|buscar?|ver|consultar?) (?:a |da )?loja (\d+)/i,
        /loja (\d+)/i,
        /^(\d{1,4})$/  // Apenas números
      ];

      for (const pattern of searchPatterns) {
        const searchMatch = message.match(pattern);
        if (searchMatch) {
          const storeNumber = searchMatch[1].padStart(4, '0');
          if (!this.storesData || !this.storesData.stores || this.storesData.stores.length <= 1) {
            return '⚠️ **Dados não disponíveis**\n\n' +
                   'Não consegui carregar a lista de lojas. Tenta:\n' +
                   '• Recarregar a página (F5)\n' +
                   '• Recarregar a extensão\n\n' +
                   'Qualquer coisa me chama! 🙋‍♂️';
          }
          
          // Verifica se loja existe
          if (!this.storesData.stores.includes(storeNumber)) {
            return `Hmm, não encontrei a loja **${storeNumber}** aqui no cadastro... 🤔\n\n` +
                   `Talvez você queira adicionar ela? Ou conferir se digitou o número certinho?`;
          }
          
          // NOVO: Buscar detalhes completos
          const details = this.storesData.details ? this.storesData.details[storeNumber] : null;
          
          if (!details) {
            // Fallback: Se não tem detalhes, mostra mensagem simples
            return `Achei! A loja **${storeNumber}** está ativa no nosso cadastro. ✅\n\n` +
                   `Por enquanto só tenho o número dela. Execute \`python extract_stores.py\` para atualizar os dados completos!`;
          }
          
          // Formatar resposta com todos os detalhes
          let response = `**🏪 Loja ${details.codigo} - ${details.nome}**\n\n`;
          
          // Status e Bandeira
          const statusEmoji = details.status === 'ATIVA' ? '✅' : '⚠️';
          response += `${statusEmoji} **Status:** ${details.status}\n`;
          response += `🏷️ **Bandeira:** ${details.bandeira}\n\n`;
          
          // Endereço
          if (details.endereco && details.endereco.logradouro) {
            response += `📍 **Endereço:**\n`;
            response += `${details.endereco.logradouro}, ${details.endereco.numero}\n`;
            response += `${details.endereco.bairro} - ${details.endereco.cidade}/${details.endereco.uf}\n`;
            response += `CEP: ${details.endereco.cep}\n\n`;
          }
          
          // Coordenadas (com link Google Maps)
          if (details.coordenadas && details.coordenadas.google_maps) {
            response += `🗺️ **Localização:** [Ver no Google Maps](${details.coordenadas.google_maps})\n\n`;
          }
          
          // Organização
          if (details.hub) {
            response += `📦 **Hub:** ${details.hub}\n`;
          }
          
          // Operação
          if (details.sistema_operante || details.tipo_entrega) {
            response += `⚙️ **Sistema:** ${details.sistema_operante || 'N/A'}\n`;
            response += `🚚 **Tipo de Entrega:** ${details.tipo_entrega || 'N/A'}\n\n`;
          }
          
          // Contatos
          if (details.contatos && (details.contatos.email_responsavel || details.contatos.consultor_operacional)) {
            response += `👥 **Contatos:**\n`;
            if (details.contatos.consultor_operacional && details.contatos.consultor_operacional !== 'None') {
              response += `• Consultor Operacional: ${details.contatos.consultor_operacional}\n`;
            }
            if (details.contatos.consultor_transporte && details.contatos.consultor_transporte !== 'None') {
              response += `• Consultor Transporte: ${details.contatos.consultor_transporte}\n`;
            }
            if (details.contatos.email_responsavel && details.contatos.email_responsavel !== '-') {
              response += `• Email: ${details.contatos.email_responsavel}\n`;
            }
            response += '\n';
          }
          
          // CNPJ
          if (details.cnpj) {
            response += `🏢 **CNPJ:** ${details.cnpj}\n`;
          }
          
          return response + '\nPrecisa de mais alguma informação? É só perguntar! 😊';
        }
      }

      // Adicionar loja (conversação natural)
      const addPatterns = [
        /(?:adicionar?|cadastrar?|criar|registrar|incluir) (?:a |uma )?loja (\d+)/i,
        /(?:loja )?(\d+) (?:não|nao) (?:tá|ta|está|esta) (?:cadastrada|aqui)/i,
        /(?:quero|preciso) (?:adicionar?|cadastrar?) (?:a |uma )?loja (\d+)/i
      ];

      for (const pattern of addPatterns) {
        const addMatch = message.match(pattern);
        if (addMatch) {
          const storeNumber = addMatch[1].padStart(4, '0');
          if (!this.storesData || !this.storesData.stores || this.storesData.stores.length <= 1) {
            return '⚠️ **Não posso adicionar lojas agora**\n\n' +
                   'Os dados não carregaram. Tenta recarregar a página ou a extensão! �';
          }

          if (this.storesData.stores.includes(storeNumber)) {
            return `Opa, a loja **${storeNumber}** já tá cadastrada aqui! ⚠️\n\n` +
                   `Quer consultar os dados dela?`;
          }

          this.storesData.stores.push(storeNumber);
          this.storesData.stores.sort();
          await this.saveStoresData();
          
          const count = this.storesData.stores.length - 1;
          return `Pronto! Loja **${storeNumber}** cadastrada com sucesso! 🎉\n\n` +
                 `Agora temos ${count} lojas no total.`;
        }
      }

      // Remover loja (conversação natural)
      const removePatterns = [
        /(?:remover?|excluir|deletar|apagar|tirar) (?:a )?loja (\d+)/i,
        /loja (\d+) (?:não|nao) (?:existe|funciona) mais/i
      ];

      for (const pattern of removePatterns) {
        const removeMatch = message.match(pattern);
        if (removeMatch) {
          const storeNumber = removeMatch[1].padStart(4, '0');
          if (!this.storesData || !this.storesData.stores || this.storesData.stores.length <= 1) {
            return '⚠️ **Não posso remover lojas agora**\n\n' +
                   'Os dados não carregaram. Recarrega a página ou a extensão! 🔄';
          }

          const index = this.storesData.stores.indexOf(storeNumber);
          if (index === -1) {
            return `Hmm, a loja **${storeNumber}** não tá no cadastro... 🤔\n\n` +
                   `Tem certeza do número?`;
          }

          this.storesData.stores.splice(index, 1);
          await this.saveStoresData();
          
          const count = this.storesData.stores.length - 1;
          return `Loja **${storeNumber}** removida! ✅\n\n` +
                 `Agora temos ${count} lojas cadastradas.`;
        }
      }

      // ══════════════════════════════════════════════════════════════════════
      // AJUDA E DÚVIDAS
      // ══════════════════════════════════════════════════════════════════════

      if (message.match(/ajuda|help|o que (?:você|voce) faz|como funciona|não sei|nao sei|comandos/i)) {
        // Usar addRichMessage para criar ajuda visual com botões
        setTimeout(() => {
          this.addRichMessage('assistant', `
            <div style="display: flex; flex-direction: column; gap: 16px;">
              <div style="text-align: center; padding-bottom: 12px; border-bottom: 2px solid var(--nexos-border, #e5e7eb);">
                <div style="font-size: 24px; margin-bottom: 8px;">🤖✨</div>
                <div style="font-size: 16px; font-weight: 600; color: var(--nexos-primary, #667eea);">
                  Comandos Disponíveis
                </div>
              </div>

              <!-- CONSULTAS -->
              <div style="background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%); padding: 12px; border-radius: 12px; border-left: 4px solid #667eea;">
                <div style="font-weight: 600; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                  <span style="font-size: 18px;">🔍</span>
                  <span>Consultas</span>
                </div>
                <div style="display: flex; flex-direction: column; gap: 6px; font-size: 13px; color: var(--nexos-text-secondary, #6b7280);">
                  <button onclick="document.querySelector('#nexos-ai-input').value='Quantas lojas temos?'; document.querySelector('#nexos-ai-input').focus();" 
                          style="text-align: left; padding: 8px 12px; background: white; border: 1px solid #e5e7eb; border-radius: 8px; cursor: pointer; transition: all 0.2s;"
                          onmouseover="this.style.background='#f9fafb'; this.style.borderColor='#667eea';"
                          onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb';">
                    💬 "Quantas lojas temos?"
                  </button>
                  <button onclick="document.querySelector('#nexos-ai-input').value='Qual loja 0001'; document.querySelector('#nexos-ai-input').focus();" 
                          style="text-align: left; padding: 8px 12px; background: white; border: 1px solid #e5e7eb; border-radius: 8px; cursor: pointer; transition: all 0.2s;"
                          onmouseover="this.style.background='#f9fafb'; this.style.borderColor='#667eea';"
                          onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb';">
                    💬 "Qual loja 0001"
                  </button>
                  <button onclick="document.querySelector('#nexos-ai-input').value='0123'; document.querySelector('#nexos-ai-input').focus();" 
                          style="text-align: left; padding: 8px 12px; background: white; border: 1px solid #e5e7eb; border-radius: 8px; cursor: pointer; transition: all 0.2s;"
                          onmouseover="this.style.background='#f9fafb'; this.style.borderColor='#667eea';"
                          onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb';">
                    💬 Apenas o número: "0123"
                  </button>
                </div>
              </div>

              <!-- CADASTRO -->
              <div style="background: linear-gradient(135deg, #10b98115 0%, #059669 15 100%); padding: 12px; border-radius: 12px; border-left: 4px solid #10b981;">
                <div style="font-weight: 600; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                  <span style="font-size: 18px;">➕</span>
                  <span>Cadastro</span>
                </div>
                <div style="display: flex; flex-direction: column; gap: 6px; font-size: 13px;">
                  <button onclick="document.querySelector('#nexos-ai-input').value='Adicionar loja 9999'; document.querySelector('#nexos-ai-input').focus();" 
                          style="text-align: left; padding: 8px 12px; background: white; border: 1px solid #e5e7eb; border-radius: 8px; cursor: pointer; transition: all 0.2s;"
                          onmouseover="this.style.background='#f9fafb'; this.style.borderColor='#10b981';"
                          onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb';">
                    💬 "Adicionar loja 9999"
                  </button>
                  <button onclick="document.querySelector('#nexos-ai-input').value='Cadastrar loja 1234'; document.querySelector('#nexos-ai-input').focus();" 
                          style="text-align: left; padding: 8px 12px; background: white; border: 1px solid #e5e7eb; border-radius: 8px; cursor: pointer; transition: all 0.2s;"
                          onmouseover="this.style.background='#f9fafb'; this.style.borderColor='#10b981';"
                          onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb';">
                    💬 "Cadastrar loja 1234"
                  </button>
                </div>
              </div>

              <!-- REMOÇÃO -->
              <div style="background: linear-gradient(135deg, #ef444415 0%, #dc262615 100%); padding: 12px; border-radius: 12px; border-left: 4px solid #ef4444;">
                <div style="font-weight: 600; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                  <span style="font-size: 18px;">🗑️</span>
                  <span>Remoção</span>
                </div>
                <div style="display: flex; flex-direction: column; gap: 6px; font-size: 13px;">
                  <button onclick="document.querySelector('#nexos-ai-input').value='Remover loja 5555'; document.querySelector('#nexos-ai-input').focus();" 
                          style="text-align: left; padding: 8px 12px; background: white; border: 1px solid #e5e7eb; border-radius: 8px; cursor: pointer; transition: all 0.2s;"
                          onmouseover="this.style.background='#f9fafb'; this.style.borderColor='#ef4444';"
                          onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb';">
                    💬 "Remover loja 5555"
                  </button>
                  <button onclick="document.querySelector('#nexos-ai-input').value='Loja 0999 não funciona mais'; document.querySelector('#nexos-ai-input').focus();" 
                          style="text-align: left; padding: 8px 12px; background: white; border: 1px solid #e5e7eb; border-radius: 8px; cursor: pointer; transition: all 0.2s;"
                          onmouseover="this.style.background='#f9fafb'; this.style.borderColor='#ef4444';"
                          onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb';">
                    💬 "Loja 0999 não funciona mais"
                  </button>
                </div>
              </div>

              <!-- DICA FINAL -->
              <div style="text-align: center; padding: 12px; background: var(--nexos-bg-elevated, #f3f4f6); border-radius: 8px; font-size: 13px; color: var(--nexos-text-secondary, #6b7280);">
                💡 <strong>Dica:</strong> Converse naturalmente! Não precisa decorar comandos exatos. 😊
              </div>
            </div>
          `);
        }, 500);
        
        return 'Aqui está tudo que eu sei fazer! Clique nos botões para experimentar! 👇';
      }

      if (message.match(/quem (?:é|e) (?:você|voce)|seu nome/i)) {
        return 'Sou o assistente IA do Nexos! 🤖\n\n' +
               'Tô aqui pra te ajudar com informações sobre as lojas. ' +
               'Pode me chamar de Nexos mesmo! 😊';
      }

      // ══════════════════════════════════════════════════════════════════════
      // RESPOSTAS CONTEXTUAIS
      // ══════════════════════════════════════════════════════════════════════

      // Se menciona "loja" mas não captou nada
      if (message.includes('loja')) {
        return 'Vi que você mencionou "loja"... 🤔\n\n' +
               'Você quer consultar, adicionar ou remover alguma loja? ' +
               'Me fala o número dela que eu te ajudo!';
      }

      // Resposta padrão natural
      const defaultResponses = [
        'Hmm, não entendi muito bem... 🤔 Pode reformular? Ou digita "ajuda" que eu te mostro o que posso fazer!',
        'Essa eu não peguei direito... 😅 Tenta perguntar de outro jeito? Ou dá uma olhada na "ajuda"!',
        'Opa, não tô sabendo como responder isso ainda... Mas posso te ajudar com informações das lojas! Quer saber sobre alguma?'
      ];
      
      return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
    }

    /**
     * Tenta obter resposta usando SmartSearch (busca instantânea < 100ms)
     * Retorna null se SmartSearch não estiver disponível ou não souber responder
     */
    async trySmartSearch(userMessage) {
      try {
        if (!this.smartSearch) {
          console.warn('[AI Assistant] ⚠️ SmartSearch não inicializado');
          return null;
        }
        
        // Buscar resposta (< 100ms)
        const resultado = this.smartSearch.search(userMessage);
        
        if (!resultado || resultado.confianca === 0) {
          console.log('[AI Assistant] 💡 SmartSearch não encontrou resposta relevante');
          return null;
        }
        
        // Se delegou para sistema de lojas, retornar null para usar sistema existente
        if (resultado.delegarPara === 'sistema_lojas') {
          console.log('[AI Assistant] 🏪 Delegando para sistema de lojas');
          return null;
        }
        
        console.log('[AI Assistant] ✅ SmartSearch respondeu (confiança: ' + Math.round(resultado.confianca * 100) + '%)');
        return resultado.resposta;
        
      } catch (error) {
        console.warn('[AI Assistant] ⚠️ SmartSearch error:', error.message);
        return null;
      }
    }

    /**
     * Salva alterações no stores.json
     */
    async saveStoresData() {
      try {
        // Envia mensagem para background script salvar
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
          chrome.runtime.sendMessage({
            type: 'SAVE_STORES_DATA',
            data: this.storesData
          }, (response) => {
            if (response && response.success) {
              console.log('[AI Assistant] ✅ Dados de lojas salvos');
            } else {
              console.error('[AI Assistant] ❌ Erro ao salvar dados:', response?.error);
            }
          });
        } else {
          console.warn('[AI Assistant] ⚠️ chrome.runtime não disponível, não foi possível salvar');
        }
      } catch (error) {
        console.error('[AI Assistant] ❌ Erro ao salvar stores.json:', error);
      }
    }

    /**
     * Carrega histórico do localStorage
     */
    loadHistory() {
      try {
        const saved = localStorage.getItem('nexos-ai-history');
        if (saved) {
          this.messages = JSON.parse(saved);
          // Renderiza mensagens antigas (exceto a de boas-vindas)
          this.messages.slice(1).forEach(msg => {
            this.addMessage(msg.sender, msg.text);
          });
        }
      } catch (error) {
        console.warn('[AI Assistant] Erro ao carregar histórico:', error);
      }
    }

    /**
     * 🧠 BUSCA INTELIGENTE DE LOJAS
     * Detecta intenções complexas e retorna dados instantaneamente
     */
    async intelligentStoreSearch(userMessage, messageLower) {
      // 🔥 VALIDAÇÃO: Garantir que details existe
      if (!this.storesData || !this.storesData.details) {
        console.error('[AI Assistant] ❌ Dados de lojas não carregados ou sem detalhes!');
        return '⚠️ **Dados de lojas não disponíveis**\n\nPor favor, recarregue a extensão ou tente novamente em alguns instantes.';
      }
      
      const details = this.storesData.details;
      console.log('[AI Assistant] 🔍 Buscando em', Object.keys(details).length, 'lojas com detalhes');
      
      // ═══════════════════════════════════════════════════════════════════
      // 1. CONSULTA DIRETA POR NÚMERO (ex: "2409", "me mostra a 1201")
      // ═══════════════════════════════════════════════════════════════════
      const numberMatch = messageLower.match(/\b(\d{3,4})\b/);
      if (numberMatch) {
        const storeNumber = numberMatch[1];
        const store = details[storeNumber];
        
        if (store) {
          this.lastMentionedStore = storeNumber; // Salvar contexto
          return this.formatStoreDetails(store, storeNumber);
        } else {
          return `⚠️ **Loja ${storeNumber} não encontrada**\n\nTente:\n- Verificar se o código está correto\n- Listar todas: "quantas lojas temos?"\n- Buscar por cidade: "lojas em São Paulo"`;
        }
      }
      
      // ═══════════════════════════════════════════════════════════════════
      // 2. CONTEXTO: "me traz os detalhes", "qual o endereço dela?"
      // ═══════════════════════════════════════════════════════════════════
      if (this.lastMentionedStore && 
          messageLower.match(/(detalh|endereço|info|dado|mostra|traz|qual)/)) {
        const store = details[this.lastMentionedStore];
        if (store) {
          return this.formatStoreDetails(store, this.lastMentionedStore);
        }
      }
      
      // ═══════════════════════════════════════════════════════════════════
      // 3. BUSCA POR ENDEREÇO (ex: "qual loja na AV BRIGADEIRO?")
      // ═══════════════════════════════════════════════════════════════════
      const addressMatch = messageLower.match(/(?:endere[çc]o|rua|av(?:enida)?|alameda)\s+(.+)/);
      if (addressMatch || messageLower.includes('endereço')) {
        const searchTerm = (addressMatch?.[1] || messageLower)
          .replace(/qual|loja|do|da|de|em|na|no/gi, '')
          .trim()
          .toUpperCase();
        
        const found = Object.entries(details).find(([code, d]) => 
          d.endereco?.logradouro?.toUpperCase().includes(searchTerm)
        );
        
        if (found) {
          const [code, store] = found;
          this.lastMentionedStore = code;
          return this.formatStoreDetails(store, code);
        }
      }
      
      // ═══════════════════════════════════════════════════════════════════
      // 4. BUSCA POR CIDADE (ex: "quantas lojas em SP?", "lojas de Sorocaba")
      // ═══════════════════════════════════════════════════════════════════
      const cityMatch = messageLower.match(/(?:em|de|cidade)\s+([a-záàâãéèêíïóôõöúçñ\s]+)/);
      if (cityMatch || messageLower.match(/quantas?\s+loja/)) {
        let city = cityMatch?.[1]?.trim();
        
        // Mapeamento de apelidos
        const cityMap = {
          'sp': 'SAO PAULO',
          'são paulo': 'SAO PAULO',
          'sampa': 'SAO PAULO',
          'rio': 'RIO DE JANEIRO',
          'bh': 'BELO HORIZONTE'
        };
        
        if (city && cityMap[city.toLowerCase()]) {
          city = cityMap[city.toLowerCase()];
        }
        
        if (city) {
          const found = Object.entries(details).filter(([, d]) => 
            d.endereco?.cidade?.toUpperCase().includes(city.toUpperCase())
          );
          
          if (found.length > 0) {
            let response = `**🏙️ ${city.toUpperCase()}**: ${found.length} loja(s) encontrada(s)\n\n`;
            
            found.slice(0, 10).forEach(([code, d]) => {
              response += `📍 **Loja ${code}**: ${d.nome}\n`;
              response += `   ${d.endereco?.bairro} - ${d.bandeira}\n\n`;
            });
            
            if (found.length > 10) {
              response += `_...e mais ${found.length - 10} lojas_`;
            }
            
            return response.trim();
          }
        }
      }
      
      // ═══════════════════════════════════════════════════════════════════
      // 5. BUSCA POR BANDEIRA (ex: "quantas lojas Pão de Açúcar?")
      // ═══════════════════════════════════════════════════════════════════
      const bandeiraMatch = messageLower.match(/(?:bandeira|rede)\s+(.+)|pão\s*de\s*açúcar|minuto\s*pa|extra/i);
      if (bandeiraMatch) {
        let bandeira = (bandeiraMatch[1] || bandeiraMatch[0]).trim().toUpperCase();
        
        // Normalizar apelidos
        if (bandeira.includes('PÃO') || bandeira.includes('AÇÚCAR')) {
          bandeira = 'PÃO DE AÇÚCAR';
        } else if (bandeira.includes('MINUTO')) {
          bandeira = 'MINUTO PA';
        }
        
        const found = Object.entries(details).filter(([, d]) => 
          d.bandeira?.toUpperCase().includes(bandeira)
        );
        
        if (found.length > 0) {
          let response = `**🏪 ${bandeira}**: ${found.length} loja(s)\n\n`;
          
          found.slice(0, 10).forEach(([code, d]) => {
            response += `📍 **Loja ${code}**: ${d.nome} (${d.endereco?.cidade})\n`;
          });
          
          if (found.length > 10) {
            response += `\n_...e mais ${found.length - 10} lojas_`;
          }
          
          return response.trim();
        }
      }
      
      // ═══════════════════════════════════════════════════════════════════
      // 6. ESTATÍSTICAS (ex: "quantas lojas ativas?", "total de lojas")
      // ═══════════════════════════════════════════════════════════════════
      if (messageLower.match(/quant|total|numero|ativa|inativa/)) {
        const allStores = Object.entries(details);
        const active = allStores.filter(([, d]) => d.status?.toUpperCase() === 'ATIVA');
        const inactive = allStores.filter(([, d]) => d.status?.toUpperCase() !== 'ATIVA');
        
        let response = `**📊 Estatísticas das Lojas**\n\n`;
        response += `✅ **Ativas**: ${active.length}\n`;
        response += `❌ **Inativas**: ${inactive.length}\n`;
        response += `📌 **Total**: ${allStores.length}\n\n`;
        
        // Breakdown por bandeira
        const byBandeira = {};
        allStores.forEach(([, d]) => {
          const b = d.bandeira || 'Sem bandeira';
          byBandeira[b] = (byBandeira[b] || 0) + 1;
        });
        
        response += `**Por Bandeira:**\n`;
        Object.entries(byBandeira)
          .sort((a, b) => b[1] - a[1])
          .forEach(([bandeira, count]) => {
            response += `🏪 ${bandeira}: ${count}\n`;
          });
        
        return response.trim();
      }
      
      return null; // Nenhuma busca inteligente aplicável
    }

    /**
     * Formata detalhes completos de uma loja
     */
    formatStoreDetails(store, code) {
      let response = `**📋 ${store.nome}** (Loja ${code})\n\n`;
      
      if (store.endereco) {
        const e = store.endereco;
        response += `**📍 Endereço:**\n`;
        response += `${e.logradouro}, ${e.numero || 'S/N'}\n`;
        response += `${e.bairro} - ${e.cidade}/${e.uf}\n`;
        response += `CEP: ${e.cep}\n`;
        
        // 🔥 LINK PARA GOOGLE MAPS
        if (store.coordenadas?.lat && store.coordenadas?.lng) {
          const mapsUrl = `https://www.google.com/maps?q=${store.coordenadas.lat},${store.coordenadas.lng}`;
          response += `[🗺️ Ver no Google Maps](${mapsUrl})\n`;
        } else {
          const address = `${e.logradouro} ${e.numero} ${e.cidade} ${e.uf}`.replace(/\s+/g, '+');
          const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${address}`;
          response += `[🗺️ Ver no Google Maps](${mapsUrl})\n`;
        }
        response += '\n';
      }
      
      if (store.contatos) {
        response += `**👥 Contatos:**\n`;
        if (store.contatos.consultor_operacional) {
          response += `Consultor: ${store.contatos.consultor_operacional}\n`;
        }
        if (store.contatos.gerente_geral) {
          response += `Gerente: ${store.contatos.gerente_geral}\n`;
        }
        response += '\n';
      }
      
      if (store.status) {
        const statusEmoji = store.status.toUpperCase() === 'ATIVA' ? '✅' : '❌';
        response += `**${statusEmoji} Status:** ${store.status}\n`;
      }
      
      if (store.bandeira) {
        response += `**🏪 Bandeira:** ${store.bandeira}\n`;
      }
      
      console.log('[AI Assistant] ⚡ Resposta instantânea gerada');
      return response.trim();
    }

    /**
     * Salva histórico no localStorage
     */
    saveHistory() {
      try {
        // Mantém apenas as últimas 50 mensagens
        const recent = this.messages.slice(-50);
        localStorage.setItem('nexos-ai-history', JSON.stringify(recent));
      } catch (error) {
        console.warn('[AI Assistant] Erro ao salvar histórico:', error);
      }
    }

    /**
     * Foca no input do chat
     */
    focus() {
      if (this.input) {
        this.input.focus();
      }
    }

    /**
     * Anexa focus trap ao chat (se necessário)
     * Nota: Como o painel está dentro do overlay, o focus trap do overlay já cuida disso
     */
    attachFocusTrap() {
      // Focus trap é gerenciado pelo overlay principal
      console.log('[AI Assistant] Focus trap gerenciado pelo overlay principal');
    }

  } // Fim da classe NexosAIAssistant

  /* ═══════════════════════════════════════════════════════════════════════════
     ANIMAÇÕES CSS
     ══════════════════════════════════════════════════════════════════════════ */

  const style = document.createElement('style');
  style.textContent = `
    @keyframes messageSlideIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes chatWindowSlideIn {
      from {
        opacity: 0;
        transform: translateY(20px) scale(0.95);
      }
      to {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
    }

    @keyframes chatWindowSlideOut {
      from {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
      to {
        opacity: 0;
        transform: translateY(20px) scale(0.95);
      }
    }

    @keyframes typingDot {
      0%, 100% { opacity: 0.3; }
      50% { opacity: 1; }
    }

    /* Scrollbar customizada */
    .nexos-ai-messages::-webkit-scrollbar {
      width: 6px;
    }

    .nexos-ai-messages::-webkit-scrollbar-track {
      background: transparent;
    }

    .nexos-ai-messages::-webkit-scrollbar-thumb {
      background: #cbd5e0;
      border-radius: 3px;
    }

    .nexos-ai-messages::-webkit-scrollbar-thumb:hover {
      background: #a0aec0;
    }
  `;
  document.head.appendChild(style);

  /* ═══════════════════════════════════════════════════════════════════════════
     INICIALIZAÇÃO GLOBAL
     ══════════════════════════════════════════════════════════════════════════ */

  // Expor classe globalmente para ser instanciada pelo overlay Picking
  window.NexosAIAssistant = NexosAIAssistant;
  
  console.log('[AI Assistant] 🚀 Classe exposta globalmente - aguardando inicialização pelo overlay');

})();
