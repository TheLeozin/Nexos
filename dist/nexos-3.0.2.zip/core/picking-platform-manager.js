/**
 * ════════════════════════════════════════════════════════════════════════════
 * PICKING PLATFORM MANAGER - Adaptadores Unificados de Plataformas
 * ════════════════════════════════════════════════════════════════════════════
 * 
 * Responsável por:
 * - API unificada para Uber, Lalamove, 99
 * - Envio sem estar na plataforma
 * - Validação de dados
 * - Mapeamento de veículos
 * - Tratamento de erros
 */

class PickingPlatformManager {
  constructor(stateManager, queueManager) {
    this.stateManager = stateManager;
    this.queueManager = queueManager;
    
    // Configuração de veículos por plataforma
    this.vehicleConfig = {
      'uber': {
        name: 'Uber Direct',
        vehicles: [
          { id: 'moto', name: 'Moto', icon: '🏍️', maxWeight: 10 },
          { id: 'carro', name: 'Carro', icon: '🚗', maxWeight: 50 }
        ],
        color: '#000000',
        requiredFields: ['origem', 'destino', 'nome_cliente', 'telefone_cliente']
      },
      'lalamove': {
        name: 'Lalamove',
        vehicles: [
          { id: 'motorcycle', name: 'Moto', icon: '🏍️', maxWeight: 20 },
          { id: 'sedan', name: 'Sedan', icon: '🚗', maxWeight: 50 },
          { id: 'suv_mpv', name: 'SUV/MPV', icon: '🚙', maxWeight: 100 },
          { id: 'van', name: 'Van', icon: '🚐', maxWeight: 500 }
        ],
        color: '#ff6700',
        requiredFields: ['origem', 'destino', 'nome_cliente', 'telefone_cliente']
      },
      '99': {
        name: '99 Entrega',
        vehicles: [
          { id: 'moto', name: 'Moto', icon: '🏍️', maxWeight: 10 },
          { id: 'carro', name: 'Carro', icon: '🚗', maxWeight: 40 }
        ],
        color: '#fccc0a',
        requiredFields: ['origem', 'destino', 'nome_cliente', 'telefone_cliente']
      }
    };
    
    // Platform Manager inicializado silenciosamente
  }
  
  /**
   * Obter plataformas disponíveis
   */
  getAvailablePlatforms() {
    return Object.keys(this.vehicleConfig).map(key => ({
      id: key,
      ...this.vehicleConfig[key]
    }));
  }
  
  /**
   * Obter veículos de uma plataforma
   */
  getVehicles(platform) {
    const config = this.vehicleConfig[platform];
    return config ? config.vehicles : [];
  }
  
  /**
   * Validar dados do pedido antes de enviar
   * Nota: campos como 'origem' e 'destino' são construídos internamente pelo _buildAutoFillData,
   * então a validação aqui deve ser mais flexível.
   */
  validateOrder(order, platform) {
    const config = this.vehicleConfig[platform];
    
    if (!config) {
      return {
        valid: false,
        errors: [`Plataforma ${platform} não suportada`]
      };
    }
    
    // Validação mínima: apenas pedido e loja
    const errors = [];
    if (!order.pedido && !order.pedido_id) {
      errors.push('Número do pedido não encontrado');
    }
    if (!order.loja) {
      errors.push('Loja não identificada');
    }
    
    return {
      valid: errors.length === 0,
      errors
    };
  }
  
  /**
   * Enviar pedido para plataforma
   */
  async sendOrder(orderData) {
    const {
      loja,
      pedidoId,
      platform,
      vehicle,
      order
    } = orderData;
    
    console.log(`[PickingPlatform] 📤 Enviando ${pedidoId} para ${platform}...`);
    
    // Validar
    const validation = this.validateOrder(order, platform);
    
    if (!validation.valid) {
      throw new Error(`Validação falhou: ${validation.errors.join(', ')}`);
    }
    
    // Chamar adaptador específico
    let result;
    
    switch (platform) {
      case 'uber':
        result = await this.sendToUber(order, vehicle);
        break;
        
      case 'lalamove':
        result = await this.sendToLalamove(order, vehicle);
        break;
        
      case '99':
        result = await this.sendTo99(order, vehicle);
        break;
        
      default:
        throw new Error(`Plataforma ${platform} não implementada`);
    }
    
    console.log(`[PickingPlatform] ✅ Enviado com sucesso:`, result);
    
    return result;
  }
  
  /**
   * Mapear campos do pedido para o formato esperado pelas funções de auto-fill (content.js)
   */
  _buildAutoFillData(order, vehicle) {
    const nomeCompleto = (
      order.nome_cliente || order.nomeCliente || order.cliente ||
      order.data?.nome_cliente || order.data?.nomeCliente || ''
    ).trim();
    const nomeParts   = nomeCompleto.split(/\s+/);
    const primeiroNome = nomeParts[0] || '';
    const sobrenome    = nomeParts.slice(1).join(' ') || '';

    const endereco = order.endereco_completo ||
      order.enderecoCompleto ||
      order.data?.enderecoCompleto ||
      order.data?.endereco_completo ||
      [
        order.logradouro || order.endereco_logradouro || order.data?.endereco,
        order.numero     || order.numero_logradouro   || order.data?.numero
      ].filter(Boolean).join(', ') ||
      order.endereco || '';

    // Telefone: tentar todas as variantes possíveis (snake_case, camelCase, data.*)
    const telefone =
      order.celular_cliente    || order.telefone_cliente ||
      order.celularCliente     || order.telefoneCliente  ||
      order.telefone           ||
      order.data?.celular_cliente  || order.data?.telefone_cliente ||
      order.data?.celularCliente   || order.data?.telefoneCliente  ||
      order.data?.telefone         || '';

    return {
      // Identificação
      numero_loja:    order.loja || order.numero_loja || '',
      numero_pedido:  order.pedido || order.numero_pedido || '',
      loja:           order.loja || '',
      pedido:         order.pedido || '',
      // Cliente
      nome_cliente:   nomeCompleto,
      primeiro_nome:  primeiroNome,
      sobrenome,
      celular_cliente:  telefone,
      telefone_cliente: telefone,
      // Endereço
      endereco_completo: endereco,
      endereco,
      complemento: order.complemento || order.endereco_complemento || order.data?.complemento || order.data?.endereco_complemento || '',
      cep:    order.cep || order.data?.cep || '',
      bairro: order.bairro || order.data?.bairro || '',
      cidade: order.cidade || order.data?.cidade || '',
      // Valor
      valor_pedido: order.valor_pedido || order.valor || order.valorPedido || order.data?.valorPedido || order.data?.valor || '',
      valor:        order.valor || order.valor_pedido || order.valorPedido || order.data?.valorPedido || order.data?.valor || '',
      // Observações
      observacoes: order.observacoes || order.obs || '',
      // Link de rastreio
      link_rastreio: order.link_rastreio || order.trackingLink || '',
      // Modalidade
      modalidade: order.modalidade || order.data?.modalidade || '',
      // Volumetria (itens do pedido)
      volumetria: order.volumetria || order.data?.volumetria || order.data?.volume || [],
      // Veículo preferido (consumido pelo content.js na plataforma)
      __nexos_preferred_vehicle: vehicle,
      preferred_vehicle: vehicle,
      vehicle
    };
  }

  /**
   * Fallback: persiste o payload de auto-fill diretamente no chrome.storage.local
   * (usado quando as funções queueAutoFillFor* do content.js ainda não estão disponíveis)
   */
  _persistPlatformPayload(platform, data, vehicle) {
    const key = '__nexos_auto_fill_next_platform';
    const payload = {
      platform,
      data,
      mode: 'entrega',
      queuedAt: Date.now(),
      attempts: 0,
      vehicle,
      awaitingManualStart: false,
      redirectExpected: true,
      redirectContext: {
        requireReferer: false,
        createdAt: Date.now(),
        maxAgeMs: 600000   // 10 min
      }
    };
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ [key]: payload });
        console.log(`[PickingPlatform] 💾 Payload ${platform} persistido via chrome.storage.local`);
      } else {
        localStorage.setItem(key, JSON.stringify(payload));
        console.log(`[PickingPlatform] 💾 Payload ${platform} persistido via localStorage (fallback)`);
      }
    } catch (e) {
      console.warn('[PickingPlatform] ⚠️ Falha ao persistir payload:', e);
    }
  }

  /**
   * Abre uma nova aba para a plataforma e a adiciona ao grupo "Nexos Torre".
   * 
   * Fluxo:
   * 1. Cria a aba via chrome.tabs.create (não ativa imediatamente para evitar flicker)
   * 2. Busca se já existe um grupo "Nexos Torre" na janela atual
   * 3. Se existe: adiciona a nova aba ao grupo existente
   * 4. Se não existe: cria um grupo novo com título "Nexos Torre" e cor azul
   * 5. Ativa a aba após agrupá-la
   * 
   * Fallback: window.open se chrome.tabs não estiver disponível.
   */
  async _openPlatformTab(url, platform) {
    // chrome.tabs.group NÃO está disponível em content scripts (MV3).
    // Delegamos ao background.js via sendMessage para criar a aba e o grupo.
    if (typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) {
      try {
        const response = await new Promise((resolve) => {
          chrome.runtime.sendMessage(
            { action: 'openTabInNexosGroup', url },
            (res) => resolve(res || {})
          );
        });
        if (response.ok) return response.tabId || true;
        console.warn('[PickingPlatform] background retornou erro ao abrir aba:', response.error);
      } catch (e) {
        console.warn('[PickingPlatform] sendMessage falhou, usando window.open:', e);
      }
    }

    // Fallback
    try {
      window.open(url, '_blank');
      return true;
    } catch (e) {
      console.error('[PickingPlatform] ❌ Não foi possível abrir aba para', platform, e);
      return false;
    }
  }

  /**
   * Adaptador Uber Direct
   * ─────────────────────
   * 1. Mapeia os campos do pedido para o formato do content.js
   * 2. Enfileira o auto-fill via queueAutoFillForUber (chrome.storage.local)
   * 3. Abre nova aba diretamente no formulário de nova entrega
   * 4. O content.js na aba detecta o payload e preenche automaticamente.
   *    Se o usuário não estiver autenticado, Uber redireciona para o login;
   *    ao concluir a autenticação, o content.js detecta o payload novamente
   *    e navega de volta para o formulário.
   */
  async sendToUber(order, vehicle) {
    console.log('[PickingPlatform] � Preparando envio para Uber Direct...');

    const data = this._buildAutoFillData(order, vehicle);

    // Enfileirar auto-fill — queueAutoFillForUber já está disponível no contexto
    // do content.js (injected na página de Picking Admin)
    if (typeof window.queueAutoFillForUber === 'function') {
      window.queueAutoFillForUber(data, 'envio', {
        vehicle,
        redirectExpected: true,
        requireReferer: false,     // nova aba não tem referrer
        awaitingManualStart: false // preencher automaticamente sem prompt
      });
      console.log('[PickingPlatform] ✅ Payload Uber enfileirado via queueAutoFillForUber');
    } else {
      // Fallback: persiste diretamente — content.js lerá ao carregar na aba
      this._persistPlatformPayload('uber', data, vehicle);
    }

    // Abrir formulário de nova entrega da Uber
    const uberUrl = 'https://direct.uber.com/accounts/740e6e18-263c-4f1a-8ee6-a8a706696e89/new-delivery?';
    const uberTabId = await this._openPlatformTab(uberUrl, 'Uber Direct');

    return {
      success: true,
      platform: 'uber',
      vehicle,
      awaitingFill: true,
      tabId: typeof uberTabId === 'number' ? uberTabId : null,
      message: 'Nova aba aberta. O preenchimento será automático — faça login se solicitado.'
    };
  }

  /**
   * Adaptador Lalamove
   * ⚠️ Preenchimento automático desabilitado — abrir aba sem autofill.
   */
  async sendToLalamove(order, vehicle) {
    console.log('[PickingPlatform] 🟠 Lalamove: abrindo aba (sem preenchimento automático)...');

    // 🚫 Autofill desabilitado para Lalamove — apenas abre a aba
    const lalamoveUrl = 'https://web.lalamove.com/';
    await this._openPlatformTab(lalamoveUrl, 'Lalamove');

    return {
      success: true,
      platform: 'lalamove',
      vehicle,
      awaitingFill: false,
      message: 'Aba Lalamove aberta. Preencha manualmente — preenchimento automático disponível apenas para Uber.'
    };
  }

  /**
   * Adaptador 99 Entrega
   * ⚠️ Preenchimento automático desabilitado — abrir aba sem autofill.
   */
  async sendTo99(order, vehicle) {
    console.log('[PickingPlatform] 🟡 99 Entrega: abrindo aba (sem preenchimento automático)...');

    // 🚫 Autofill desabilitado para 99 — apenas abre a aba
    const url99 = 'https://entrega.99app.com/newDeliver';
    await this._openPlatformTab(url99, '99 Entrega');

    return {
      success: true,
      platform: '99',
      vehicle,
      awaitingFill: false,
      message: 'Aba 99 aberta. Preencha manualmente — preenchimento automático disponível apenas para Uber.'
    };
  }
  
  /**
   * Calcular valor estimado
   */
  calculateEstimatedValue(order, platform, vehicle) {
    // Valor base por plataforma e veículo
    const baseValues = {
      'uber': { 'moto': 15, 'carro': 25 },
      'lalamove': { 'motorcycle': 12, 'sedan': 22, 'suv_mpv': 35, 'van': 50 },
      '99': { 'moto': 14, 'carro': 24 }
    };
    
    const base = baseValues[platform]?.[vehicle] || 20;
    
    // Adicionar variação aleatória (±20%)
    const variation = base * 0.2;
    const value = base + (Math.random() * variation * 2 - variation);
    
    return value.toFixed(2);
  }
  
  /**
   * Simular delay de rede
   */
  async simulateNetworkDelay(minMs, maxMs) {
    const delay = minMs + Math.random() * (maxMs - minMs);
    return new Promise(resolve => setTimeout(resolve, delay));
  }
  
  /**
   * Criar modal de seleção de plataforma
   */
  async showPlatformSelectionModal(order) {
    return new Promise((resolve) => {
      if (typeof window.NexosUI === 'undefined') {
        // Fallback: usar plataforma padrão
        resolve({ platform: 'uber', vehicle: 'moto' });
        return;
      }
      
      // Container do modal
      const bodyHtml = `
        <div style="display: flex; flex-direction: column; gap: 16px;">
          <!-- Plataformas -->
          <div>
            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--nexos-text-primary);">
              Plataforma
            </label>
            <div id="platform-options" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px;">
              ${this.renderPlatformOptions()}
            </div>
          </div>
          
          <!-- Veículos (será preenchido dinamicamente) -->
          <div id="vehicle-container" style="display: none;">
            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--nexos-text-primary);">
              Tipo de Veículo
            </label>
            <div id="vehicle-options" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px;">
            </div>
          </div>
          
          <!-- Resumo -->
          <div id="summary-container" style="display: none; padding: 12px; background: var(--nexos-bg-secondary); border-radius: 6px; font-size: 13px;">
            <div style="color: var(--nexos-text-secondary); margin-bottom: 4px;">Resumo:</div>
            <div id="summary-text" style="color: var(--nexos-text-primary);"></div>
          </div>
        </div>
      `;
      
      let selectedPlatform = null;
      let selectedVehicle = null;
      
      const confirmBtn = window.NexosUI.createButton({
        text: 'Enviar Pedido',
        variant: 'primary',
        disabled: true,
        onClick: () => {
          modal.backdrop.remove();
          resolve({ platform: selectedPlatform, vehicle: selectedVehicle });
        }
      });
      
      const cancelBtn = window.NexosUI.createButton({
        text: 'Cancelar',
        variant: 'ghost',
        onClick: () => {
          modal.backdrop.remove();
          resolve(null);
        }
      });
      
      const modal = window.NexosUI.createModal({
        title: '🚀 Selecionar Plataforma de Envio',
        body: bodyHtml,
        footer: [cancelBtn, confirmBtn],
        size: 'md'
      });
      
      // Após renderizar, adicionar event listeners
      setTimeout(() => {
        const platformButtons = document.querySelectorAll('[data-platform]');
        
        platformButtons.forEach(btn => {
          if (btn.disabled) return; // ignorar plataformas desabilitadas
          btn.addEventListener('click', () => {
            // Desmarcar todos
            platformButtons.forEach(b => b.classList.remove('selected'));
            
            // Marcar selecionado
            btn.classList.add('selected');
            
            selectedPlatform = btn.dataset.platform;
            selectedVehicle = null;
            
            // Mostrar veículos
            this.updateVehicleOptions(selectedPlatform);
            
            // Desabilitar botão confirmar
            confirmBtn.disabled = true;
            
            // Esconder resumo
            const summaryEl = document.getElementById('summary-container');
            if (summaryEl) summaryEl.style.display = 'none';
          });
        });
      }, 100);
      
      // ESC cancela
      const handleEsc = (e) => {
        if (e.key === 'Escape') {
          modal.backdrop.remove();
          document.removeEventListener('keydown', handleEsc);
          resolve(null);
        }
      };
      document.addEventListener('keydown', handleEsc);
      
      // Helper para atualizar veículos
      this.updateVehicleOptions = (platform) => {
        const container = document.getElementById('vehicle-container');
        const optionsDiv = document.getElementById('vehicle-options');
        
        // ✅ CORREÇÃO: Verificar se elemento existe ANTES de usar
        if (!container) {
          // Silencioso: o modal pode ter sido fechado antes da atualização
          return;
        }
        
        if (!optionsDiv) {
          console.error('[PlatformManager] ❌ Elemento #vehicle-options não encontrado');
          return;
        }
        
        const vehicles = this.getVehicles(platform);
        
        optionsDiv.innerHTML = vehicles.map(v => `
          <button 
            class="nexos-vehicle-option"
            data-vehicle="${v.id}"
            style="
              padding: 12px;
              border: 2px solid var(--nexos-border-light);
              border-radius: 8px;
              background: var(--nexos-bg-secondary);
              cursor: pointer;
              transition: all 0.2s;
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 4px;
            "
          >
            <span style="font-size: 24px;">${v.icon}</span>
            <span style="font-size: 13px; font-weight: 600; color: var(--nexos-text-primary);">${v.name}</span>
            <span style="font-size: 11px; color: var(--nexos-text-secondary);">até ${v.maxWeight}kg</span>
          </button>
        `).join('');
        
        container.style.display = 'block';
        
        // Event listeners nos veículos
        const vehicleButtons = optionsDiv.querySelectorAll('[data-vehicle]');
        
        vehicleButtons.forEach(btn => {
          btn.addEventListener('click', () => {
            // Desmarcar todos
            vehicleButtons.forEach(b => b.classList.remove('selected'));
            
            // Marcar selecionado
            btn.classList.add('selected');
            btn.style.borderColor = 'var(--nexos-primary)';
            btn.style.background = 'var(--nexos-primary-light)';
            
            selectedVehicle = btn.dataset.vehicle;
            
            // Habilitar botão confirmar
            confirmBtn.disabled = false;
            
            // Mostrar resumo
            const platformConfig = this.vehicleConfig[selectedPlatform];
            const vehicleConfig = vehicles.find(v => v.id === selectedVehicle);
            
            const clienteNome = order.nome_cliente || order.nomeCliente || order.cliente
              || order.data?.nome_cliente || order.data?.nomeCliente || order.customer_name || 'N/A';
            document.getElementById('summary-container').style.display = 'block';
            document.getElementById('summary-text').innerHTML = `
              <strong>${platformConfig.name}</strong> • ${vehicleConfig.name} ${vehicleConfig.icon}<br>
              <span style="color: var(--nexos-text-secondary); font-size: 12px;">
                Pedido: ${order.pedido || order.pedido_id || 'N/A'} • Cliente: ${clienteNome}
              </span>
            `;
          });
          
          // Hover effect
          btn.addEventListener('mouseenter', () => {
            if (!btn.classList.contains('selected')) {
              btn.style.borderColor = 'var(--nexos-primary)';
            }
          });
          
          btn.addEventListener('mouseleave', () => {
            if (!btn.classList.contains('selected')) {
              btn.style.borderColor = 'var(--nexos-border-light)';
            }
          });
        });
      };
    });
  }
  
  /**
   * Renderizar opções de plataforma
   */
  renderPlatformOptions() {
    // ⚠️ Preenchimento automático disponível apenas para Uber.
    // Lalamove e 99 são exibidas como desabilitadas.
    const uberOnly = ['uber'];
    return Object.entries(this.vehicleConfig).map(([key, config]) => {
      const isDisabled = !uberOnly.includes(key);
      const disabledStyles = isDisabled ? `
        opacity: 0.45;
        cursor: not-allowed;
        filter: grayscale(60%);
        position: relative;
      ` : '';
      const disabledAttr = isDisabled ? 'disabled title="Preenchimento automático disponível apenas para Uber"' : '';
      const disabledTag = isDisabled ? `
        <span style="
          position: absolute;
          bottom: 6px;
          left: 50%;
          transform: translateX(-50%);
          font-size: 9px;
          background: #FEF3C7;
          color: #92400E;
          border: 1px solid #FDE68A;
          border-radius: 4px;
          padding: 1px 5px;
          white-space: nowrap;
        ">Em breve</span>` : '';
      return `
        <button
          class="nexos-platform-option"
          data-platform="${key}"
          ${disabledAttr}
          style="
            padding: 16px 12px;
            border: 2px solid var(--nexos-border-light);
            border-radius: 8px;
            background: var(--nexos-bg-secondary);
            ${isDisabled ? 'cursor: not-allowed;' : 'cursor: pointer;'}
            transition: all 0.2s;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            ${disabledStyles}
          "
        >
          <div style="
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: ${config.color};
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 18px;
          ">
            ${config.name[0]}
          </div>
          <span style="font-size: 13px; font-weight: 600; color: var(--nexos-text-primary);">
            ${config.name}
          </span>
          ${disabledTag}
        </button>
      `;
    }).join('');
  }
}

// Exportar
window.PickingPlatformManager = PickingPlatformManager;

console.log('[PickingPlatform] 🔌 Módulo carregado');
