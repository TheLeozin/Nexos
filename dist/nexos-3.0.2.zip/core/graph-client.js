/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - MICROSOFT GRAPH API CLIENT
 * Cliente completo para comunicação com SharePoint via Graph API
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Funcionalidades:
 * - Comunicação com SharePoint Lists e Document Libraries
 * - Retry automático com exponential backoff
 * - Cache inteligente com IndexedDB
 * - Throttling e rate limiting
 * - Fallback offline
 * - Sincronização em lote (batch requests)
 * - Delta queries para sincronização incremental
 */

class GraphClient {
  constructor(tokenManager, config = {}) {
    this.tokenManager = tokenManager;
    this.baseUrl = config.baseUrl || 'https://graph.microsoft.com/v1.0';
    this.siteId = config.siteId || null;
    this.retryConfig = {
      maxRetries: config.maxRetries || 3,
      initialDelay: config.initialDelay || 1000,
      maxDelay: config.maxDelay || 30000,
      backoffMultiplier: config.backoffMultiplier || 2
    };
    
    this.cache = new GraphCache();
    this.rateLimiter = new RateLimiter();
    this.offlineQueue = new OfflineQueue();
    
    this.log('info', '🚀 GraphClient inicializado', { baseUrl: this.baseUrl });
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // LOGGING
  // ═══════════════════════════════════════════════════════════════════════════
  
  log(level, message, data = {}) {
    const prefix = '[GraphClient]';
    const color = {
      debug: '#888',
      info: '#00C2FF',
      warn: '#FFA502',
      error: '#FF4757',
      success: '#2ED573'
    }[level] || '#FFF';
    
    console.log(`%c${prefix} ${message}`, `color: ${color}`, data);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // REQUISIÇÕES BASE
  // ═══════════════════════════════════════════════════════════════════════════
  
  async request(endpoint, options = {}) {
    const method = options.method || 'GET';
    const cacheKey = `${method}:${endpoint}`;
    
    // Verificar cache primeiro (apenas para GET)
    if (method === 'GET' && options.cache !== false) {
      const cached = await this.cache.get(cacheKey);
      if (cached && !this.cache.isExpired(cached)) {
        this.log('debug', `✅ Cache hit: ${endpoint}`);
        return cached.data;
      }
    }
    
    // Rate limiting
    await this.rateLimiter.waitIfNeeded();
    
    try {
      const response = await this._requestWithRetry(endpoint, options);
      
      // Salvar em cache (apenas GET)
      if (method === 'GET' && response) {
        await this.cache.set(cacheKey, response, options.cacheTTL || 300000); // 5min default
      }
      
      return response;
      
    } catch (error) {
      // Se offline, adicionar à fila
      if (this.isNetworkError(error) && method !== 'GET') {
        this.log('warn', '⚠️ Offline detectado, adicionando à fila', { endpoint, method });
        await this.offlineQueue.add({ endpoint, options, timestamp: Date.now() });
        throw new OfflineError('Operação adicionada à fila offline');
      }
      
      throw error;
    }
  }
  
  async _requestWithRetry(endpoint, options, attempt = 1) {
    try {
      return await this._makeRequest(endpoint, options);
      
    } catch (error) {
      if (attempt >= this.retryConfig.maxRetries) {
        this.log('error', `❌ Falha após ${attempt} tentativas`, { endpoint, error: error.message });
        throw error;
      }
      
      // Calcular delay com exponential backoff
      const delay = Math.min(
        this.retryConfig.initialDelay * Math.pow(this.retryConfig.backoffMultiplier, attempt - 1),
        this.retryConfig.maxDelay
      );
      
      // Adicionar jitter (variação aleatória)
      const jitter = Math.random() * 0.3 * delay;
      const totalDelay = delay + jitter;
      
      this.log('warn', `⏳ Retry ${attempt}/${this.retryConfig.maxRetries} em ${Math.round(totalDelay)}ms`, {
        endpoint,
        error: error.message,
        status: error.status
      });
      
      // Se recebeu 429 (rate limit), usar o Retry-After header
      if (error.status === 429 && error.retryAfter) {
        await this.sleep(error.retryAfter * 1000);
      } else {
        await this.sleep(totalDelay);
      }
      
      return this._requestWithRetry(endpoint, options, attempt + 1);
    }
  }
  
  async _makeRequest(endpoint, options = {}) {
    const token = await this.tokenManager.getAccessToken();
    
    if (!token) {
      throw new AuthenticationError('Token de acesso não disponível');
    }
    
    const url = endpoint.startsWith('http') ? endpoint : `${this.baseUrl}${endpoint}`;
    
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      ...options.headers
    };
    
    const fetchOptions = {
      method: options.method || 'GET',
      headers,
      ...options.fetchOptions
    };
    
    if (options.body) {
      fetchOptions.body = typeof options.body === 'string' 
        ? options.body 
        : JSON.stringify(options.body);
    }
    
    this.log('debug', `📡 ${fetchOptions.method} ${url}`);
    
    const response = await fetch(url, fetchOptions);
    
    // Rate limiting tracking
    this.rateLimiter.trackResponse(response);
    
    if (!response.ok) {
      await this._handleErrorResponse(response);
    }
    
    // Se resposta vazia (204 No Content), retornar null
    if (response.status === 204) {
      return null;
    }
    
    const data = await response.json();
    
    this.log('success', `✅ ${fetchOptions.method} ${url}`, {
      status: response.status,
      hasData: !!data
    });
    
    return data;
  }
  
  async _handleErrorResponse(response) {
    let errorData = null;
    
    try {
      errorData = await response.json();
    } catch (e) {
      // Resposta não é JSON
    }
    
    const error = new GraphError(
      errorData?.error?.message || `Request failed with status ${response.status}`,
      response.status,
      errorData
    );
    
    // Se 429, extrair Retry-After
    if (response.status === 429) {
      error.retryAfter = parseInt(response.headers.get('Retry-After') || '60', 10);
    }
    
    this.log('error', `❌ Erro na requisição: ${error.message}`, {
      status: response.status,
      errorData
    });
    
    throw error;
  }
  
  isNetworkError(error) {
    return (
      error.message.includes('Failed to fetch') ||
      error.message.includes('NetworkError') ||
      error.message.includes('network') ||
      !navigator.onLine
    );
  }
  
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // SHAREPOINT SITES
  // ═══════════════════════════════════════════════════════════════════════════
  
  async getSiteByUrl(siteUrl) {
    this.log('info', `🏢 Buscando site: ${siteUrl}`);
    
    try {
      // Extrair hostname e path do siteUrl
      const url = new URL(siteUrl);
      const hostname = url.hostname;
      const sitePath = url.pathname;
      
      const endpoint = `/sites/${hostname}:${sitePath}`;
      const site = await this.request(endpoint);
      
      // Armazenar siteId para uso futuro
      this.siteId = site.id;
      
      this.log('success', `✅ Site encontrado: ${site.displayName}`, { siteId: site.id });
      
      return site;
      
    } catch (error) {
      this.log('error', `❌ Erro ao buscar site: ${error.message}`);
      throw error;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // SHAREPOINT LISTS
  // ═══════════════════════════════════════════════════════════════════════════
  
  async getList(listName) {
    this._ensureSiteId();
    
    this.log('debug', `📋 Buscando lista: ${listName}`);
    
    const endpoint = `/sites/${this.siteId}/lists/${listName}`;
    return await this.request(endpoint);
  }
  
  async getListItems(listName, options = {}) {
    this._ensureSiteId();
    
    const queryParams = new URLSearchParams();
    
    if (options.select) {
      queryParams.append('$select', Array.isArray(options.select) 
        ? options.select.join(',') 
        : options.select
      );
    }
    
    if (options.filter) {
      queryParams.append('$filter', options.filter);
    }
    
    if (options.orderBy) {
      queryParams.append('$orderby', options.orderBy);
    }
    
    if (options.top) {
      queryParams.append('$top', options.top.toString());
    }
    
    if (options.expand) {
      queryParams.append('$expand', Array.isArray(options.expand)
        ? options.expand.join(',')
        : options.expand
      );
    }
    
    const query = queryParams.toString();
    const endpoint = `/sites/${this.siteId}/lists/${listName}/items${query ? '?' + query : ''}`;
    
    this.log('debug', `📄 Buscando itens: ${listName}`, { options });
    
    const response = await this.request(endpoint, {
      cache: options.cache !== false,
      cacheTTL: options.cacheTTL
    });
    
    return response.value || [];
  }
  
  async getListItem(listName, itemId, options = {}) {
    this._ensureSiteId();
    
    const queryParams = new URLSearchParams();
    
    if (options.select) {
      queryParams.append('$select', Array.isArray(options.select)
        ? options.select.join(',')
        : options.select
      );
    }
    
    if (options.expand) {
      queryParams.append('$expand', Array.isArray(options.expand)
        ? options.expand.join(',')
        : options.expand
      );
    }
    
    const query = queryParams.toString();
    const endpoint = `/sites/${this.siteId}/lists/${listName}/items/${itemId}${query ? '?' + query : ''}`;
    
    return await this.request(endpoint);
  }
  
  async createListItem(listName, fields) {
    this._ensureSiteId();
    
    this.log('info', `➕ Criando item em: ${listName}`);
    
    const endpoint = `/sites/${this.siteId}/lists/${listName}/items`;
    
    const body = {
      fields
    };
    
    const result = await this.request(endpoint, {
      method: 'POST',
      body
    });
    
    // Invalidar cache da lista
    await this.cache.invalidate(`GET:/sites/${this.siteId}/lists/${listName}/items`);
    
    this.log('success', `✅ Item criado: ${result.id}`);
    
    return result;
  }
  
  async updateListItem(listName, itemId, fields, etag = null) {
    this._ensureSiteId();
    
    this.log('info', `✏️ Atualizando item ${itemId} em: ${listName}`);
    
    const endpoint = `/sites/${this.siteId}/lists/${listName}/items/${itemId}/fields`;
    
    const headers = {};
    
    // Se ETag fornecido, usar para controle de concorrência
    if (etag) {
      headers['If-Match'] = etag;
    }
    
    const result = await this.request(endpoint, {
      method: 'PATCH',
      body: fields,
      headers
    });
    
    // Invalidar cache
    await this.cache.invalidate(`GET:/sites/${this.siteId}/lists/${listName}/items/${itemId}`);
    await this.cache.invalidate(`GET:/sites/${this.siteId}/lists/${listName}/items`);
    
    this.log('success', `✅ Item atualizado: ${itemId}`);
    
    return result;
  }
  
  async deleteListItem(listName, itemId) {
    this._ensureSiteId();
    
    this.log('info', `🗑️ Deletando item ${itemId} de: ${listName}`);
    
    const endpoint = `/sites/${this.siteId}/lists/${listName}/items/${itemId}`;
    
    await this.request(endpoint, {
      method: 'DELETE'
    });
    
    // Invalidar cache
    await this.cache.invalidate(`GET:/sites/${this.siteId}/lists/${listName}/items/${itemId}`);
    await this.cache.invalidate(`GET:/sites/${this.siteId}/lists/${listName}/items`);
    
    this.log('success', `✅ Item deletado: ${itemId}`);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // BATCH REQUESTS (Múltiplas operações em uma requisição)
  // ═══════════════════════════════════════════════════════════════════════════
  
  async batch(requests) {
    this.log('info', `📦 Executando batch com ${requests.length} requisições`);
    
    const endpoint = '/$batch';
    
    const batchBody = {
      requests: requests.map((req, index) => ({
        id: req.id || `request-${index}`,
        method: req.method || 'GET',
        url: req.url.startsWith('/') ? req.url : `/${req.url}`,
        headers: req.headers || {},
        body: req.body || undefined
      }))
    };
    
    const response = await this.request(endpoint, {
      method: 'POST',
      body: batchBody
    });
    
    this.log('success', `✅ Batch concluído: ${response.responses.length} respostas`);
    
    return response.responses;
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // DOCUMENT LIBRARY
  // ═══════════════════════════════════════════════════════════════════════════
  
  async getDriveByName(driveName) {
    this._ensureSiteId();
    
    this.log('debug', `📁 Buscando drive: ${driveName}`);
    
    // Listar todos os drives do site
    const endpoint = `/sites/${this.siteId}/drives`;
    const response = await this.request(endpoint);
    
    const drive = response.value.find(d => d.name === driveName);
    
    if (!drive) {
      throw new Error(`Drive '${driveName}' não encontrado`);
    }
    
    this.log('success', `✅ Drive encontrado: ${drive.id}`);
    
    return drive;
  }
  
  async getFileFromLibrary(libraryName, filePath) {
    this._ensureSiteId();
    
    this.log('debug', `📄 Buscando arquivo: ${filePath} em ${libraryName}`);
    
    const drive = await this.getDriveByName(libraryName);
    const endpoint = `/drives/${drive.id}/root:${filePath}`;
    
    return await this.request(endpoint);
  }
  
  async downloadFile(libraryName, filePath) {
    this._ensureSiteId();
    
    this.log('info', `⬇️ Baixando: ${filePath}`);
    
    const fileInfo = await this.getFileFromLibrary(libraryName, filePath);
    
    if (!fileInfo['@microsoft.graph.downloadUrl']) {
      throw new Error('URL de download não disponível');
    }
    
    const response = await fetch(fileInfo['@microsoft.graph.downloadUrl']);
    
    if (!response.ok) {
      throw new Error(`Falha ao baixar arquivo: ${response.statusText}`);
    }
    
    const content = await response.text();
    
    this.log('success', `✅ Arquivo baixado: ${filePath} (${content.length} bytes)`);
    
    return content;
  }
  
  async uploadFile(libraryName, filePath, content) {
    this._ensureSiteId();
    
    this.log('info', `⬆️ Enviando: ${filePath} para ${libraryName}`);
    
    const drive = await this.getDriveByName(libraryName);
    const endpoint = `/drives/${drive.id}/root:${filePath}:/content`;
    
    const result = await this.request(endpoint, {
      method: 'PUT',
      body: content,
      headers: {
        'Content-Type': 'application/octet-stream'
      }
    });
    
    this.log('success', `✅ Arquivo enviado: ${result.name}`);
    
    return result;
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // DELTA QUERIES (Sincronização incremental)
  // ═══════════════════════════════════════════════════════════════════════════
  
  async getDelta(listName, deltaToken = null) {
    this._ensureSiteId();
    
    this.log('info', `🔄 Buscando delta: ${listName}`);
    
    let endpoint = `/sites/${this.siteId}/lists/${listName}/items/delta`;
    
    if (deltaToken) {
      endpoint += `?token=${encodeURIComponent(deltaToken)}`;
    }
    
    const response = await this.request(endpoint, {
      cache: false // Nunca cachear delta queries
    });
    
    // Extrair próximo deltaToken do @odata.deltaLink
    let nextDeltaToken = null;
    if (response['@odata.deltaLink']) {
      const deltaUrl = new URL(response['@odata.deltaLink']);
      nextDeltaToken = deltaUrl.searchParams.get('token');
    }
    
    this.log('success', `✅ Delta recebido: ${response.value.length} mudanças`);
    
    return {
      items: response.value || [],
      deltaToken: nextDeltaToken
    };
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // USER PROFILE
  // ═══════════════════════════════════════════════════════════════════════════
  
  async getUserProfile() {
    this.log('debug', '👤 Buscando perfil do usuário');
    
    const endpoint = '/me';
    const profile = await this.request(endpoint, {
      cacheTTL: 3600000 // Cache por 1 hora
    });
    
    this.log('success', `✅ Perfil: ${profile.displayName} (${profile.mail})`);
    
    return profile;
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // UTILITÁRIOS
  // ═══════════════════════════════════════════════════════════════════════════
  
  _ensureSiteId() {
    if (!this.siteId) {
      throw new Error('siteId não configurado. Chame getSiteByUrl() primeiro.');
    }
  }
  
  async processPendingOfflineQueue() {
    this.log('info', '🔄 Processando fila offline...');
    
    const pending = await this.offlineQueue.getAll();
    
    if (pending.length === 0) {
      this.log('info', '✅ Nenhuma operação pendente');
      return { processed: 0, failed: 0 };
    }
    
    this.log('info', `📋 ${pending.length} operações pendentes`);
    
    let processed = 0;
    let failed = 0;
    
    for (const operation of pending) {
      try {
        await this.request(operation.endpoint, operation.options);
        await this.offlineQueue.remove(operation.id);
        processed++;
        
        this.log('success', `✅ Operação processada: ${operation.endpoint}`);
        
      } catch (error) {
        failed++;
        this.log('error', `❌ Falha ao processar: ${operation.endpoint}`, {
          error: error.message
        });
      }
    }
    
    this.log('success', `✨ Fila processada: ${processed} sucesso, ${failed} falhas`);
    
    return { processed, failed };
  }
  
  clearCache() {
    this.log('info', '🗑️ Limpando cache...');
    return this.cache.clear();
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// CLASSES AUXILIARES
// ═══════════════════════════════════════════════════════════════════════════

class GraphCache {
  constructor() {
    this.dbName = 'NexosGraphCache';
    this.storeName = 'cache';
    this.db = null;
    this._initPromise = this._init();
  }
  
  async _init() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, 1);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };
      
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName, { keyPath: 'key' });
        }
      };
    });
  }
  
  async get(key) {
    await this._initPromise;
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.storeName], 'readonly');
      const store = transaction.objectStore(this.storeName);
      const request = store.get(key);
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  
  async set(key, data, ttl = 300000) {
    await this._initPromise;
    
    const entry = {
      key,
      data,
      timestamp: Date.now(),
      expiresAt: Date.now() + ttl
    };
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.storeName], 'readwrite');
      const store = transaction.objectStore(this.storeName);
      const request = store.put(entry);
      
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }
  
  isExpired(entry) {
    return Date.now() > entry.expiresAt;
  }
  
  async invalidate(keyPattern) {
    await this._initPromise;
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.storeName], 'readwrite');
      const store = transaction.objectStore(this.storeName);
      const request = store.openCursor();
      
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          if (cursor.value.key.includes(keyPattern)) {
            cursor.delete();
          }
          cursor.continue();
        } else {
          resolve();
        }
      };
      
      request.onerror = () => reject(request.error);
    });
  }
  
  async clear() {
    await this._initPromise;
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.storeName], 'readwrite');
      const store = transaction.objectStore(this.storeName);
      const request = store.clear();
      
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }
}

class RateLimiter {
  constructor() {
    this.requests = [];
    this.window = 60000; // 1 minuto
    this.maxRequests = 1000; // Limite conservador
  }
  
  async waitIfNeeded() {
    const now = Date.now();
    
    // Remover requisições antigas
    this.requests = this.requests.filter(timestamp => now - timestamp < this.window);
    
    if (this.requests.length >= this.maxRequests) {
      const oldestRequest = this.requests[0];
      const waitTime = this.window - (now - oldestRequest);
      
      console.log(`[RateLimiter] ⏳ Aguardando ${Math.round(waitTime / 1000)}s para respeitar rate limit`);
      
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
    
    this.requests.push(now);
  }
  
  trackResponse(response) {
    // Atualizar limites se fornecidos pelo servidor
    const remaining = response.headers.get('RateLimit-Remaining');
    const limit = response.headers.get('RateLimit-Limit');
    
    if (limit) {
      this.maxRequests = parseInt(limit, 10);
    }
  }
}

class OfflineQueue {
  constructor() {
    this.storageKey = 'nexos-offline-queue';
  }
  
  async getAll() {
    try {
      const data = localStorage.getItem(this.storageKey);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }
  
  async add(operation) {
    const queue = await this.getAll();
    
    operation.id = `op-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    queue.push(operation);
    
    localStorage.setItem(this.storageKey, JSON.stringify(queue));
    
    return operation.id;
  }
  
  async remove(operationId) {
    const queue = await this.getAll();
    const filtered = queue.filter(op => op.id !== operationId);
    
    localStorage.setItem(this.storageKey, JSON.stringify(filtered));
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// CUSTOM ERRORS
// ═══════════════════════════════════════════════════════════════════════════

class GraphError extends Error {
  constructor(message, status, details) {
    super(message);
    this.name = 'GraphError';
    this.status = status;
    this.details = details;
  }
}

class AuthenticationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'AuthenticationError';
  }
}

class OfflineError extends Error {
  constructor(message) {
    super(message);
    this.name = 'OfflineError';
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════════════════════════════════════

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    GraphClient,
    GraphError,
    AuthenticationError,
    OfflineError
  };
}

// Expor globalmente para uso em browser
if (typeof window !== 'undefined') {
  window.GraphClient = GraphClient;
}
