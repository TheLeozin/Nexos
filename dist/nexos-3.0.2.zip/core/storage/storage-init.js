/**
 * storage-init.js
 * 
 * Utilitário para inicializar StorageAdapter com configuração unificada.
 * Garante que todos os módulos usem a mesma instância e configuração.
 */

// Importar dependências
// Obter redirectUri com fallback seguro
let redirectUri;
try {
  redirectUri = (typeof chrome !== 'undefined' && chrome.identity && typeof chrome.identity.getRedirectURL === 'function')
    ? chrome.identity.getRedirectURL()
    : 'https://obodcljemkajclohcfjhmommhfpklojo.chromiumapp.org/';
} catch (err) {
  console.warn('[storage-init] Erro ao obter redirectUri, usando fallback:', err);
  redirectUri = 'https://obodcljemkajclohcfjhmommhfpklojo.chromiumapp.org/';
}

const SHAREPOINT_CONFIG = {
  auth: {
    clientId: 'obodcljemkajclohcfjhmommhfpklojo',
    authority: 'https://login.microsoftonline.com/consumers',
    redirectUri: redirectUri,
    scopes: [
      'openid',
      'profile',
      'email',
      'Files.ReadWrite.All',
      'Sites.ReadWrite.All',
      'User.Read'
    ]
  },
  sharepoint: {
    siteUrl: 'https://gpabr.sharepoint.com/sites/Nexos',
    driveType: 'documentLibrary',
    driveName: 'Documentos Compartilhados'
  }
};

// Singleton: instância única de StorageAdapter
let storageAdapterInstance = null;
let graphClientInstance = null;
let authHelperInstance = null;

/**
 * Inicializa StorageAdapter com backend híbrido (Chrome + SharePoint).
 * Reutiliza instância existente se já foi inicializada.
 * 
 * @param {Object} options - Opções de inicialização
 * @param {string} options.backend - Backend a usar ('chrome-only', 'sharepoint-only', 'hybrid')
 * @param {boolean} options.forceReInit - Força reinicialização mesmo se já existe instância
 * @returns {Promise<StorageAdapter>} Instância do StorageAdapter
 */
async function initStorageAdapter(options = {}) {
  const {
    backend = 'hybrid',
    forceReInit = false
  } = options;

  // Retornar instância existente se não forçar reinit
  if (storageAdapterInstance && !forceReInit) {
    console.log('[storage-init] Reutilizando instância existente de StorageAdapter');
    return storageAdapterInstance;
  }

  try {
    console.log('[storage-init] Inicializando StorageAdapter com backend:', backend);

    // Se backend for hybrid ou sharepoint-only, precisamos do GraphClient
    if (backend === 'hybrid' || backend === 'sharepoint-only') {
      // Inicializar AuthHelper se ainda não existe
      if (!authHelperInstance || forceReInit) {
        console.log('[storage-init] Criando AuthHelper...');
        
        // Carregar classes necessárias
        if (typeof AuthHelper === 'undefined') {
          await loadScript('/core/auth/auth-helper.js');
        }
        if (typeof TokenManager === 'undefined') {
          await loadScript('/core/auth/token-manager.js');
        }
        if (typeof OAuthClient === 'undefined') {
          await loadScript('/core/auth/oauth-client.js');
        }
        
        authHelperInstance = new AuthHelper(SHAREPOINT_CONFIG.auth);
      }

      // Inicializar GraphClient se ainda não existe
      if (!graphClientInstance || forceReInit) {
        console.log('[storage-init] Criando GraphClient...');
        
        if (typeof GraphClient === 'undefined') {
          await loadScript('/core/sharepoint/graph-client.js');
        }
        
        graphClientInstance = new GraphClient({
          siteUrl: SHAREPOINT_CONFIG.sharepoint.siteUrl,
          driveType: SHAREPOINT_CONFIG.sharepoint.driveType,
          driveName: SHAREPOINT_CONFIG.sharepoint.driveName,
          authHelper: authHelperInstance
        });
      }
    }

    // Carregar StorageAdapter se ainda não está disponível
    if (typeof StorageAdapter === 'undefined') {
      await loadScript('/core/storage/storage-adapter.js');
    }

    // Criar instância do StorageAdapter
    const config = {
      backend: backend,
      syncInterval: 60000, // 1 minuto
      maxRetries: 3
    };

    // Adicionar GraphClient e AuthHelper se backend precisar
    if (backend === 'hybrid' || backend === 'sharepoint-only') {
      config.graphClient = graphClientInstance;
      config.authHelper = authHelperInstance;
    }

    storageAdapterInstance = new StorageAdapter(config);
    
    console.log('[storage-init] ✅ StorageAdapter inicializado com sucesso');
    
    return storageAdapterInstance;
  } catch (error) {
    console.error('[storage-init] ❌ Erro ao inicializar StorageAdapter:', error);
    
    // Fallback: tentar criar com backend chrome-only
    if (backend !== 'chrome-only') {
      console.warn('[storage-init] Tentando fallback para chrome-only...');
      return initStorageAdapter({ backend: 'chrome-only', forceReInit: true });
    }
    
    throw error;
  }
}

/**
 * Retorna a instância atual de StorageAdapter sem reinicializar.
 * Lança erro se ainda não foi inicializada.
 * 
 * @returns {StorageAdapter} Instância do StorageAdapter
 * @throws {Error} Se StorageAdapter ainda não foi inicializado
 */
function getStorageAdapter() {
  if (!storageAdapterInstance) {
    throw new Error('StorageAdapter ainda não foi inicializado. Chame initStorageAdapter() primeiro.');
  }
  return storageAdapterInstance;
}

/**
 * Retorna a instância de GraphClient (se disponível).
 * 
 * @returns {GraphClient|null} Instância do GraphClient ou null
 */
function getGraphClient() {
  return graphClientInstance;
}

/**
 * Retorna a instância de AuthHelper (se disponível).
 * 
 * @returns {AuthHelper|null} Instância do AuthHelper ou null
 */
function getAuthHelper() {
  return authHelperInstance;
}

/**
 * Verifica se o usuário está autenticado no SharePoint.
 * 
 * @returns {Promise<boolean>} True se autenticado, false caso contrário
 */
async function isAuthenticated() {
  if (!authHelperInstance) {
    return false;
  }
  
  try {
    const token = await authHelperInstance.getAccessToken();
    return !!token;
  } catch (error) {
    return false;
  }
}

/**
 * Carrega um script dinamicamente.
 * 
 * @param {string} src - Caminho do script
 * @returns {Promise<void>}
 */
function loadScript(src) {
  return new Promise((resolve, reject) => {
    // Verificar se já está carregado
    const existing = document.querySelector(`script[src="${src}"]`);
    if (existing) {
      resolve();
      return;
    }

    const script = document.createElement('script');
    script.src = chrome.runtime.getURL(src);
    script.onload = () => {
      console.log(`[storage-init] Script carregado: ${src}`);
      resolve();
    };
    script.onerror = (err) => {
      console.error(`[storage-init] Erro ao carregar script: ${src}`, err);
      reject(new Error(`Falha ao carregar ${src}`));
    };
    document.head.appendChild(script);
  });
}

/**
 * Wrapper de compatibilidade com chrome.storage.local.get()
 * Mantém mesma assinatura para facilitar migração.
 * 
 * @param {string|string[]} keys - Chave(s) a buscar
 * @returns {Promise<Object>} Objeto com chaves e valores
 */
async function compatGet(keys) {
  const adapter = await ensureAdapter();
  
  // Normalizar para array
  const keyArray = Array.isArray(keys) ? keys : [keys];
  
  const result = {};
  for (const key of keyArray) {
    const value = await adapter.get(key);
    if (value !== null) {
      result[key] = value;
    }
  }
  
  return result;
}

/**
 * Wrapper de compatibilidade com chrome.storage.local.set()
 * 
 * @param {Object} items - Objeto com chaves e valores
 * @returns {Promise<void>}
 */
async function compatSet(items) {
  const adapter = await ensureAdapter();
  
  for (const [key, value] of Object.entries(items)) {
    await adapter.set(key, value);
  }
}

/**
 * Wrapper de compatibilidade com chrome.storage.local.remove()
 * 
 * @param {string|string[]} keys - Chave(s) a remover
 * @returns {Promise<void>}
 */
async function compatRemove(keys) {
  const adapter = await ensureAdapter();
  
  const keyArray = Array.isArray(keys) ? keys : [keys];
  
  for (const key of keyArray) {
    await adapter.remove(key);
  }
}

/**
 * Garante que StorageAdapter está inicializado, ou inicializa se necessário.
 * 
 * @returns {Promise<StorageAdapter>} Instância do StorageAdapter
 */
async function ensureAdapter() {
  if (!storageAdapterInstance) {
    console.log('[storage-init] Inicializando StorageAdapter automaticamente...');
    return initStorageAdapter({ backend: 'hybrid' });
  }
  return storageAdapterInstance;
}

/**
 * Reseta todas as instâncias (útil para testes).
 */
function resetInstances() {
  storageAdapterInstance = null;
  graphClientInstance = null;
  authHelperInstance = null;
  console.log('[storage-init] Instâncias resetadas');
}

// Exportar funções
if (typeof module !== 'undefined' && module.exports) {
  // Node.js/CommonJS
  module.exports = {
    initStorageAdapter,
    getStorageAdapter,
    getGraphClient,
    getAuthHelper,
    isAuthenticated,
    compatGet,
    compatSet,
    compatRemove,
    ensureAdapter,
    resetInstances,
    SHAREPOINT_CONFIG
  };
}

// Tornar disponível globalmente para content scripts
if (typeof window !== 'undefined') {
  window.NexosStorage = {
    init: initStorageAdapter,
    getAdapter: getStorageAdapter,
    getGraphClient,
    getAuthHelper,
    isAuthenticated,
    compatGet,
    compatSet,
    compatRemove,
    ensureAdapter,
    resetInstances,
    config: SHAREPOINT_CONFIG
  };
  
  console.log('[storage-init] ✅ window.NexosStorage disponível');
}
