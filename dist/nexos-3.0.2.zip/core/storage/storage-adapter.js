/**
 * Nexos Torre - Storage Adapter
 * Camada de abstração para armazenamento híbrido (Chrome Storage + SharePoint)
 * 
 * Features:
 * - Fallback automático (Chrome → SharePoint)
 * - Cache local com sync em background
 * - Conflict resolution (last-write-wins ou custom)
 * - Offline-first com queue de sync
 * 
 * @example
 * const adapter = new StorageAdapter({
 *   backend: 'hybrid',
 *   graphClient: graphClientInstance,
 *   syncInterval: 60000 // 1 min
 * });
 * 
 * await adapter.set('picking-data', data);
 * const data = await adapter.get('picking-data');
 */

class StorageAdapter {
  constructor(options = {}) {
    this.backend = options.backend || 'chrome-only'; // 'chrome-only' | 'sharepoint-only' | 'hybrid'
    this.graphClient = options.graphClient || null;
    this.authHelper = options.authHelper || null;
    this.syncInterval = options.syncInterval || 60000; // 1 min padrão
    this.syncTimer = null;
    this.syncQueue = [];
    this.conflictStrategy = options.conflictStrategy || 'last-write-wins'; // 'last-write-wins' | 'manual'
    
    // Prefixos para organização
    this.chromePrefix = options.chromePrefix || 'nexos-';
    this.sharepointFolder = options.sharepointFolder || 'Extension Data';
    
    // Cache de metadados (timestamps, hashes)
    this.metadata = new Map();
    
    console.log(`[StorageAdapter] Inicializado (backend: ${this.backend})`);
    
    // Iniciar sync automático se hybrid
    if (this.backend === 'hybrid' && this.graphClient) {
      this._startAutoSync();
    }
  }
  
  /**
   * Lê valor do storage
   * @param {string} key - Chave do dado
   * @param {Object} options - Opções de leitura
   * @returns {Promise<any>}
   */
  async get(key, options = {}) {
    const forceRemote = options.forceRemote || false;
    const useCache = options.useCache !== false; // default true
    
    try {
      // 1. Tentar chrome.storage primeiro (se não forçar remoto)
      if (!forceRemote && useCache && this._isChromeBackend()) {
        const chromeData = await this._getFromChrome(key);
        if (chromeData !== null && chromeData !== undefined) {
          console.log(`[StorageAdapter] ✅ Lido de Chrome: ${key}`);
          return chromeData;
        }
      }
      
      // 2. Fallback para SharePoint (se híbrido ou sharepoint-only)
      if (this._isSharePointBackend() && this.graphClient) {
        const sharepointData = await this._getFromSharePoint(key);
        
        // Atualizar cache local se híbrido
        if (this.backend === 'hybrid' && sharepointData !== null) {
          await this._setToChrome(key, sharepointData, { skipMetadata: true });
        }
        
        console.log(`[StorageAdapter] ✅ Lido de SharePoint: ${key}`);
        return sharepointData;
      }
      
      // 3. Não encontrado
      console.log(`[StorageAdapter] ⚠️ Chave não encontrada: ${key}`);
      return null;
      
    } catch (error) {
      console.error(`[StorageAdapter] ❌ Erro ao ler ${key}:`, error);
      
      // Último fallback: tentar localStorage (apenas em contextos que suportam)
      try {
        if (typeof localStorage !== 'undefined') {
          const localData = localStorage.getItem(this.chromePrefix + key);
          if (localData) {
            console.log(`[StorageAdapter] ✅ Fallback para localStorage: ${key}`);
            return JSON.parse(localData);
          }
        }
      } catch (e) {
        // Silenciar erro - service workers não têm localStorage
      }
      
      throw error;
    }
  }
  
  /**
   * Salva valor no storage
   * @param {string} key - Chave do dado
   * @param {any} value - Valor a salvar
   * @param {Object} options - Opções de escrita
   * @returns {Promise<void>}
   */
  async set(key, value, options = {}) {
    const syncNow = options.syncNow || false; // Sync imediato ou em background
    const skipChrome = options.skipChrome || false;
    const skipSharePoint = options.skipSharePoint || false;
    
    try {
      // Atualizar timestamp
      const timestamp = Date.now();
      this.metadata.set(key, { timestamp, hash: this._hashValue(value) });
      
      // 1. Salvar em Chrome Storage (se permitido)
      if (!skipChrome && this._isChromeBackend()) {
        await this._setToChrome(key, value, { timestamp });
        console.log(`[StorageAdapter] ✅ Salvo em Chrome: ${key}`);
      }
      
      // 2. Salvar em SharePoint (sync ou queue)
      if (!skipSharePoint && this._isSharePointBackend() && this.graphClient) {
        if (syncNow) {
          await this._setToSharePoint(key, value, { timestamp });
          console.log(`[StorageAdapter] ✅ Salvo em SharePoint (sync): ${key}`);
        } else {
          // Adicionar à fila de sync
          this._queueSync(key, value, { timestamp });
          console.log(`[StorageAdapter] 📤 Agendado para sync: ${key}`);
        }
      }
      
      // 3. Fallback localStorage (apenas em contextos que suportam)
      try {
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem(this.chromePrefix + key, JSON.stringify(value));
        }
      } catch (e) {
        // Silenciar erro - service workers não têm localStorage
      }
      
    } catch (error) {
      console.error(`[StorageAdapter] ❌ Erro ao salvar ${key}:`, error);
      throw error;
    }
  }
  
  /**
   * Remove valor do storage
   * @param {string} key - Chave a remover
   * @param {Object} options - Opções de remoção
   * @returns {Promise<void>}
   */
  async remove(key, options = {}) {
    const syncNow = options.syncNow || false;
    
    try {
      // Limpar metadados
      this.metadata.delete(key);
      
      // 1. Remover de Chrome
      if (this._isChromeBackend()) {
        await this._removeFromChrome(key);
        console.log(`[StorageAdapter] ✅ Removido de Chrome: ${key}`);
      }
      
      // 2. Remover de SharePoint
      if (this._isSharePointBackend() && this.graphClient) {
        if (syncNow) {
          await this._removeFromSharePoint(key);
          console.log(`[StorageAdapter] ✅ Removido de SharePoint: ${key}`);
        } else {
          this._queueSync(key, null, { operation: 'delete' });
        }
      }
      
      // 3. Remover de localStorage (apenas em contextos que suportam)
      if (typeof localStorage !== 'undefined') {
        try {
          localStorage.removeItem(this.chromePrefix + key);
        } catch (e) {
          // Silenciar erro - service workers não têm localStorage
        }
      }
      
    } catch (error) {
      console.error(`[StorageAdapter] ❌ Erro ao remover ${key}:`, error);
      throw error;
    }
  }
  
  /**
   * Sincroniza dados entre Chrome e SharePoint
   * @param {string} [key] - Chave específica ou todas se omitido
   * @param {Object} options - Opções de sync
   * @returns {Promise<Object>} Resultado da sincronização
   */
  async sync(key = null, options = {}) {
    if (this.backend !== 'hybrid' || !this.graphClient) {
      console.warn('[StorageAdapter] Sync requer backend hybrid e GraphClient');
      return { synced: 0, conflicts: 0, errors: 0 };
    }
    
    const direction = options.direction || 'bidirectional'; // 'up' | 'down' | 'bidirectional'
    const dryRun = options.dryRun || false;
    
    console.log(`[StorageAdapter] 🔄 Iniciando sync (direction: ${direction}, dryRun: ${dryRun})`);
    
    try {
      const result = { synced: 0, conflicts: 0, errors: 0, details: [] };
      
      // Determinar chaves a sincronizar
      const keys = key ? [key] : await this._getAllKeys();
      
      for (const k of keys) {
        try {
          const syncResult = await this._syncSingleKey(k, direction, dryRun);
          result.synced += syncResult.synced ? 1 : 0;
          result.conflicts += syncResult.conflict ? 1 : 0;
          result.details.push({ key: k, ...syncResult });
        } catch (error) {
          result.errors++;
          result.details.push({ key: k, error: error.message });
        }
      }
      
      console.log(`[StorageAdapter] ✅ Sync concluído:`, result);
      return result;
      
    } catch (error) {
      console.error('[StorageAdapter] ❌ Erro durante sync:', error);
      throw error;
    }
  }
  
  /**
   * Lista todas as chaves disponíveis
   * @param {Object} options - Opções de listagem
   * @returns {Promise<string[]>}
   */
  async list(options = {}) {
    const source = options.source || 'chrome'; // 'chrome' | 'sharepoint' | 'both'
    
    try {
      const keys = new Set();
      
      // Chrome Storage
      if (source === 'chrome' || source === 'both') {
        const chromeKeys = await this._getAllKeys('chrome');
        chromeKeys.forEach(k => keys.add(k));
      }
      
      // SharePoint
      if ((source === 'sharepoint' || source === 'both') && this.graphClient) {
        const spKeys = await this._getAllKeys('sharepoint');
        spKeys.forEach(k => keys.add(k));
      }
      
      return Array.from(keys);
      
    } catch (error) {
      console.error('[StorageAdapter] ❌ Erro ao listar chaves:', error);
      return [];
    }
  }
  
  /**
   * Obtém estatísticas de uso
   * @returns {Promise<Object>}
   */
  async getStats() {
    try {
      const stats = {
        backend: this.backend,
        chromeSize: 0,
        sharepointSize: 0,
        totalKeys: 0,
        syncQueueSize: this.syncQueue.length,
        lastSync: null
      };
      
      // Chrome Storage
      if (this._isChromeBackend()) {
        const chromeData = await chrome.storage.local.get(null);
        stats.chromeSize = JSON.stringify(chromeData).length;
        stats.totalKeys = Object.keys(chromeData).filter(k => k.startsWith(this.chromePrefix)).length;
      }
      
      // SharePoint (se disponível)
      if (this._isSharePointBackend() && this.graphClient) {
        // TODO: Implementar quando GraphClient estiver pronto
        stats.sharepointSize = 0;
      }
      
      return stats;
      
    } catch (error) {
      console.error('[StorageAdapter] ❌ Erro ao obter stats:', error);
      return null;
    }
  }
  
  // ==================== Métodos Privados: Chrome Storage ====================
  
  async _getFromChrome(key) {
    try {
      const fullKey = this.chromePrefix + key;
      const result = await chrome.storage.local.get([fullKey]);
      return result[fullKey] !== undefined ? result[fullKey] : null;
    } catch (error) {
      console.error(`[StorageAdapter] Erro ao ler de Chrome: ${key}`, error);
      return null;
    }
  }
  
  async _setToChrome(key, value, options = {}) {
    try {
      const fullKey = this.chromePrefix + key;
      const data = { [fullKey]: value };
      
      // Adicionar metadados se necessário
      if (!options.skipMetadata && options.timestamp) {
        data[fullKey + '__meta'] = { timestamp: options.timestamp };
      }
      
      await chrome.storage.local.set(data);
    } catch (error) {
      console.error(`[StorageAdapter] Erro ao salvar em Chrome: ${key}`, error);
      throw error;
    }
  }
  
  async _removeFromChrome(key) {
    try {
      const fullKey = this.chromePrefix + key;
      await chrome.storage.local.remove([fullKey, fullKey + '__meta']);
    } catch (error) {
      console.error(`[StorageAdapter] Erro ao remover de Chrome: ${key}`, error);
      throw error;
    }
  }
  
  // ==================== Métodos Privados: SharePoint ====================
  
  async _getFromSharePoint(key) {
    if (!this.graphClient) {
      console.warn('[StorageAdapter] GraphClient não disponível');
      return null;
    }
    
    try {
      const filePath = `${this.sharepointFolder}/${key}.json`;
      const data = await this.graphClient.downloadFile(filePath);
      return data;
    } catch (error) {
      // 404 é esperado se arquivo não existe
      if (error.status === 404) {
        return null;
      }
      console.error(`[StorageAdapter] Erro ao ler de SharePoint: ${key}`, error);
      throw error;
    }
  }
  
  async _setToSharePoint(key, value, options = {}) {
    if (!this.graphClient) {
      throw new Error('GraphClient não disponível');
    }
    
    try {
      const filePath = `${this.sharepointFolder}/${key}.json`;
      const content = {
        data: value,
        metadata: {
          timestamp: options.timestamp || Date.now(),
          version: 1,
          source: 'chrome-extension'
        }
      };
      
      await this.graphClient.uploadFile(filePath, content);
    } catch (error) {
      console.error(`[StorageAdapter] Erro ao salvar em SharePoint: ${key}`, error);
      throw error;
    }
  }
  
  async _removeFromSharePoint(key) {
    if (!this.graphClient) {
      throw new Error('GraphClient não disponível');
    }
    
    try {
      const filePath = `${this.sharepointFolder}/${key}.json`;
      await this.graphClient.deleteFile(filePath);
    } catch (error) {
      console.error(`[StorageAdapter] Erro ao remover de SharePoint: ${key}`, error);
      throw error;
    }
  }
  
  // ==================== Métodos Privados: Sync ====================
  
  _queueSync(key, value, options = {}) {
    // Remover entradas antigas da mesma chave
    this.syncQueue = this.syncQueue.filter(item => item.key !== key);
    
    // Adicionar à fila
    this.syncQueue.push({
      key,
      value,
      timestamp: options.timestamp || Date.now(),
      operation: options.operation || 'set'
    });
    
    // Limitar tamanho da fila (max 100 itens)
    if (this.syncQueue.length > 100) {
      this.syncQueue.shift();
    }
  }
  
  async _processSyncQueue() {
    if (this.syncQueue.length === 0) {
      return;
    }
    
    console.log(`[StorageAdapter] 🔄 Processando fila de sync (${this.syncQueue.length} itens)`);
    
    const batch = [...this.syncQueue];
    this.syncQueue = [];
    
    for (const item of batch) {
      try {
        if (item.operation === 'delete') {
          await this._removeFromSharePoint(item.key);
        } else {
          await this._setToSharePoint(item.key, item.value, { timestamp: item.timestamp });
        }
      } catch (error) {
        console.error(`[StorageAdapter] Erro ao processar sync de ${item.key}:`, error);
        // Re-adicionar à fila em caso de erro
        this.syncQueue.push(item);
      }
    }
  }
  
  async _syncSingleKey(key, direction, dryRun) {
    const result = { synced: false, conflict: false, action: null };
    
    // Obter dados de ambos os lados
    const chromeData = await this._getFromChrome(key);
    const spData = await this._getFromSharePoint(key);
    
    // Obter metadados
    const chromeMetaKey = this.chromePrefix + key + '__meta';
    const chromeMeta = await chrome.storage.local.get([chromeMetaKey]);
    const chromeTimestamp = chromeMeta[chromeMetaKey]?.timestamp || 0;
    const spTimestamp = spData?.metadata?.timestamp || 0;
    
    // Determinar ação
    if (!chromeData && !spData) {
      result.action = 'skip-empty';
    } else if (!chromeData && spData) {
      result.action = 'download';
      if (!dryRun && (direction === 'down' || direction === 'bidirectional')) {
        await this._setToChrome(key, spData.data, { timestamp: spTimestamp });
        result.synced = true;
      }
    } else if (chromeData && !spData) {
      result.action = 'upload';
      if (!dryRun && (direction === 'up' || direction === 'bidirectional')) {
        await this._setToSharePoint(key, chromeData, { timestamp: chromeTimestamp });
        result.synced = true;
      }
    } else {
      // Ambos existem - verificar conflito
      if (chromeTimestamp === spTimestamp) {
        result.action = 'skip-identical';
      } else if (chromeTimestamp > spTimestamp) {
        result.action = 'upload-newer';
        if (!dryRun && (direction === 'up' || direction === 'bidirectional')) {
          await this._setToSharePoint(key, chromeData, { timestamp: chromeTimestamp });
          result.synced = true;
        }
      } else {
        result.action = 'download-newer';
        if (!dryRun && (direction === 'down' || direction === 'bidirectional')) {
          await this._setToChrome(key, spData.data, { timestamp: spTimestamp });
          result.synced = true;
        }
      }
      
      // Detectar conflito (diferença de conteúdo com timestamps próximos)
      if (Math.abs(chromeTimestamp - spTimestamp) < 5000) { // 5s threshold
        const chromeHash = this._hashValue(chromeData);
        const spHash = this._hashValue(spData.data);
        if (chromeHash !== spHash) {
          result.conflict = true;
          console.warn(`[StorageAdapter] ⚠️ Conflito detectado: ${key}`);
        }
      }
    }
    
    return result;
  }
  
  async _getAllKeys(source = 'chrome') {
    if (source === 'chrome') {
      const data = await chrome.storage.local.get(null);
      return Object.keys(data)
        .filter(k => k.startsWith(this.chromePrefix) && !k.endsWith('__meta'))
        .map(k => k.substring(this.chromePrefix.length));
    } else if (source === 'sharepoint' && this.graphClient) {
      // TODO: Implementar quando GraphClient tiver listFiles()
      return [];
    }
    return [];
  }
  
  _startAutoSync() {
    if (this.syncTimer) {
      clearInterval(this.syncTimer);
    }
    
    this.syncTimer = setInterval(async () => {
      try {
        await this._processSyncQueue();
      } catch (error) {
        console.error('[StorageAdapter] Erro no auto-sync:', error);
      }
    }, this.syncInterval);
    
    console.log(`[StorageAdapter] Auto-sync iniciado (intervalo: ${this.syncInterval}ms)`);
  }
  
  stopAutoSync() {
    if (this.syncTimer) {
      clearInterval(this.syncTimer);
      this.syncTimer = null;
      console.log('[StorageAdapter] Auto-sync parado');
    }
  }
  
  // ==================== Helpers ====================
  
  _isChromeBackend() {
    return this.backend === 'chrome-only' || this.backend === 'hybrid';
  }
  
  _isSharePointBackend() {
    return this.backend === 'sharepoint-only' || this.backend === 'hybrid';
  }
  
  _hashValue(value) {
    // Hash simples para detecção de mudanças
    const str = JSON.stringify(value);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return hash.toString(36);
  }
  
  /**
   * Destrói a instância e limpa recursos
   */
  destroy() {
    this.stopAutoSync();
    this.syncQueue = [];
    this.metadata.clear();
    console.log('[StorageAdapter] Destruído');
  }
}

// Export para uso em módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = StorageAdapter;
}

// Export global para content scripts
if (typeof window !== 'undefined') {
  window.StorageAdapter = StorageAdapter;
  console.log('[StorageAdapter] ✅ Disponível globalmente');
}
