/**
 * ════════════════════════════════════════════════════════════════════════════
 * PICKING QUEUE MANAGER - Fila de Envios em Background
 * ════════════════════════════════════════════════════════════════════════════
 * 
 * Responsável por:
 * - Enfileirar pedidos para envio
 * - Processar em segundo plano
 * - Notificar progresso
 * - Retry automático em caso de erro
 * - Envio sem estar na plataforma
 */

class PickingQueueManager {
  constructor(stateManager, lockManager) {
    this.stateManager = stateManager;
    this.lockManager = lockManager;
    
    this.queue = [];
    this.processing = false;
    this.currentJob = null;
    this.results = {
      success: [],
      failed: [],
      skipped: []
    };
    
    // Queue Manager inicializado silenciosamente
  }
  
  /**
   * Adicionar pedido à fila
   */
  async enqueue(job) {
    const {
      loja,
      pedidoId,
      platform,      // 'uber', 'lalamove', '99'
      vehicle,       // tipo de veículo
      priority = 0,  // maior = mais prioritário
      metadata = {}
    } = job;
    
    // Validar
    if (!loja || !pedidoId || !platform || !vehicle) {
      console.error('[PickingQueue] ❌ Job inválido:', job);
      return { success: false, reason: 'Dados incompletos' };
    }
    
    // Verificar se já está na fila
    const existing = this.queue.find(j => 
      j.loja === loja && j.pedidoId === pedidoId && j.status === 'pending'
    );
    
    if (existing) {
      console.log('[PickingQueue] ℹ️ Pedido já está na fila:', pedidoId);
      return { success: false, reason: 'Já está na fila' };
    }
    
    // Tentar travar
    const lockResult = await this.lockManager.tryLock(pedidoId, 'queued_for_send');
    
    if (!lockResult.success) {
      console.log('[PickingQueue] 🔒 Não foi possível travar:', lockResult.reason);
      return { success: false, reason: lockResult.reason };
    }
    
    // Criar job
    const queuedJob = {
      id: `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      loja,
      pedidoId,
      platform,
      vehicle,
      priority,
      metadata,
      status: 'pending',
      attempts: 0,
      maxAttempts: 3,
      addedAt: Date.now(),
      addedBy: this.stateManager.getCurrentUser()?.name || 'Desconhecido',
      startedAt: null,
      completedAt: null,
      error: null
    };
    
    this.queue.push(queuedJob);
    
    // Ordenar por prioridade
    this.queue.sort((a, b) => b.priority - a.priority);
    
    // Adicionar evento na timeline
    this.stateManager.addTimelineEvent(pedidoId, {
      type: 'queued',
      user: queuedJob.addedBy,
      message: `Adicionado à fila: ${platform} (${vehicle})`,
      platform,
      vehicle
    });
    
    this.stateManager.notifyListeners('job_queued', { job: queuedJob });
    
    console.log(`[PickingQueue] ✅ Job enfileirado: ${pedidoId} -> ${platform} (${vehicle})`);
    console.log(`[PickingQueue] 📊 Fila: ${this.queue.length} job(s)`);
    
    // Iniciar processamento se não estiver rodando
    if (!this.processing) {
      this.startProcessing();
    }
    
    return { success: true, job: queuedJob };
  }
  
  /**
   * Remover da fila
   */
  async dequeue(jobId) {
    const index = this.queue.findIndex(j => j.id === jobId);
    
    if (index === -1) {
      return { success: false, reason: 'Job não encontrado' };
    }
    
    const job = this.queue[index];
    
    // Se está processando, não pode remover
    if (this.currentJob && this.currentJob.id === jobId) {
      return { success: false, reason: 'Job está sendo processado' };
    }
    
    // Remover
    this.queue.splice(index, 1);
    
    // Destravar
    await this.lockManager.unlock(job.pedidoId);
    
    // Adicionar evento
    this.stateManager.addTimelineEvent(job.pedidoId, {
      type: 'dequeued',
      user: this.stateManager.getCurrentUser()?.name || 'Sistema',
      message: 'Removido da fila de envio'
    });
    
    this.stateManager.notifyListeners('job_dequeued', { job });
    
    console.log(`[PickingQueue] 🗑️ Job removido da fila: ${jobId}`);
    
    return { success: true };
  }
  
  /**
   * Iniciar processamento da fila
   */
  async startProcessing() {
    if (this.processing) {
      console.log('[PickingQueue] ⚠️ Já está processando');
      return;
    }
    
    this.processing = true;
    this.results = { success: [], failed: [], skipped: [] };
    
    console.log('[PickingQueue] 🚀 Iniciando processamento da fila...');
    console.log(`[PickingQueue] 📊 Total: ${this.queue.length} job(s)`);
    
    this.stateManager.notifyListeners('queue_started', { 
      total: this.queue.length 
    });
    
    while (this.queue.length > 0 && this.processing) {
      // Pegar próximo job
      const job = this.queue[0];
      this.currentJob = job;
      
      console.log(`[PickingQueue] 🔄 Processando: ${job.pedidoId} (${this.queue.length} restantes)`);
      
      // Processar
      await this.processJob(job);
      
      // Remover da fila
      this.queue.shift();
      this.currentJob = null;
      
      // Pequeno delay entre jobs
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    this.processing = false;
    
    console.log('[PickingQueue] ✅ Processamento concluído!');
    console.log(`[PickingQueue] 📊 Sucesso: ${this.results.success.length}, Falha: ${this.results.failed.length}, Pulados: ${this.results.skipped.length}`);
    
    this.stateManager.notifyListeners('queue_completed', { 
      results: this.results 
    });
    
    // Mostrar notificação
    this.showCompletionNotification();
  }
  
  /**
   * Parar processamento
   */
  stopProcessing() {
    if (!this.processing) return;
    
    this.processing = false;
    console.log('[PickingQueue] ⏹️ Processamento parado');
    
    this.stateManager.notifyListeners('queue_stopped', {});
  }
  
  /**
   * Processar um job
   */
  async processJob(job) {
    job.status = 'processing';
    job.startedAt = Date.now();
    job.attempts++;
    
    this.stateManager.notifyListeners('job_started', { job });
    
    // Adicionar evento
    this.stateManager.addTimelineEvent(job.pedidoId, {
      type: 'sending',
      user: job.addedBy,
      message: `Enviando para ${job.platform}...`,
      platform: job.platform,
      vehicle: job.vehicle
    });
    
    try {
      // Chamar função de envio apropriada
      const result = await this.sendToPlatform(job);
      
      if (result.success) {
        job.status = 'completed';
        job.completedAt = Date.now();
        this.results.success.push(job);
        
        // Adicionar evento de sucesso
        this.stateManager.addTimelineEvent(job.pedidoId, {
          type: 'sent',
          user: job.addedBy,
          message: `Enviado com sucesso para ${job.platform}`,
          platform: job.platform,
          vehicle: job.vehicle,
          trackingId: result.trackingId,
          value: result.value
        });
        
        // Atualizar pedido com dados do envio
        const order = this.stateManager.getOrder(job.loja, job.pedidoId);
        if (order) {
          order.status = 'solicitado';
          order.plataforma = job.platform;
          order.veiculo = job.vehicle;
          order.id_solicitacao = result.trackingId;
          order.valor_transporte = result.value;
          order.timestamp_carregamento = Date.now();
          
          await this.stateManager.setOrder(job.loja, job.pedidoId, order);
        }
        
        console.log(`[PickingQueue] ✅ Job concluído: ${job.pedidoId}`);
        
      } else {
        throw new Error(result.error || 'Falha desconhecida');
      }
      
    } catch (error) {
      console.error(`[PickingQueue] ❌ Erro no job ${job.pedidoId}:`, error);
      
      job.error = error.message;
      
      // Retry?
      if (job.attempts < job.maxAttempts) {
        job.status = 'retrying';
        
        console.log(`[PickingQueue] 🔄 Tentativa ${job.attempts}/${job.maxAttempts} falhou, tentando novamente...`);
        
        // Adicionar de volta à fila
        this.queue.push(job);
        
        this.stateManager.addTimelineEvent(job.pedidoId, {
          type: 'send_retry',
          user: 'Sistema',
          message: `Tentativa ${job.attempts} falhou, tentando novamente...`,
          error: error.message
        });
        
      } else {
        job.status = 'failed';
        job.completedAt = Date.now();
        this.results.failed.push(job);
        
        this.stateManager.addTimelineEvent(job.pedidoId, {
          type: 'send_failed',
          user: 'Sistema',
          message: `Falha após ${job.maxAttempts} tentativas`,
          error: error.message
        });
        
        console.log(`[PickingQueue] ❌ Job falhou definitivamente: ${job.pedidoId}`);
      }
    } finally {
      // Destravar
      await this.lockManager.unlock(job.pedidoId);
      
      this.stateManager.notifyListeners('job_completed', { job });
    }
  }
  
  /**
   * Enviar para plataforma (função principal)
   */
  async sendToPlatform(job) {
    const { platform, vehicle, loja, pedidoId } = job;
    
    console.log(`[PickingQueue] 📤 Enviando ${pedidoId} para ${platform} via ${vehicle}`);
    
    // Obter dados do pedido
    const order = this.stateManager.getOrder(loja, pedidoId);
    
    if (!order) {
      throw new Error('Pedido não encontrado');
    }
    
    // Simular envio (TEMPORÁRIO - depois implementamos real)
    // TODO: Chamar funções reais de cada plataforma
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Retorno simulado
    return {
      success: true,
      trackingId: `${platform.toUpperCase()}-${Date.now()}`,
      value: (Math.random() * 30 + 15).toFixed(2),
      platform,
      vehicle
    };
  }
  
  /**
   * Obter status da fila
   */
  getQueueStatus() {
    return {
      total: this.queue.length,
      processing: this.processing,
      currentJob: this.currentJob,
      pending: this.queue.filter(j => j.status === 'pending').length,
      results: this.results
    };
  }
  
  /**
   * Limpar fila
   */
  async clearQueue() {
    // Destravar todos
    for (const job of this.queue) {
      await this.lockManager.unlock(job.pedidoId);
    }
    
    this.queue = [];
    this.processing = false;
    this.currentJob = null;
    
    console.log('[PickingQueue] 🧹 Fila limpa');
    
    this.stateManager.notifyListeners('queue_cleared', {});
  }
  
  /**
   * Mostrar notificação de conclusão
   */
  showCompletionNotification() {
    const { success, failed, skipped } = this.results;
    const total = success.length + failed.length + skipped.length;
    
    if (total === 0) return;
    
    let message = `Processamento concluído: `;
    
    if (success.length > 0) {
      message += `${success.length} enviado(s)`;
    }
    
    if (failed.length > 0) {
      message += success.length > 0 ? `, ${failed.length} falha(s)` : `${failed.length} falha(s)`;
    }
    
    if (skipped.length > 0) {
      message += `, ${skipped.length} pulado(s)`;
    }
    
    const type = failed.length === 0 ? 'success' : (success.length > 0 ? 'warning' : 'error');
    
    if (typeof window.NexosUI !== 'undefined') {
      window.NexosUI.showToast(message, type, 5000);
    }
  }
}

// Exportar
window.PickingQueueManager = PickingQueueManager;

console.log('[PickingQueue] 📋 Módulo carregado');
