/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - UPDATE ENGINE
 * Sistema automático de atualização via SharePoint
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Funcionalidades:
 * - Verificação periódica de atualizações no SharePoint
 * - Download automático de novas versões
 * - Aplicação silenciosa sem interrupção do usuário
 * - Fallback para múltiplas fontes (SharePoint, GitHub, backup)
 * - Release notes e changelog automático
 * - Rollback em caso de falha
 * - Zero intervenção do usuário
 */

class UpdateEngine {
  constructor(graphClient, config = {}) {
    this.graphClient = graphClient;
    this.config = {
      libraryName: config.libraryName || 'Nexos_Files',
      versionFilePath: config.versionFilePath || '/version.json',
      updateCheckInterval: config.updateCheckInterval || 1800000, // 30 minutos
      autoApplyUpdates: config.autoApplyUpdates !== false,
      fallbackUrls: config.fallbackUrls || [],
      ...config
    };
    
    this.currentVersion = chrome.runtime.getManifest().version;
    this.updateCheckTimer = null;
    this.isUpdating = false;
    
    this.log('info', `🔄 UpdateEngine inicializado v${this.currentVersion}`);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // LOGGING
  // ═══════════════════════════════════════════════════════════════════════════
  
  log(level, message, data = {}) {
    const prefix = '[UpdateEngine]';
    const color = {
      debug: '#888',
      info: '#00C2FF',
      warn: '#FFA502',
      error: '#FF4757',
      success: '#2ED573'
    }[level] || '#FFF';
    
    console.log(`%c${prefix} ${message}`, `color: ${color}`, data);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // INICIALIZAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  async start() {
    this.log('info', '🚀 Iniciando UpdateEngine...');
    
    try {
      // Verificação imediata na inicialização
      await this.checkForUpdates();
      
      // Configurar verificação periódica
      this.scheduleUpdateCheck();
      
      this.log('success', '✅ UpdateEngine iniciado com sucesso');
      
    } catch (error) {
      this.log('error', '❌ Erro ao iniciar UpdateEngine', { error: error.message });
    }
  }
  
  stop() {
    this.log('info', '⏹️ Parando UpdateEngine...');
    
    if (this.updateCheckTimer) {
      clearInterval(this.updateCheckTimer);
      this.updateCheckTimer = null;
    }
  }
  
  scheduleUpdateCheck() {
    this.log('debug', `⏰ Agendando verificação a cada ${this.config.updateCheckInterval / 1000}s`);
    
    this.updateCheckTimer = setInterval(() => {
      this.checkForUpdates().catch(error => {
        this.log('error', 'Erro na verificação periódica', { error: error.message });
      });
    }, this.config.updateCheckInterval);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // VERIFICAÇÃO DE ATUALIZAÇÕES
  // ═══════════════════════════════════════════════════════════════════════════
  
  async checkForUpdates() {
    if (this.isUpdating) {
      this.log('warn', '⚠️ Atualização já em andamento, ignorando verificação');
      return null;
    }
    
    this.log('info', '🔍 Verificando atualizações...');
    
    try {
      // Buscar version.json do SharePoint
      const versionInfo = await this.fetchVersionInfo();
      
      if (!versionInfo) {
        this.log('warn', '⚠️ Não foi possível obter informações de versão');
        return null;
      }
      
      // Comparar versões
      const comparison = this.compareVersions(this.currentVersion, versionInfo.version);
      
      if (comparison < 0) {
        // Versão disponível é mais nova
        this.log('success', `✨ Nova versão disponível: ${versionInfo.version} (atual: ${this.currentVersion})`);
        
        // Salvar informações da atualização
        await this.saveUpdateInfo(versionInfo);
        
        // Aplicar automaticamente se configurado
        if (this.config.autoApplyUpdates) {
          await this.applyUpdate(versionInfo);
        } else {
          // Notificar usuário
          this.notifyUpdateAvailable(versionInfo);
        }
        
        return versionInfo;
        
      } else if (comparison === 0) {
        this.log('info', '✅ Extensão está atualizada');
        return null;
        
      } else {
        this.log('warn', `⚠️ Versão local (${this.currentVersion}) é mais nova que SharePoint (${versionInfo.version})`);
        return null;
      }
      
    } catch (error) {
      this.log('error', '❌ Erro ao verificar atualizações', { error: error.message });
      
      // Tentar fallback
      return await this.checkForUpdatesFallback();
    }
  }
  
  async fetchVersionInfo() {
    this.log('debug', `📄 Buscando ${this.config.versionFilePath} do SharePoint...`);
    
    try {
      const content = await this.graphClient.downloadFile(
        this.config.libraryName,
        this.config.versionFilePath
      );
      
      const versionInfo = JSON.parse(content);
      
      this.log('success', `✅ Version info obtido: v${versionInfo.version}`);
      
      return versionInfo;
      
    } catch (error) {
      this.log('error', 'Erro ao buscar version.json do SharePoint', { error: error.message });
      throw error;
    }
  }
  
  async checkForUpdatesFallback() {
    this.log('info', '🔄 Tentando fontes alternativas...');
    
    for (const fallbackUrl of this.config.fallbackUrls) {
      try {
        this.log('debug', `Tentando: ${fallbackUrl}`);
        
        const response = await fetch(`${fallbackUrl}/version.json`);
        
        if (!response.ok) continue;
        
        const versionInfo = await response.json();
        
        this.log('success', `✅ Version info obtido de fallback: v${versionInfo.version}`);
        
        return versionInfo;
        
      } catch (error) {
        this.log('warn', `Fallback falhou: ${fallbackUrl}`, { error: error.message });
      }
    }
    
    this.log('error', '❌ Todas as fontes de atualização falharam');
    return null;
  }
  
  compareVersions(v1, v2) {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);
    
    for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
      const part1 = parts1[i] || 0;
      const part2 = parts2[i] || 0;
      
      if (part1 < part2) return -1;
      if (part1 > part2) return 1;
    }
    
    return 0;
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // APLICAÇÃO DE ATUALIZAÇÕES
  // ═══════════════════════════════════════════════════════════════════════════
  
  async applyUpdate(versionInfo) {
    if (this.isUpdating) {
      this.log('warn', '⚠️ Atualização já em andamento');
      return false;
    }
    
    this.isUpdating = true;
    
    this.log('info', `🚀 Aplicando atualização para v${versionInfo.version}...`);
    
    const updateLog = {
      startedAt: Date.now(),
      fromVersion: this.currentVersion,
      toVersion: versionInfo.version,
      steps: [],
      errors: []
    };
    
    try {
      // 1. Criar backup da versão atual
      this.log('info', '📋 Passo 1/5: Criando backup...');
      await this.createBackup();
      updateLog.steps.push({ step: 'backup', success: true, timestamp: Date.now() });
      
      // 2. Baixar arquivos atualizados
      this.log('info', '⬇️ Passo 2/5: Baixando arquivos...');
      const files = await this.downloadUpdateFiles(versionInfo);
      updateLog.steps.push({ step: 'download', success: true, fileCount: files.length, timestamp: Date.now() });
      
      // 3. Validar arquivos baixados
      this.log('info', '✔️ Passo 3/5: Validando arquivos...');
      const isValid = await this.validateFiles(files, versionInfo);
      
      if (!isValid) {
        throw new Error('Validação de arquivos falhou');
      }
      
      updateLog.steps.push({ step: 'validation', success: true, timestamp: Date.now() });
      
      // 4. Aplicar arquivos
      this.log('info', '📝 Passo 4/5: Aplicando arquivos...');
      await this.applyFiles(files);
      updateLog.steps.push({ step: 'apply', success: true, timestamp: Date.now() });
      
      // 5. Atualizar configurações e caches
      this.log('info', '⚙️ Passo 5/5: Atualizando configurações...');
      await this.updateConfig(versionInfo);
      updateLog.steps.push({ step: 'config', success: true, timestamp: Date.now() });
      
      // Marcar como atualizado
      await this.markAsUpdated(versionInfo, updateLog);
      
      const duration = Date.now() - updateLog.startedAt;
      
      this.log('success', `✨ Atualização concluída com sucesso em ${duration}ms`);
      
      // Notificar usuário
      this.notifyUpdateComplete(versionInfo);
      
      // Recarregar extensão
      if (versionInfo.requiresReload !== false) {
        this.log('info', '🔄 Recarregando extensão...');
        setTimeout(() => {
          chrome.runtime.reload();
        }, 2000);
      }
      
      return true;
      
    } catch (error) {
      this.log('error', '❌ Erro durante atualização', { error: error.message });
      
      updateLog.errors.push({
        message: error.message,
        stack: error.stack,
        timestamp: Date.now()
      });
      
      // Salvar log de erro
      await this.saveUpdateError(updateLog);
      
      // Tentar rollback
      this.log('warn', '🔄 Tentando rollback...');
      
      try {
        await this.rollback();
        this.log('success', '✅ Rollback concluído');
      } catch (rollbackError) {
        this.log('error', '❌ Rollback falhou', { error: rollbackError.message });
      }
      
      this.notifyUpdateFailed(error);
      
      return false;
      
    } finally {
      this.isUpdating = false;
    }
  }
  
  async downloadUpdateFiles(versionInfo) {
    this.log('debug', 'Baixando arquivos da atualização...');
    
    const files = [];
    
    // Baixar cada arquivo listado em versionInfo.files
    if (versionInfo.files && Array.isArray(versionInfo.files)) {
      for (const fileInfo of versionInfo.files) {
        try {
          this.log('debug', `⬇️ Baixando: ${fileInfo.path}`);
          
          const content = await this.graphClient.downloadFile(
            this.config.libraryName,
            fileInfo.path
          );
          
          files.push({
            path: fileInfo.path,
            content,
            hash: fileInfo.hash || null,
            size: content.length
          });
          
          this.log('success', `✅ ${fileInfo.path} (${content.length} bytes)`);
          
        } catch (error) {
          this.log('error', `❌ Erro ao baixar ${fileInfo.path}`, { error: error.message });
          
          // Tentar fallback
          const fallbackContent = await this.downloadFileFallback(fileInfo.path);
          
          if (fallbackContent) {
            files.push({
              path: fileInfo.path,
              content: fallbackContent,
              hash: fileInfo.hash || null,
              size: fallbackContent.length,
              fromFallback: true
            });
          } else {
            throw new Error(`Não foi possível baixar arquivo crítico: ${fileInfo.path}`);
          }
        }
      }
    }
    
    this.log('success', `✅ ${files.length} arquivos baixados`);
    
    return files;
  }
  
  async downloadFileFallback(filePath) {
    this.log('debug', `🔄 Tentando fallback para: ${filePath}`);
    
    for (const fallbackUrl of this.config.fallbackUrls) {
      try {
        const url = `${fallbackUrl}${filePath}`;
        this.log('debug', `Tentando: ${url}`);
        
        const response = await fetch(url);
        
        if (response.ok) {
          const content = await response.text();
          this.log('success', `✅ Arquivo obtido via fallback: ${filePath}`);
          return content;
        }
        
      } catch (error) {
        this.log('warn', `Fallback falhou para ${fallbackUrl}`, { error: error.message });
      }
    }
    
    return null;
  }
  
  async validateFiles(files, versionInfo) {
    this.log('debug', 'Validando arquivos baixados...');
    
    for (const file of files) {
      // Validar tamanho mínimo
      if (file.size === 0) {
        this.log('error', `❌ Arquivo vazio: ${file.path}`);
        return false;
      }
      
      // Validar hash se fornecido
      if (file.hash) {
        const computedHash = await this.computeHash(file.content);
        
        if (computedHash !== file.hash) {
          this.log('error', `❌ Hash inválido para ${file.path}`, {
            expected: file.hash,
            computed: computedHash
          });
          return false;
        }
      }
      
      // Validar sintaxe para arquivos JS/JSON
      if (file.path.endsWith('.js')) {
        try {
          new Function(file.content); // Tentar parsear JS
        } catch (error) {
          this.log('error', `❌ Sintaxe JS inválida em ${file.path}`, { error: error.message });
          return false;
        }
      }
      
      if (file.path.endsWith('.json')) {
        try {
          JSON.parse(file.content);
        } catch (error) {
          this.log('error', `❌ JSON inválido em ${file.path}`, { error: error.message });
          return false;
        }
      }
    }
    
    this.log('success', '✅ Todos os arquivos válidos');
    
    return true;
  }
  
  async computeHash(content) {
    const encoder = new TextEncoder();
    const data = encoder.encode(content);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }
  
  async applyFiles(files) {
    this.log('debug', 'Aplicando arquivos...');
    
    // Salvar arquivos no chrome.storage ou IndexedDB
    const filesMap = {};
    
    for (const file of files) {
      filesMap[file.path] = {
        content: file.content,
        size: file.size,
        appliedAt: Date.now()
      };
    }
    
    await this.saveToStorage('nexos-updated-files', filesMap);
    
    this.log('success', '✅ Arquivos aplicados');
  }
  
  async updateConfig(versionInfo) {
    this.log('debug', 'Atualizando configurações...');
    
    // Atualizar informações de versão
    await this.saveToStorage('nexos-current-version', {
      version: versionInfo.version,
      updatedAt: Date.now(),
      previousVersion: this.currentVersion
    });
    
    // Limpar caches se necessário
    if (versionInfo.clearCache) {
      this.log('info', '🗑️ Limpando caches...');
      await this.graphClient.clearCache();
    }
    
    this.log('success', '✅ Configurações atualizadas');
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // BACKUP E ROLLBACK
  // ═══════════════════════════════════════════════════════════════════════════
  
  async createBackup() {
    this.log('debug', 'Criando backup da versão atual...');
    
    try {
      // Backup de arquivos atuais
      const currentFiles = await this.getStorageItem('nexos-updated-files') || {};
      
      const backup = {
        version: this.currentVersion,
        timestamp: Date.now(),
        files: currentFiles
      };
      
      await this.saveToStorage('nexos-backup', backup);
      
      this.log('success', '✅ Backup criado');
      
    } catch (error) {
      this.log('error', 'Erro ao criar backup', { error: error.message });
      throw error;
    }
  }
  
  async rollback() {
    this.log('info', '🔄 Iniciando rollback...');
    
    try {
      const backup = await this.getStorageItem('nexos-backup');
      
      if (!backup) {
        throw new Error('Backup não encontrado');
      }
      
      // Restaurar arquivos
      if (backup.files) {
        await this.saveToStorage('nexos-updated-files', backup.files);
      }
      
      // Restaurar versão
      await this.saveToStorage('nexos-current-version', {
        version: backup.version,
        restoredAt: Date.now()
      });
      
      this.log('success', `✅ Rollback concluído para v${backup.version}`);
      
      // Recarregar extensão
      chrome.runtime.reload();
      
    } catch (error) {
      this.log('error', 'Erro durante rollback', { error: error.message });
      throw error;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // NOTIFICAÇÕES
  // ═══════════════════════════════════════════════════════════════════════════
  
  notifyUpdateAvailable(versionInfo) {
    this.log('info', '📢 Notificando atualização disponível...');
    
    try {
      chrome.notifications.create('nexos-update-available', {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('images/logo.png'),
        title: '✨ Atualização Disponível',
        message: `Nexos v${versionInfo.version} está disponível! A atualização será aplicada automaticamente.`,
        priority: 1,
        requireInteraction: false
      });
      
      setTimeout(() => {
        chrome.notifications.clear('nexos-update-available');
      }, 5000);
      
    } catch (error) {
      this.log('warn', 'Erro ao exibir notificação', { error: error.message });
    }
  }
  
  notifyUpdateComplete(versionInfo) {
    this.log('info', '📢 Notificando atualização concluída...');
    
    try {
      chrome.notifications.create('nexos-update-complete', {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('images/logo.png'),
        title: '✅ Atualização Concluída',
        message: `Nexos atualizado para v${versionInfo.version}! ${versionInfo.releaseNotes || ''}`,
        priority: 1,
        requireInteraction: false
      });
      
      setTimeout(() => {
        chrome.notifications.clear('nexos-update-complete');
      }, 8000);
      
    } catch (error) {
      this.log('warn', 'Erro ao exibir notificação', { error: error.message });
    }
  }
  
  notifyUpdateFailed(error) {
    this.log('info', '📢 Notificando falha na atualização...');
    
    try {
      chrome.notifications.create('nexos-update-failed', {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('images/logo.png'),
        title: '⚠️ Atualização Falhou',
        message: 'Não foi possível atualizar. A extensão continuará funcionando normalmente.',
        priority: 2,
        requireInteraction: false
      });
      
      setTimeout(() => {
        chrome.notifications.clear('nexos-update-failed');
      }, 10000);
      
    } catch (error) {
      this.log('warn', 'Erro ao exibir notificação', { error: error.message });
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // STORAGE
  // ═══════════════════════════════════════════════════════════════════════════
  
  async getStorageItem(key) {
    try {
      const result = await chrome.storage.local.get([key]);
      return result[key] || null;
    } catch (error) {
      this.log('warn', `Erro ao ler ${key}, tentando localStorage`, { error: error.message });
      
      try {
        const value = localStorage.getItem(key);
        return value ? JSON.parse(value) : null;
      } catch (e) {
        return null;
      }
    }
  }
  
  async saveToStorage(key, value) {
    try {
      await chrome.storage.local.set({ [key]: value });
    } catch (error) {
      this.log('warn', `Erro ao salvar ${key}, tentando localStorage`, { error: error.message });
      
      try {
        localStorage.setItem(key, JSON.stringify(value));
      } catch (e) {
        this.log('error', `Falha ao salvar ${key}`, { error: e.message });
      }
    }
  }
  
  async saveUpdateInfo(versionInfo) {
    await this.saveToStorage('nexos-pending-update', {
      version: versionInfo.version,
      releaseNotes: versionInfo.releaseNotes,
      files: versionInfo.files,
      timestamp: Date.now()
    });
  }
  
  async markAsUpdated(versionInfo, updateLog) {
    await this.saveToStorage('nexos-last-update', {
      version: versionInfo.version,
      previousVersion: this.currentVersion,
      timestamp: Date.now(),
      log: updateLog
    });
  }
  
  async saveUpdateError(updateLog) {
    await this.saveToStorage('nexos-update-error', {
      log: updateLog,
      timestamp: Date.now()
    });
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════════════════════════════════════

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { UpdateEngine };
}

if (typeof window !== 'undefined') {
  window.UpdateEngine = UpdateEngine;
}
