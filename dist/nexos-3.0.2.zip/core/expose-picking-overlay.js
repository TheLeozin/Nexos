/**
 * NEXOS TORRE - Expor buildExtractionOverlayRefactored no contexto da página
 * Este arquivo é injetado via manifest.json no contexto da página (world: MAIN)
 */

console.log('[NEXOS] 🔌 Expondo buildExtractionOverlayRefactored no window...');

window.buildExtractionOverlayRefactored = function() {
  console.log('[NEXOS] 📞 Disparando evento para executar overlay...');
  window.dispatchEvent(new CustomEvent('nexos-build-picking-overlay'));
};

console.log('[NEXOS] ✅ buildExtractionOverlayRefactored() disponível no console!');
console.log('[NEXOS] 💡 Execute: buildExtractionOverlayRefactored()');
