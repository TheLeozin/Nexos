/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - LOADER CORPORATIVO
 * Migração automática transparente para SharePoint
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Este módulo é responsável por:
 * 1. Detectar se é a primeira execução da versão corporativa
 * 2. Migrar automaticamente de versão local para SharePoint
 * 3. Carregar todos os módulos dinamicamente do SharePoint
 * 4. Garantir fallback offline se SharePoint não estiver disponível
 * 5. Fazer tudo isso SEM nenhuma ação do usuário
 * 
 * IMPORTANTE: Este loader roda ANTES de qualquer outro código da extensão
 */

(function() {
  'use strict';
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CONSTANTES E CONFIGURAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  const LOADER_VERSION = '2.0.0';
  const MIGRATION_FLAG_KEY = 'nexos-migrated-to-sharepoint';
  const SHAREPOINT_CONFIG_KEY = 'nexos-sharepoint-config';
  const FALLBACK_MODE_KEY = 'nexos-fallback-mode';
  const LAST_SUCCESSFUL_SYNC_KEY = 'nexos-last-sync';
  
  // Configuração do SharePoint (será carregada dinamicamente)
  const DEFAULT_SHAREPOINT_CONFIG = {
    siteUrl: 'https://gpabr.sharepoint.com/sites/NexosTorre',
    libraryName: 'Nexos_Files',
    paths: {
      core: '/core',
      modules: '/modules',
      templates: '/templates',
      styles: '/styles',
      config: '/config',
      version: '/version.json'
    },
    fallbackUrls: [
      'https://raw.githubusercontent.com/TheLeozin/Nexos/main',
      'https://gpabr.sharepoint.com/sites/NexosTorreBackup'
    ]
  };
  
  // ═══════════════════════════════════════════════════════════════════════════
  // ESTADO GLOBAL DO LOADER
  // ═══════════════════════════════════════════════════════════════════════════
  
  const LoaderState = {
    initialized: false,
    migrated: false,
    sharepointAvailable: false,
    fallbackMode: false,
    loadedModules: new Map(),
    config: null,
    graphClient: null,
    startTime: Date.now()
  };
  
  // ═══════════════════════════════════════════════════════════════════════════
  // LOGGING CENTRALIZADO
  // ═══════════════════════════════════════════════════════════════════════════
  
  function log(level, message, data = {}) {
    const timestamp = new Date().toISOString();
    const logEntry = {
      timestamp,
      level,
      module: 'Loader',
      version: LOADER_VERSION,
      message,
      data
    };
    
    const prefix = `[NEXOS LOADER ${level.toUpperCase()}]`;
    const color = {
      debug: 'color: #888',
      info: 'color: #00C2FF',
      warn: 'color: #FFA502',
      error: 'color: #FF4757',
      success: 'color: #2ED573'
    }[level] || 'color: #FFF';
    
    console.log(`%c${prefix}`, color, message, data);
    
    // Salvar logs localmente para auditoria
    try {
      const logs = JSON.parse(localStorage.getItem('nexos-loader-logs') || '[]');
      logs.push(logEntry);
      
      // Manter apenas últimos 100 logs
      if (logs.length > 100) logs.shift();
      
      localStorage.setItem('nexos-loader-logs', JSON.stringify(logs));
    } catch (e) {
      // Ignorar erro de storage
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // DETECÇÃO E MIGRAÇÃO AUTOMÁTICA
  // ═══════════════════════════════════════════════════════════════════════════
  
  async function detectAndMigrate() {
    log('info', '🔍 Detectando necessidade de migração...');
    
    try {
      // Verificar se já foi migrado
      const migrationStatus = await getStorageItem(MIGRATION_FLAG_KEY);
      
      if (migrationStatus && migrationStatus.completed) {
        log('success', '✅ Extensão já migrada para SharePoint', migrationStatus);
        LoaderState.migrated = true;
        return true;
      }
      
      // Detectar versão antiga (arquivos locais)
      const hasLocalVersion = await detectLocalVersion();
      
      if (hasLocalVersion) {
        log('warn', '⚠️ Versão local detectada, iniciando migração automática...');
        await performAutomaticMigration();
      } else {
        log('info', '✨ Primeira instalação corporativa, pulando migração');
        await markAsMigrated({
          firstInstall: true,
          migratedAt: Date.now(),
          version: LOADER_VERSION
        });
      }
      
      LoaderState.migrated = true;
      return true;
      
    } catch (error) {
      log('error', '❌ Erro durante detecção/migração', { error: error.message });
      
      // Mesmo com erro, permitir continuar em modo fallback
      LoaderState.fallbackMode = true;
      return false;
    }
  }
  
  async function detectLocalVersion() {
    log('debug', 'Verificando presença de arquivos locais...');
    
    try {
      // Verificar se há dados no storage antigo
      const oldData = await getStorageItem('nexos-picking-data');
      const oldLogs = await getStorageItem('nexos-logs');
      const oldConfig = localStorage.getItem('nexos-config');
      
      const hasOldData = !!(oldData || oldLogs || oldConfig);
      
      if (hasOldData) {
        log('info', '📦 Dados da versão antiga encontrados', {
          hasPickingData: !!oldData,
          hasLogs: !!oldLogs,
          hasConfig: !!oldConfig
        });
      }
      
      return hasOldData;
      
    } catch (error) {
      log('warn', 'Erro ao verificar versão local', { error: error.message });
      return false;
    }
  }
  
  async function performAutomaticMigration() {
    log('info', '🚀 Iniciando migração automática...');
    
    const startTime = Date.now();
    const migrationLog = {
      startedAt: startTime,
      steps: [],
      errors: []
    };
    
    try {
      // Passo 1: Backup de dados locais
      log('info', '📋 Passo 1/5: Criando backup de dados locais...');
      const backup = await createLocalBackup();
      migrationLog.steps.push({ step: 'backup', success: true, timestamp: Date.now() });
      
      // Passo 2: Carregar configuração do SharePoint
      log('info', '⚙️ Passo 2/5: Carregando configuração SharePoint...');
      const config = await loadSharePointConfig();
      migrationLog.steps.push({ step: 'config', success: true, timestamp: Date.now() });
      
      // Passo 3: Adaptar dados para novo formato
      log('info', '🔄 Passo 3/5: Adaptando dados para formato corporativo...');
      const adaptedData = await adaptDataToNewFormat(backup);
      migrationLog.steps.push({ step: 'adaptation', success: true, timestamp: Date.now() });
      
      // Passo 4: Sincronizar com SharePoint (tentativa)
      log('info', '☁️ Passo 4/5: Sincronizando com SharePoint...');
      try {
        await syncToSharePoint(adaptedData);
        migrationLog.steps.push({ step: 'sync', success: true, timestamp: Date.now() });
      } catch (syncError) {
        log('warn', '⚠️ Não foi possível sincronizar agora, dados salvos localmente', {
          error: syncError.message
        });
        migrationLog.steps.push({ 
          step: 'sync', 
          success: false, 
          error: syncError.message,
          timestamp: Date.now() 
        });
        migrationLog.syncPending = true;
      }
      
      // Passo 5: Marcar como migrado
      log('info', '✅ Passo 5/5: Finalizando migração...');
      const duration = Date.now() - startTime;
      await markAsMigrated({
        completed: true,
        migratedAt: Date.now(),
        duration,
        version: LOADER_VERSION,
        log: migrationLog
      });
      
      log('success', `✨ Migração concluída com sucesso em ${duration}ms`);
      
      // Exibir notificação discreta para o usuário
      showMigrationNotification('success');
      
    } catch (error) {
      log('error', '❌ Erro durante migração automática', { error: error.message });
      
      migrationLog.errors.push({
        message: error.message,
        stack: error.stack,
        timestamp: Date.now()
      });
      
      // Salvar log de erro
      await saveStorageItem('nexos-migration-error', {
        error: error.message,
        log: migrationLog,
        timestamp: Date.now()
      });
      
      // Mesmo com erro, marcar como migrado para não tentar novamente
      await markAsMigrated({
        completed: true,
        hasErrors: true,
        migratedAt: Date.now(),
        error: error.message,
        log: migrationLog
      });
      
      showMigrationNotification('error');
      
      throw error;
    }
  }
  
  async function createLocalBackup() {
    log('debug', 'Criando backup de dados locais...');
    
    const backup = {
      timestamp: Date.now(),
      version: LOADER_VERSION,
      data: {}
    };
    
    try {
      // Backup do chrome.storage
      const storageData = await chrome.storage.local.get(null);
      backup.data.chromeStorage = storageData;
      
      // Backup do localStorage relevante
      const localStorageKeys = [
        'nexos-config',
        'nexos-user-full-name',
        'nexos-picking-data',
        'nexos-logs'
      ];
      
      backup.data.localStorage = {};
      localStorageKeys.forEach(key => {
        const value = localStorage.getItem(key);
        if (value) {
          backup.data.localStorage[key] = value;
        }
      });
      
      log('success', `✅ Backup criado: ${Object.keys(backup.data.chromeStorage || {}).length} itens`, backup);
      
      // Salvar backup
      await saveStorageItem('nexos-local-backup', backup);
      
      return backup;
      
    } catch (error) {
      log('error', 'Erro ao criar backup', { error: error.message });
      throw error;
    }
  }
  
  async function adaptDataToNewFormat(backup) {
    log('debug', 'Adaptando dados para formato corporativo...');
    
    const adapted = {
      timestamp: Date.now(),
      version: LOADER_VERSION,
      user: {},
      pedidos: [],
      logs: [],
      config: {}
    };
    
    try {
      // Adaptar dados de picking
      if (backup.data.chromeStorage && backup.data.chromeStorage['nexos-picking-data']) {
        const pickingData = backup.data.chromeStorage['nexos-picking-data'];
        
        // Converter estrutura antiga para nova
        for (const loja in pickingData) {
          for (const pedido in pickingData[loja]) {
            const pedidoData = pickingData[loja][pedido];
            
            adapted.pedidos.push({
              PedidoID: `${loja}-${pedido}`,
              Loja: loja,
              NumeroPedido: pedido,
              Status: pedidoData.status || 'Novo',
              Plataforma: pedidoData.plataforma || 'Desconhecido',
              OrderUUID: pedidoData.order_uuid || pedidoData.uuid || null,
              ValorSolicitacao: pedidoData.valor_solicitacao || pedidoData.valor || null,
              NomeCliente: pedidoData.nome_cliente || null,
              EnderecoCompleto: pedidoData.endereco_completo || pedidoData.endereco || null,
              TelefoneCliente: pedidoData.celular_cliente || pedidoData.telefone_cliente || null,
              TrackingLink: pedidoData.link_rastreio || pedidoData.tracking_link || null,
              Observacoes: `Migrado da versão ${backup.version}`,
              DataCriacao: pedidoData.created_at || new Date().toISOString(),
              _migrated: true
            });
          }
        }
      }
      
      // Adaptar usuário
      if (backup.data.chromeStorage && backup.data.chromeStorage['nexos-user-full-name']) {
        adapted.user.fullName = backup.data.chromeStorage['nexos-user-full-name'];
      }
      
      // Adaptar logs
      if (backup.data.localStorage && backup.data.localStorage['nexos-logs']) {
        try {
          const logs = JSON.parse(backup.data.localStorage['nexos-logs']);
          adapted.logs = Array.isArray(logs) ? logs : [];
        } catch (e) {
          log('warn', 'Erro ao parsear logs antigos', { error: e.message });
        }
      }
      
      log('success', `✅ Dados adaptados: ${adapted.pedidos.length} pedidos, ${adapted.logs.length} logs`);
      
      return adapted;
      
    } catch (error) {
      log('error', 'Erro ao adaptar dados', { error: error.message });
      throw error;
    }
  }
  
  async function syncToSharePoint(data) {
    log('debug', 'Tentando sincronizar com SharePoint...');
    
    // Por enquanto, apenas salvar localmente para sincronização futura
    // A sincronização real será implementada quando GraphClient estiver disponível
    
    await saveStorageItem('nexos-pending-sync', {
      data,
      timestamp: Date.now(),
      syncAttempts: 0
    });
    
    log('info', '📝 Dados preparados para sincronização futura com SharePoint');
  }
  
  async function markAsMigrated(status) {
    await saveStorageItem(MIGRATION_FLAG_KEY, {
      ...status,
      loaderVersion: LOADER_VERSION
    });
    
    log('success', '✅ Migração marcada como concluída');
  }
  
  function showMigrationNotification(type) {
    const messages = {
      success: {
        title: '✨ Nexos Atualizado',
        message: 'Extensão migrada para modo corporativo com sucesso!'
      },
      error: {
        title: '⚠️ Nexos Atualizado',
        message: 'Extensão atualizada. Algumas funcionalidades serão sincronizadas gradualmente.'
      }
    };
    
    const notification = messages[type] || messages.success;
    
    try {
      // Notificação discreta via Chrome API
      chrome.notifications.create('nexos-migration', {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('images/logo.png'),
        title: notification.title,
        message: notification.message,
        priority: 0,
        requireInteraction: false
      });
      
      // Auto-fechar após 5 segundos
      setTimeout(() => {
        chrome.notifications.clear('nexos-migration');
      }, 5000);
      
    } catch (e) {
      log('warn', 'Não foi possível exibir notificação', { error: e.message });
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CARREGAMENTO DINÂMICO DE MÓDULOS
  // ═══════════════════════════════════════════════════════════════════════════
  
  async function loadSharePointConfig() {
    log('debug', 'Carregando configuração SharePoint...');
    
    try {
      // Tentar carregar config salva
      let config = await getStorageItem(SHAREPOINT_CONFIG_KEY);
      
      if (config && config.siteUrl) {
        log('success', '✅ Configuração SharePoint carregada do cache');
        LoaderState.config = config;
        return config;
      }
      
      // Usar configuração padrão
      config = { ...DEFAULT_SHAREPOINT_CONFIG };
      
      // Salvar para próxima vez
      await saveStorageItem(SHAREPOINT_CONFIG_KEY, config);
      
      LoaderState.config = config;
      log('info', '📝 Usando configuração padrão SharePoint', config);
      
      return config;
      
    } catch (error) {
      log('error', 'Erro ao carregar configuração', { error: error.message });
      
      // Fallback para configuração padrão
      LoaderState.config = { ...DEFAULT_SHAREPOINT_CONFIG };
      return LoaderState.config;
    }
  }
  
  async function loadModuleFromSharePoint(modulePath) {
    log('debug', `Carregando módulo: ${modulePath}`);
    
    // Verificar cache primeiro
    if (LoaderState.loadedModules.has(modulePath)) {
      log('debug', `✅ Módulo ${modulePath} já carregado (cache)`);
      return LoaderState.loadedModules.get(modulePath);
    }
    
    try {
      // TODO: Implementar carregamento real via Graph API
      // Por enquanto, usar arquivos locais como fallback
      
      const localPath = chrome.runtime.getURL(modulePath);
      const module = await import(localPath);
      
      LoaderState.loadedModules.set(modulePath, module);
      log('success', `✅ Módulo carregado: ${modulePath}`);
      
      return module;
      
    } catch (error) {
      log('error', `❌ Erro ao carregar módulo ${modulePath}`, { error: error.message });
      
      // Tentar fallback
      return await loadModuleFallback(modulePath);
    }
  }
  
  async function loadModuleFallback(modulePath) {
    log('warn', `🔄 Tentando fallback para ${modulePath}`);
    
    const config = LoaderState.config || DEFAULT_SHAREPOINT_CONFIG;
    
    for (const fallbackUrl of config.fallbackUrls || []) {
      try {
        const fullUrl = `${fallbackUrl}${modulePath}`;
        log('debug', `Tentando: ${fullUrl}`);
        
        const response = await fetch(fullUrl);
        
        if (response.ok) {
          const code = await response.text();
          
          // Executar código em contexto isolado
          const module = { exports: {} };
          const wrapper = new Function('module', 'exports', code);
          wrapper(module, module.exports);
          
          LoaderState.loadedModules.set(modulePath, module.exports);
          log('success', `✅ Módulo carregado via fallback: ${modulePath}`);
          
          return module.exports;
        }
        
      } catch (error) {
        log('warn', `Fallback falhou para ${fallbackUrl}`, { error: error.message });
      }
    }
    
    throw new Error(`Não foi possível carregar módulo: ${modulePath}`);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // UTILITÁRIOS DE STORAGE
  // ═══════════════════════════════════════════════════════════════════════════
  
  async function getStorageItem(key) {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        const result = await chrome.storage.local.get([key]);
        return result[key] || null;
      }
    } catch (error) {
      log('warn', `Fallback localStorage para leitura de ${key}`, { error: error.message });
    }
    
    // Fallback localStorage
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : null;
    } catch (e) {
      return null;
    }
  }
  
  async function saveStorageItem(key, value) {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        await chrome.storage.local.set({ [key]: value });
        return true;
      }
    } catch (error) {
      log('warn', `Fallback localStorage para escrita de ${key}`, { error: error.message });
    }
    
    // Fallback localStorage
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      log('error', `Erro ao salvar ${key}`, { error: e.message });
      return false;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // VERIFICAÇÃO DE SAÚDE DO SHAREPOINT
  // ═══════════════════════════════════════════════════════════════════════════
  
  async function checkSharePointHealth() {
    log('debug', '🏥 Verificando saúde do SharePoint...');
    
    try {
      const config = LoaderState.config || DEFAULT_SHAREPOINT_CONFIG;
      
      // Ping simples (sem autenticação)
      const healthUrl = `${config.siteUrl}/_api/web/title`;
      
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      
      const response = await fetch(healthUrl, {
        method: 'GET',
        headers: {
          'Accept': 'application/json;odata=nometadata'
        },
        signal: controller.signal
      });
      
      clearTimeout(timeout);
      
      const isHealthy = response.ok || response.status === 401; // 401 é ok (não autenticado)
      
      LoaderState.sharepointAvailable = isHealthy;
      
      if (isHealthy) {
        log('success', '✅ SharePoint disponível');
        await saveStorageItem(LAST_SUCCESSFUL_SYNC_KEY, Date.now());
      } else {
        log('warn', `⚠️ SharePoint retornou status ${response.status}`);
      }
      
      return isHealthy;
      
    } catch (error) {
      log('warn', '⚠️ SharePoint indisponível, modo fallback ativado', { error: error.message });
      LoaderState.sharepointAvailable = false;
      LoaderState.fallbackMode = true;
      
      await saveStorageItem(FALLBACK_MODE_KEY, {
        active: true,
        reason: error.message,
        timestamp: Date.now()
      });
      
      return false;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // INICIALIZAÇÃO PRINCIPAL
  // ═══════════════════════════════════════════════════════════════════════════
  
  async function initialize() {
    if (LoaderState.initialized) {
      log('warn', 'Loader já inicializado, ignorando...');
      return LoaderState;
    }
    
    const startTime = Date.now();
    
    log('info', '═══════════════════════════════════════════════════════════════');
    log('info', '🚀 NEXOS TORRE - LOADER CORPORATIVO v' + LOADER_VERSION);
    log('info', '═══════════════════════════════════════════════════════════════');
    
    try {
      // 1. Detectar e migrar automaticamente
      log('info', '📦 Etapa 1: Detecção e migração automática...');
      await detectAndMigrate();
      
      // 2. Carregar configuração SharePoint
      log('info', '⚙️ Etapa 2: Carregando configuração SharePoint...');
      await loadSharePointConfig();
      
      // 3. Verificar saúde do SharePoint
      log('info', '🏥 Etapa 3: Verificando conectividade SharePoint...');
      await checkSharePointHealth();
      
      // 4. Preparar ambiente corporativo
      log('info', '🏢 Etapa 4: Preparando ambiente corporativo...');
      await prepareEnvironment();
      
      // 5. Finalizar
      const duration = Date.now() - startTime;
      LoaderState.initialized = true;
      LoaderState.startTime = startTime;
      
      log('success', '═══════════════════════════════════════════════════════════════');
      log('success', `✨ LOADER INICIALIZADO COM SUCESSO em ${duration}ms`);
      log('success', '═══════════════════════════════════════════════════════════════');
      log('info', `Modo: ${LoaderState.fallbackMode ? '⚠️ FALLBACK (offline)' : '☁️ SHAREPOINT (online)'}`);
      log('info', `Migrado: ${LoaderState.migrated ? '✅ Sim' : '❌ Não'}`);
      log('info', `SharePoint: ${LoaderState.sharepointAvailable ? '✅ Disponível' : '⚠️ Indisponível'}`);
      log('success', '═══════════════════════════════════════════════════════════════');
      
      // Disparar evento de inicialização completa
      dispatchLoaderEvent('nexos:loader:ready', LoaderState);
      
      return LoaderState;
      
    } catch (error) {
      log('error', '═══════════════════════════════════════════════════════════════');
      log('error', '❌ ERRO CRÍTICO NO LOADER', { error: error.message, stack: error.stack });
      log('error', '═══════════════════════════════════════════════════════════════');
      
      // Ativar modo fallback de emergência
      LoaderState.fallbackMode = true;
      LoaderState.initialized = true; // Marcar como inicializado mesmo com erro
      
      dispatchLoaderEvent('nexos:loader:error', { error, state: LoaderState });
      
      return LoaderState;
    }
  }
  
  async function prepareEnvironment() {
    log('debug', 'Preparando ambiente corporativo...');
    
    try {
      // Criar namespace global Nexos
      if (typeof window !== 'undefined') {
        window.Nexos = window.Nexos || {};
        window.Nexos.Loader = {
          version: LOADER_VERSION,
          state: LoaderState,
          loadModule: loadModuleFromSharePoint,
          reload: initialize,
          getConfig: () => LoaderState.config
        };
        
        log('success', '✅ Namespace global Nexos criado');
      }
      
      // Expor utilitários globais
      if (typeof globalThis !== 'undefined') {
        globalThis.NexosLoader = window.Nexos?.Loader;
      }
      
    } catch (error) {
      log('warn', 'Erro ao preparar ambiente', { error: error.message });
    }
  }
  
  function dispatchLoaderEvent(eventName, detail) {
    try {
      if (typeof window !== 'undefined') {
        const event = new CustomEvent(eventName, { detail });
        window.dispatchEvent(event);
        log('debug', `📡 Evento disparado: ${eventName}`);
      }
    } catch (error) {
      log('warn', `Erro ao disparar evento ${eventName}`, { error: error.message });
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // AUTO-INICIALIZAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  // Inicializar automaticamente quando o script carregar
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      initialize().catch(err => {
        log('error', 'Erro durante inicialização', { error: err.message });
      });
    });
  } else {
    // DOM já carregado, inicializar imediatamente
    initialize().catch(err => {
      log('error', 'Erro durante inicialização', { error: err.message });
    });
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // EXPORTAR (para uso em módulos ES6)
  // ═══════════════════════════════════════════════════════════════════════════
  
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      initialize,
      loadModule: loadModuleFromSharePoint,
      state: LoaderState,
      version: LOADER_VERSION
    };
  }
  
})();
