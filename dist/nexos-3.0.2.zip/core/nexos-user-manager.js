/**
 * ============================================================================
 * NEXOS USER MANAGER
 * ============================================================================
 * Gerencia usuários da extensão no SharePoint
 * - Auto-registro no primeiro login
 * - Aprovação via Dash Admin
 * - Cache em memória
 * - CRUD de perfis
 * ============================================================================
 */

// Log IMEDIATO para confirmar que script foi carregado
console.log('[NexosUserManager] 🚀 Script iniciado (topo do arquivo)');

class NexosUserManager {
  constructor() {
    this.graphUrl = 'https://graph.microsoft.com/v1.0';
    this.siteId = null;
    this.listId = null;
    this.usersCache = new Map(); // email -> userData
    this.cacheExpiry = 5 * 60 * 1000; // 5 minutos
    this.initialized = false;
    
    // Usuário fixo sempre aprovado
    this.FIXED_ADMIN = 'leonardo.miguel@gpabr.com';
  }

  /**
   * Inicializar manager (obter IDs do site e lista)
   */
  async initialize() {
    if (this.initialized) return true;

    try {
      console.log('[NexosUserManager] 🔧 Inicializando...');
      
      // Obter token
      let token = await this._getAccessToken();
      
      // Obter Site ID
      let siteResponse = await this._fetch(
        `${this.graphUrl}/sites/gpabr.sharepoint.com:/sites/nexos`,
        { headers: { 'Authorization': `Bearer ${token}` } }
      );

      // 401 → token expirado — não tentar renovação de rede aqui (CSP bloqueia em páginas terceiras)
      // O token só pode ser renovado abrindo o Nexos Admin e fazendo login lá.
      if (siteResponse.status === 401) {
        return false;
      }
      if (!siteResponse.ok) {
        throw new Error(`Erro ao obter site: ${siteResponse.status}`);
      }
      
      const siteData = await siteResponse.json();
      this.siteId = siteData.id;
      
      // Obter List ID
      const listResponse = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists?$filter=displayName eq 'Nexos_Usuarios'`,
        { headers: { 'Authorization': `Bearer ${token}` } }
      );
      
      const listData = await listResponse.json();
      
      if (!listData.value || listData.value.length === 0) {
        throw new Error('Lista Nexos_Usuarios não encontrada. Execute o script de criação primeiro.');
      }
      
      this.listId = listData.value[0].id;
      this.initialized = true;
      
      console.log('[NexosUserManager] ✅ Inicializado!');
      console.log('[NexosUserManager] 📍 Site ID:', this.siteId);
      console.log('[NexosUserManager] 📋 List ID:', this.listId);
      
      return true;
    } catch (error) {
      const msg = error?.message || String(error);
      if (msg.includes('Extension context invalidated')) {
        // Silencioso: extensão foi recarregada, não é um erro real
        return false;
      }
      console.error('[NexosUserManager] ❌ Erro ao inicializar:', error);
      return false;
    }
  }

  /**
   * Obter token de acesso
   */
  async _getAccessToken() {
    // 1) NexosAuth em memória (sem rede)
    if (window.NexosAuth?.getToken) {
      try { const t = await window.NexosAuth.getToken(); if (t) return t; } catch (_) {}
    }
    // 2) chrome.storage.local (sem rede)
    if (typeof chrome !== 'undefined' && chrome.storage?.local) {
      try {
        const r = await new Promise(res => chrome.storage.local.get(['nexos-user-session'], res));
        const t = r['nexos-user-session']?.user?.accessToken;
        if (t) return t;
      } catch (_) {}
    }
    // 3) localStorage
    try {
      const raw = localStorage.getItem('nexos-user-session');
      if (raw) { const d = JSON.parse(raw); if (d?.user?.accessToken) return d.user.accessToken; }
    } catch (_) {}
    // 4) NexosAuth fallback
    if (window.NexosAuth) {
      const user = window.NexosAuth.getCurrentUser();
      if (user?.accessToken) return user.accessToken;
    }
    throw new Error('Token não disponível. Faça login na extensão Nexos.');
  }

  /**
   * Fetch com proxy CSP (para páginas de terceiros como Uber, Lalamove, etc.)
   */
  async _fetch(url, options = {}) {
    const isThirdParty = (() => {
      try {
        const h = window.location.hostname;
        return h !== 'picking-admin.backoffice.gpa.digital' &&
               !h.endsWith('.chromiumapp.org') &&
               !window.location.protocol.startsWith('chrome-extension');
      } catch (_) { return false; }
    })();
    if (isThirdParty) {
      // Em página de terceiro (Uber, Lalamove…) NUNCA fazer fetch direto — viola CSP.
      // Sempre rotear pelo background. Se o contexto estiver inválido, lançar erro claro.
      const canProxy = (() => {
        try { return typeof chrome !== 'undefined' && !!chrome.runtime?.sendMessage; } catch (_) { return false; }
      })();
      if (!canProxy) throw new Error('Extension context invalidated');
      return new Promise((resolve, reject) => {
        try {
          chrome.runtime.sendMessage({
            action: 'nexos_fetch',
            url,
            method: options.method || 'GET',
            headers: options.headers || {},
            body: options.body || undefined
          }, (response) => {
            if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
            if (!response) { reject(new Error('Sem resposta do background (proxy fetch)')); return; }
            resolve({
              ok: response.ok,
              status: response.status,
              text: () => Promise.resolve(response.body || ''),
              json: () => {
                try { return Promise.resolve(JSON.parse(response.body || '{}')); }
                catch (e) { return Promise.reject(new Error('JSON inválido: ' + response.body)); }
              }
            });
          });
        } catch (_e) { reject(new Error('Extension context invalidated')); }
      });
    }
    return fetch(url, options);
  }

  /**
   * Buscar usuário por email (com cache)
   */
  async getUserByEmail(email) {
    if (!email) return null;

    // Verificar cache
    const cached = this.usersCache.get(email);
    if (cached && (Date.now() - cached.timestamp < this.cacheExpiry)) {
      console.log('[NexosUserManager] 📦 Cache hit:', email);
      return cached.data;
    }

    // Buscar no SharePoint
    try {
      await this.initialize();
      const token = await this._getAccessToken();
      
      const response = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listId}/items?$filter=fields/Email eq '${email}'&$expand=fields`,
        { headers: { 'Authorization': `Bearer ${token}` } }
      );
      
      if (!response.ok) {
        // 401 = sessão expirada — não logar como erro crítico
        if (response.status === 401) {
          // sessão expirada
        } else {
          console.error('[NexosUserManager] ❌ Erro ao buscar usuário:', response.status);
        }
        return null;
      }
      
      const data = await response.json();
      
      if (!data.value || data.value.length === 0) {
        console.log('[NexosUserManager] ℹ️ Usuário não encontrado:', email);
        return null;
      }
      
      const userData = {
        itemId: data.value[0].id,
        ...data.value[0].fields
      };
      
      // Atualizar cache
      this.usersCache.set(email, {
        data: userData,
        timestamp: Date.now()
      });
      
      console.log('[NexosUserManager] ✅ Usuário encontrado:', email);
      return userData;
    } catch (error) {
      const msg = error?.message || String(error);
      if (msg.includes('Extension context invalidated')) return null; // silencioso
      console.error('[NexosUserManager] ❌ Erro ao buscar usuário:', error);
      return null;
    }
  }

  /**
   * Criar novo usuário (auto-registro)
   */
  async createUser(userInfo) {
    try {
      await this.initialize();
      const token = await this._getAccessToken();
      
      // Verificar se usuário já existe
      const existing = await this.getUserByEmail(userInfo.email);
      if (existing) {
        console.log('[NexosUserManager] ℹ️ Usuário já existe:', userInfo.email);
        return { success: true, user: existing, created: false };
      }
      
      // Determinar status inicial
      const isFixedAdmin = userInfo.email.toLowerCase() === this.FIXED_ADMIN.toLowerCase();
      const status = isFixedAdmin ? 'aprovado' : 'pendente';
      
      console.log('[NexosUserManager] 📝 Criando usuário:', userInfo.email);
      console.log('[NexosUserManager] 🔐 Status:', status, isFixedAdmin ? '(Admin Fixo)' : '(Aguardando Aprovação)');
      
      // Preparar campos (garantir tipos corretos)
      // IMPORTANTE: FotoURL deve ser uma URL do Graph API, não base64
      let fotoURL = '';
      if (userInfo.photo) {
        // Se for data URI (base64), converter para URL do Graph API
        if (userInfo.photo.startsWith('data:')) {
          fotoURL = userInfo.id ? `https://graph.microsoft.com/v1.0/users/${userInfo.id}/photo/$value` : '';
        } else {
          fotoURL = String(userInfo.photo);
        }
      }
      
      const fields = {
        Title: String(userInfo.displayName || userInfo.name || 'Usuário'),
        Email: String(userInfo.email),
        NomeCompleto: String(userInfo.name || userInfo.displayName || ''),
        NomeExibicao: String(userInfo.displayName || userInfo.name || ''),
        Cargo: String(userInfo.jobTitle || ''),
        Departamento: String(userInfo.department || ''),
        FotoURL: fotoURL,
        UserID: String(userInfo.id || userInfo.email),
        Ativo: true,
        Status: String(status),
        DataCriacao: new Date().toISOString(),
        UltimaAtualizacao: new Date().toISOString()
      };
      
      console.log('[NexosUserManager] 📊 Campos a enviar:', fields);
      
      // Criar item no SharePoint
      const response = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listId}/items`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ fields })
        }
      );
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('[NexosUserManager] ❌ Erro do SharePoint:', errorText);
        console.error('[NexosUserManager] 📍 URL:', `${this.graphUrl}/sites/${this.siteId}/lists/${this.listId}/items`);
        console.error('[NexosUserManager] 📊 Campos enviados:', fields);
        
        let errorMessage = `HTTP ${response.status}`;
        try {
          const errorJson = JSON.parse(errorText);
          errorMessage += `: ${errorJson.error?.message || errorText}`;
        } catch {
          errorMessage += `: ${errorText}`;
        }
        
        throw new Error(errorMessage);
      }
      
      const result = await response.json();
      const userData = {
        itemId: result.id,
        ...result.fields
      };
      
      // Atualizar cache
      this.usersCache.set(userInfo.email, {
        data: userData,
        timestamp: Date.now()
      });
      
      console.log('[NexosUserManager] ✅ Usuário criado com sucesso!');
      
      // Se não é admin, notificar que precisa aprovação
      if (!isFixedAdmin) {
        console.log('[NexosUserManager] ⏳ Usuário aguardando aprovação do administrador');
        
        // Mostrar toast informativo
        if (window.NexosUI?.showToast) {
          window.NexosUI.showToast(
            '⏳ Seu acesso está pendente de aprovação pelo administrador',
            'info',
            5000
          );
        }
      }
      
      return { success: true, user: userData, created: true, status };
    } catch (error) {
      console.error('[NexosUserManager] ❌ Erro ao criar usuário:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Atualizar dados do usuário
   */
  async updateUser(email, updates) {
    try {
      await this.initialize();
      const token = await this._getAccessToken();
      
      // Buscar usuário
      const user = await this.getUserByEmail(email);
      if (!user) {
        throw new Error('Usuário não encontrado');
      }
      
      console.log('[NexosUserManager] 📝 Atualizando usuário:', email);
      console.log('[NexosUserManager] 📊 Campos:', Object.keys(updates));
      
      // Adicionar timestamp de atualização
      updates.UltimaAtualizacao = new Date().toISOString();
      
      // Atualizar no SharePoint
      const response = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listId}/items/${user.itemId}`,
        {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ fields: updates })
        }
      );
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(`HTTP ${response.status}: ${error}`);
      }
      
      // Limpar cache
      this.usersCache.delete(email);
      
      console.log('[NexosUserManager] ✅ Usuário atualizado com sucesso!');
      
      return { success: true };
    } catch (error) {
      console.error('[NexosUserManager] ❌ Erro ao atualizar usuário:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Aprovar usuário (apenas admins)
   */
  async approveUser(email) {
    return await this.updateUser(email, {
      Status: 'aprovado',
      DataAprovacao: new Date().toISOString()
    });
  }

  /**
   * Rejeitar usuário (apenas admins)
   */
  async rejectUser(email, motivo = '') {
    return await this.updateUser(email, {
      Status: 'rejeitado',
      MotivoRejeicao: motivo,
      DataRejeicao: new Date().toISOString()
    });
  }

  /**
   * Listar usuários pendentes (para painel admin)
   */
  async getPendingUsers() {
    try {
      await this.initialize();
      const token = await this._getAccessToken();
      
      const response = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listId}/items?$filter=fields/Status eq 'pendente'&$expand=fields&$orderby=fields/DataCriacao desc`,
        { headers: { 'Authorization': `Bearer ${token}` } }
      );
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      const data = await response.json();
      
      return {
        success: true,
        users: data.value.map(item => ({
          itemId: item.id,
          ...item.fields
        }))
      };
    } catch (error) {
      console.error('[NexosUserManager] ❌ Erro ao listar pendentes:', error);
      return { success: false, error: error.message, users: [] };
    }
  }

  /**
   * Verificar se usuário tem acesso (status aprovado)
   */
  async checkUserAccess(email) {
    const user = await this.getUserByEmail(email);
    
    // Admin fixo sempre tem acesso, mas pode não estar cadastrado
    const isFixedAdmin = email.toLowerCase() === this.FIXED_ADMIN.toLowerCase();
    
    if (!user) {
      return { 
        hasAccess: isFixedAdmin, // Admin tem acesso mesmo sem registro
        status: 'nao_cadastrado', 
        isAdmin: isFixedAdmin,
        user: null 
      };
    }
    
    const hasAccess = user.Status === 'aprovado' && user.Ativo === true;
    
    return {
      hasAccess,
      status: user.Status,
      isAdmin: isFixedAdmin,
      user
    };
  }

  /**
   * Limpar cache
   */
  clearCache() {
    this.usersCache.clear();
    console.log('[NexosUserManager] 🗑️ Cache limpo');
  }
}

// ============================================================================
// EXPORTAR INSTÂNCIA GLOBAL
// ============================================================================
if (typeof window !== 'undefined') {
  try {
    if (!window.NexosUserManager) {
      console.log('[NexosUserManager] 📦 Criando instância...');
      window.NexosUserManager = new NexosUserManager();
      console.log('[NexosUserManager] ✅ Instância criada e exportada');
    } else {
      console.log('[NexosUserManager] ⚠️ Instância já existe (reload ou script duplicado)');
    }
    
    // Verificação final
    if (window.NexosUserManager && typeof window.NexosUserManager.initialize === 'function') {
      console.log('[NexosUserManager] ✅ Módulo carregado e pronto para uso');
    } else {
      console.error('[NexosUserManager] ❌ Exportação incompleta! Verificar construtor.');
    }
  } catch (error) {
    console.error('[NexosUserManager] ❌ ERRO FATAL ao criar instância:', error);
    console.error('[NexosUserManager] 📍 Stack:', error.stack);
  }
} else {
  console.warn('[NexosUserManager] ⚠️ window não disponível (ambiente Node.js?)');
}
