// ===================================================================
// NEXOS - LogManager
// Sistema centralizado de logs persistentes com rotation automática
// ===================================================================

/**
 * @typedef {Object} LogEntry
 * @property {string} id - ID único do log (timestamp + random)
 * @property {string} level - Nível: INFO, WARN, ERROR, DEBUG
 * @property {string} module - Módulo de origem: content, background, whatsapp, admin
 * @property {string} action - Ação executada: picking_extract, uber_request, etc
 * @property {string} message - Mensagem descritiva
 * @property {number} timestamp - Unix timestamp em ms
 * @property {string} user - Email/nome do usuário (se autenticado)
 * @property {Object} metadata - Dados adicionais
 * @property {string} [metadata.pedido] - Número do pedido
 * @property {string} [metadata.loja] - Código da loja
 * @property {string} [metadata.platform] - Plataforma: Uber, Lalamove, 99, etc
 * @property {number} [metadata.duration] - Duração da operação em ms
 * @property {string} [metadata.error] - Mensagem de erro (se houver)
 * @property {string} [metadata.status] - Status: success, error, pending
 */

class LogManager {
  constructor() {
    this.storageKey = '__nexos_logs';
    this.sessionKey = '__nexos_session';
    this.maxLogs = 1000; // Máximo de logs armazenados
    this.currentUser = null;
    this.initialized = false;
    
    console.log('[LogManager] Inicializando...');
  }

  /**
   * Inicializa o LogManager e carrega sessão atual
   */
  async initialize() {
    if (this.initialized) return;

    try {
      // Carregar sessão atual
      const session = await this._getFromStorage(this.sessionKey);
      if (session && session.user) {
        this.currentUser = session.user;
        console.log('[LogManager] Sessão restaurada:', this.currentUser);
      }

      this.initialized = true;
      await this.log('INFO', 'system', 'log_manager_initialized', 'LogManager inicializado');
    } catch (error) {
      console.error('[LogManager] Erro ao inicializar:', error);
    }
  }

  /**
   * Registra um log
   * @param {string} level - INFO, WARN, ERROR, DEBUG
   * @param {string} module - content, background, whatsapp, admin
   * @param {string} action - picking_extract, uber_request, etc
   * @param {string} message - Mensagem descritiva
   * @param {Object} metadata - Dados adicionais
   */
  async log(level, module, action, message, metadata = {}) {
    try {
      const entry = {
        id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        level: level.toUpperCase(),
        module,
        action,
        message,
        timestamp: Date.now(),
        user: this.currentUser || 'anonymous',
        metadata: {
          ...metadata,
          userAgent: navigator.userAgent,
          url: typeof window !== 'undefined' ? window.location?.href : 'background'
        }
      };

      // Adicionar log ao storage
      await this._appendLog(entry);

      // Log no console para debug
      const emoji = this._getLevelEmoji(level);
      console.log(`${emoji} [${module.toUpperCase()}] ${message}`, metadata);

      // Verificar alertas críticos
      if (level === 'ERROR') {
        await this._createAlert(entry);
      }

      return entry;
    } catch (error) {
      console.error('[LogManager] Erro ao registrar log:', error);
    }
  }

  /**
   * Métodos de conveniência
   */
  async info(module, action, message, metadata) {
    return this.log('INFO', module, action, message, metadata);
  }

  async warn(module, action, message, metadata) {
    return this.log('WARN', module, action, message, metadata);
  }

  async error(module, action, message, metadata) {
    return this.log('ERROR', module, action, message, metadata);
  }

  async debug(module, action, message, metadata) {
    return this.log('DEBUG', module, action, message, metadata);
  }

  /**
   * Busca logs com filtros
   * @param {Object} filters - Filtros de busca
   * @param {string} [filters.level] - Filtrar por nível
   * @param {string} [filters.module] - Filtrar por módulo
   * @param {string} [filters.action] - Filtrar por ação
   * @param {string} [filters.user] - Filtrar por usuário
   * @param {number} [filters.startDate] - Data início (timestamp)
   * @param {number} [filters.endDate] - Data fim (timestamp)
   * @param {string} [filters.search] - Busca em message/metadata
   * @param {number} [filters.limit] - Limite de resultados (padrão: 50)
   * @param {number} [filters.offset] - Offset para paginação (padrão: 0)
   * @returns {Promise<{logs: LogEntry[], total: number}>}
   */
  async searchLogs(filters = {}) {
    try {
      const allLogs = await this._getFromStorage(this.storageKey) || [];
      
      // Aplicar filtros
      let filtered = allLogs.filter(log => {
        // Filtro de níveis múltiplos (array)
        if (filters.levels && filters.levels.length > 0) {
          if (!filters.levels.includes(log.level.toUpperCase())) return false;
        }
        
        // Filtro de nível único (retrocompatibilidade)
        if (filters.level && log.level !== filters.level.toUpperCase()) return false;
        
        if (filters.module && log.module !== filters.module) return false;
        if (filters.action && log.action !== filters.action) return false;
        if (filters.user && log.user !== filters.user) return false;
        
        // Filtros de data com suporte a string ISO (YYYY-MM-DD)
        if (filters.dateStart) {
          const startTimestamp = typeof filters.dateStart === 'string' 
            ? new Date(filters.dateStart + 'T00:00:00').getTime() 
            : filters.dateStart;
          if (log.timestamp < startTimestamp) return false;
        }
        
        if (filters.dateEnd) {
          const endTimestamp = typeof filters.dateEnd === 'string' 
            ? new Date(filters.dateEnd + 'T23:59:59').getTime() 
            : filters.dateEnd;
          if (log.timestamp > endTimestamp) return false;
        }
        
        // Retrocompatibilidade com startDate/endDate
        if (filters.startDate && log.timestamp < filters.startDate) return false;
        if (filters.endDate && log.timestamp > filters.endDate) return false;
        
        if (filters.search) {
          const searchLower = filters.search.toLowerCase();
          const messageMatch = log.message.toLowerCase().includes(searchLower);
          const metadataMatch = JSON.stringify(log.metadata).toLowerCase().includes(searchLower);
          if (!messageMatch && !metadataMatch) return false;
        }
        
        return true;
      });

      // Ordenar por timestamp decrescente (mais recente primeiro)
      filtered.sort((a, b) => b.timestamp - a.timestamp);

      const total = filtered.length;
      const limit = filters.limit || 50;
      const offset = filters.offset || 0;
      
      // Paginação
      const logs = filtered.slice(offset, offset + limit);

      return { logs, total };
    } catch (error) {
      console.error('[LogManager] Erro ao buscar logs:', error);
      return { logs: [], total: 0 };
    }
  }

  /**
   * Obtém estatísticas agregadas
   * @param {number} periodDays - Período em dias (padrão: 7)
   * @returns {Promise<Object>}
   */
  async getStatistics(periodDays = 7) {
    try {
      const startDate = Date.now() - (periodDays * 24 * 60 * 60 * 1000);
      const { logs } = await this.searchLogs({ startDate, limit: 10000 });

      const stats = {
        total: logs.length,
        byLevel: {},
        byModule: {},
        byAction: {},
        byUser: {},
        byPlatform: {},
        byHour: Array(24).fill(0),
        errorRate: 0,
        avgDuration: 0,
        topUsers: [],
        topActions: []
      };

      let totalDuration = 0;
      let durationCount = 0;
      let errorCount = 0;

      logs.forEach(log => {
        // Por nível
        stats.byLevel[log.level] = (stats.byLevel[log.level] || 0) + 1;
        
        // Por módulo
        stats.byModule[log.module] = (stats.byModule[log.module] || 0) + 1;
        
        // Por ação
        stats.byAction[log.action] = (stats.byAction[log.action] || 0) + 1;
        
        // Por usuário
        stats.byUser[log.user] = (stats.byUser[log.user] || 0) + 1;
        
        // Por plataforma
        if (log.metadata.platform) {
          stats.byPlatform[log.metadata.platform] = (stats.byPlatform[log.metadata.platform] || 0) + 1;
        }
        
        // Por hora do dia
        const hour = new Date(log.timestamp).getHours();
        stats.byHour[hour]++;
        
        // Duração média
        if (log.metadata.duration) {
          totalDuration += log.metadata.duration;
          durationCount++;
        }
        
        // Taxa de erro
        if (log.level === 'ERROR') {
          errorCount++;
        }
      });

      stats.errorRate = logs.length > 0 ? (errorCount / logs.length * 100).toFixed(2) : 0;
      stats.avgDuration = durationCount > 0 ? Math.round(totalDuration / durationCount) : 0;

      // Top 5 usuários
      stats.topUsers = Object.entries(stats.byUser)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([user, count]) => ({ user, count }));

      // Top 10 ações
      stats.topActions = Object.entries(stats.byAction)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([action, count]) => ({ action, count }));

      return stats;
    } catch (error) {
      console.error('[LogManager] Erro ao calcular estatísticas:', error);
      return null;
    }
  }

  /**
   * Exporta logs para JSON
   * @param {Object} filters - Filtros para exportação
   * @returns {Promise<string>} JSON string
   */
  async exportLogs(filters = {}) {
    const { logs } = await this.searchLogs({ ...filters, limit: 10000 });
    return JSON.stringify(logs, null, 2);
  }

  /**
   * Limpa logs antigos
   * @param {number} daysOld - Limpar logs mais antigos que X dias
   */
  async cleanOldLogs(daysOld = 30) {
    try {
      const cutoffDate = Date.now() - (daysOld * 24 * 60 * 60 * 1000);
      const allLogs = await this._getFromStorage(this.storageKey) || [];
      
      const filtered = allLogs.filter(log => log.timestamp >= cutoffDate);
      const removed = allLogs.length - filtered.length;
      
      await this._saveToStorage(this.storageKey, filtered);
      
      console.log(`[LogManager] Limpeza concluída: ${removed} logs removidos`);
      return removed;
    } catch (error) {
      console.error('[LogManager] Erro ao limpar logs:', error);
    }
  }

  /**
   * Define o usuário atual da sessão
   * @param {string} user - Email ou nome do usuário
   */
  async setCurrentUser(user) {
    this.currentUser = user;
    await this._saveToStorage(this.sessionKey, { user, timestamp: Date.now() });
    await this.info('system', 'user_login', `Usuário logado: ${user}`);
  }

  /**
   * Remove o usuário atual
   */
  async clearCurrentUser() {
    const previousUser = this.currentUser;
    this.currentUser = null;
    await this._saveToStorage(this.sessionKey, null);
    await this.info('system', 'user_logout', `Usuário deslogado: ${previousUser}`);
  }

  /**
   * Obtém sessões ativas (últimas 24h)
   */
  async getActiveSessions() {
    const last24h = Date.now() - (24 * 60 * 60 * 1000);
    const { logs } = await this.searchLogs({ 
      action: 'user_login',
      startDate: last24h,
      limit: 1000
    });

    const sessions = {};
    logs.forEach(log => {
      if (!sessions[log.user] || sessions[log.user].timestamp < log.timestamp) {
        sessions[log.user] = {
          user: log.user,
          lastSeen: log.timestamp,
          status: this._getSessionStatus(log.timestamp)
        };
      }
    });

    return Object.values(sessions);
  }

  // ===================================================================
  // Métodos privados
  // ===================================================================

  async _appendLog(entry) {
    try {
      let logs = await this._getFromStorage(this.storageKey) || [];
      
      // Adicionar novo log
      logs.push(entry);
      
      // Rotation: manter apenas os últimos N logs
      if (logs.length > this.maxLogs) {
        logs = logs.slice(-this.maxLogs);
      }
      
      await this._saveToStorage(this.storageKey, logs);
    } catch (error) {
      console.error('[LogManager] Erro ao adicionar log:', error);
    }
  }

  async _createAlert(logEntry) {
    try {
      const alertKey = '__nexos_alerts';
      let alerts = await this._getFromStorage(alertKey) || [];
      
      const alert = {
        id: logEntry.id,
        type: 'error',
        message: logEntry.message,
        timestamp: logEntry.timestamp,
        read: false,
        source: logEntry
      };
      
      alerts.push(alert);
      
      // Manter últimos 50 alertas
      if (alerts.length > 50) {
        alerts = alerts.slice(-50);
      }
      
      await this._saveToStorage(alertKey, alerts);
      
      // Badge na extensão
      if (typeof chrome !== 'undefined' && chrome.action) {
        const unreadCount = alerts.filter(a => !a.read).length;
        chrome.action.setBadgeText({ text: unreadCount > 0 ? String(unreadCount) : '' });
        chrome.action.setBadgeBackgroundColor({ color: '#FF0000' });
      }
    } catch (error) {
      console.error('[LogManager] Erro ao criar alerta:', error);
    }
  }

  async _getFromStorage(key) {
    // Tentar chrome.storage primeiro
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        const result = await chrome.storage.local.get([key]);
        return result[key];
      } catch (error) {
        // Fallback para localStorage se chrome.storage não disponível
        console.warn('[LogManager] chrome.storage não disponível, usando localStorage');
      }
    }
    
    // Fallback: localStorage
    try {
      const item = localStorage.getItem(`nexos-log-${key}`);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.warn('[LogManager] Erro ao ler do localStorage:', error);
      return null;
    }
  }

  async _saveToStorage(key, value) {
    // Tentar chrome.storage primeiro
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        await chrome.storage.local.set({ [key]: value });
        return;
      } catch (error) {
        console.warn('[LogManager] chrome.storage não disponível, usando localStorage');
      }
    }
    
    // Fallback: localStorage
    try {
      localStorage.setItem(`nexos-log-${key}`, JSON.stringify(value));
    } catch (error) {
      console.warn('[LogManager] Erro ao salvar no localStorage:', error);
    }
  }

  _getLevelEmoji(level) {
    const emojis = {
      'INFO': 'ℹ️',
      'WARN': '⚠️',
      'ERROR': '❌',
      'DEBUG': '🔍'
    };
    return emojis[level.toUpperCase()] || '📝';
  }

  _getSessionStatus(lastSeen) {
    const now = Date.now();
    const diff = now - lastSeen;
    
    if (diff < 5 * 60 * 1000) return 'online'; // < 5min
    if (diff < 30 * 60 * 1000) return 'idle'; // < 30min
    return 'offline';
  }
}

// ===================================================================
// EXPORT - Garantir que LogManager seja disponibilizado globalmente
// ===================================================================

// Para páginas web (content scripts, admin, etc)
if (typeof window !== 'undefined') {
  window.LogManager = LogManager;
  console.log('[LogManager] ✅ Exportado para window.LogManager');
}

// Para service workers (background.js)
if (typeof self !== 'undefined' && typeof WorkerGlobalScope !== 'undefined') {
  self.LogManager = LogManager;
  console.log('[LogManager] ✅ Exportado para self.LogManager');
}

// Fallback global
if (typeof globalThis !== 'undefined') {
  globalThis.LogManager = LogManager;
}
