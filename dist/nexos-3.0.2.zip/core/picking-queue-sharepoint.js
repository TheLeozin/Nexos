/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - PICKING QUEUE SHAREPOINT INTEGRATION v3.0.0
 * Gerencia fila de processamento em lote com sistema de locks distribuídos
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * FUNCIONALIDADES:
 * - Adiciona pedidos à fila para processamento em lote
 * - Sistema de locks distribuídos (evita race conditions)
 * - Priorização de pedidos
 * - Processamento paralelo seguro entre múltiplos usuários
 * - Auto-limpeza de locks expirados
 * 
 * LISTA SHAREPOINT: Nexos_FilaPedidos
 * 
 * @version 3.0.0
 * @date 2026-01-08
 */

(function() {
  'use strict';

  // ═══════════════════════════════════════════════════════════════════════════
  // CONFIGURAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  const CONFIG = {
    LIST_NAME: 'Nexos_FilaPedidos',
    MAX_RETRIES: 3,
    RETRY_DELAY_MS: 1000,
    DEFAULT_LOCK_MINUTES: 10,
    CLEANUP_INTERVAL_MS: 5 * 60 * 1000, // 5 minutos
    MAX_BATCH_SIZE: 50
  };

  // Status da fila
  const STATUS_FILA = {
    AGUARDANDO: 'Aguardando',
    PROCESSANDO: 'Processando',
    CONCLUIDO: 'Concluído',
    ERRO: 'Erro',
    CANCELADO: 'Cancelado'
  };

  // Níveis de prioridade
  const PRIORIDADE = {
    BAIXA: 1,
    NORMAL: 2,
    ALTA: 3,
    URGENTE: 4
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // CLASSE PRINCIPAL
  // ═══════════════════════════════════════════════════════════════════════════

  class PickingQueueSharePoint {
    constructor() {
      this.graphClient = null;
      this.currentUser = null;
      this.cleanupTimer = null;
    }

    /**
     * Inicializa o manager
     */
    async initialize() {
      try {
        console.log('[QueueSharePoint] Inicializando...');
        
        // Aguardar graph-client-init.js carregar
        if (typeof window !== 'undefined' && !window.graphClient) {
          await new Promise((resolve) => {
            const onReady = () => resolve();
            window.addEventListener('nexos-graphclient-ready', onReady, { once: true });
            
            setTimeout(() => {
              window.removeEventListener('nexos-graphclient-ready', onReady);
              resolve();
            }, 15000);
            
            if (window.graphClient) resolve();
          });
        }
        
        // Obter Graph Client
        if (typeof window !== 'undefined' && window.graphClient) {
          this.graphClient = window.graphClient;
          this.currentUser = window.currentUser;
          
          // Iniciar timer de limpeza automática
          this.startCleanupTimer();
          
          console.log('[QueueSharePoint] ✅ Inicializado com sucesso');
          return true;
        }
        
        console.warn('[QueueSharePoint] ⚠️ Graph Client não disponível');
        return false;
        
      } catch (error) {
        console.error('[QueueSharePoint] ❌ Erro na inicialização:', error);
        return false;
      }
    }

    /**
     * Adiciona pedido à fila
     * @param {Object} options - Configurações do item da fila
     * @returns {Object} Resultado da operação
     */
    async adicionarNaFila({
      pedidoGPAID,
      pedidoID,
      plataforma,
      prioridade = PRIORIDADE.NORMAL,
      loteID = null,
      dadosPedidoJSON = null,
      observacoes = null
    }) {
      try {
        console.log('[QueueSharePoint] ➕ Adicionando à fila:', { pedidoGPAID, plataforma, prioridade });

        // Validar parâmetros
        if (!pedidoGPAID) {
          throw new Error('pedidoGPAID é obrigatório');
        }
        if (!pedidoID) {
          throw new Error('pedidoID é obrigatório');
        }
        if (!plataforma) {
          throw new Error('plataforma é obrigatória');
        }

        // Verificar se já existe na fila
        const existente = await this.buscarPorPedidoID(pedidoID);
        if (existente && existente.statusFila !== STATUS_FILA.CONCLUIDO && existente.statusFila !== STATUS_FILA.ERRO) {
          console.warn('[QueueSharePoint] ⚠️ Pedido já está na fila:', existente.id);
          return {
            success: false,
            error: 'Pedido já existe na fila',
            itemId: existente.id
          };
        }

        // Obter próxima posição na fila
        const proximaPosicao = await this.obterProximaPosicao();

        // Preparar item para SharePoint
        const queueItem = {
          fields: {
            // Identificação
            PedidoGPAID: pedidoGPAID,
            PedidoID: pedidoID,
            Plataforma: plataforma,
            
            // Fila
            StatusFila: STATUS_FILA.AGUARDANDO,
            Prioridade: prioridade,
            PosicaoFila: proximaPosicao,
            LoteID: loteID,
            
            // Timestamps
            DataCriacao: new Date().toISOString(),
            DataUltimaAtualizacao: new Date().toISOString(),
            
            // Processamento (null inicialmente)
            ProcessadorAtual: null,
            LockExpiry: null,
            DataInicio: null,
            DataConclusao: null,
            
            // Resultado
            Sucesso: false,
            MensagemErro: null,
            ResultadoJSON: null,
            
            // Dados
            DadosPedidoJSON: dadosPedidoJSON ? JSON.stringify(dadosPedidoJSON) : null,
            Observacoes: observacoes,
            VersaoExtensao: chrome.runtime.getManifest().version
          }
        };

        // Salvar no SharePoint
        const result = await this.saveWithRetry(queueItem);

        if (result.success) {
          console.log('[QueueSharePoint] ✅ Adicionado à fila:', result.itemId);
          
          // Atualizar campo TemItemsNaFila no pedido master
          await this.atualizarFlagFila(pedidoID, true);
          
          return {
            success: true,
            itemId: result.itemId,
            posicaoFila: proximaPosicao,
            message: 'Pedido adicionado à fila com sucesso'
          };
        } else {
          throw new Error(result.error || 'Falha ao salvar no SharePoint');
        }

      } catch (error) {
        console.error('[QueueSharePoint] ❌ Erro ao adicionar à fila:', error);
        return {
          success: false,
          error: error.message,
          stack: error.stack
        };
      }
    }

    /**
     * Processa próximo pedido da fila (com lock)
     * @param {number} lockMinutes - Tempo de lock em minutos
     * @returns {Object|null} Dados do pedido ou null se fila vazia
     */
    async processarProximo(lockMinutes = CONFIG.DEFAULT_LOCK_MINUTES) {
      try {
        console.log('[QueueSharePoint] 🔍 Buscando próximo pedido...');

        if (!this.graphClient) {
          throw new Error('Graph Client não disponível');
        }

        // Buscar pedidos aguardando, ordenados por prioridade e posição
        const filter = `fields/StatusFila eq '${STATUS_FILA.AGUARDANDO}'`;
        const orderBy = 'fields/Prioridade desc,fields/PosicaoFila asc';
        
        const response = await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items`)
          .filter(filter)
          .orderby(orderBy)
          .expand('fields')
          .top(1)
          .get();

        if (response.value.length === 0) {
          console.log('[QueueSharePoint] 📭 Fila vazia');
          return null;
        }

        const item = response.value[0];
        const lockExpiry = new Date(Date.now() + lockMinutes * 60 * 1000).toISOString();

        // Atualizar com lock
        await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items/${item.id}`)
          .update({
            fields: {
              StatusFila: STATUS_FILA.PROCESSANDO,
              ProcessadorAtual: this.currentUser?.email || 'unknown',
              LockExpiry: lockExpiry,
              DataInicio: new Date().toISOString(),
              DataUltimaAtualizacao: new Date().toISOString()
            }
          });

        console.log('[QueueSharePoint] ✅ Pedido obtido e travado:', item.id);

        // Retornar dados formatados
        return {
          id: item.id,
          pedidoGPAID: item.fields.PedidoGPAID,
          pedidoID: item.fields.PedidoID,
          plataforma: item.fields.Plataforma,
          prioridade: item.fields.Prioridade,
          dadosPedido: item.fields.DadosPedidoJSON ? JSON.parse(item.fields.DadosPedidoJSON) : null,
          observacoes: item.fields.Observacoes,
          lockExpiry: lockExpiry
        };

      } catch (error) {
        console.error('[QueueSharePoint] ❌ Erro ao processar próximo:', error);
        return null;
      }
    }

    /**
     * Marca processamento como concluído
     * @param {number} filaID - ID do item na fila
     * @param {boolean} sucesso - Se processamento foi bem-sucedido
     * @param {Object} resultado - Dados do resultado
     * @returns {Object} Resultado da operação
     */
    async concluirProcessamento(filaID, sucesso, resultado = {}) {
      try {
        console.log('[QueueSharePoint] ✅ Concluindo processamento:', filaID);

        const updateData = {
          fields: {
            StatusFila: sucesso ? STATUS_FILA.CONCLUIDO : STATUS_FILA.ERRO,
            Sucesso: sucesso,
            MensagemErro: resultado.error || null,
            ResultadoJSON: JSON.stringify(resultado),
            DataConclusao: new Date().toISOString(),
            DataUltimaAtualizacao: new Date().toISOString(),
            ProcessadorAtual: null,
            LockExpiry: null
          }
        };

        await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items/${filaID}`)
          .update(updateData);

        console.log('[QueueSharePoint] ✅ Processamento concluído');

        return { success: true };

      } catch (error) {
        console.error('[QueueSharePoint] ❌ Erro ao concluir processamento:', error);
        return { success: false, error: error.message };
      }
    }

    /**
     * Cancela item da fila
     * @param {number} filaID - ID do item
     * @param {string} motivo - Motivo do cancelamento
     */
    async cancelarItem(filaID, motivo = null) {
      try {
        await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items/${filaID}`)
          .update({
            fields: {
              StatusFila: STATUS_FILA.CANCELADO,
              MensagemErro: motivo,
              DataConclusao: new Date().toISOString(),
              DataUltimaAtualizacao: new Date().toISOString(),
              ProcessadorAtual: null,
              LockExpiry: null
            }
          });

        console.log('[QueueSharePoint] ❌ Item cancelado:', filaID);
        return { success: true };

      } catch (error) {
        console.error('[QueueSharePoint] Erro ao cancelar item:', error);
        return { success: false, error: error.message };
      }
    }

    /**
     * Remove locks expirados
     * @returns {number} Quantidade de locks limpos
     */
    async limparLocksExpirados() {
      try {
        console.log('[QueueSharePoint] 🧹 Limpando locks expirados...');

        if (!this.graphClient) {
          return 0;
        }

        const now = new Date().toISOString();
        const filter = `fields/StatusFila eq '${STATUS_FILA.PROCESSANDO}' and fields/LockExpiry lt datetime'${now}'`;
        
        const response = await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items`)
          .filter(filter)
          .expand('fields')
          .top(CONFIG.MAX_BATCH_SIZE)
          .get();

        let cleaned = 0;

        for (const item of response.value) {
          try {
            await this.graphClient
              .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items/${item.id}`)
              .update({
                fields: {
                  StatusFila: STATUS_FILA.AGUARDANDO,
                  ProcessadorAtual: null,
                  LockExpiry: null,
                  DataUltimaAtualizacao: new Date().toISOString()
                }
              });
            
            cleaned++;
          } catch (err) {
            console.warn('[QueueSharePoint] Erro ao limpar lock:', item.id, err);
          }
        }

        if (cleaned > 0) {
          console.log(`[QueueSharePoint] ✅ ${cleaned} locks expirados limpos`);
        }

        return cleaned;

      } catch (error) {
        // Log silencioso - graphClient pode não estar disponível
        console.debug('[QueueSharePoint] ℹ️ Limpeza de locks não executada:', error.message);
        return 0;
      }
    }

    /**
     * Obtém estatísticas da fila
     */
    async obterEstatisticas() {
      try {
        if (!this.graphClient) {
          return null;
        }

        const response = await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items`)
          .expand('fields')
          .top(1000)
          .get();

        const items = response.value;

        const stats = {
          total: items.length,
          aguardando: items.filter(i => i.fields.StatusFila === STATUS_FILA.AGUARDANDO).length,
          processando: items.filter(i => i.fields.StatusFila === STATUS_FILA.PROCESSANDO).length,
          concluido: items.filter(i => i.fields.StatusFila === STATUS_FILA.CONCLUIDO).length,
          erro: items.filter(i => i.fields.StatusFila === STATUS_FILA.ERRO).length,
          cancelado: items.filter(i => i.fields.StatusFila === STATUS_FILA.CANCELADO).length,
          porPlataforma: {},
          porPrioridade: {}
        };

        // Contar por plataforma
        items.forEach(item => {
          const plat = item.fields.Plataforma || 'Indefinida';
          stats.porPlataforma[plat] = (stats.porPlataforma[plat] || 0) + 1;
        });

        // Contar por prioridade
        items.forEach(item => {
          const prio = item.fields.Prioridade || 0;
          stats.porPrioridade[prio] = (stats.porPrioridade[prio] || 0) + 1;
        });

        return stats;

      } catch (error) {
        console.error('[QueueSharePoint] Erro ao obter estatísticas:', error);
        return null;
      }
    }

    /**
     * Busca item da fila por PedidoID
     */
    async buscarPorPedidoID(pedidoID) {
      try {
        const filter = `fields/PedidoID eq '${pedidoID}'`;
        const response = await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items`)
          .filter(filter)
          .expand('fields')
          .top(1)
          .get();

        if (response.value.length === 0) {
          return null;
        }

        const item = response.value[0];
        return {
          id: item.id,
          pedidoGPAID: item.fields.PedidoGPAID,
          pedidoID: item.fields.PedidoID,
          statusFila: item.fields.StatusFila,
          prioridade: item.fields.Prioridade,
          posicaoFila: item.fields.PosicaoFila
        };

      } catch (error) {
        console.error('[QueueSharePoint] Erro ao buscar por PedidoID:', error);
        return null;
      }
    }

    /**
     * Obtém próxima posição disponível na fila
     */
    async obterProximaPosicao() {
      try {
        const response = await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items`)
          .orderby('fields/PosicaoFila desc')
          .expand('fields')
          .top(1)
          .get();

        if (response.value.length === 0) {
          return 1;
        }

        return (response.value[0].fields.PosicaoFila || 0) + 1;

      } catch (error) {
        console.warn('[QueueSharePoint] Erro ao obter próxima posição, usando 1:', error);
        return 1;
      }
    }

    /**
     * Atualiza flag TemItemsNaFila no pedido master
     */
    async atualizarFlagFila(pedidoID, temItems) {
      try {
        // Buscar pedido no Nexos_StatusPedidos
        const filter = `fields/PedidoID eq '${pedidoID}'`;
        const response = await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/Nexos_StatusPedidos/items`)
          .filter(filter)
          .top(1)
          .get();

        if (response.value.length > 0) {
          await this.graphClient
            .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/Nexos_StatusPedidos/items/${response.value[0].id}`)
            .update({
              fields: {
                TemItemsNaFila: temItems,
                DataUltimaAtualizacao: new Date().toISOString()
              }
            });
        }

      } catch (error) {
        console.warn('[QueueSharePoint] Erro ao atualizar flag fila:', error);
      }
    }

    /**
     * Salva item no SharePoint com retry
     */
    async saveWithRetry(itemData, attempt = 1) {
      try {
        if (!this.graphClient) {
          return { success: false, error: 'Graph Client não disponível' };
        }

        const response = await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items`)
          .post(itemData);

        return {
          success: true,
          itemId: response.id,
          data: response
        };

      } catch (error) {
        console.warn(`[QueueSharePoint] Tentativa ${attempt}/${CONFIG.MAX_RETRIES} falhou:`, error.message);

        if (attempt < CONFIG.MAX_RETRIES) {
          await new Promise(resolve => setTimeout(resolve, CONFIG.RETRY_DELAY_MS * attempt));
          return this.saveWithRetry(itemData, attempt + 1);
        }

        return {
          success: false,
          error: error.message,
          statusCode: error.statusCode
        };
      }
    }

    /**
     * Inicia timer de limpeza automática
     */
    startCleanupTimer() {
      if (this.cleanupTimer) {
        clearInterval(this.cleanupTimer);
      }

      this.cleanupTimer = setInterval(() => {
        this.limparLocksExpirados();
      }, CONFIG.CLEANUP_INTERVAL_MS);

      console.log('[QueueSharePoint] ⏰ Timer de limpeza iniciado (5 min)');
    }

    /**
     * Para timer de limpeza
     */
    stopCleanupTimer() {
      if (this.cleanupTimer) {
        clearInterval(this.cleanupTimer);
        this.cleanupTimer = null;
        console.log('[QueueSharePoint] ⏰ Timer de limpeza parado');
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // EXPORTAR
  // ═══════════════════════════════════════════════════════════════════════════

  // Instância global
  window.pickingQueueSharePoint = new PickingQueueSharePoint();

  // Exportar classe e constantes
  window.PickingQueueSharePoint = PickingQueueSharePoint;
  window.QUEUE_STATUS_FILA = STATUS_FILA;
  window.QUEUE_PRIORIDADE = PRIORIDADE;

  console.log('[QueueSharePoint] 📦 Módulo carregado');

  // Auto-inicializar se Graph Client já estiver pronto
  if (window.graphClient) {
    window.pickingQueueSharePoint.initialize();
  } else {
    window.addEventListener('nexos-graphclient-ready', () => {
      window.pickingQueueSharePoint.initialize();
    });
  }

})();
