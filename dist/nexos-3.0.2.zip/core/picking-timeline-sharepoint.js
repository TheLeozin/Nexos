/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - PICKING TIMELINE SHAREPOINT INTEGRATION v3.0.0
 * Gerencia histórico de tentativas de solicitação de transporte no SharePoint
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * FUNCIONALIDADES:
 * - Registra cada tentativa de solicitação (extração, envio, cancelamento)
 * - Permite rastrear todas as ações realizadas em um pedido GPA
 * - Suporta múltiplas tentativas em diferentes plataformas
 * - Integração com Nexos_StatusPedidos para atualizar contadores
 * 
 * LISTA SHAREPOINT: Nexos_TimelinePedidos
 * 
 * @version 3.0.0
 * @date 2026-01-08
 */

(function() {
  'use strict';

  // ═══════════════════════════════════════════════════════════════════════════
  // CONFIGURAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  const CONFIG = {
    LIST_NAME: 'Nexos_TimelinePedidos',
    MAX_RETRIES: 3,
    RETRY_DELAY_MS: 1000,
    CACHE_TTL_MINUTES: 5
  };

  // Tipos de eventos permitidos
  const TIPO_EVENTO = {
    EXTRACAO: 'Extração',
    SOLICITACAO: 'Solicitação',
    ATUALIZACAO_STATUS: 'Atualização Status',
    CANCELAMENTO: 'Cancelamento',
    CONCLUSAO: 'Conclusão'
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // CLASSE PRINCIPAL
  // ═══════════════════════════════════════════════════════════════════════════

  class PickingTimelineSharePoint {
    constructor() {
      this.graphClient = null;
      this.currentUser = null;
      this.cache = new Map(); // Cache de timelines
    }

    /**
     * Inicializa o manager
     */
    async initialize() {
      try {
        console.log('[TimelineSharePoint] Inicializando...');
        
        // Aguardar graph-client-init.js carregar
        if (typeof window !== 'undefined' && !window.graphClient) {
          await new Promise((resolve) => {
            const onReady = () => resolve();
            window.addEventListener('nexos-graphclient-ready', onReady, { once: true });
            
            setTimeout(() => {
              window.removeEventListener('nexos-graphclient-ready', onReady);
              resolve();
            }, 15000);
            
            if (window.graphClient) resolve();
          });
        }
        
        // Obter Graph Client
        if (typeof window !== 'undefined' && window.graphClient) {
          this.graphClient = window.graphClient;
          this.currentUser = window.currentUser;
          console.log('[TimelineSharePoint] ✅ Inicializado com sucesso');
          return true;
        }
        
        console.warn('[TimelineSharePoint] ⚠️ Graph Client não disponível');
        return false;
        
      } catch (error) {
        console.error('[TimelineSharePoint] ❌ Erro na inicialização:', error);
        return false;
      }
    }

    /**
     * Registra nova tentativa na timeline
     * @param {Object} options - Configurações da tentativa
     * @returns {Object} Resultado da operação
     */
    async registrarTentativa({
      pedidoGPAID,
      numeroTentativa,
      tipoEvento,
      plataforma = null,
      statusAnterior = null,
      statusNovo = null,
      sucesso = false,
      mensagemErro = null,
      valorSolicitado = null,
      trackingLink = null,
      duracaoMs = null,
      enderecoCompleto = null,
      nomeCliente = null,
      telefoneCliente = null,
      observacoes = null,
      metadadosJSON = null
    }) {
      try {
        console.log('[TimelineSharePoint] 📝 Registrando tentativa:', {
          pedidoGPAID,
          numeroTentativa,
          tipoEvento,
          plataforma
        });

        // Validar parâmetros obrigatórios
        if (!pedidoGPAID) {
          throw new Error('pedidoGPAID é obrigatório');
        }
        if (!numeroTentativa) {
          throw new Error('numeroTentativa é obrigatório');
        }
        if (!tipoEvento || !Object.values(TIPO_EVENTO).includes(tipoEvento)) {
          throw new Error(`tipoEvento inválido. Use: ${Object.values(TIPO_EVENTO).join(', ')}`);
        }

        // Preparar dados para SharePoint
        const timelineItem = {
          fields: {
            // Identificação
            PedidoGPAID: pedidoGPAID,
            NumeroTentativa: numeroTentativa,
            
            // Evento
            TipoEvento: tipoEvento,
            Plataforma: plataforma,
            StatusAnterior: statusAnterior,
            StatusNovo: statusNovo,
            
            // Resultado
            UsuarioResponsavel: this.currentUser?.email || 'system',
            Sucesso: sucesso,
            MensagemErro: mensagemErro,
            
            // Valores e tracking
            ValorSolicitado: valorSolicitado,
            TrackingLink: trackingLink ? { Url: String(trackingLink), Description: 'Rastrear entrega' } : null,
            
            // Timestamp e performance
            TimestampEvento: new Date().toISOString(),
            DuracaoProcessamento: duracaoMs,
            
            // Dados adicionais
            EnderecoCompleto: enderecoCompleto,
            NomeCliente: nomeCliente,
            TelefoneCliente: telefoneCliente,
            Observacoes: observacoes,
            MetadadosJSON: metadadosJSON ? JSON.stringify(metadadosJSON) : null,
            VersaoExtensao: chrome.runtime.getManifest().version
          }
        };

        // Salvar no SharePoint com retry
        const result = await this.saveWithRetry(timelineItem);

        if (result.success) {
          console.log('[TimelineSharePoint] ✅ Tentativa registrada:', result.itemId);
          
          // Invalidar cache
          this.cache.delete(pedidoGPAID);
          
          return {
            success: true,
            itemId: result.itemId,
            tentativaID: result.itemId,
            message: 'Tentativa registrada com sucesso na timeline'
          };
        } else {
          throw new Error(result.error || 'Falha ao salvar no SharePoint');
        }

      } catch (error) {
        console.error('[TimelineSharePoint] ❌ Erro ao registrar tentativa:', error);
        return {
          success: false,
          error: error.message,
          stack: error.stack
        };
      }
    }

    /**
     * Busca histórico completo de um pedido
     * @param {string} pedidoGPAID - ID do pedido GPA
     * @param {boolean} useCache - Usar cache se disponível
     * @returns {Array} Lista de tentativas ordenadas por data
     */
    async obterHistorico(pedidoGPAID, useCache = true) {
      try {
        // Verificar cache
        if (useCache && this.cache.has(pedidoGPAID)) {
          const cached = this.cache.get(pedidoGPAID);
          const age = Date.now() - cached.timestamp;
          
          if (age < CONFIG.CACHE_TTL_MINUTES * 60 * 1000) {
            console.log('[TimelineSharePoint] 📦 Retornando do cache');
            return cached.data;
          }
        }

        console.log('[TimelineSharePoint] 🔍 Buscando histórico:', pedidoGPAID);

        if (!this.graphClient) {
          console.warn('[TimelineSharePoint] Graph Client não disponível');
          return [];
        }

        // Buscar no SharePoint
        const filter = `fields/PedidoGPAID eq '${pedidoGPAID}'`;
        const orderBy = 'fields/NumeroTentativa asc';
        
        const response = await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items`)
          .filter(filter)
          .orderby(orderBy)
          .expand('fields')
          .top(100)
          .get();

        const timeline = response.value.map(item => ({
          id: item.id,
          pedidoGPAID: item.fields.PedidoGPAID,
          numeroTentativa: item.fields.NumeroTentativa,
          tipoEvento: item.fields.TipoEvento,
          plataforma: item.fields.Plataforma,
          statusAnterior: item.fields.StatusAnterior,
          statusNovo: item.fields.StatusNovo,
          usuarioResponsavel: item.fields.UsuarioResponsavel,
          sucesso: item.fields.Sucesso,
          mensagemErro: item.fields.MensagemErro,
          valorSolicitado: item.fields.ValorSolicitado,
          trackingLink: item.fields.TrackingLink?.Url || (typeof item.fields.TrackingLink === 'string' ? item.fields.TrackingLink : null),
          timestampEvento: new Date(item.fields.TimestampEvento),
          duracaoMs: item.fields.DuracaoProcessamento,
          nomeCliente: item.fields.NomeCliente,
          telefoneCliente: item.fields.TelefoneCliente,
          enderecoCompleto: item.fields.EnderecoCompleto,
          observacoes: item.fields.Observacoes,
          metadados: item.fields.MetadadosJSON ? JSON.parse(item.fields.MetadadosJSON) : null,
          versaoExtensao: item.fields.VersaoExtensao
        }));

        // Atualizar cache
        this.cache.set(pedidoGPAID, {
          data: timeline,
          timestamp: Date.now()
        });

        console.log('[TimelineSharePoint] ✅ Histórico obtido:', timeline.length, 'tentativas');
        return timeline;

      } catch (error) {
        console.error('[TimelineSharePoint] ❌ Erro ao obter histórico:', error);
        return [];
      }
    }

    /**
     * Busca última tentativa de um pedido
     * @param {string} pedidoGPAID - ID do pedido GPA
     * @returns {Object|null} Última tentativa ou null
     */
    async obterUltimaTentativa(pedidoGPAID) {
      try {
        const historico = await this.obterHistorico(pedidoGPAID, true);
        return historico.length > 0 ? historico[historico.length - 1] : null;
      } catch (error) {
        console.error('[TimelineSharePoint] Erro ao obter última tentativa:', error);
        return null;
      }
    }

    /**
     * Conta tentativas de um pedido
     * @param {string} pedidoGPAID - ID do pedido GPA
     * @param {Object} filtros - Filtros opcionais (plataforma, sucesso, tipoEvento)
     * @returns {number} Total de tentativas
     */
    async contarTentativas(pedidoGPAID, filtros = {}) {
      try {
        const historico = await this.obterHistorico(pedidoGPAID, true);
        
        let filtered = historico;
        
        if (filtros.plataforma) {
          filtered = filtered.filter(t => t.plataforma === filtros.plataforma);
        }
        
        if (filtros.sucesso !== undefined) {
          filtered = filtered.filter(t => t.sucesso === filtros.sucesso);
        }
        
        if (filtros.tipoEvento) {
          filtered = filtered.filter(t => t.tipoEvento === filtros.tipoEvento);
        }
        
        return filtered.length;
      } catch (error) {
        console.error('[TimelineSharePoint] Erro ao contar tentativas:', error);
        return 0;
      }
    }

    /**
     * Salva item no SharePoint com retry
     */
    async saveWithRetry(itemData, attempt = 1) {
      try {
        if (!this.graphClient) {
          return { success: false, error: 'Graph Client não disponível' };
        }

        const response = await this.graphClient
          .api(`/sites/${window.SHAREPOINT_CONFIG.siteId}/lists/${CONFIG.LIST_NAME}/items`)
          .post(itemData);

        return {
          success: true,
          itemId: response.id,
          data: response
        };

      } catch (error) {
        console.warn(`[TimelineSharePoint] Tentativa ${attempt}/${CONFIG.MAX_RETRIES} falhou:`, error.message);

        if (attempt < CONFIG.MAX_RETRIES) {
          await new Promise(resolve => setTimeout(resolve, CONFIG.RETRY_DELAY_MS * attempt));
          return this.saveWithRetry(itemData, attempt + 1);
        }

        return {
          success: false,
          error: error.message,
          statusCode: error.statusCode
        };
      }
    }

    /**
     * Limpa cache
     */
    clearCache(pedidoGPAID = null) {
      if (pedidoGPAID) {
        this.cache.delete(pedidoGPAID);
        console.log('[TimelineSharePoint] 🗑️ Cache limpo para:', pedidoGPAID);
      } else {
        this.cache.clear();
        console.log('[TimelineSharePoint] 🗑️ Todo cache limpo');
      }
    }

    /**
     * Gera resumo estatístico do histórico
     */
    async gerarEstatisticas(pedidoGPAID) {
      try {
        const historico = await this.obterHistorico(pedidoGPAID, true);

        if (historico.length === 0) {
          return {
            totalTentativas: 0,
            tentativasSucesso: 0,
            tentativasFalha: 0,
            plataformasUtilizadas: [],
            duracaoMedia: 0,
            ultimaTentativa: null
          };
        }

        const stats = {
          totalTentativas: historico.length,
          tentativasSucesso: historico.filter(t => t.sucesso).length,
          tentativasFalha: historico.filter(t => !t.sucesso).length,
          plataformasUtilizadas: [...new Set(historico.map(t => t.plataforma).filter(Boolean))],
          duracaoMedia: historico
            .filter(t => t.duracaoMs)
            .reduce((acc, t) => acc + t.duracaoMs, 0) / historico.filter(t => t.duracaoMs).length || 0,
          ultimaTentativa: historico[historico.length - 1],
          primeiraTentativa: historico[0],
          tiposEventos: historico.reduce((acc, t) => {
            acc[t.tipoEvento] = (acc[t.tipoEvento] || 0) + 1;
            return acc;
          }, {})
        };

        return stats;
      } catch (error) {
        console.error('[TimelineSharePoint] Erro ao gerar estatísticas:', error);
        return null;
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // EXPORTAR
  // ═══════════════════════════════════════════════════════════════════════════

  // Instância global
  window.pickingTimelineSharePoint = new PickingTimelineSharePoint();

  // Exportar classe e constantes
  window.PickingTimelineSharePoint = PickingTimelineSharePoint;
  window.TIMELINE_TIPO_EVENTO = TIPO_EVENTO;

  console.log('[TimelineSharePoint] 📦 Módulo carregado');

  // Auto-inicializar se Graph Client já estiver pronto
  if (window.graphClient) {
    window.pickingTimelineSharePoint.initialize();
  } else {
    window.addEventListener('nexos-graphclient-ready', () => {
      window.pickingTimelineSharePoint.initialize();
    });
  }

})();
