/**
 * ════════════════════════════════════════════════════════════════════════════
 * PICKING CONTEXT DETECTOR - Detecção de Contexto da Página
 * ════════════════════════════════════════════════════════════════════════════
 * 
 * Responsável por:
 * - Detectar em qual página/plataforma o usuário está
 * - Habilitar/desabilitar funcionalidades conforme contexto
 * - Fornecer informações sobre capacidades disponíveis
 * - Avisar sobre limitações
 */

class PickingContextDetector {
  constructor() {
    this.currentContext = null;
    this.capabilities = {};
    
    // Mapa de contextos e suas funcionalidades
    this.contextMap = {
      'picking': {
        name: 'Picking Admin',
        url: /picking-admin\.backoffice\.gpa\.digital/i,
        capabilities: {
          extraction: true,      // Pode extrair dados
          sending: true,         // Pode enviar pedidos
          timeline: true,        // Pode ver timeline
          batch: true,           // Pode enviar em lote
          orders: true,          // Tem acesso aos pedidos
          filters: true          // Pode filtrar pedidos
        },
        description: 'Todas as funcionalidades disponíveis',
        icon: '📦'
      },
      
      'orkestra': {
        name: 'James Orkestra',
        url: /james-orkestra\.backoffice\.gpa\.digital/i,
        capabilities: {
          extraction: false,
          sending: true,         // Pode enviar do histórico
          timeline: true,
          batch: false,
          orders: true,          // Acesso limitado (somente histórico)
          filters: true
        },
        description: 'Envio e timeline disponíveis',
        icon: '📊'
      },
      
      'uber': {
        name: 'Uber Direct',
        url: /direct\.uber\.com/i,
        capabilities: {
          extraction: false,
          sending: false,        // Não pode enviar de dentro do Uber
          timeline: true,
          batch: false,
          orders: true,
          filters: true
        },
        description: 'Visualização apenas',
        icon: '🚗'
      },
      
      'lalamove': {
        name: 'Lalamove',
        url: /web\.lalamove\.com/i,
        capabilities: {
          extraction: false,
          sending: false,
          timeline: true,
          batch: false,
          orders: true,
          filters: true
        },
        description: 'Visualização apenas',
        icon: '🟠'
      },
      
      '99': {
        name: '99 Entrega',
        url: /entrega\.99app\.com/i,
        capabilities: {
          extraction: false,
          sending: false,
          timeline: true,
          batch: false,
          orders: true,
          filters: true
        },
        description: 'Visualização apenas',
        icon: '🟡'
      },
      
      'james_map': {
        name: 'James Map',
        url: /mapa\.james\.delivery/i,
        capabilities: {
          extraction: false,
          sending: true,         // Pode enviar direto do mapa
          timeline: true,
          batch: true,
          orders: true,
          filters: true
        },
        description: 'Envio e visualização disponíveis',
        icon: '🗺️'
      },
      
      'whatsapp': {
        name: 'WhatsApp Web',
        url: /web\.whatsapp\.com/i,
        capabilities: {
          extraction: false,
          sending: false,
          timeline: true,
          batch: false,
          orders: true,
          filters: true
        },
        description: 'Visualização apenas',
        icon: '💬'
      },
      
      'other': {
        name: 'Outra Página',
        url: /.*/,
        capabilities: {
          extraction: false,
          sending: true,         // Pode enviar via background
          timeline: true,
          batch: true,
          orders: true,
          filters: true
        },
        description: 'Envio em background disponível',
        icon: '🌐'
      }
    };
    
    // Context Detector inicializado silenciosamente
  }
  
  /**
   * Detectar contexto atual
   */
  detectContext() {
    const currentUrl = window.location.href;
    
    // Tentar cada contexto
    for (const [key, context] of Object.entries(this.contextMap)) {
      if (key === 'other') continue; // Skip 'other' por enquanto
      
      if (context.url.test(currentUrl)) {
        this.currentContext = {
          id: key,
          ...context
        };
        
        this.capabilities = { ...context.capabilities };
        
        // CORREÇÃO: Para contexto 'picking', verificar se está na página de detalhes
        if (key === 'picking') {
          const isOnOrderDetailPage = /\/detalhe\/\d+/.test(currentUrl);
          console.log('[PickingContext] 🔍 URL atual:', currentUrl);
          console.log('[PickingContext] 🔍 Regex /\\/detalhe\\/\\d+/ test:', isOnOrderDetailPage);
          
          if (!isOnOrderDetailPage) {
            // Desabilitar extração se NÃO estiver na página de detalhes
            this.capabilities.extraction = false;
            console.log('[PickingContext] 📍 Picking Admin detectado, mas FORA da página de detalhes - extração DESABILITADA');
          } else {
            console.log('[PickingContext] 📍 Picking Admin detectado NA página de detalhes - extração HABILITADA');
          }
        }
        
        console.log(`[PickingContext] 📍 Contexto detectado: ${context.name}`, this.capabilities);
        
        return this.currentContext;
      }
    }
    
    // Fallback: 'other'
    this.currentContext = {
      id: 'other',
      ...this.contextMap.other
    };
    
    this.capabilities = { ...this.contextMap.other.capabilities };
    
    console.log('[PickingContext] 📍 Contexto genérico detectado', this.capabilities);
    
    return this.currentContext;
  }
  
  /**
   * Obter contexto atual
   */
  getContext() {
    if (!this.currentContext) {
      this.detectContext();
    }
    
    return this.currentContext;
  }
  
  /**
   * Obter capacidades
   */
  getCapabilities() {
    if (!this.currentContext) {
      this.detectContext();
    }
    
    return { ...this.capabilities };
  }
  
  /**
   * Verificar se uma capacidade está disponível
   */
  hasCapability(capability) {
    if (!this.currentContext) {
      this.detectContext();
    }
    
    return this.capabilities[capability] === true;
  }
  
  /**
   * Verificar múltiplas capacidades
   */
  hasCapabilities(capabilities) {
    if (!this.currentContext) {
      this.detectContext();
    }
    
    if (Array.isArray(capabilities)) {
      return capabilities.every(cap => this.capabilities[cap] === true);
    }
    
    return false;
  }
  
  /**
   * Obter mensagem de limitação
   */
  getLimitationMessage(capability) {
    const context = this.getContext();
    
    const messages = {
      'extraction': `⚠️ Extração de dados não disponível em ${context.name}. Abra o Picking Admin para extrair pedidos.`,
      'sending': `⚠️ Envio direto não disponível em ${context.name}. Os pedidos serão enviados em background.`,
      'batch': `⚠️ Envio em lote não disponível em ${context.name}. Envie pedidos individualmente.`,
      'orders': `⚠️ Acesso aos pedidos não disponível em ${context.name}.`,
      'filters': `⚠️ Filtros não disponíveis em ${context.name}.`
    };
    
    return messages[capability] || `⚠️ Funcionalidade '${capability}' não disponível neste contexto.`;
  }
  
  /**
   * Criar badge de contexto
   */
  createContextBadge() {
    const context = this.getContext();
    
    const badge = document.createElement('div');
    badge.className = 'nexos-context-badge';
    badge.style.cssText = `
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 10px;
      background: var(--nexos-bg-secondary);
      border: 1px solid var(--nexos-border-light);
      border-radius: 12px;
      font-size: 12px;
      color: var(--nexos-text-primary);
    `;
    
    const icon = document.createElement('span');
    icon.textContent = context.icon;
    icon.style.fontSize = '14px';
    
    const name = document.createElement('span');
    name.textContent = context.name;
    name.style.fontWeight = '500';
    
    badge.appendChild(icon);
    badge.appendChild(name);
    
    // Tooltip ao passar o mouse
    badge.title = context.description;
    
    return badge;
  }
  
  /**
   * Criar aviso de funcionalidade desabilitada
   */
  createDisabledWarning(capability, container) {
    const warning = document.createElement('div');
    warning.className = 'nexos-capability-warning';
    warning.style.cssText = `
      padding: 12px;
      background: rgba(245, 158, 11, 0.1);
      border: 1px solid rgba(245, 158, 11, 0.3);
      border-radius: 6px;
      color: var(--nexos-text-primary);
      font-size: 13px;
      display: flex;
      align-items: flex-start;
      gap: 8px;
      margin-bottom: 12px;
    `;
    
    const iconEl = document.createElement('span');
    iconEl.textContent = '⚠️';
    iconEl.style.fontSize = '18px';
    
    const message = document.createElement('div');
    message.innerHTML = this.getLimitationMessage(capability);
    
    warning.appendChild(iconEl);
    warning.appendChild(message);
    
    if (container) {
      container.insertBefore(warning, container.firstChild);
    }
    
    return warning;
  }
  
  /**
   * Desabilitar elemento se capacidade não disponível
   */
  disableIfUnavailable(element, capability, showWarning = true) {
    if (!this.hasCapability(capability)) {
      element.disabled = true;
      element.style.opacity = '0.5';
      element.style.cursor = 'not-allowed';
      
      if (showWarning) {
        element.title = this.getLimitationMessage(capability);
        
        // Adicionar evento de click para mostrar aviso
        element.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          
          if (typeof window.NexosUI !== 'undefined') {
            window.NexosUI.showToast(
              this.getLimitationMessage(capability),
              'warning',
              4000
            );
          }
        }, true);
      }
      
      return true; // Foi desabilitado
    }
    
    return false; // Está disponível
  }
  
  /**
   * Criar seção de capacidades (para modal de ajuda)
   */
  createCapabilitiesSection() {
    const context = this.getContext();
    const capabilities = this.getCapabilities();
    
    const section = document.createElement('div');
    section.className = 'nexos-capabilities-section';
    section.style.cssText = `
      padding: 16px;
      background: var(--nexos-bg-secondary);
      border-radius: 8px;
    `;
    
    // Header
    const header = document.createElement('div');
    header.style.cssText = `
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 12px;
      font-weight: 600;
      color: var(--nexos-text-primary);
    `;
    header.innerHTML = `
      <span style="font-size: 20px;">${context.icon}</span>
      <span>${context.name}</span>
    `;
    
    // Description
    const desc = document.createElement('div');
    desc.textContent = context.description;
    desc.style.cssText = `
      font-size: 13px;
      color: var(--nexos-text-secondary);
      margin-bottom: 12px;
    `;
    
    // Lista de capacidades
    const list = document.createElement('div');
    list.style.cssText = `
      display: flex;
      flex-direction: column;
      gap: 6px;
    `;
    
    const capabilityLabels = {
      extraction: 'Extração de Dados',
      sending: 'Envio de Pedidos',
      timeline: 'Visualização de Timeline',
      batch: 'Envio em Lote',
      orders: 'Acesso aos Pedidos',
      filters: 'Filtros e Busca'
    };
    
    Object.entries(capabilities).forEach(([key, enabled]) => {
      const item = document.createElement('div');
      item.style.cssText = `
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13px;
        color: var(--nexos-text-primary);
      `;
      
      const icon = document.createElement('span');
      icon.textContent = enabled ? '✅' : '❌';
      
      const label = document.createElement('span');
      label.textContent = capabilityLabels[key] || key;
      label.style.opacity = enabled ? '1' : '0.5';
      
      item.appendChild(icon);
      item.appendChild(label);
      list.appendChild(item);
    });
    
    section.appendChild(header);
    section.appendChild(desc);
    section.appendChild(list);
    
    return section;
  }
  
  /**
   * Verificar se está na página de extração
   */
  isExtractionPage() {
    return this.hasCapability('extraction');
  }
  
  /**
   * Verificar se pode enviar diretamente
   */
  canSendDirect() {
    return this.hasCapability('sending');
  }
  
  /**
   * Verificar se pode enviar em lote
   */
  canSendBatch() {
    return this.hasCapability('batch');
  }
  
  /**
   * Obter método de envio recomendado
   */
  getRecommendedSendingMethod() {
    if (this.hasCapability('sending')) {
      if (this.hasCapability('batch')) {
        return 'direct_batch'; // Envio direto com lote
      }
      return 'direct'; // Envio direto
    }
    
    return 'background'; // Background apenas
  }
  
  /**
   * Redetectar contexto (útil após navegação)
   */
  refresh() {
    console.log('[PickingContext] 🔄 Atualizando contexto...');
    this.currentContext = null;
    this.capabilities = {};
    return this.detectContext();
  }
}

// Exportar como singleton
window.PickingContextDetector = window.PickingContextDetector || new PickingContextDetector();

console.log('[PickingContext] 🔍 Módulo carregado');
