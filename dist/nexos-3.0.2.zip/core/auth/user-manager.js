/**
 * ════════════════════════════════════════════════════════════════════════════
 * USER MANAGER - Gerenciamento de Usuário Logado
 * ════════════════════════════════════════════════════════════════════════════
 * 
 * Responsável por:
 * - Buscar informações do usuário via Microsoft Graph
 * - Armazenar dados do usuário
 * - Gerenciar foto de perfil
 * - Cache de informações
 */

class UserManager {
  constructor() {
    this.STORAGE_KEY = 'nexos_current_user';
    this.currentUser = null;
    
    console.log('[UserManager] 👤 Inicializado');
  }
  
  /**
   * Buscar informações do usuário via Microsoft Graph
   */
  async fetchUserInfo(accessToken) {
    try {
      console.log('[UserManager] 📡 Buscando informações do usuário...');
      
      // Buscar dados básicos
      const response = await fetch('https://graph.microsoft.com/v1.0/me', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`Erro ao buscar usuário: ${response.status} - ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Buscar foto
      const photo = await this.fetchUserPhoto(accessToken);
      
      // Buscar grupos (opcional - pode falhar se não tiver permissão)
      let groups = [];
      try {
        groups = await this.fetchUserGroups(accessToken);
      } catch (error) {
        console.warn('[UserManager] ⚠️ Não foi possível buscar grupos:', error.message);
      }
      
      const userInfo = {
        id: data.id,
        displayName: data.displayName,
        givenName: data.givenName,
        surname: data.surname,
        email: data.mail || data.userPrincipalName,
        userPrincipalName: data.userPrincipalName,
        jobTitle: data.jobTitle,
        department: data.department,
        officeLocation: data.officeLocation,
        mobilePhone: data.mobilePhone,
        businessPhones: data.businessPhones || [],
        photo: photo,
        groups: groups,
        fetchedAt: Date.now()
      };
      
      console.log('[UserManager] ✅ Informações obtidas:', {
        name: userInfo.displayName,
        email: userInfo.email,
        department: userInfo.department
      });
      
      return userInfo;
      
    } catch (error) {
      console.error('[UserManager] ❌ Erro ao buscar usuário:', error);
      throw error;
    }
  }
  
  /**
   * Buscar foto do perfil do usuário
   */
  async fetchUserPhoto(accessToken) {
    try {
      const response = await fetch('https://graph.microsoft.com/v1.0/me/photo/$value', {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const photoUrl = URL.createObjectURL(blob);
        
        console.log('[UserManager] 📷 Foto de perfil obtida');
        return photoUrl;
      }
      
      console.log('[UserManager] ℹ️ Usuário sem foto de perfil');
      return null;
      
    } catch (error) {
      console.warn('[UserManager] ⚠️ Não foi possível obter foto:', error.message);
      return null;
    }
  }
  
  /**
   * Buscar grupos do usuário
   */
  async fetchUserGroups(accessToken) {
    try {
      const response = await fetch('https://graph.microsoft.com/v1.0/me/memberOf', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`Erro ao buscar grupos: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Filtrar apenas grupos (não devices, etc)
      const groups = (data.value || [])
        .filter(item => item['@odata.type'] === '#microsoft.graph.group')
        .map(group => ({
          id: group.id,
          displayName: group.displayName,
          mail: group.mail,
          description: group.description
        }));
      
      console.log('[UserManager] 👥 Grupos obtidos:', groups.length);
      return groups;
      
    } catch (error) {
      console.warn('[UserManager] ⚠️ Erro ao buscar grupos:', error.message);
      return [];
    }
  }
  
  /**
   * Salvar informações do usuário
   */
  async saveUser(userInfo) {
    try {
      await chrome.storage.local.set({ [this.STORAGE_KEY]: userInfo });
      this.currentUser = userInfo;
      
      console.log('[UserManager] 💾 Usuário salvo:', userInfo.displayName);
      
      // Emitir evento
      window.dispatchEvent(new CustomEvent('nexos:user:saved', { detail: userInfo }));
      
      return userInfo;
    } catch (error) {
      console.error('[UserManager] ❌ Erro ao salvar usuário:', error);
      throw error;
    }
  }
  
  /**
   * Obter usuário atual do storage
   */
  async getCurrentUser() {
    try {
      // Retornar cache se disponível
      if (this.currentUser) {
        return this.currentUser;
      }
      
      // Buscar do storage
      const result = await chrome.storage.local.get(this.STORAGE_KEY);
      this.currentUser = result[this.STORAGE_KEY] || null;
      
      return this.currentUser;
    } catch (error) {
      console.error('[UserManager] ❌ Erro ao obter usuário:', error);
      return null;
    }
  }
  
  /**
   * Atualizar informações do usuário (re-fetch)
   */
  async refreshUserInfo() {
    try {
      console.log('[UserManager] 🔄 Atualizando informações do usuário...');
      
      // Obter token válido
      const accessToken = await window.tokenManager.getValidAccessToken();
      
      // Buscar novas informações
      const userInfo = await this.fetchUserInfo(accessToken);
      
      // Salvar
      await this.saveUser(userInfo);
      
      return userInfo;
    } catch (error) {
      console.error('[UserManager] ❌ Erro ao atualizar usuário:', error);
      throw error;
    }
  }
  
  /**
   * Limpar usuário (logout)
   */
  async clearUser() {
    try {
      // Revogar URL da foto se existir
      if (this.currentUser?.photo) {
        URL.revokeObjectURL(this.currentUser.photo);
      }
      
      await chrome.storage.local.remove(this.STORAGE_KEY);
      this.currentUser = null;
      
      console.log('[UserManager] 🧹 Usuário removido');
      
      // Emitir evento
      window.dispatchEvent(new CustomEvent('nexos:user:cleared'));
      
      return true;
    } catch (error) {
      console.error('[UserManager] ❌ Erro ao limpar usuário:', error);
      return false;
    }
  }
  
  /**
   * Verificar se há usuário logado
   */
  async isLoggedIn() {
    const user = await this.getCurrentUser();
    return user !== null;
  }
  
  /**
   * Obter role do usuário baseado em grupos/departamento
   */
  async getUserRole() {
    const user = await this.getCurrentUser();
    
    if (!user) {
      return 'guest';
    }
    
    // Mapear baseado em grupos do Azure AD
    const groupNames = (user.groups || []).map(g => g.displayName.toLowerCase());
    
    // Verificar grupos específicos
    if (groupNames.some(g => g.includes('admin') || g.includes('administrador'))) {
      return 'admin';
    }
    
    if (groupNames.some(g => g.includes('specialist') || g.includes('especialista'))) {
      return 'specialist';
    }
    
    if (groupNames.some(g => g.includes('manager') || g.includes('gestor'))) {
      return 'manager';
    }
    
    // Verificar por departamento
    if (user.department) {
      const dept = user.department.toLowerCase();
      if (dept.includes('ti') || dept.includes('tech')) {
        return 'specialist';
      }
    }
    
    // Role padrão
    return 'operator';
  }
  
  /**
   * Obter permissões do usuário
   */
  async getUserPermissions() {
    const role = await this.getUserRole();
    
    const permissions = {
      guest: [],
      operator: ['view_orders', 'create_orders', 'edit_own_orders'],
      specialist: ['view_orders', 'create_orders', 'edit_own_orders', 'edit_all_orders', 'force_unlock'],
      manager: ['view_orders', 'create_orders', 'edit_own_orders', 'edit_all_orders', 'force_unlock', 'view_reports', 'manage_users'],
      admin: ['*'] // Todas as permissões
    };
    
    return permissions[role] || permissions.guest;
  }
  
  /**
   * Verificar se usuário tem permissão específica
   */
  async hasPermission(permission) {
    const permissions = await this.getUserPermissions();
    
    // Admin tem tudo
    if (permissions.includes('*')) {
      return true;
    }
    
    return permissions.includes(permission);
  }
  
  /**
   * Obter iniciais do nome para avatar
   */
  getUserInitials(user) {
    if (!user) return '??';
    
    const name = user.displayName || user.email || '??';
    const parts = name.split(' ').filter(p => p.length > 0);
    
    if (parts.length === 0) return '??';
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
}

// Exportar
window.UserManager = UserManager;

// Criar instância global
if (!window.userManager) {
  window.userManager = new UserManager();
}

console.log('[UserManager] 👤 Módulo carregado e instância criada');
