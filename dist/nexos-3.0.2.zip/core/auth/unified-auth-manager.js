/**
 * ═══════════════════════════════════════════════════════════════════════════
 * UNIFIED AUTH MANAGER - Gerenciador Unificado de Autenticação
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Resolve o problema de sincronização entre MSAL e TokenManager
 * Garante que o token MSAL seja SEMPRE usado em todas as chamadas
 * 
 * @version 2.0.0
 * @date 2026-01-09
 */

(function() {
  'use strict';

  class UnifiedAuthManager {
    constructor() {
      this.msalAuth = null;
      this.tokenCache = null;
      this.tokenExpiryTime = null;
      this.initialized = false;
      
      console.log('[UnifiedAuth] 🔐 Gerenciador Unificado Inicializado');
    }

    /**
     * Inicializa o gerenciador
     * DEVE ser chamado após MSAL carregar
     */
    async init() {
      if (this.initialized) {
        console.log('[UnifiedAuth] ⚠️ Já inicializado');
        return;
      }

      try {
        // Aguardar MSAL estar disponível
        await this.ensureMSALAvailable();
        
        this.msalAuth = window.msalAuth;
        
        // Verificar se já tem conta logada
        if (this.msalAuth.currentAccount && this.msalAuth.accessToken) {
          console.log('[UnifiedAuth] ✅ Conta MSAL detectada:', this.msalAuth.currentAccount.username);
          await this.syncTokenToStorage();
        }

        this.initialized = true;
        console.log('[UnifiedAuth] ✅ Inicialização completa');

        // Auto-sync a cada 5 minutos
        this.startAutoSync();

      } catch (error) {
        console.error('[UnifiedAuth] ❌ Erro na inicialização:', error);
        throw error;
      }
    }

    /**
     * Aguarda MSAL estar disponível
     */
    async ensureMSALAvailable() {
      if (window.msalAuth && window.msalAuth.initialized) {
        console.log('[UnifiedAuth] ✅ MSAL já inicializado');
        return true;
      }

      console.log('[UnifiedAuth] ⏳ Aguardando MSAL...');
      
      // Aguardar até 10 segundos
      for (let i = 0; i < 20; i++) {
        await new Promise(resolve => setTimeout(resolve, 500));
        if (window.msalAuth && window.msalAuth.initialized) {
          console.log('[UnifiedAuth] ✅ MSAL disponível');
          return true;
        }
      }

      // Se MSAL existe mas não está inicializado, aguardar init
      if (window.msalAuth && !window.msalAuth.initialized) {
        console.log('[UnifiedAuth] ⏳ MSAL existe, aguardando inicialização...');
        for (let i = 0; i < 10; i++) {
          await new Promise(resolve => setTimeout(resolve, 500));
          if (window.msalAuth.initialized) {
            console.log('[UnifiedAuth] ✅ MSAL inicializado');
            return true;
          }
        }
      }

      // Último recurso: tentar inicializar manualmente
      if (window.MsalAuth && !window.msalAuth) {
        console.log('[UnifiedAuth] 🔧 Criando instância MSAL manualmente...');
        window.msalAuth = new window.MsalAuth();
      }
      
      if (window.msalAuth && !window.msalAuth.initialized) {
        console.log('[UnifiedAuth] 🔧 Inicializando MSAL manualmente...');
        try {
          await window.msalAuth.init();
          return true;
        } catch (error) {
          console.error('[UnifiedAuth] ❌ Erro ao inicializar MSAL:', error);
          return false;
        }
      }

      console.error('[UnifiedAuth] ❌ MSAL não disponível após todas tentativas');
      return false;
    }

    /**
     * Obtém token válido
     * PRIORIDADE: TokenInterceptor > Cache > MSAL
     */
    async getAccessToken() {
      try {
        console.log('[UnifiedAuth] 🔍 Obtendo access token...');

        // 0. Verificar cache local PRIMEIRO (válido por 5 min)
        if (this.tokenCache && this.tokenExpiryTime > Date.now()) {
          console.log('[UnifiedAuth] ✅ Token do cache (válido por', Math.round((this.tokenExpiryTime - Date.now()) / 1000), 's)');
          return this.tokenCache;
        }

        // 1. Verificar se MSAL inicializado
        if (!this.initialized) {
          console.log('[UnifiedAuth] ⚠️ Não inicializado, inicializando...');
          await this.init();
        }

        // 2. Tentar obter token do MSAL silenciosamente (PRIORIDADE MÁXIMA para SharePoint)
        const msalToken = await this.getMSALToken();
        
        if (msalToken) {
          console.log('[UnifiedAuth] ✅ Token MSAL obtido (SharePoint-ready)');
          
          // Cachear por 5 minutos
          this.tokenCache = msalToken;
          this.tokenExpiryTime = Date.now() + (5 * 60 * 1000);
          
          // Sincronizar para storage
          await this.syncTokenToStorage();
          
          return msalToken;
        }

        // 3. FALLBACK: Token do picking-admin (pode não ter permissão SharePoint)
        if (window.tokenStorageScanner) {
          try {
            const scannedToken = await window.tokenStorageScanner.getToken();
            if (scannedToken) {
              console.log('[UnifiedAuth] ⚠️ Usando token picking-admin (pode falhar no SharePoint)');
              
              // Cachear apenas por 1 minuto (token pode não funcionar)
              this.tokenCache = scannedToken;
              this.tokenExpiryTime = Date.now() + (1 * 60 * 1000);
              
              return scannedToken;
            }
          } catch (e) {
            console.warn('[UnifiedAuth] ⚠️ Erro ao obter token escaneado:', e.message);
          }
        }

        if (window.tokenInterceptor) {
          try {
            const interceptedToken = await window.tokenInterceptor.getToken();
            if (interceptedToken) {
              console.log('[UnifiedAuth] ⚠️ Usando token interceptado (pode falhar no SharePoint)');
              
              this.tokenCache = interceptedToken;
              this.tokenExpiryTime = Date.now() + (1 * 60 * 1000);
              
              return interceptedToken;
            }
          } catch (e) {
            console.warn('[UnifiedAuth] ⚠️ Erro ao obter token interceptado:', e.message);
          }
        }

        // 2. Verificar se MSAL inicializado
        if (!this.initialized) {
          console.log('[UnifiedAuth] ⚠️ Não inicializado, inicializando...');
          await this.init();
        }

        // 3. Tentar obter token do MSAL silenciosamente
        const token = await this.getMSALToken();
        
        if (token) {
          console.log('[UnifiedAuth] ✅ Token MSAL obtido');
          
          // Cachear por 5 minutos
          this.tokenCache = token;
          this.tokenExpiryTime = Date.now() + (5 * 60 * 1000);
          
          // Sincronizar para storage
          await this.syncTokenToStorage();
          
          return token;
        }

        // 4. Se não tem token, precisa fazer login
        console.warn('[UnifiedAuth] ⚠️ Sem token válido, login necessário');
        throw new Error('Autenticação necessária. Por favor, faça login.');

      } catch (error) {
        console.error('[UnifiedAuth] ❌ Erro ao obter token:', error);
        throw error;
      }
    }

    /**
     * Obtém token do MSAL
     * Tenta silent primeiro, depois popup se necessário
     */
    async getMSALToken() {
      try {
        // ═══════════════════════════════════════════════════════════════════════
        // 🔥 PRIORIDADE 1: NEXOS AUTH (Sistema que está funcionando!)
        // ═══════════════════════════════════════════════════════════════════════
        
        // 1. Tentar obter token do NexosAuth (sistema atual que funciona)
        if (window.NexosAuth && typeof window.NexosAuth.getToken === 'function') {
          try {
            const nexosToken = await window.NexosAuth.getToken();
            if (nexosToken) {
              // Log silencioso - remove verbosidade
              return nexosToken;
            }
          } catch (e) {
            console.warn('[UnifiedAuth] ⚠️ NexosAuth.getToken() falhou:', e.message);
          }
        }
        
        // 2. Buscar sessão do NexosAuth no localStorage
        try {
          const nexosSession = localStorage.getItem('nexos-user-session');
          if (nexosSession) {
            const session = JSON.parse(nexosSession);
            if (session && session.user && session.user.accessToken) {
              console.log('[UnifiedAuth] ✅ Token encontrado em nexos-user-session');
              console.log('[UnifiedAuth] 👤 Usuário:', session.user.displayName || session.user.name);
              console.log('[UnifiedAuth] 🎫 Token preview:', session.user.accessToken.substring(0, 50) + '...');
              return session.user.accessToken;
            }
          }
        } catch (e) {
          console.warn('[UnifiedAuth] ⚠️ Erro ao ler nexos-user-session:', e.message);
        }
        
        // 3. Buscar token legado em 'access-token'
        try {
          const accessToken = localStorage.getItem('access-token');
          if (accessToken) {
            console.log('[UnifiedAuth] ✅ Token encontrado em access-token (legado)');
            
            // Extrair JWT se estiver em JSON
            let finalToken = accessToken;
            try {
              const parsed = JSON.parse(accessToken);
              if (parsed && parsed.access_token) {
                finalToken = parsed.access_token;
                console.log('[UnifiedAuth] 🔑 Token extraído de JSON: access_token');
              }
            } catch (e) {
              // Não é JSON, usar direto
              console.log('[UnifiedAuth] 🔑 Token é string pura');
            }
            
            console.log('[UnifiedAuth] 🎫 Token preview:', finalToken.substring(0, 50) + '...');
            return finalToken;
          }
        } catch (e) {
          console.warn('[UnifiedAuth] ⚠️ Erro ao ler access-token:', e.message);
        }
        
        console.log('[UnifiedAuth] ℹ️ Nenhum token encontrado no NexosAuth, tentando MSAL...');
        
        // ═══════════════════════════════════════════════════════════════════════
        // 🔥 PRIORIDADE 2: MSAL (Fallback se NexosAuth não tiver token)
        // ═══════════════════════════════════════════════════════════════════════
        
        // Verificar se MSAL está inicializado
        if (!this.msalAuth || !this.msalAuth.msalInstance) {
          console.warn('[UnifiedAuth] ⚠️ MSAL não inicializado, aguardando...');
          await this.ensureMSALAvailable();
          
          // Se ainda não tiver, retornar null
          if (!this.msalAuth || !this.msalAuth.msalInstance) {
            console.error('[UnifiedAuth] ❌ MSAL não pôde ser inicializado');
            console.error('[UnifiedAuth] ❌ Nenhuma fonte de token disponível (NexosAuth, MSAL, localStorage)');
            return null;
          }
        }

        const accounts = this.msalAuth.msalInstance.getAllAccounts();
        
        // Sem contas = nenhuma autenticação disponível
        if (!accounts || accounts.length === 0) {
          console.error('[UnifiedAuth] ❌ MSAL sem contas');
          console.error('[UnifiedAuth] ❌ Nenhuma fonte de token disponível');
          return null;
        }

        // Pegar primeira conta
        const account = accounts[0];
        console.log('[UnifiedAuth] 📧 Conta MSAL:', account.username);

        // Tentar obter token silenciosamente
        const silentRequest = {
          account: account,
          scopes: ['https://graph.microsoft.com/.default']
        };

        try {
          const response = await this.msalAuth.msalInstance.acquireTokenSilent(silentRequest);
          
          if (response && response.accessToken) {
            console.log('[UnifiedAuth] ✅ Token obtido silenciosamente');
            return response.accessToken;
          }
        } catch (silentError) {
          console.warn('[UnifiedAuth] ⚠️ acquireTokenSilent falhou:', silentError.errorCode || silentError.message);
          
          // Se erro de interação necessária, não fazer popup aqui
          // Deixar para o usuário clicar em "Login"
          if (silentError.errorCode === 'interaction_required' || 
              silentError.errorCode === 'consent_required' ||
              silentError.errorCode === 'login_required') {
            console.log('[UnifiedAuth] 🔐 Interação necessária, usuário precisa fazer login');
            return null;
          }
          
          throw silentError;
        }

        return null;

      } catch (error) {
        console.error('[UnifiedAuth] ❌ Erro ao obter token MSAL:', error);
        return null;
      }
    }

    /**
     * Realiza login - tenta silent primeiro, depois popup se necessário
     * Deve ser chamado por ação do usuário (click) se precisar abrir popup
     */
    async login() {
      try {
        console.log('[UnifiedAuth] 🔐 Iniciando login...');

        if (!this.initialized) {
          await this.init();
        }

        // Primeiro tenta obter token silenciosamente se já existir conta
        const accounts = this.msalAuth.getAllAccounts();
        if (accounts && accounts.length > 0) {
          console.log('[UnifiedAuth] 🔍 Conta existente encontrada, tentando renovar token...');
          
          try {
            const silentRequest = {
              account: accounts[0],
              scopes: ['https://graph.microsoft.com/.default'],
              forceRefresh: true // Força renovação do token
            };

            const silentResponse = await this.msalAuth.acquireTokenSilent(silentRequest);
            
            if (silentResponse && silentResponse.accessToken) {
              console.log('[UnifiedAuth] ✅ Token renovado silenciosamente');
              
              // Cachear token
              this.tokenCache = silentResponse.accessToken;
              this.tokenExpiryTime = Date.now() + (5 * 60 * 1000);

              // Sincronizar para storage
              await this.syncTokenToStorage();

              // Disparar evento
              window.dispatchEvent(new CustomEvent('nexos:auth:login-success', {
                detail: { account: silentResponse.account }
              }));

              return {
                success: true,
                account: silentResponse.account,
                token: silentResponse.accessToken,
                method: 'silent'
              };
            }
          } catch (silentError) {
            console.warn('[UnifiedAuth] ⚠️ Token silent falhou, tentando popup...', silentError.errorCode);
            // Continua para tentar popup
          }
        }

        // Se silent falhou ou não há conta, tentar popup
        console.log('[UnifiedAuth] 🪟 Abrindo popup de login...');
        
        // Forçar chromiumapp.org como redirect URI para evitar problemas
        const extensionId = chrome?.runtime?.id || 'obodcljemkajclohcfjhmommhfpklojo';
        const fixedRedirectUri = `https://${extensionId}.chromiumapp.org/`;

        const loginRequest = {
          scopes: ['https://graph.microsoft.com/.default'],
          prompt: 'select_account',
          redirectUri: fixedRedirectUri // ✅ Força URI correto
        };

        try {
          const response = await this.msalAuth.loginPopup(loginRequest);

          if (!response || !response.accessToken) {
            throw new Error('Login falhou - nenhum token retornado');
          }

          console.log('[UnifiedAuth] ✅ Login bem-sucedido:', response.account.username);

          // Cachear token
          this.tokenCache = response.accessToken;
          this.tokenExpiryTime = Date.now() + (5 * 60 * 1000);

          // Sincronizar para storage
          await this.syncTokenToStorage();

          // Disparar evento
          window.dispatchEvent(new CustomEvent('nexos:auth:login-success', {
            detail: { account: response.account }
          }));

          return {
            success: true,
            account: response.account,
            token: response.accessToken,
            method: 'popup'
          };

        } catch (popupError) {
          console.error('[UnifiedAuth] ❌ Popup falhou:', popupError);
          
          // Última tentativa: redirect
          const errorCode = popupError.errorCode || popupError.message || '';
          
          if (errorCode.includes('user_cancelled') || 
              errorCode.includes('popup') ||
              errorCode.includes('monitor_window_timeout') ||
              errorCode.includes('Cross-Origin-Opener-Policy')) {
            
            console.warn('[UnifiedAuth] ⚠️ Popup não funcionou, você precisa usar redirect');
            console.warn('[UnifiedAuth] 💡 Por favor, recarregue a página e tente novamente');
            console.warn('[UnifiedAuth] � Se o problema persistir, use loginRedirect() manualmente');
            
            // Não pedir confirmação automática - deixar usuário decidir
            throw new Error('Popup bloqueado. Recarregue a página e tente novamente, ou use window.unifiedAuth.loginRedirect()');
          }
          
          throw popupError;
        }

      } catch (error) {
        console.error('[UnifiedAuth] ❌ Erro no login:', error);

        // Disparar evento de erro
        window.dispatchEvent(new CustomEvent('nexos:auth:login-failed', {
          detail: { error: error.message }
        }));

        throw error;
      }
    }

    /**
     * Verifica se está autenticado
     */
    async isAuthenticated() {
      try {
        // Verificar cache
        if (this.tokenCache && this.tokenExpiryTime > Date.now()) {
          return true;
        }

        // Verificar MSAL
        if (!this.initialized) {
          await this.init();
        }

        const accounts = this.msalAuth?.getAllAccounts?.();
        if (accounts && accounts.length > 0) {
          // Tentar obter token silenciosamente
          const token = await this.getMSALToken();
          return !!token;
        }

        return false;

      } catch (error) {
        console.error('[UnifiedAuth] ❌ Erro ao verificar autenticação:', error);
        return false;
      }
    }

    /**
     * Garante autenticação (faz login se necessário)
     * @returns {Promise<Object>} Informações do usuário autenticado
     */
    async ensureAuthenticated() {
      try {
        // Verificar se já está autenticado
        const isAuth = await this.isAuthenticated();
        
        if (isAuth) {
          // Obter informações do usuário atual
          const accounts = this.msalAuth?.getAllAccounts?.();
          if (accounts && accounts.length > 0) {
            const account = accounts[0];
            return {
              id: account.homeAccountId,
              userPrincipalName: account.username,
              displayName: account.name || account.username,
              mail: account.username
            };
          }
        }

        // Não autenticado - fazer login
        console.log('[UnifiedAuth] 🔐 Usuário não autenticado - iniciando login...');
        const response = await this.login();
        
        if (response && response.account) {
          return {
            id: response.account.homeAccountId,
            userPrincipalName: response.account.username,
            displayName: response.account.name || response.account.username,
            mail: response.account.username
          };
        }

        throw new Error('Login cancelado ou falhou');

      } catch (error) {
        console.error('[UnifiedAuth] ❌ Erro ao garantir autenticação:', error);
        throw error;
      }
    }

    /**
     * Logout
     */
    async logout() {
      try {
        console.log('[UnifiedAuth] 🔓 Fazendo logout...');

        // Limpar cache local
        this.tokenCache = null;
        this.tokenExpiryTime = null;

        // Logout do MSAL
        if (this.msalAuth) {
          await this.msalAuth.logout();
        }

        // Limpar storage
        await this.clearStorage();

        console.log('[UnifiedAuth] ✅ Logout completo');

        // Disparar evento
        window.dispatchEvent(new CustomEvent('nexos:auth:logout'));

      } catch (error) {
        console.error('[UnifiedAuth] ❌ Erro no logout:', error);
        throw error;
      }
    }

    /**
     * Login via redirect (método alternativo quando popup não funciona)
     * Redireciona para Microsoft, volta automaticamente
     * 
     * ⚠️ IMPORTANTE: Força redirect URI fixo (chromiumapp.org) para evitar
     * que o usuário seja redirecionado para domínio errado após login
     */
    async loginRedirect() {
      try {
        console.log('[UnifiedAuth] 🔄 Redirecionando para login...');
        
        if (!this.initialized) {
          await this.init();
        }

        // Forçar chromiumapp.org como redirect URI
        const extensionId = chrome?.runtime?.id || 'obodcljemkajclohcfjhmommhfpklojo';
        const fixedRedirectUri = `https://${extensionId}.chromiumapp.org/`;

        console.log('[UnifiedAuth] 📍 Usando redirect URI fixo:', fixedRedirectUri);

        const loginRequest = {
          scopes: ['https://graph.microsoft.com/.default'],
          prompt: 'select_account',
          redirectUri: fixedRedirectUri // ✅ Força URI correto
        };

        // Salvar estado antes de redirecionar
        sessionStorage.setItem('nexos-auth-redirect', Date.now().toString());
        sessionStorage.setItem('nexos-auth-redirect-uri', fixedRedirectUri);

        // Redirecionar (não retorna - página será recarregada)
        await this.msalAuth.loginRedirect(loginRequest);

      } catch (error) {
        console.error('[UnifiedAuth] ❌ Erro no redirect:', error);
        throw error;
      }
    }

    /**
     * Sincroniza token MSAL para storage
     * Garante que TokenManager e outros componentes vejam o token
     */
    async syncTokenToStorage() {
      try {
        if (!this.tokenCache) {
          console.warn('[UnifiedAuth] ⚠️ Nenhum token para sincronizar');
          return;
        }

        console.log('[UnifiedAuth] 💾 Sincronizando token para storage...');

        const tokenData = {
          access_token: this.tokenCache,
          token_type: 'Bearer',
          expires_at: this.tokenExpiryTime,
          source: 'msal',
          synced_at: Date.now()
        };

        // Salvar em múltiplos locais para compatibilidade
        const storageKeys = [
          'nexos-auth-token',
          'auth-token',
          'msal-token',
          'access-token',
          'nexos-unified-token'
        ];

        // chrome.storage.local (prioritário)
        try {
          const storageData = {};
          storageKeys.forEach(key => {
            storageData[key] = tokenData;
          });
          await chrome.storage.local.set(storageData);
          console.log('[UnifiedAuth] ✅ Token salvo em chrome.storage.local');
        } catch (chromeError) {
          console.warn('[UnifiedAuth] ⚠️ chrome.storage falhou:', chromeError.message);
        }

        // localStorage (fallback)
        try {
          storageKeys.forEach(key => {
            localStorage.setItem(key, JSON.stringify(tokenData));
          });
          console.log('[UnifiedAuth] ✅ Token salvo em localStorage');
        } catch (localError) {
          console.warn('[UnifiedAuth] ⚠️ localStorage falhou:', localError.message);
        }

        // sessionStorage (temporário)
        try {
          storageKeys.forEach(key => {
            sessionStorage.setItem(key, JSON.stringify(tokenData));
          });
          console.log('[UnifiedAuth] ✅ Token salvo em sessionStorage');
        } catch (sessionError) {
          console.warn('[UnifiedAuth] ⚠️ sessionStorage falhou:', sessionError.message);
        }

        console.log('[UnifiedAuth] ✅ Sincronização completa');

      } catch (error) {
        console.error('[UnifiedAuth] ❌ Erro ao sincronizar token:', error);
        // Não fazer throw - sincronização é best-effort
      }
    }

    /**
     * Limpa todos os storages
     */
    async clearStorage() {
      const storageKeys = [
        'nexos-auth-token',
        'auth-token',
        'msal-token',
        'access-token',
        'nexos-unified-token'
      ];

      // chrome.storage
      try {
        await chrome.storage.local.remove(storageKeys);
      } catch (e) {}

      // localStorage
      try {
        storageKeys.forEach(key => localStorage.removeItem(key));
      } catch (e) {}

      // sessionStorage
      try {
        storageKeys.forEach(key => sessionStorage.removeItem(key));
      } catch (e) {}
    }

    /**
     * Auto-sync a cada 5 minutos
     */
    startAutoSync() {
      setInterval(async () => {
        try {
          const isAuth = await this.isAuthenticated();
          if (isAuth && this.tokenCache) {
            console.log('[UnifiedAuth] 🔄 Auto-sync...');
            await this.syncTokenToStorage();
          }
        } catch (error) {
          console.error('[UnifiedAuth] ❌ Erro no auto-sync:', error);
        }
      }, 5 * 60 * 1000); // 5 minutos
    }

    /**
     * Força refresh do token
     */
    async refreshToken() {
      console.log('[UnifiedAuth] 🔄 Forçando refresh do token...');
      
      // Limpar cache para forçar nova obtenção
      this.tokenCache = null;
      this.tokenExpiryTime = null;
      
      // Obter novo token
      return await this.getAccessToken();
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════════
     * ALIASES PARA COMPATIBILIDADE
     * ═══════════════════════════════════════════════════════════════════════════
     */

    /**
     * Alias para login() - usa popup
     */
    async loginPopup() {
      return await this.login();
    }

    /**
     * Alias para getMSALToken() - compatibilidade com código antigo
     */
    async getMsalToken() {
      return await this.getMSALToken();
    }

    /**
     * Obtém user info do MSAL (se logado)
     * 🆕 FALLBACK: Se MSAL não tiver conta, tenta obter do NexosAuth
     */
    getMsalUser() {
      if (!this.msalAuth || !this.msalAuth.msalInstance) {
        console.warn('[UnifiedAuth] ⚠️ MSAL não disponível, tentando NexosAuth...');
        
        // Fallback: usar NexosAuth
        if (window.NexosAuth) {
          const nexosUser = window.NexosAuth.getCurrentUser();
          if (nexosUser) {
            console.log('[UnifiedAuth] ✅ Usando usuário do NexosAuth:', nexosUser.email);
            return {
              username: nexosUser.email,
              name: nexosUser.name,
              source: 'NexosAuth' // Indicador de fallback
            };
          }
        }
        
        return null;
      }

      const accounts = this.msalAuth.msalInstance.getAllAccounts();
      if (!accounts || accounts.length === 0) {
        console.warn('[UnifiedAuth] ⚠️ MSAL sem contas, tentando NexosAuth...');
        
        // Fallback: usar NexosAuth
        if (window.NexosAuth) {
          const nexosUser = window.NexosAuth.getCurrentUser();
          if (nexosUser) {
            console.log('[UnifiedAuth] ✅ Usando usuário do NexosAuth:', nexosUser.email);
            return {
              username: nexosUser.email,
              name: nexosUser.name,
              source: 'NexosAuth' // Indicador de fallback
            };
          }
        }
        
        return null;
      }

      return accounts[0]; // Retorna primeira conta MSAL
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SINGLETON GLOBAL
  // ═══════════════════════════════════════════════════════════════════════════

  if (typeof window !== 'undefined') {
    window.UnifiedAuthManager = UnifiedAuthManager;
    window.unifiedAuth = new UnifiedAuthManager();
    
    // Auto-inicializar após 2 segundos (dar tempo pro MSAL carregar)
    setTimeout(async () => {
      try {
        await window.unifiedAuth.init();
      } catch (error) {
        console.error('[UnifiedAuth] ❌ Auto-init falhou:', error);
      }
    }, 2000);

    console.log('[UnifiedAuth] 📦 Módulo carregado - window.unifiedAuth disponível');
  }

})();
