/**
 * Nexos Torre - Microsoft Entra ID OAuth Client
 * Implementação OAuth 2.0 com PKCE (Proof Key for Code Exchange)
 * 
 * Referências:
 * - https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-auth-code-flow
 * - https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-implicit-grant-flow
 */

class OAuthClient {
  constructor(config) {
    this.config = config || (typeof NEXOS_CONFIG !== 'undefined' ? NEXOS_CONFIG.auth : null);
    
    if (!this.config) {
      throw new Error('OAuthClient: Configuração de autenticação não fornecida');
    }
    
    // Validar campos obrigatórios
    if (!this.config.scopes || !Array.isArray(this.config.scopes)) {
      throw new Error('OAuthClient: config.scopes deve ser um array de strings');
    }
    
    if (!this.config.clientId) {
      throw new Error('OAuthClient: config.clientId não fornecido');
    }
    
    if (!this.config.tenantId) {
      throw new Error('OAuthClient: config.tenantId não fornecido');
    }
    
    if (!this.config.authority) {
      throw new Error('OAuthClient: config.authority não fornecido');
    }
    
    // Validar/gerar redirect URI baseado no ID da extensão
    // Formato para Chrome extensions: https://EXTENSION_ID.chromiumapp.org/
    if (!this.config.redirectUri || this.config.redirectUri.startsWith('chrome-extension://')) {
      // Se não tem ou está no formato chrome-extension://, gerar o correto
      try {
        const extensionId = chrome.runtime.id;
        this.config.redirectUri = `https://${extensionId}.chromiumapp.org/`;
        console.log('[OAuth] Redirect URI gerado dinamicamente:', this.config.redirectUri);
      } catch (err) {
        console.error('[OAuth] Erro ao obter ID da extensão:', err);
        this.config.redirectUri = 'https://oeapadgapicgkiebeihodhiplkemgjbk.chromiumapp.org/';
        console.log('[OAuth] Usando redirect URI fallback:', this.config.redirectUri);
      }
    } else {
      console.log('[OAuth] Usando redirect URI da configuração:', this.config.redirectUri);
    }
    
    // `config.authority` pode já conter o tenantId (ex: https://login.microsoftonline.com/<tenantId>)
    // Evitar duplicar o tenantId na URL (causa 404). Se o tenant já estiver presente, use como-is.
    try {
      const normalizedAuthority = String(this.config.authority).replace(/\/+$/, '');
      if (normalizedAuthority.endsWith('/' + this.config.tenantId) || normalizedAuthority.match(new RegExp('/' + this.config.tenantId + '$'))) {
        this.authority = normalizedAuthority; // já contém tenantId
      } else if (normalizedAuthority.endsWith(this.config.tenantId)) {
        this.authority = normalizedAuthority;
      } else {
        this.authority = `${normalizedAuthority}/${this.config.tenantId}`;
      }
    } catch (err) {
      this.authority = `${this.config.authority}/${this.config.tenantId}`;
    }

    this.authEndpoint = `${this.authority.replace(/\/+$/, '')}/oauth2/v2.0/authorize`;
    this.tokenEndpoint = `${this.authority}/oauth2/v2.0/token`;
    this.logoutEndpoint = `${this.authority}/oauth2/v2.0/logout`;
    
    // Estado da autenticação
    this.currentUser = null;
    this.authWindow = null;
    
    console.log('[OAuth] Cliente OAuth inicializado', {
      authority: this.authority,
      redirectUri: this.config.redirectUri,
      clientId: this.config.clientId,
      tenantId: this.config.tenantId
    });
    
    // Log adicional para debug
    console.log('[OAuth] ⚠️ IMPORTANTE: Verifique se este Redirect URI está registrado no Azure AD:');
    console.log('[OAuth]   → ' + this.config.redirectUri);
  }
  
  /**
   * Gera code verifier e code challenge para PKCE
   * @returns {Promise<{verifier: string, challenge: string}>}
   */
  async generatePKCE() {
    // Gerar code verifier (string aleatória de 43-128 chars)
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    const verifier = this._base64URLEncode(array);
    
    // Gerar code challenge (SHA256 hash do verifier)
    const encoder = new TextEncoder();
    const data = encoder.encode(verifier);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const challenge = this._base64URLEncode(new Uint8Array(hashBuffer));
    
    return {
      verifier,
      challenge
    };
  }
  
  /**
   * Codifica em Base64 URL-safe
   * @private
   */
  _base64URLEncode(buffer) {
    const base64 = btoa(String.fromCharCode.apply(null, buffer));
    return base64
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=/g, '');
  }
  
  /**
   * Gera state aleatório para proteção CSRF
   * @returns {string}
   */
  generateState() {
    const array = new Uint8Array(16);
    crypto.getRandomValues(array);
    return this._base64URLEncode(array);
  }
  
  /**
   * Constrói URL de autorização
   * @param {string} codeChallenge - Code challenge PKCE
   * @param {string} state - State para CSRF protection
   * @returns {string} Authorization URL
   */
  buildAuthUrl(codeChallenge, state) {
    const params = new URLSearchParams({
      client_id: this.config.clientId,
      response_type: 'code',
      redirect_uri: this.config.redirectUri,
      scope: this.config.scopes.join(' '),
      state: state,
      code_challenge: codeChallenge,
      code_challenge_method: 'S256',
      prompt: 'select_account'  // Permitir escolha de conta
    });
    
    const authUrl = `${this.authEndpoint}?${params.toString()}`;
    
    console.log('[OAuth] URL de autorização construída:');
    console.log('[OAuth]   → redirect_uri:', this.config.redirectUri);
    console.log('[OAuth]   → client_id:', this.config.clientId);
    console.log('[OAuth]   → scopes:', this.config.scopes.join(' '));
    
    return authUrl;
  }
  
  /**
   * Inicia fluxo de autenticação OAuth
   * @returns {Promise<{code: string, state: string}>}
   */
  async authorize() {
    // Gerar PKCE
    const pkce = await this.generatePKCE();
    const state = this.generateState();
    
    // Salvar verifier e state para validação posterior
    await this._saveAuthState({
      codeVerifier: pkce.verifier,
      state: state,
      timestamp: Date.now()
    });
    
    // Construir URL de autorização
    const authUrl = this.buildAuthUrl(pkce.challenge, state);
    
    console.log('[OAuth] Iniciando autorização...', { authUrl });

    // DEBUG: gravar authUrl e contexto antes de chamar chrome.identity
    try {
      const dbgKey = '__nexos_oauth_debug';
      const dbgEntry = {
        ts: Date.now(),
        action: 'authorize.start',
        authUrl,
        redirectUri: this.config.redirectUri,
        extensionId: (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) ? chrome.runtime.id : null,
        userAgent: navigator.userAgent
      };
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get([dbgKey], (res) => {
          const arr = res[dbgKey] || [];
          arr.push(dbgEntry);
          const max = 50;
          const toSave = arr.slice(-max);
          chrome.storage.local.set({ [dbgKey]: toSave }, () => {});
        });
      } else {
        console.log('[OAuth][Debug]', dbgEntry);
      }
    } catch (e) {
      console.warn('[OAuth] Falha ao gravar debug inicial:', e);
    }

    // Usar chrome.identity.launchWebAuthFlow (API oficial do Chrome para OAuth)
    if (typeof chrome !== 'undefined' && chrome.identity && chrome.identity.launchWebAuthFlow) {
      console.log('[OAuth] Usando chrome.identity.launchWebAuthFlow (tentativa)');

      // Wrapper que tenta launchWebAuthFlow e, se falhar, deixa o fluxo continuar
      const tryLaunch = () => new Promise((resolve, reject) => {
        try {
          chrome.identity.launchWebAuthFlow({ url: String(authUrl), interactive: true }, (redirectUrl) => {
            if (chrome.runtime.lastError) {
              // Registrar debug do erro e rejeitar para que possamos tentar fallback
              console.warn('[OAuth] launchWebAuthFlow falhou:', chrome.runtime.lastError);
              try {
                const dbgKey = '__nexos_oauth_debug';
                const dbgErr = {
                  ts: Date.now(),
                  action: 'launchWebAuthFlow.error',
                  // gravar apenas a message para evitar problemas de serialização vazia
                  lastErrorMessage: chrome.runtime.lastError.message || null
                };
                if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                  chrome.storage.local.get([dbgKey], (res) => {
                    const arr = res[dbgKey] || [];
                    arr.push(dbgErr);
                    const max = 200;
                    const toSave = arr.slice(-max);
                    chrome.storage.local.set({ [dbgKey]: toSave }, () => {});
                  });
                } else {
                  console.log('[OAuth][DebugErr]', dbgErr);
                }
              } catch (e) {
                console.warn('[OAuth] Falha ao gravar debug de erro:', e);
              }

              reject(new Error(chrome.runtime.lastError.message || 'Erro desconhecido ao autenticar'));
              return;
            }

            if (!redirectUrl) {
              reject(new Error('Nenhuma URL de redirect foi recebida'));
              return;
            }

            resolve(redirectUrl);
          });
        } catch (err) {
          reject(err);
        }
      });

      try {
        const redirectUrl = await tryLaunch();
        console.log('[OAuth] launchWebAuthFlow retornou redirectUrl:', redirectUrl);

        // processar redirectUrl como antes
        try {
          const url = new URL(redirectUrl);
          const code = url.searchParams.get('code');
          const returnedState = url.searchParams.get('state');
          const error = url.searchParams.get('error');
          const errorDescription = url.searchParams.get('error_description');

          if (error) {
            throw new Error(`Autorização falhou: ${error} - ${errorDescription}`);
          }

          if (!code) {
            throw new Error('Authorization code não recebido');
          }

          console.log('[OAuth] ✅ Authorization code recebido (launchWebAuthFlow)');
          return { code, state: returnedState };
        } catch (err) {
          // Propagar para outer catch que tentará fallback
          throw err;
        }
      } catch (err) {
        console.warn('[OAuth] launchWebAuthFlow falhou/lançou erro — fallback será tentado:', err && err.message);
        // não rejeitar aqui; continuar para tentar o fallback com tabs+webRequest
      }
    }

    // Fallback manual: usar chrome.tabs + chrome.webRequest para interceptar redirect
    // Útil quando chrome.identity.launchWebAuthFlow falha em alguns ambientes
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.webRequest) {
      console.warn('[OAuth] launchWebAuthFlow falhou ou indisponível — tentando fallback via tabs + webRequest');

      return new Promise((resolve, reject) => {
        let timeoutId = null;
        let tabId = null;

        const onBeforeRequestHandler = (details) => {
          try {
            // details.url deve conter ?code=...
            const url = new URL(details.url);
            const code = url.searchParams.get('code');
            const returnedState = url.searchParams.get('state');
            const error = url.searchParams.get('error');

            if (error) {
              cleanup();
              reject(new Error('Autorização falhou: ' + error));
              return;
            }

            if (!code) {
              // Ignorar se não houver code
              return;
            }

            cleanup();
            resolve({ code, state: returnedState });
          } catch (err) {
            cleanup();
            reject(err);
          }
        };

        const cleanup = () => {
          try {
            if (timeoutId) clearTimeout(timeoutId);
            if (tabId) {
              try { chrome.tabs.remove(tabId); } catch (e) {}
              tabId = null;
            }
            try { chrome.webRequest.onBeforeRequest.removeListener(onBeforeRequestHandler); } catch (e) {}
          } catch (e) {}
        };

        try {
          const filter = { urls: [this.config.redirectUri + '*'] };
          chrome.webRequest.onBeforeRequest.addListener(onBeforeRequestHandler, filter);

          chrome.tabs.create({ url: authUrl, active: true }, (tab) => {
            if (chrome.runtime.lastError) {
              cleanup();
              reject(new Error(chrome.runtime.lastError.message || 'Falha ao abrir aba de autenticação'));
              return;
            }
            tabId = tab.id;

            // Timeout (5 minutos)
            timeoutId = setTimeout(() => {
              cleanup();
              reject(new Error('Timeout: Autenticação não completada'));
            }, 5 * 60 * 1000);
          });
        } catch (err) {
          cleanup();
          reject(err);
        }
      });
    }
    
    // Fallback: usar window.open (antigo método, pode ter problemas COOP)
    console.log('[OAuth] chrome.identity não disponível, usando window.open (fallback)');
    
    return new Promise((resolve, reject) => {
      const width = 600;
      const height = 700;
      const left = (screen.width - width) / 2;
      const top = (screen.height - height) / 2;
      
      // Abrir janela de autenticação
      this.authWindow = window.open(
        authUrl,
        'nexos-oauth-login',
        `width=${width},height=${height},left=${left},top=${top},toolbar=no,menubar=no,location=no`
      );
      
      if (!this.authWindow) {
        reject(new Error('Não foi possível abrir janela de autenticação. Verifique se popups estão permitidos.'));
        return;
      }
      
      // Listener para postMessage do auth-callback.html
      const messageHandler = (event) => {
        if (event.data && event.data.type === 'nexos-oauth-callback') {
          console.log('[OAuth] Callback recebido via postMessage');
          window.removeEventListener('message', messageHandler);
          clearInterval(checkInterval);
          
          if (this.authWindow && !this.authWindow.closed) {
            this.authWindow.close();
          }
          
          resolve({
            code: event.data.code,
            state: event.data.state
          });
        }
      };
      
      window.addEventListener('message', messageHandler);
      
      // Monitorar redirecionamento
      const checkInterval = setInterval(() => {
        try {
          const url = this.authWindow.location.href;
          
          if (url.startsWith(this.config.redirectUri)) {
            clearInterval(checkInterval);
            window.removeEventListener('message', messageHandler);
            this.authWindow.close();
            
            const urlParams = new URL(url);
            const code = urlParams.searchParams.get('code');
            const returnedState = urlParams.searchParams.get('state');
            const error = urlParams.searchParams.get('error');
            
            if (error) {
              reject(new Error(`Autorização falhou: ${error}`));
              return;
            }
            
            if (!code) {
              reject(new Error('Authorization code não recebido'));
              return;
            }
            
            resolve({ code, state: returnedState });
          }
        } catch (err) {
          // Ignorar cross-origin errors
        }
        
        if (this.authWindow.closed) {
          clearInterval(checkInterval);
          window.removeEventListener('message', messageHandler);
          reject(new Error('Janela de autenticação foi fechada'));
        }
      }, 500);
      
      // Timeout
      setTimeout(() => {
        window.removeEventListener('message', messageHandler);
        if (this.authWindow && !this.authWindow.closed) {
          clearInterval(checkInterval);
          this.authWindow.close();
          reject(new Error('Timeout: Autenticação não completada'));
        }
      }, 5 * 60 * 1000);
    });
  }
  
  /**
   * Troca authorization code por tokens
   * @param {string} code - Authorization code
   * @returns {Promise<{access_token: string, refresh_token: string, expires_in: number}>}
   */
  async exchangeCodeForTokens(code) {
    // Recuperar state salvo
    const authState = await this._getAuthState();
    
    if (!authState || !authState.codeVerifier) {
      throw new Error('Code verifier não encontrado. Estado de autenticação inválido.');
    }
    
    // Preparar body para token request
    const body = new URLSearchParams({
      client_id: this.config.clientId,
      grant_type: 'authorization_code',
      code: code,
      redirect_uri: this.config.redirectUri,
      code_verifier: authState.codeVerifier
    });
    
    console.log('[OAuth] Trocando code por tokens...');
    
    // Fazer request
    const response = await fetch(this.tokenEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: body.toString()
    });
    
    if (!response.ok) {
      const error = await response.json();
      console.error('[OAuth] Erro ao obter tokens:', error);
      throw new Error(`Falha ao obter tokens: ${error.error_description || error.error}`);
    }
    
    const tokens = await response.json();
    console.log('[OAuth] Tokens obtidos com sucesso');
    
    // Limpar state
    await this._clearAuthState();
    
    return tokens;
  }
  
  /**
   * Renova access token usando refresh token
   * @param {string} refreshToken - Refresh token
   * @returns {Promise<{access_token: string, refresh_token: string, expires_in: number}>}
   */
  async refreshAccessToken(refreshToken) {
    const body = new URLSearchParams({
      client_id: this.config.clientId,
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
      scope: this.config.scopes.join(' ')
    });
    
    console.log('[OAuth] Renovando access token...');
    
    const response = await fetch(this.tokenEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: body.toString()
    });
    
    if (!response.ok) {
      const error = await response.json();
      console.error('[OAuth] Erro ao renovar token:', error);
      throw new Error(`Falha ao renovar token: ${error.error_description || error.error}`);
    }
    
    const tokens = await response.json();
    console.log('[OAuth] Token renovado com sucesso');
    
    return tokens;
  }
  
  /**
   * Fluxo completo de login
   * @returns {Promise<{tokens: object, user: object}>}
   */
  async login() {
    try {
      console.log('[OAuth] Iniciando fluxo de login...');
      
      // 1. Autorização (obter code)
      const { code, state } = await this.authorize();
      
      // 2. Validar state (proteção CSRF)
      const savedState = await this._getAuthState();
      if (!savedState || savedState.state !== state) {
        throw new Error('State inválido. Possível ataque CSRF detectado.');
      }
      
      // 3. Trocar code por tokens
      const tokens = await this.exchangeCodeForTokens(code);
      
      // 4. Obter perfil do usuário
      const user = await this.getUserProfile(tokens.access_token);
      
      // 5. Salvar usuário (tokens serão salvos pelo AuthHelper)
      this.currentUser = user;
      
      console.log('[OAuth] Login concluído com sucesso', {
        user: user.displayName,
        userPrincipalName: user.userPrincipalName
      });
      
      // Disparar evento de login
      this._dispatchEvent('nexos:auth:login', { user, tokens });
      
      return { tokens, user };
      
    } catch (error) {
      console.error('[OAuth] Erro durante login:', error);
      this._dispatchEvent('nexos:auth:error', { error });
      throw error;
    }
  }
  
  /**
   * Logout do usuário
   */
  async logout() {
    try {
      console.log('[OAuth] Fazendo logout...');
      
      // Limpar usuário (tokens serão limpos pelo AuthHelper)
      this.currentUser = null;
      
      // Disparar evento de logout
      this._dispatchEvent('nexos:auth:logout');
      
      console.log('[OAuth] Logout concluído');
      
    } catch (error) {
      console.error('[OAuth] Erro durante logout:', error);
      throw error;
    }
  }
  
  /**
   * Obtém perfil do usuário via Microsoft Graph API
   * @param {string} accessToken - Access token
   * @returns {Promise<object>} Perfil do usuário
   */
  async getUserProfile(accessToken) {
    const response = await fetch('https://graph.microsoft.com/v1.0/me', {
      headers: {
        'Authorization': `Bearer ${accessToken}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Falha ao obter perfil do usuário');
    }
    
    const profile = await response.json();
    
    // Extrair informações relevantes
    return {
      id: profile.id,
      displayName: profile.displayName,
      givenName: profile.givenName,
      surname: profile.surname,
      userPrincipalName: profile.userPrincipalName,
      mail: profile.mail,
      jobTitle: profile.jobTitle,
      department: profile.department,
      officeLocation: profile.officeLocation,
      mobilePhone: profile.mobilePhone
    };
  }
  
  /**
   * Salva estado de autenticação (PKCE verifier e state)
   * @private
   */
  async _saveAuthState(state) {
    try {
      await chrome.storage.local.set({ 'nexos-auth-state': state });
    } catch (err) {
      console.warn('[OAuth] Fallback para sessionStorage:', err);
      sessionStorage.setItem('nexos-auth-state', JSON.stringify(state));
    }
  }
  
  /**
   * Recupera estado de autenticação
   * @private
   */
  async _getAuthState() {
    try {
      const result = await chrome.storage.local.get(['nexos-auth-state']);
      return result['nexos-auth-state'] || null;
    } catch (err) {
      const stored = sessionStorage.getItem('nexos-auth-state');
      return stored ? JSON.parse(stored) : null;
    }
  }
  
  /**
   * Limpa estado de autenticação
   * @private
   */
  async _clearAuthState() {
    try {
      await chrome.storage.local.remove(['nexos-auth-state']);
    } catch (err) {
      sessionStorage.removeItem('nexos-auth-state');
    }
  }
  
  /**
   * Dispara evento customizado
   * @private
   */
  _dispatchEvent(eventName, detail = {}) {
    try {
      // Enviar via chrome.runtime (funciona em service worker e content scripts)
      try {
        chrome.runtime.sendMessage({
          type: eventName,
          ...detail
        }).catch(() => {
          // Ignorar erro se background script não estiver escutando
        });
      } catch (e) {
        // chrome.runtime pode não estar disponível em alguns contextos
      }
      
      // Se temos window (não é service worker), disparar evento DOM também
      if (typeof window !== 'undefined') {
        try {
          const event = new CustomEvent(eventName, { detail });
          window.dispatchEvent(event);
        } catch (windowErr) {
          // Ignorar erro em contextos sem window
        }
      }
    } catch (err) {
      console.warn('[OAuth] Erro ao disparar evento:', err);
    }
  }
}

// Exportar
if (typeof module !== 'undefined' && module.exports) {
  module.exports = OAuthClient;
}

// Export global para content scripts e service worker
if (typeof window !== 'undefined') {
  window.OAuthClient = OAuthClient;
  console.log('[OAuthClient] ✅ Disponível globalmente');
} else if (typeof self !== 'undefined') {
  self.OAuthClient = OAuthClient;
  console.log('[OAuthClient] ✅ Disponível no service worker');
}
