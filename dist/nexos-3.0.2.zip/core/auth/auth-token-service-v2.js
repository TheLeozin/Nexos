/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - AUTH TOKEN SERVICE V2
 * Serviço centralizado de autenticação integrado ao TokenVaultManager
 * 
 * Responsabilidades:
 * ✅ Única fonte de verdade para tokens (SharePoint Nexos_TokenVault via TokenVaultManager)
 * ✅ Validação de tokens (expiração, validade)
 * ✅ Renovação silenciosa de tokens via MSAL
 * ✅ Revogação de tokens
 * ✅ Distribuição segura de tokens para extensão
 * 
 * NUNCA:
 * ❌ Armazenar em chrome.storage.local
 * ❌ Armazenar em IndexedDB
 * ❌ Armazenar em localStorage
 * ❌ Expor token em APIs públicas
 * ═══════════════════════════════════════════════════════════════════════════
 */

class AuthTokenServiceV2 {
  constructor(tokenVaultManager, msalAuth) {
    this.tokenVault = tokenVaultManager;
    this.msalAuth = msalAuth;
    this.tokenCache = null;
    this.tokenCacheExpiresAt = null;
    
    if (!tokenVaultManager) {
      throw new Error('AuthTokenServiceV2 requer TokenVaultManager');
    }
    
    if (!msalAuth) {
      throw new Error('AuthTokenServiceV2 requer MsalAuth');
    }
    
    console.log('[AuthTokenServiceV2] ✅ Inicializado com TokenVaultManager e MSAL');
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // RECUPERAR TOKEN
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Obter userId (email corporativo)
   * @private
   */
  _getUserId() {
    // Primeiro: conta MSAL (fluxo MSAL nativo)
    const account = this.msalAuth?.getCurrentAccount?.();
    if (account?.username) return account.username;

    // Fallback: NexosAuth (fluxo chrome.identity — MSAL não tem conta em cache)
    const nexosUser = window.NexosAuth?.getCurrentUser?.();
    const userId = nexosUser?.email || nexosUser?.userPrincipalName || nexosUser?.mail;
    if (userId) return userId;

    throw new Error('Usuário não autenticado');
  }
  
  /**
   * Obter token válido (com renovação automática se expirado)
   * @returns {Promise<object>} { accessToken, refreshToken, expiresAt, expiresIn }
   */
  async getToken() {
    try {
      const userId = this._getUserId();
      
      // 1️⃣ Verificar cache em memória
      if (this.isTokenCacheValid()) {
        console.log('[AuthTokenServiceV2] ✅ Token encontrado em cache (memória)');
        return this.tokenCache;
      }
      
      // 2️⃣ Buscar de SharePoint via TokenVaultManager
      console.log('[AuthTokenServiceV2] Buscando token em SharePoint...');
      const tokenRecord = await this.tokenVault.getToken(userId);
      
      if (!tokenRecord) {
        console.warn('[AuthTokenServiceV2] ⚠️ Token não encontrado em SharePoint');
        throw new Error('Token não encontrado. Faça login.');
      }
      
      // 3️⃣ Verificar status
      const status = await this.tokenVault.checkTokenStatus(userId);
      
      if (!status.exists || !status.valid) {
        console.warn('[AuthTokenServiceV2] ⚠️ Token inválido');
        throw new Error('Token inválido. Faça login novamente.');
      }
      
      if (status.expired) {
        console.warn('[AuthTokenServiceV2] ⚠️ Token expirado, renovando...');
        return await this.renewToken();
      }
      
      // 4️⃣ Token válido, formatar e cachear
      const token = this._formatToken(tokenRecord);
      
      // Cache por 5 minutos ou até 1 minuto antes de expirar (menor)
      const now = Date.now();
      const cacheFor = Math.min(
        5 * 60 * 1000, 
        (token.expiresAt - now) - 60 * 1000
      );
      
      this.updateTokenCache(token, cacheFor);
      
      console.log('[AuthTokenServiceV2] ✅ Token válido, expira em', token.expiresIn, 'segundos');
      
      return token;
      
    } catch (error) {
      console.error('[AuthTokenServiceV2] ❌ Erro ao obter token:', error.message);
      throw error;
    }
  }
  
  /**
   * Obter apenas access token (string)
   * @returns {Promise<string>} Access token
   */
  async getAccessToken() {
    const token = await this.getToken();
    return token.accessToken;
  }
  
  /**
   * Formatar token do TokenVault para formato esperado
   * @private
   */
  _formatToken(tokenRecord) {
    const expiresAt = new Date(tokenRecord.ExpiresAt).getTime();
    const now = Date.now();
    
    return {
      accessToken: tokenRecord.AccessToken,
      refreshToken: tokenRecord.RefreshToken,
      expiresAt: expiresAt,
      expiresIn: Math.max(0, Math.round((expiresAt - now) / 1000)),
      tokenType: 'Bearer'
    };
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // SALVAR TOKEN
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Salvar novo token em SharePoint
   * @param {string} accessToken - Access token do OAuth
   * @param {string} refreshToken - Refresh token
   * @param {number} expiresIn - Segundos até expiração
   */
  async saveToken(accessToken, refreshToken, expiresIn) {
    try {
      console.log('[AuthTokenServiceV2] Salvando token em SharePoint...');
      
      if (!accessToken) {
        throw new Error('accessToken não pode ser vazio');
      }
      
      const userId = this._getUserId();
      const expiresAt = new Date(Date.now() + expiresIn * 1000).toISOString();
      
      // Gerar deviceID único
      const deviceId = await this._getDeviceID();
      
      // Verificar se já existe token
      const existing = await this.tokenVault.getToken(userId);
      
      if (existing) {
        // Atualizar existente
        await this.tokenVault.updateToken(userId, {
          AccessToken: accessToken,
          RefreshToken: refreshToken,
          ExpiresAt: expiresAt,
          LastUsedAt: new Date().toISOString(),
          IsValid: true
        });
        console.log('[AuthTokenServiceV2] ✅ Token atualizado em SharePoint');
      } else {
        // Criar novo
        await this.tokenVault.createToken({
          UserID: userId,
          AccessToken: accessToken,
          RefreshToken: refreshToken,
          ExpiresAt: expiresAt,
          DeviceID: deviceId,
          Scopes: this.msalAuth.defaultScopes.join(' ')
        });
        console.log('[AuthTokenServiceV2] ✅ Token criado em SharePoint');
      }
      
      // Atualizar cache
      const token = {
        accessToken,
        refreshToken,
        expiresAt: new Date(expiresAt).getTime(),
        expiresIn,
        tokenType: 'Bearer'
      };
      
      this.updateTokenCache(token, 5 * 60 * 1000); // Cache por 5 minutos
      
    } catch (error) {
      console.error('[AuthTokenServiceV2] ❌ Erro ao salvar token:', error.message);
      throw new Error(`Erro ao salvar token: ${error.message}`);
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // RENOVAR TOKEN
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Renovar token silenciosamente via MSAL
   */
  async renewToken() {
    try {
      console.log('[AuthTokenServiceV2] 🔄 Renovando token via MSAL...');
      
      const userId = this._getUserId();
      
      // Renovar via TokenVaultManager (que usa MSAL internamente)
      const renewedToken = await this.tokenVault.refreshToken(userId);
      
      if (!renewedToken) {
        throw new Error('Falha ao renovar token via MSAL');
      }
      
      // Formatar e cachear
      const token = this._formatToken(renewedToken);
      this.updateTokenCache(token, 5 * 60 * 1000);
      
      console.log('[AuthTokenServiceV2] ✅ Token renovado com sucesso');
      
      return token;
      
    } catch (error) {
      console.error('[AuthTokenServiceV2] ❌ Erro ao renovar:', error.message);
      
      // Limpar cache local para forçar novo login
      this.clearCache();
      
      throw error;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // REVOGAR TOKEN
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Revogar token (logout)
   */
  async revokeToken() {
    try {
      console.log('[AuthTokenServiceV2] 🚪 Revogando token...');
      
      const userId = this._getUserId();
      
      // Soft delete via TokenVaultManager
      await this.tokenVault.deleteToken(userId, false);
      
      // Limpar cache
      this.clearCache();
      
      console.log('[AuthTokenServiceV2] ✅ Token revogado');
      
    } catch (error) {
      console.error('[AuthTokenServiceV2] ❌ Erro ao revogar:', error.message);
      
      // Mesmo se falhar em SharePoint, limpar cache localmente
      this.clearCache();
      
      throw error;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CACHE EM MEMÓRIA
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Verificar se cache de token é válido
   * @private
   */
  isTokenCacheValid() {
    if (!this.tokenCache || !this.tokenCacheExpiresAt) {
      return false;
    }
    
    if (Date.now() >= this.tokenCacheExpiresAt) {
      console.log('[AuthTokenServiceV2] Cache expirou');
      this.tokenCache = null;
      return false;
    }
    
    return true;
  }
  
  /**
   * Atualizar cache em memória
   * @private
   */
  updateTokenCache(token, cacheFor = 5 * 60 * 1000) {
    this.tokenCache = token;
    this.tokenCacheExpiresAt = Date.now() + cacheFor;
    console.log('[AuthTokenServiceV2] Cache atualizado por', Math.round(cacheFor / 1000), 'segundos');
  }
  
  /**
   * Limpar cache
   */
  clearCache() {
    this.tokenCache = null;
    this.tokenCacheExpiresAt = null;
    console.log('[AuthTokenServiceV2] Cache limpo');
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // UTILITÁRIOS
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Obter ID do dispositivo (para rastreamento)
   * @private
   */
  async _getDeviceID() {
    try {
      const extensionId = chrome?.runtime?.id || 'unknown';
      const userAgent = navigator.userAgent;
      
      // Criar hash simples do deviceID
      const combined = `${extensionId}-${userAgent}`;
      const hash = await this._simpleHash(combined);
      
      return hash;
    } catch (error) {
      return 'unknown-device';
    }
  }
  
  /**
   * Hash simples para deviceID
   * @private
   */
  async _simpleHash(str) {
    const encoded = new TextEncoder().encode(str);
    const hashBuffer = await crypto.subtle.digest('SHA-256', encoded);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 16);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // VERIFICAÇÃO E MONITORAMENTO
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Verificar se usuário está autenticado
   */
  async isAuthenticated() {
    try {
      const token = await this.getToken();
      return !!token && !!token.accessToken;
    } catch (error) {
      return false;
    }
  }
  
  /**
   * Obter informações do token atual
   */
  async getTokenInfo() {
    try {
      const userId = this._getUserId();
      const status = await this.tokenVault.checkTokenStatus(userId);
      const token = await this.getToken();
      
      return {
        user: userId,
        expiresAt: new Date(token.expiresAt).toISOString(),
        expiresIn: token.expiresIn,
        isExpiringSoon: token.expiresIn < 5 * 60, // Menos de 5 minutos
        tokenType: token.tokenType,
        cached: this.isTokenCacheValid(),
        status: status
      };
    } catch (error) {
      const userId = this._getUserId();
      return {
        user: userId,
        authenticated: false,
        error: error.message
      };
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORTAR PARA WINDOW (MAIN WORLD)
// ═══════════════════════════════════════════════════════════════════════════
if (typeof window !== 'undefined') {
  window.AuthTokenServiceV2 = AuthTokenServiceV2;
  console.log('[AuthTokenServiceV2] ✅ Classe exportada para window.AuthTokenServiceV2');
}
