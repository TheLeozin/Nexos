/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - APP-ONLY AUTHENTICATION
 * Implementa Client Credentials Flow OAuth 2.0 para background tasks
 * 
 * CONTEXTO:
 * - Permite extensão funcionar 24/7 sem usuário logado
 * - Usado para: auto-update, sync automático, notificações push
 * - Diferente de OAuthClient (delegated): não precisa de user interaction
 * - Usa Application Permissions (Sites.Selected) configuradas no Azure AD
 * 
 * FLUXO:
 * 1. Extension background task inicia
 * 2. AppOnlyAuth.getAccessToken() é chamado
 * 3. Se token cached e válido → retorna imediatamente
 * 4. Se expirado → faz POST para token endpoint com client_credentials
 * 5. Armazena novo token em chrome.storage.local
 * 6. Background task usa token para chamar Graph API
 * 
 * SEGURANÇA:
 * - Client Secret nunca enviado para servidor (só em token request)
 * - Tokens cacheados com TTL
 * - Retry automático com exponential backoff
 * - Logs de auditoria de todas operações
 * ═══════════════════════════════════════════════════════════════════════════
 */

class AppOnlyAuth {
  constructor(config = (typeof self !== 'undefined' ? self.SHAREPOINT_CONFIG?.auth?.app : null)) {
    if (!config) {
      throw new Error('AppOnlyAuth: config.auth.app não encontrado no SHAREPOINT_CONFIG');
    }
    
    this.config = config;
    this.storageKey = 'nexos-app-only-token';
    this.tokenCache = null;
    
    console.log('[AppOnlyAuth] Inicializado com config:', {
      clientId: config.clientId,
      tenantId: config.tenantId,
      authority: config.authority,
      hasClientSecret: !!config.clientSecret
    });
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // TOKEN MANAGEMENT
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Obtém access token válido (cached ou novo)
   * @returns {Promise<string>} Access token
   */
  async getAccessToken() {
    try {
      console.log('[AppOnlyAuth] Obtendo access token...');
      
      // Verificar se há token em cache válido
      const cachedToken = await this._getCachedToken();
      if (cachedToken) {
        console.log('[AppOnlyAuth] ✅ Token cached válido encontrado');
        return cachedToken;
      }
      
      // Token expirado ou não existe - adquirir novo
      console.log('[AppOnlyAuth] Token expirado/inexistente - adquirindo novo...');
      const newToken = await this._acquireNewToken();
      
      // Cachear novo token
      await this._cacheToken(newToken);
      
      console.log('[AppOnlyAuth] ✅ Novo token adquirido e cacheado');
      return newToken.access_token;
      
    } catch (error) {
      console.error('[AppOnlyAuth] ❌ Erro ao obter access token:', error);
      throw new Error(`AppOnlyAuth: Falha ao obter token - ${error.message}`);
    }
  }
  
  /**
   * Força renovação do token (ignora cache)
   * @returns {Promise<string>} Novo access token
   */
  async refreshToken() {
    console.log('[AppOnlyAuth] Forçando refresh de token...');
    
    try {
      const newToken = await this._acquireNewToken();
      await this._cacheToken(newToken);
      
      console.log('[AppOnlyAuth] ✅ Token renovado com sucesso');
      return newToken.access_token;
      
    } catch (error) {
      console.error('[AppOnlyAuth] ❌ Erro ao renovar token:', error);
      throw error;
    }
  }
  
  /**
   * Limpa token cacheado (útil para troubleshooting)
   */
  async clearToken() {
    console.log('[AppOnlyAuth] Limpando token cacheado...');
    
    this.tokenCache = null;
    
    try {
      await chrome.storage.local.remove(this.storageKey);
      console.log('[AppOnlyAuth] ✅ Token limpo com sucesso');
    } catch (error) {
      console.warn('[AppOnlyAuth] ⚠️ Erro ao limpar token do storage:', error);
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // PRIVATE: TOKEN ACQUISITION
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Adquire novo token via Azure Function Proxy
   * @private
   */
  async _acquireNewToken() {
    console.log('[AppOnlyAuth] Adquirindo token via Azure Function Proxy...');
    
    try {
      // Verificar se AzureFunctionTokenClient está disponível
      const globalScope = typeof self !== 'undefined' ? self : (typeof window !== 'undefined' ? window : null);
      if (!globalScope || !globalScope.AzureFunctionTokenClient) {
        throw new Error('AzureFunctionTokenClient não carregado. Certifique-se de importar azure-function-token-client.js antes de app-auth.js');
      }
      
      // Obter configuração da Function URL
      const functionUrl = this.config.azureFunctionUrl || 
                         (globalScope.SHAREPOINT_CONFIG?.auth?.app?.azureFunctionUrl) ||
                         'http://localhost:7071/api/token'; // Fallback para desenvolvimento local
      
      console.log('[AppOnlyAuth] Azure Function URL:', functionUrl);
      
      // Criar cliente
      const tokenClient = new globalScope.AzureFunctionTokenClient({
        functionUrl: functionUrl,
        timeout: 10000
      });
      
      // Obter token
      const tokenData = await tokenClient.getAccessToken();
      
      console.log('[AppOnlyAuth] ✅ Token adquirido com sucesso via Azure Function:', {
        token_type: tokenData.token_type,
        expires_in: tokenData.expires_in,
        access_token_length: tokenData.access_token?.length
      });
      
      return tokenData;
      
    } catch (error) {
      console.error('[AppOnlyAuth] ❌ Erro ao obter token via Azure Function:', error);
      
      // Log de auditoria para troubleshooting
      this._logAuditEvent('token_acquisition_failed', {
        error: error.message,
        functionUrl: functionUrl,
        timestamp: new Date().toISOString()
      });
      
      throw error;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // PRIVATE: TOKEN CACHING
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Obtém token do cache (memória ou storage)
   * @private
   */
  async _getCachedToken() {
    // Verificar cache em memória primeiro (mais rápido)
    if (this.tokenCache && this._isTokenValid(this.tokenCache)) {
      console.log('[AppOnlyAuth] Token encontrado em cache de memória');
      return this.tokenCache.access_token;
    }
    
    // Cache em memória expirado/vazio - verificar storage
    try {
      const stored = await chrome.storage.local.get(this.storageKey);
      const tokenData = stored[this.storageKey];
      
      if (tokenData && this._isTokenValid(tokenData)) {
        console.log('[AppOnlyAuth] Token encontrado em chrome.storage.local');
        this.tokenCache = tokenData;
        return tokenData.access_token;
      }
      
      console.log('[AppOnlyAuth] Nenhum token válido encontrado em cache');
      return null;
      
    } catch (error) {
      console.warn('[AppOnlyAuth] ⚠️ Erro ao ler token do storage:', error);
      return null;
    }
  }
  
  /**
   * Cacheia token em memória e storage
   * @private
   */
  async _cacheToken(tokenData) {
    // Cache em memória
    this.tokenCache = tokenData;
    
    // Persistir em storage
    try {
      await chrome.storage.local.set({
        [this.storageKey]: tokenData
      });
      
      console.log('[AppOnlyAuth] Token cacheado em memória e storage');
      
    } catch (error) {
      console.warn('[AppOnlyAuth] ⚠️ Erro ao cachear token no storage (usando apenas memória):', error);
      // Não é crítico - token ainda está em memória
    }
  }
  
  /**
   * Verifica se token ainda é válido (não expirado)
   * @private
   */
  _isTokenValid(tokenData) {
    if (!tokenData || !tokenData.access_token || !tokenData.expires_in || !tokenData.acquired_at) {
      return false;
    }
    
    const expiresAt = tokenData.acquired_at + (tokenData.expires_in * 1000);
    const now = Date.now();
    
    // Buffer de 5 minutos antes de expirar (300000ms)
    const bufferMs = 300000;
    const isValid = (expiresAt - now) > bufferMs;
    
    if (!isValid) {
      const remainingMs = expiresAt - now;
      console.log('[AppOnlyAuth] Token expirado ou próximo de expirar:', {
        remainingMs,
        bufferMs,
        expired: remainingMs <= 0
      });
    }
    
    return isValid;
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // PRIVATE: LOGGING & AUDIT
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Log de eventos de auditoria
   * @private
   */
  _logAuditEvent(action, details) {
    try {
      const event = {
        action,
        details,
        timestamp: new Date().toISOString(),
        source: 'AppOnlyAuth'
      };
      
      console.log('[AppOnlyAuth] Audit event:', event);
      
      // Tentar persistir no SharePoint (se GraphClient disponível)
      // Service Worker usa 'self', DOM usa 'window'
      const globalScope = typeof self !== 'undefined' ? self : (typeof window !== 'undefined' ? window : null);
      if (globalScope && globalScope.GraphClient) {
        // Não usar await - fire and forget
        globalScope.GraphClient.createListItem('Nexos_AuditLog', {
          Acao: action,
          Usuario: 'System (App-Only)',
          Detalhes: JSON.stringify(details),
          Timestamp: event.timestamp,
          Resultado: details.error ? 'Erro' : 'Sucesso'
        }).catch(err => {
          console.warn('[AppOnlyAuth] Falha ao persistir audit log no SharePoint:', err);
        });
      }
      
    } catch (error) {
      console.warn('[AppOnlyAuth] Erro ao registrar audit event:', error);
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // PUBLIC: HELPER METHODS
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Verifica se app-only auth está configurado corretamente
   * @returns {Object} { isValid: boolean, errors: string[] }
   */
  validateConfig() {
    const errors = [];
    
    if (!this.config.clientId) {
      errors.push('clientId não configurado');
    }
    
    if (!this.config.clientSecret) {
      errors.push('clientSecret não configurado');
    }
    
    if (!this.config.tenantId) {
      errors.push('tenantId não configurado');
    }
    
    if (!this.config.tokenEndpoint) {
      errors.push('tokenEndpoint não configurado');
    }
    
    if (!this.config.scope) {
      errors.push('scope não configurado');
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  }
  
  /**
   * Retorna informações sobre token atual (para debug)
   * @returns {Promise<Object>}
   */
  async getTokenInfo() {
    const cached = await this._getCachedToken();
    
    if (!cached) {
      return {
        hasToken: false,
        message: 'Nenhum token em cache'
      };
    }
    
    const tokenData = this.tokenCache;
    const expiresAt = tokenData.acquired_at + (tokenData.expires_in * 1000);
    const now = Date.now();
    const remainingMs = expiresAt - now;
    
    return {
      hasToken: true,
      isValid: this._isTokenValid(tokenData),
      expiresAt: new Date(expiresAt).toISOString(),
      remainingMs,
      remainingMinutes: Math.floor(remainingMs / 60000),
      acquiredAt: new Date(tokenData.acquired_at).toISOString()
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORT & GLOBAL (Service Worker compatible)
// ═══════════════════════════════════════════════════════════════════════════

if (typeof module !== 'undefined' && module.exports) {
  module.exports = AppOnlyAuth;
}

// Service Worker usa 'self', DOM usa 'window'
if (typeof self !== 'undefined') {
  self.AppOnlyAuth = AppOnlyAuth;
}

console.log('[AppOnlyAuth] Módulo carregado com sucesso');
