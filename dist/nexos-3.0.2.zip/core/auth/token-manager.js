/**
 * ═══════════════════════════════════════════════════════════════════════════
 * ⚠️ DEPRECATED - NÃO USAR EM CÓDIGO NOVO
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Este arquivo está DEPRECATED desde v3.0.0 (Janeiro 2026)
 * 
 * RAZÃO:
 * - Usa chrome.storage.local (inseguro, limitado)
 * - Criptografia complexa e desnecessária
 * - Fallbacks para localStorage/IndexedDB (problemático)
 * 
 * SUBSTITUIÇÃO:
 * Use AuthTokenServiceV2 + TokenVaultManager (SharePoint storage)
 * 
 * MIGRAÇÃO:
 * - Tokens antigos são migrados automaticamente via migrations/migrate-to-sharepoint.js
 * - Após migração, este arquivo será removido
 * 
 * NOVO CÓDIGO:
 * ```javascript
 * // Obter token (antigo)
 * const token = await tokenManager.getAccessToken(); // ❌ NÃO USAR
 * 
 * // Obter token (novo)
 * const token = await window.getNexosAccessToken(); // ✅ USAR ESTE
 * ```
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Nexos Torre - Token Manager (LEGACY)
 * Gerenciamento seguro de tokens OAuth com encryption e renovação automática
 * 
 * Features:
 * - Encryption de tokens usando Web Crypto API
 * - Auto-renovação antes de expirar
 * - Fallback para IndexedDB se chrome.storage falhar
 * - Lock para evitar renovações simultâneas
 */

class TokenManager {
  constructor(config) {
    this.config = config || (typeof NEXOS_CONFIG !== 'undefined' ? NEXOS_CONFIG.auth : {
      tokenExpiry: 3600,
      refreshThreshold: 300
    });
    
    this.currentTokens = null;
    this.renewalLock = false;
    this.renewalTimer = null;
    this.encryptionKey = null;
    this.userContext = null;
    this.authTokenService = null;
    this.authTokenServiceInitializing = null;
    
  }

  _normalizeUser(user) {
    if (!user) return null;
    return {
      userPrincipalName: user.userPrincipalName || user.mail || user.email,
      displayName: user.displayName || user.givenName || user.name || user.mail,
      id: user.id || user.objectId || null,
      mail: user.mail || user.userPrincipalName || null
    };
  }

  async _getAuthTokenService() {
    if (this.authTokenService) {
      return this.authTokenService;
    }

    if (this.authTokenServiceInitializing) {
      return this.authTokenServiceInitializing;
    }

    const graphClient = (typeof window !== 'undefined') ? window.graphClient : null;
    const hasAuthTokenService = typeof AuthTokenService !== 'undefined';
    const normalizedUser = this._normalizeUser(this.userContext || (typeof window !== 'undefined' ? window.currentUser : null));

    if (!hasAuthTokenService || !graphClient || !normalizedUser || !normalizedUser.userPrincipalName) {
      return null;
    }

    this.authTokenServiceInitializing = (async () => {
      try {
        this.authTokenService = new AuthTokenService(graphClient, normalizedUser);
        return this.authTokenService;
      } catch (err) {
        console.warn('[TokenManager] ⚠️ Não foi possível inicializar AuthTokenService:', err.message);
        this.authTokenService = null;
        return null;
      } finally {
        this.authTokenServiceInitializing = null;
      }
    })();

    return this.authTokenServiceInitializing;
  }

  _mapSharePointTokenToLegacy(spToken) {
    if (!spToken) return null;
    const expiresAt = spToken.expiresAt || spToken.expires_at || Date.now();
    return {
      access_token: spToken.accessToken,
      refresh_token: spToken.refreshToken,
      expires_in: spToken.expiresIn,
      expires_at: expiresAt,
      token_type: spToken.tokenType || 'Bearer',
      scope: this.config.scopes?.join(' '),
      saved_at: Date.now()
    };
  }
  
  /**
   * Obtém ou cria chave de encryption
   * @private
   */
  async _getOrCreateEncryptionKey() {
    if (this.encryptionKey) {
      return this.encryptionKey;
    }
    
    // Gerar fingerprint do dispositivo (não exportável)
    const fingerprint = await this._getDeviceFingerprint();
    
    // Importar como key material
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      new TextEncoder().encode(fingerprint),
      { name: 'PBKDF2' },
      false,
      ['deriveBits', 'deriveKey']
    );
    
    // Derivar chave AES-GCM
    this.encryptionKey = await crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: new TextEncoder().encode('nexos-torre-v2-salt'),
        iterations: 100000,
        hash: 'SHA-256'
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
    
    return this.encryptionKey;
  }
  
  /**
   * Gera fingerprint do dispositivo
   * @private
   */
  async _getDeviceFingerprint() {
    const components = [
      navigator.userAgent,
      navigator.language,
      // screen não existe em service workers, usar fallback
      typeof screen !== 'undefined' ? (screen.width + 'x' + screen.height) : 'service-worker',
      new Date().getTimezoneOffset(),
      navigator.hardwareConcurrency || 'unknown',
      navigator.deviceMemory || 'unknown'
    ];
    
    const combined = components.join('|');
    const encoder = new TextEncoder();
    const data = encoder.encode(combined);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    
    // Converter para hex string
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }
  
  /**
   * Encripta dados usando AES-GCM
   * @private
   */
  async _encrypt(data) {
    const key = await this._getOrCreateEncryptionKey();
    const encoded = new TextEncoder().encode(JSON.stringify(data));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      encoded
    );
    
    return {
      data: Array.from(new Uint8Array(encrypted)),
      iv: Array.from(iv)
    };
  }
  
  /**
   * Decripta dados usando AES-GCM
   * @private
   */
  async _decrypt(encryptedData) {
    if (!encryptedData || !encryptedData.data || !encryptedData.iv) {
      throw new Error('Dados encriptados inválidos');
    }
    
    const key = await this._getOrCreateEncryptionKey();
    const data = new Uint8Array(encryptedData.data);
    const iv = new Uint8Array(encryptedData.iv);
    
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      data
    );
    
    const decoded = new TextDecoder().decode(decrypted);
    return JSON.parse(decoded);
  }
  
  /**
   * Salva tokens de forma segura
   * @param {object} tokens - Tokens OAuth (access_token, refresh_token, expires_in)
   * @param {object|null} user - Dados do usuário autenticado (opcional)
   */
  async saveTokens(tokens, user = null) {
    try {
      
      // Calcular timestamp de expiração
      const expiresAt = Date.now() + (tokens.expires_in * 1000);
      
      // Preparar payload
      const tokenData = {
        access_token: tokens.access_token,
        refresh_token: tokens.refresh_token,
        expires_in: tokens.expires_in,
        expires_at: expiresAt,
        token_type: tokens.token_type || 'Bearer',
        scope: tokens.scope || this.config.scopes?.join(' '),
        saved_at: Date.now()
      };

      // Atualizar contexto do usuário para integração SharePoint
      const normalizedUser = this._normalizeUser(user || this.userContext || (typeof window !== 'undefined' ? window.currentUser : null));
      if (normalizedUser) {
        this.userContext = normalizedUser;
      }

      // Tentar salvar em SharePoint (fonte de verdade)
      const authTokenService = await this._getAuthTokenService();
      if (authTokenService) {
        try {
          await authTokenService.saveToken(tokenData.access_token, tokenData.refresh_token, tokens.expires_in);
          this.currentTokens = tokenData;
          this._scheduleRenewal(expiresAt);
          return;
        } catch (spErr) {
          console.warn('[TokenManager] ⚠️ Falha ao salvar no SharePoint, usando fallback local:', spErr.message);
        }
      }
      
      // Encriptar
      const encrypted = await this._encrypt(tokenData);
      
      // Salvar em chrome.storage (preferencial)
      try {
        await chrome.storage.local.set({ 'nexos-tokens': encrypted });
      } catch (chromeErr) {
        console.warn('[TokenManager] Falha ao salvar em chrome.storage, usando IndexedDB:', chromeErr);
        await this._saveToIndexedDB(encrypted);
      }
      
      // Atualizar cache em memória
      this.currentTokens = tokenData;
      
      // Agendar renovação automática
      this._scheduleRenewal(expiresAt);
      
      
    } catch (error) {
      console.error('[TokenManager] Erro ao salvar tokens:', error);
      throw error;
    }
  }
  
  /**
   * Recupera tokens salvos
   * @returns {Promise<object|null>} Tokens ou null se não existir/expirado
   */
  async getTokens() {
    try {
      // Verificar cache em memória primeiro
      if (this.currentTokens && this._isTokenValid(this.currentTokens)) {
        return this.currentTokens;
      }

      // Preferir SharePoint se disponível
      const authTokenService = await this._getAuthTokenService();
      if (authTokenService) {
        try {
          const spToken = await authTokenService.getToken();
          const mapped = this._mapSharePointTokenToLegacy(spToken);
          if (mapped && this._isTokenValid(mapped)) {
            this.currentTokens = mapped;
            this._scheduleRenewal(mapped.expires_at);
            return mapped;
          }
        } catch (spErr) {
          console.warn('[TokenManager] ⚠️ Falha ao recuperar token do SharePoint, tentando cache local:', spErr.message);
        }
      }
      
      // Tentar recuperar de chrome.storage
      let encrypted = null;
      try {
        // Verificar se chrome.storage está disponível (contexto de extensão)
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          const result = await chrome.storage.local.get(['nexos-tokens']);
          encrypted = result['nexos-tokens'];
        } else {
          // Contexto não suporta chrome.storage (ex: MAIN world)
          encrypted = await this._loadFromIndexedDB();
        }
      } catch (chromeErr) {
        console.warn('[TokenManager] ⚠️ Falha ao ler chrome.storage, tentando IndexedDB:', chromeErr);
        encrypted = await this._loadFromIndexedDB();
      }
      
      if (!encrypted) {
        return null;
      }
      
      // Decriptar
      try {
        const tokens = await this._decrypt(encrypted);
        
        // Verificar validade
        if (!this._isTokenValid(tokens)) {
          return await this.renewTokens();
        }
        
        // Atualizar cache
        this.currentTokens = tokens;
        
        // Agendar renovação automática
        this._scheduleRenewal(tokens.expires_at);
        
        return tokens;
      } catch (decryptError) {
        console.error('[TokenManager] ❌ Erro ao decriptar tokens:', decryptError.message);
        console.warn('[TokenManager] ⚠️ Cache local corrompido, limpando...');
        
        // Limpar cache corrompido
        try {
          await chrome.storage.local.remove(['nexos-tokens']);
        } catch (cleanErr) {
          console.warn('[TokenManager] Falha ao limpar cache:', cleanErr);
        }
        
        return null;
      }
      
    } catch (error) {
      // Melhorar logging para DOMException
      const errorMsg = error?.message || String(error) || 'Erro desconhecido';
      console.error('[TokenManager] ❌ Erro ao recuperar tokens:', errorMsg);
      if (error?.name) {
        console.error('[TokenManager] Nome do erro:', error.name);
      }
      return null;
    }
  }
  
  /**
   * Obtém access token válido (renovando se necessário)
   * @returns {Promise<string>} Access token
   */
  async getAccessToken() {
    const tokens = await this.getTokens();
    
    if (!tokens) {
      throw new Error('Nenhum token disponível. Faça login primeiro.');
    }
    
    // Verificar se está próximo de expirar
    const timeUntilExpiry = tokens.expires_at - Date.now();
    const threshold = (this.config.refreshThreshold || 300) * 1000; // 5 min padrão
    
    if (timeUntilExpiry < threshold) {
      const renewed = await this.renewTokens();
      return renewed.access_token;
    }
    
    return tokens.access_token;
  }
  
  /**
   * Renova tokens usando refresh token
   * @returns {Promise<object>} Novos tokens
   */
  async renewTokens() {
    // Lock para evitar renovações simultâneas
    if (this.renewalLock) {
      
      // ✅ TIMEOUT: Se demorar mais de 10s, desbloqueia
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          console.warn('[TokenManager] ⏰ Timeout aguardando renovação (10s) - forçando desbloqueio');
          this.renewalLock = false; // Força desbloqueio
          reject(new Error('Timeout aguardando renovação de tokens'));
        }, 10000); // 10 segundos
        
        const check = setInterval(async () => {
          if (!this.renewalLock) {
            clearInterval(check);
            clearTimeout(timeout);
            try {
              const tokens = await this.getTokens();
              resolve(tokens);
            } catch (error) {
              reject(error);
            }
          }
        }, 100);
      });
    }
    
    this.renewalLock = true;
    
    // ✅ TIMEOUT: Renovação não pode demorar mais de 15 segundos
    const renewalPromise = (async () => {
      try {
        
        // Obter tokens atuais
        const currentTokens = await this.getTokens();
        
        if (!currentTokens || !currentTokens.refresh_token) {
          throw new Error('Refresh token não disponível. Faça login novamente.');
        }
        
        // Criar ou obter OAuth client
        let oauthClient;
        if (typeof OAuthClient !== 'undefined') {
          oauthClient = new OAuthClient(this.config);
        } else {
          throw new Error('OAuthClient não disponível');
        }
        
        // Renovar via OAuth
        const newTokens = await oauthClient.refreshAccessToken(currentTokens.refresh_token);
        
        // Salvar novos tokens
        await this.saveTokens(newTokens);
        
        
        return newTokens;
        
      } catch (error) {
        console.error('[TokenManager] Erro ao renovar tokens:', error);
        
        // Se falha na renovação, limpar tokens e forçar novo login
        await this.clearTokens();
        
        // Disparar evento para UI solicitar login
        this._dispatchEvent('nexos:auth:refresh-failed', { error });
        
        throw error;
        
      } finally {
        this.renewalLock = false;
      }
    })();
    
    // ✅ TIMEOUT: Cancela renovação se demorar mais de 15 segundos
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => {
        console.error('[TokenManager] ⏰ Timeout na renovação de tokens (15s)');
        this.renewalLock = false; // Força desbloqueio
        reject(new Error('Timeout na renovação de tokens (15s)'));
      }, 15000);
    });
    
    // Retorna o que resolver primeiro (renovação ou timeout)
    return Promise.race([renewalPromise, timeoutPromise]);
  }
  
  /**
   * Limpa todos os tokens
   */
  async clearTokens() {
    try {
      
      // Limpar cache
      this.currentTokens = null;
      
      // Cancelar timer de renovação
      if (this.renewalTimer) {
        clearTimeout(this.renewalTimer);
        this.renewalTimer = null;
      }

      const authTokenService = await this._getAuthTokenService();
      if (authTokenService && typeof authTokenService.revokeToken === 'function') {
        try {
          await authTokenService.revokeToken();
        } catch (revokeErr) {
          console.warn('[TokenManager] Falha ao revogar token no SharePoint:', revokeErr.message);
        }
      }
      
      // Limpar chrome.storage
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          await chrome.storage.local.remove(['nexos-tokens']);
        }
      } catch (chromeErr) {
        // Silenciar erro se chrome.storage não estiver disponível (contexto de página)
      }
      
      // Limpar IndexedDB
      await this._deleteFromIndexedDB();
      
      
    } catch (error) {
      console.error('[TokenManager] Erro ao limpar tokens:', error);
    }
  }
  
  /**
   * Verifica se token é válido
   * @private
   */
  _isTokenValid(tokens) {
    if (!tokens || !tokens.access_token || !tokens.expires_at) {
      return false;
    }
    
    // Verificar se não expirou (com margem de 1 minuto)
    const now = Date.now();
    const expiresAt = tokens.expires_at - (60 * 1000); // 1 min de margem
    
    return now < expiresAt;
  }
  
  /**
   * Agenda renovação automática antes de expirar
   * @private
   */
  _scheduleRenewal(expiresAt) {
    // Cancelar timer anterior
    if (this.renewalTimer) {
      clearTimeout(this.renewalTimer);
    }
    
    // Calcular quando renovar (threshold antes de expirar)
    const threshold = (this.config.refreshThreshold || 300) * 1000; // 5 min padrão
    const renewAt = expiresAt - threshold;
    const delay = renewAt - Date.now();
    
    if (delay > 0) {
      
      this.renewalTimer = setTimeout(async () => {
        try {
          await this.renewTokens();
        } catch (error) {
          console.error('[TokenManager] Falha na renovação automática:', error);
        }
      }, delay);
    }
  }
  
  /**
   * Salva tokens encriptados no IndexedDB (fallback)
   * @private
   */
  async _saveToIndexedDB(encrypted) {
    // ⚠️ VERIFICAR: IndexedDB não existe em Service Worker
    if (typeof indexedDB === 'undefined') {
      console.warn('[TokenManager] ⚠️ IndexedDB indisponível (Service Worker context)');
      return;
    }

    return new Promise((resolve, reject) => {
      try {
        const request = indexedDB.open('NexosTorreDB', 2);
        
        request.onerror = () => reject(request.error);
        
        request.onsuccess = () => {
          const db = request.result;
          const transaction = db.transaction(['tokens'], 'readwrite');
          const store = transaction.objectStore('tokens');
          
          const putRequest = store.put({
            id: 'current',
            data: encrypted,
            timestamp: Date.now()
          });
          
          putRequest.onsuccess = () => resolve();
          putRequest.onerror = () => reject(putRequest.error);
        };
        
        request.onupgradeneeded = (event) => {
          const db = event.target.result;
          if (!db.objectStoreNames.contains('tokens')) {
            db.createObjectStore('tokens', { keyPath: 'id' });
          }
        };
      } catch (e) {
        console.error('[TokenManager] Erro ao salvar em IndexedDB:', e);
        reject(e);
      }
    });
  }
  
  /**
   * Carrega tokens do IndexedDB
   * @private
   */
  async _loadFromIndexedDB() {
    // ⚠️ VERIFICAR: IndexedDB não existe em Service Worker
    if (typeof indexedDB === 'undefined') {
      console.warn('[TokenManager] ⚠️ IndexedDB indisponível (Service Worker context)');
      return null;
    }

    return new Promise((resolve, reject) => {
      try {
        const request = indexedDB.open('NexosTorreDB', 2);
        
        request.onerror = () => reject(request.error);
        
        request.onsuccess = () => {
          const db = request.result;
          
          if (!db.objectStoreNames.contains('tokens')) {
            resolve(null);
            return;
          }
          
          const transaction = db.transaction(['tokens'], 'readonly');
          const store = transaction.objectStore('tokens');
          const getRequest = store.get('current');
          
          getRequest.onsuccess = () => {
            const result = getRequest.result;
            resolve(result ? result.data : null);
          };
          
          getRequest.onerror = () => reject(getRequest.error);
        };
        
        request.onupgradeneeded = (event) => {
          const db = event.target.result;
          if (!db.objectStoreNames.contains('tokens')) {
            db.createObjectStore('tokens', { keyPath: 'id' });
          }
        };
      } catch (err) {
        reject(err);
      }
    });
  }
  
  /**
   * Deleta tokens do IndexedDB
   * @private
   */
  async _deleteFromIndexedDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('NexosTorreDB', 2);
      
      request.onerror = () => reject(request.error);
      
      request.onsuccess = () => {
        const db = request.result;
        
        if (!db.objectStoreNames.contains('tokens')) {
          resolve();
          return;
        }
        
        const transaction = db.transaction(['tokens'], 'readwrite');
        const store = transaction.objectStore('tokens');
        const deleteRequest = store.delete('current');
        
        deleteRequest.onsuccess = () => resolve();
        deleteRequest.onerror = () => reject(deleteRequest.error);
      };
    });
  }
  
  /**
   * Dispara evento customizado
   * @private
   */
  _dispatchEvent(eventName, detail = {}) {
    try {
      const event = new CustomEvent(eventName, { detail });
      window.dispatchEvent(event);
    } catch (err) {
      console.warn('[TokenManager] Erro ao disparar evento:', err);
    }
  }
}

// Exportar singleton
const TokenManagerInstance = new TokenManager();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = TokenManagerInstance;
}

// Export global para content scripts (exporta a classe E a instância)
if (typeof window !== 'undefined') {
  window.TokenManager = TokenManagerInstance; // Instância singleton
  window.TokenManagerClass = TokenManager; // Classe para novas instâncias se necessário
}
