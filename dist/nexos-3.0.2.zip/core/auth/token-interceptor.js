/**
 * 🔐 TOKEN INTERCEPTOR
 * 
 * Captura automaticamente tokens de autenticação das requisições HTTP
 * feitas pelo picking-admin e armazena para uso posterior.
 * 
 * OBJETIVO: O usuário já faz login no picking-admin, então vamos
 * reutilizar esse token ao invés de forçar novo login MSAL.
 */

(function() {
  'use strict';

  // console.log('[TokenInterceptor] 📦 Carregando...');

  class TokenInterceptor {
    constructor() {
      this.storageKey = 'nexos-intercepted-token';
      this.lastToken = null;
      this.lastTokenTime = null;
      this.tokenExpiry = 60 * 60 * 1000; // 1 hora
    }

    /**
     * Inicializa os interceptors de XMLHttpRequest e Fetch
     */
    init() {
      // console.log('[TokenInterceptor] 🚀 Inicializando interceptors...');
      
      // Interceptar XMLHttpRequest
      this.interceptXHR();
      
      // Interceptar Fetch API
      this.interceptFetch();
      
      // console.log('[TokenInterceptor] ✅ Interceptors ativos');
    }

    /**
     * Intercepta XMLHttpRequest para capturar headers de Authorization
     */
    interceptXHR() {
      const self = this;
      const originalOpen = XMLHttpRequest.prototype.open;
      const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
      
      // Armazenar headers
      XMLHttpRequest.prototype._headers = {};
      
      XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
        this._headers = this._headers || {};
        this._headers[header.toLowerCase()] = value;
        
        // Capturar token do header Authorization
        if (header.toLowerCase() === 'authorization' && value) {
          self.captureToken(value, 'XMLHttpRequest');
        }
        
        return originalSetRequestHeader.apply(this, arguments);
      };

      // console.log('[TokenInterceptor] ✅ XMLHttpRequest interceptado');
    }

    /**
     * Intercepta Fetch API para capturar headers de Authorization
     */
    interceptFetch() {
      const self = this;
      const originalFetch = window.fetch;
      
      window.fetch = function(...args) {
        const [url, options] = args;
        
        // Capturar token dos headers
        if (options && options.headers) {
          const headers = new Headers(options.headers);
          const authHeader = headers.get('authorization') || headers.get('Authorization');
          
          if (authHeader) {
            self.captureToken(authHeader, 'Fetch');
          }
        }
        
        // Executar fetch original
        return originalFetch.apply(this, args);
      };

      // console.log('[TokenInterceptor] ✅ Fetch API interceptado');
    }

    /**
     * Captura e valida o token
     */
    async captureToken(authHeader, source) {
      try {
        // Extrair token (remover "Bearer " se existir)
        let token = authHeader;
        if (token.toLowerCase().startsWith('bearer ')) {
          token = token.substring(7);
        }

        // Validar formato JWT
        if (!this.isValidJWT(token)) {
          console.log('[TokenInterceptor] ⚠️ Token não é JWT válido:', token.substring(0, 30) + '...');
          return;
        }

        // Verificar se é token novo
        if (token === this.lastToken) {
          return; // Já capturamos esse token
        }

        // console.log('[TokenInterceptor] ✅ Token capturado via', source);
        // console.log('[TokenInterceptor] 🔑 Token preview:', token.substring(0, 50) + '...');

        // Armazenar token
        this.lastToken = token;
        this.lastTokenTime = Date.now();

        // Salvar em storage
        await this.saveToken(token);

        // Sincronizar com MSAL/UnifiedAuth
        await this.syncWithAuth(token);

      } catch (error) {
        console.error('[TokenInterceptor] ❌ Erro ao capturar token:', error);
      }
    }

    /**
     * Valida se o token é um JWT válido
     */
    isValidJWT(token) {
      if (!token || typeof token !== 'string') return false;
      
      // JWT tem 3 partes separadas por pontos
      const parts = token.split('.');
      if (parts.length !== 3) return false;
      
      // Deve começar com eyJ (Base64 de {"alg":...)
      if (!token.startsWith('eyJ')) return false;
      
      try {
        // Tentar decodificar o payload
        const payload = JSON.parse(atob(parts[1]));
        
        // Verificar se tem claims básicas
        if (!payload.exp || !payload.iat) return false;
        
        // Verificar se não está expirado
        const now = Math.floor(Date.now() / 1000);
        if (payload.exp < now) {
          console.log('[TokenInterceptor] ⚠️ Token expirado');
          return false;
        }
        
        return true;
      } catch (e) {
        return false;
      }
    }

    /**
     * Salva token no storage
     */
    async saveToken(token) {
      try {
        // Salvar em chrome.storage.local
        await chrome.storage.local.set({
          [this.storageKey]: token,
          'nexos-token-timestamp': Date.now()
        });
        
        // Salvar em localStorage também
        localStorage.setItem(this.storageKey, token);
        localStorage.setItem('nexos-token-timestamp', Date.now().toString());
        
        // console.log('[TokenInterceptor] 💾 Token salvo no storage');
      } catch (error) {
        console.error('[TokenInterceptor] ❌ Erro ao salvar token:', error);
      }
    }

    /**
     * Sincroniza token com sistemas de auth (UnifiedAuth, MSAL)
     */
    async syncWithAuth(token) {
      try {
        // Sincronizar com UnifiedAuthManager
        if (window.unifiedAuth) {
          // Injetar token no cache do UnifiedAuth
          window.unifiedAuth.tokenCache = token;
          window.unifiedAuth.tokenExpiryTime = Date.now() + this.tokenExpiry;
          // console.log('[TokenInterceptor] ✅ Token sincronizado com UnifiedAuth');
        }

        // Sincronizar com MSAL (se disponível)
        if (window.msalAuth && window.msalAuth.currentAccount) {
          window.msalAuth.accessToken = token;
          // console.log('[TokenInterceptor] ✅ Token sincronizado com MSAL');
        }

        // Sincronizar com AuthHelper
        if (window.authHelper) {
          // AuthHelper irá usar o token via UnifiedAuth
          // console.log('[TokenInterceptor] ✅ AuthHelper usará token interceptado');
        }

      } catch (error) {
        console.error('[TokenInterceptor] ❌ Erro ao sincronizar:', error);
      }
    }

    /**
     * Obtém o último token capturado (se ainda válido)
     */
    async getToken() {
      // Verificar cache em memória
      if (this.lastToken && this.lastTokenTime) {
        const age = Date.now() - this.lastTokenTime;
        if (age < this.tokenExpiry) {
          // console.log('[TokenInterceptor] ✅ Retornando token do cache (idade: ' + Math.floor(age / 1000) + 's)');
          return this.lastToken;
        }
      }

      // Tentar carregar do storage
      try {
        const result = await chrome.storage.local.get([this.storageKey, 'nexos-token-timestamp']);
        const token = result[this.storageKey];
        const timestamp = result['nexos-token-timestamp'];

        if (token && timestamp) {
          const age = Date.now() - timestamp;
          if (age < this.tokenExpiry && this.isValidJWT(token)) {
            this.lastToken = token;
            this.lastTokenTime = timestamp;
            // console.log('[TokenInterceptor] ✅ Token carregado do storage (idade: ' + Math.floor(age / 1000) + 's)');
            return token;
          }
        }
      } catch (error) {
        console.error('[TokenInterceptor] ❌ Erro ao carregar token:', error);
      }

      return null;
    }

    /**
     * Limpa o token armazenado
     */
    async clearToken() {
      this.lastToken = null;
      this.lastTokenTime = null;
      
      try {
        await chrome.storage.local.remove([this.storageKey, 'nexos-token-timestamp']);
        localStorage.removeItem(this.storageKey);
        localStorage.removeItem('nexos-token-timestamp');
        console.log('[TokenInterceptor] 🗑️ Token removido');
      } catch (error) {
        console.error('[TokenInterceptor] ❌ Erro ao limpar token:', error);
      }
    }
  }

  // Criar instância global
  window.tokenInterceptor = new TokenInterceptor();

  // Inicializar após DOM carregar
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      window.tokenInterceptor.init();
    });
  } else {
    window.tokenInterceptor.init();
  }

  // console.log('[TokenInterceptor] 📦 Módulo carregado');
  // console.log('[TokenInterceptor] 💡 Comandos úteis:');
  // console.log('  await window.tokenInterceptor.getToken()     // Obter token atual');
  // console.log('  await window.tokenInterceptor.clearToken()   // Limpar token');

})();
