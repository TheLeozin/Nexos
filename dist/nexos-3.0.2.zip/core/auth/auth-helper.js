/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - AUTH HELPER
 * Wrapper simplificado para TokenManager + OAuthClient
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Uso:
 * ```javascript
 * // Inicializar
 * const auth = new AuthHelper();
 * 
 * // Login (abre popup OAuth)
 * await auth.login();
 * 
 * // Obter token (auto-renova se necessário)
 * const token = await auth.getAccessToken();
 * 
 * // Verificar status
 * const isAuthenticated = await auth.isAuthenticated();
 * 
 * // Logout
 * await auth.logout();
 * ```
 */

class AuthHelper {
  constructor(config) {
    // ⚠️ VERIFICAR CONTEXTO: Não rodar em Service Worker
    if (typeof window === 'undefined') {
      throw new Error('AuthHelper não pode ser instanciado em Service Worker. Use no content script.');
    }

    // ✅ Tentar múltiplas fontes de configuração
    this.config = config 
      || (typeof SHAREPOINT_CONFIG !== 'undefined' ? SHAREPOINT_CONFIG.auth : null)
      || (typeof SharePointConfig !== 'undefined' ? SharePointConfig.auth : null)
      || (typeof window !== 'undefined' && window.SHAREPOINT_CONFIG ? window.SHAREPOINT_CONFIG.auth : null);
    
    if (!this.config) {
      console.error('[AuthHelper] ❌ Nenhuma configuração encontrada!');
      console.error('[AuthHelper] Verificando variáveis globais:');
      console.error('  - SHAREPOINT_CONFIG:', typeof SHAREPOINT_CONFIG !== 'undefined' ? 'OK' : 'UNDEFINED');
      console.error('  - SharePointConfig:', typeof SharePointConfig !== 'undefined' ? 'OK' : 'UNDEFINED');
      console.error('  - window.SHAREPOINT_CONFIG:', typeof window !== 'undefined' && window.SHAREPOINT_CONFIG ? 'OK' : 'UNDEFINED');
      throw new Error('AuthHelper: Configuração não encontrada. Certifique-se de que sharepoint-config.js foi carregado.');
    }
    
    console.log('[AuthHelper] ✅ Configuração carregada:', this.config);
    
    // Inicializar componentes
    this.oauthClient = new OAuthClient(this.config);
    
    // TokenManager é exportado como singleton (window.TokenManager = instância)
    // Para criar nova instância, usar TokenManagerClass
    const TokenManagerConstructor = (typeof window !== 'undefined' && window.TokenManagerClass) 
      ? window.TokenManagerClass 
      : TokenManager; // Fallback para ambiente Node.js/testes
    
    this.tokenManager = new TokenManagerConstructor(this.config);
    
    console.log('[AuthHelper] Inicializado');
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // AUTENTICAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Realiza login interativo (abre popup OAuth)
   * @returns {Promise<boolean>} true se sucesso
   */
  async login() {
    try {
      console.log('[AuthHelper] Iniciando login...');
      
      // Verificar se já está autenticado
      if (await this.isAuthenticated()) {
        console.log('[AuthHelper] Usuário já autenticado');
        return true;
      }
      
      // Iniciar fluxo OAuth
      const result = await this.oauthClient.login();
      
  // Salvar tokens (OAuthClient.login retorna { tokens, user })
  await this.tokenManager.saveTokens(result.tokens, result.user);
      
      console.log('[AuthHelper] ✅ Login concluído com sucesso');
      
      // Disparar evento
      this._dispatchEvent('nexos:auth:login-success');
      
      return true;
      
    } catch (error) {
      console.error('[AuthHelper] ❌ Erro no login:', error);
      
      // Disparar evento de erro
      this._dispatchEvent('nexos:auth:login-failed', { error: error.message });
      
      throw error;
    }
  }
  
  /**
   * Realiza logout (limpa tokens)
   * @returns {Promise<void>}
   */
  async logout() {
    try {
      console.log('[AuthHelper] Fazendo logout...');
      
      await this.tokenManager.clearTokens();
      
      console.log('[AuthHelper] ✅ Logout concluído');
      
      // Disparar evento
      this._dispatchEvent('nexos:auth:logout');
      
    } catch (error) {
      console.error('[AuthHelper] Erro ao fazer logout:', error);
      throw error;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // TOKEN MANAGEMENT
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Obtém access token válido (auto-renova se necessário)
   * @returns {Promise<string>} Access token
   */
  async getAccessToken() {
    try {
      // ⚠️ VERIFICAR SE ESTAMOS EM CONTEXTO COM WINDOW (content script, não service worker)
      if (typeof window === 'undefined') {
        console.error('[AuthHelper] ❌ Não é possível obter token: código rodando em Service Worker sem window');
        throw new Error('Autenticação não disponível neste contexto');
      }

      // ✅ PRIORIDADE 0: Tentar MSAL PRIMEIRO (token válido para SharePoint)
      // Token do picking-admin provavelmente não tem scopes do Graph API
      
      // Verificar se MSAL tem conta ativa
      if (typeof window !== 'undefined' && window.msalAuth && window.msalAuth.currentAccount) {
        try {
          const accounts = window.msalAuth.getAllAccounts();
          if (accounts && accounts.length > 0) {
            const silentRequest = {
              account: accounts[0],
              scopes: ['https://graph.microsoft.com/.default']
            };
            const response = await window.msalAuth.acquireTokenSilent(silentRequest);
            if (response && response.accessToken) {
              console.log('[AuthHelper] ✅ Token obtido via MSAL (SharePoint-ready)');
              return response.accessToken;
            }
          }
        } catch (msalError) {
          console.warn('[AuthHelper] ⚠️ MSAL silente falhou:', msalError.message);
          // Continuar para fallbacks
        }
      }

      // ✅ PRIORIDADE 1: Usar UnifiedAuthManager (que tenta MSAL primeiro)
      if (typeof window !== 'undefined' && window.unifiedAuth) {
        try {
          const token = await window.unifiedAuth.getAccessToken();
          if (token) {
            console.log('[AuthHelper] ✅ Token obtido via UnifiedAuth');
            return token;
          }
        } catch (unifiedError) {
          console.warn('[AuthHelper] ⚠️ UnifiedAuth falhou:', unifiedError.message);
          // Continuar para fallbacks
        }
      }

      // ✅ PRIORIDADE 2: Token do picking-admin (APENAS como último recurso)
      // NOTA: Este token provavelmente NÃO funciona para SharePoint (HTTP 401)
      // Mas tentamos mesmo assim caso o usuário tenha acesso
      if (typeof window !== 'undefined' && window.tokenStorageScanner) {
        try {
          const token = await window.tokenStorageScanner.getToken();
          if (token) {
            console.log('[AuthHelper] ⚠️ Usando token do picking-admin (pode não ter permissão SharePoint)');
            return token;
          }
        } catch (scanError) {
          console.warn('[AuthHelper] ⚠️ TokenStorageScanner falhou:', scanError.message);
        }
      }

      if (typeof window !== 'undefined' && window.tokenInterceptor) {
        try {
          const token = await window.tokenInterceptor.getToken();
          if (token) {
            console.log('[AuthHelper] ⚠️ Usando token interceptado (pode não ter permissão SharePoint)');
            return token;
          }
        } catch (interceptError) {
          console.warn('[AuthHelper] ⚠️ TokenInterceptor falhou:', interceptError.message);
        }
      }

      // ✅ PRIORIDADE 2: Usar MSAL direto
      if (typeof window !== 'undefined' && window.msalAuth && window.msalAuth.currentAccount) {
        try {
          const accounts = window.msalAuth.getAllAccounts();
          if (accounts && accounts.length > 0) {
            const silentRequest = {
              account: accounts[0],
              scopes: ['https://graph.microsoft.com/.default']
            };
            const response = await window.msalAuth.acquireTokenSilent(silentRequest);
            if (response && response.accessToken) {
              console.log('[AuthHelper] ✅ Token obtido via MSAL direto');
              return response.accessToken;
            }
          }
        } catch (msalError) {
          console.warn('[AuthHelper] ⚠️ MSAL direto falhou:', msalError.message);
          // Continuar para TokenManager
        }
      }

      // ✅ PRIORIDADE 3: TokenManager (legacy)
      try {
        const token = await this.tokenManager.getAccessToken();
        console.log('[AuthHelper] ✅ Token obtido via TokenManager');
        return token;
      } catch (tmError) {
        console.warn('[AuthHelper] ⚠️ TokenManager falhou:', tmError.message);
      }

      // Nenhum método funcionou - solicitar login
      console.log('[AuthHelper] ❌ Sem token disponível, solicitando login...');
      
      // Disparar evento para UI solicitar login
      this._dispatchEvent('nexos:auth:login-required');
      
      throw new Error('Autenticação necessária. Por favor, faça login.');
      
    } catch (error) {
      // Se erro já é "auth required", apenas propagar
      if (error.message.includes('Autenticação necessária')) {
        throw error;
      }

      // Outros erros
      console.error('[AuthHelper] ❌ Erro ao obter token:', error);
      throw error;
    }
  }
  
  /**
   * Verifica se usuário está autenticado
   * @returns {Promise<boolean>}
   */
  async isAuthenticated() {
    try {
      const tokens = await this.tokenManager.getTokens();
      return tokens !== null && tokens.access_token !== null;
    } catch (error) {
      return false;
    }
  }
  
  /**
   * Obtém informações do usuário atual
   * @returns {Promise<object|null>} User info ou null
   */
  async getUser() {
    try {
      // Verificar se está autenticado
      if (!await this.isAuthenticated()) {
        return null;
      }
      
      // Se OAuthClient já tem o usuário em cache
      if (this.oauthClient.currentUser) {
        return this.oauthClient.currentUser;
      }
      
      // Buscar do Microsoft Graph
      const accessToken = await this.getAccessToken();
      const response = await fetch('https://graph.microsoft.com/v1.0/me', {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      const user = await response.json();
      this.oauthClient.currentUser = user; // Cachear
      
      return user;
      
    } catch (error) {
      console.error('[AuthHelper] Erro ao obter usuário:', error);
      return null;
    }
  }
  
  /**
   * Alias para getUser() (mais intuitivo)
   * @returns {Promise<object|null>} User info ou null
   */
  async getCurrentUser() {
    return this.getUser();
  }
  
  /**
   * Obtém informações do token atual
   * @returns {Promise<object|null>} Token info ou null
   */
  async getTokenInfo() {
    try {
      const tokens = await this.tokenManager.getTokens();
      
      if (!tokens) {
        return null;
      }
      
      return {
        expiresAt: tokens.expires_at,
        expiresIn: Math.max(0, Math.floor((tokens.expires_at - Date.now()) / 1000)),
        scope: tokens.scope,
        tokenType: tokens.token_type,
        isValid: this.tokenManager._isTokenValid(tokens)
      };
    } catch (error) {
      return null;
    }
  }
  
  /**
   * Obtém os tokens completos (access_token, refresh_token, etc)
   * @returns {Promise<Object|null>} Objeto com tokens ou null
   */
  async getTokens() {
    try {
      return await this.tokenManager.getTokens();
    } catch (error) {
      console.error('[AuthHelper] Erro ao obter tokens:', error);
      return null;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Força renovação de token
   * @returns {Promise<boolean>} true se sucesso
   */
  async refreshToken() {
    try {
      console.log('[AuthHelper] Forçando renovação de token...');
      await this.tokenManager.renewTokens();
      return true;
    } catch (error) {
      console.error('[AuthHelper] Erro ao renovar token:', error);
      return false;
    }
  }
  
  /**
   * Alias para refreshToken() (compatibilidade)
   * @returns {Promise<boolean>} true se sucesso
   */
  async renewTokens() {
    return this.refreshToken();
  }
  
  /**
   * Dispara evento customizado
   * @private
   */
  _dispatchEvent(eventName, detail = {}) {
    try {
      // Enviar via chrome.runtime (funciona em service worker e content scripts)
      try {
        chrome.runtime.sendMessage({
          type: eventName,
          ...detail
        }).catch(() => {
          // Ignorar erro se background script não estiver escutando
        });
      } catch (e) {
        // chrome.runtime pode não estar disponível em alguns contextos
      }
      
      // Se temos window (não é service worker), disparar evento DOM também
      if (typeof window !== 'undefined') {
        try {
          const event = new CustomEvent(eventName, { detail });
          window.dispatchEvent(event);
        } catch (windowErr) {
          // Ignorar erro em contextos sem window
        }
      }
    } catch (err) {
      console.warn('[AuthHelper] Erro ao disparar evento:', err);
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SINGLETON GLOBAL
// ═══════════════════════════════════════════════════════════════════════════

let authHelperInstance = null;

/**
 * Obtém instância singleton do AuthHelper
 * @param {object} config - Configuração (opcional, usa SHAREPOINT_CONFIG se omitido)
 * @returns {AuthHelper}
 */
function getAuthHelper(config) {
  if (!authHelperInstance) {
    authHelperInstance = new AuthHelper(config);
  }
  return authHelperInstance;
}

// Exportar para diferentes ambientes
if (typeof window !== 'undefined') {
  window.AuthHelper = AuthHelper;
  window.getAuthHelper = getAuthHelper;
}

if (typeof self !== 'undefined') {
  self.AuthHelper = AuthHelper;
  self.getAuthHelper = getAuthHelper;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { AuthHelper, getAuthHelper };
}
