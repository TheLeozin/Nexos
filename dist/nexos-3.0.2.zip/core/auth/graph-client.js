// ===================================================================
// NEXOS - Microsoft Graph API Client
// Consultas ao Microsoft 365 (perfil, grupos, foto, etc.)
// ===================================================================

/**
 * Cliente para Microsoft Graph API
 * 
 * ENDPOINTS SUPORTADOS:
 * - /me - Perfil do usuário
 * - /me/memberOf - Grupos do usuário
 * - /me/photo/$value - Foto do perfil
 * - /users - Lista de usuários (requer permissão adicional)
 * 
 * Documentação: https://docs.microsoft.com/graph/api/overview
 */

class GraphClient {
  constructor(msalAuth) {
    if (!msalAuth) {
      throw new Error('GraphClient requer instância de MsalAuth');
    }
    
    this.msalAuth = msalAuth;
    this.baseUrl = window.AZURE_AD_CONFIG.graphApiEndpoint;
    
    console.log('[GraphClient] 📊 Cliente Graph API inicializado');
  }

  /**
   * Faz requisição autenticada ao Graph API
   * @private
   * @param {string} endpoint - Caminho relativo (ex: '/me')
   * @param {Object} options - Opções fetch (method, body, etc.)
   * @returns {Promise<any>} Resposta JSON
   */
  async _request(endpoint, options = {}) {
    try {
      // Obter token de acesso
      const token = await this.msalAuth.getAccessToken();
      
      const url = `${this.baseUrl}${endpoint}`;
      
      const response = await fetch(url, {
        ...options,
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          ...options.headers
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Graph API error: ${response.status} ${response.statusText} - ${errorText}`);
      }

      // Se response é binário (foto), retornar blob
      if (options.returnBlob) {
        return await response.blob();
      }

      // Caso contrário, retornar JSON
      return await response.json();
    } catch (error) {
      console.error('[GraphClient] ❌ Erro na requisição:', error);
      throw error;
    }
  }

  /**
   * Obtém perfil completo do usuário logado
   * @returns {Promise<Object>} { displayName, mail, jobTitle, department, officeLocation, mobilePhone, ... }
   */
  async getUserProfile() {
    try {
      console.log('[GraphClient] 👤 Buscando perfil do usuário...');
      
      const profile = await this._request('/me');
      
      console.log('[GraphClient] ✅ Perfil obtido:', {
        nome: profile.displayName,
        email: profile.mail || profile.userPrincipalName,
        cargo: profile.jobTitle,
        departamento: profile.department
      });
      
      return {
        id: profile.id,
        displayName: profile.displayName,
        givenName: profile.givenName, // Primeiro nome
        surname: profile.surname, // Sobrenome
        email: profile.mail || profile.userPrincipalName,
        userPrincipalName: profile.userPrincipalName,
        jobTitle: profile.jobTitle,
        department: profile.department,
        officeLocation: profile.officeLocation,
        mobilePhone: profile.mobilePhone,
        businessPhones: profile.businessPhones || [],
        preferredLanguage: profile.preferredLanguage,
        raw: profile // Dados completos
      };
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao buscar perfil:', error);
      throw error;
    }
  }

  /**
   * Obtém grupos do usuário (Security Groups)
   * NOTA: Requer permissão Group.Read.All no Azure AD
   * @returns {Promise<Array<Object>>} [{ id, displayName, description, ... }]
   */
  async getUserGroups() {
    try {
      console.log('[GraphClient] 👥 Buscando grupos do usuário...');
      
      const response = await this._request('/me/memberOf');
      
      // Filtrar apenas Security Groups (não inclui outros tipos)
      const groups = response.value
        .filter(group => group['@odata.type'] === '#microsoft.graph.group')
        .map(group => ({
          id: group.id,
          displayName: group.displayName,
          description: group.description,
          mail: group.mail,
          mailEnabled: group.mailEnabled,
          securityEnabled: group.securityEnabled,
          raw: group
        }));
      
      console.log('[GraphClient] ✅ Grupos obtidos:', groups.map(g => g.displayName));
      
      return groups;
    } catch (error) {
      // Se não tiver permissão Group.Read.All, retorna array vazio em vez de lançar erro
      if (error.message?.includes('Insufficient privileges') || 
          error.message?.includes('Authorization_RequestDenied')) {
        console.warn('[GraphClient] ⚠️ Permissão Group.Read.All não configurada');
        return [];
      }
      console.error('[GraphClient] ❌ Erro ao buscar grupos:', error);
      throw error;
    }
  }

  /**
   * Obtém nomes dos grupos (array de strings)
   * Útil para mapeamento de roles
   * @returns {Promise<Array<string>>} ['Nexos - Admin Master', 'Nexos - Torre', ...]
   */
  async getUserGroupNames() {
    const groups = await this.getUserGroups();
    return groups.map(g => g.displayName);
  }

  /**
   * Mapeia grupos do usuário para role do Nexos
   * NOTA: Se Group.Read.All não estiver configurado, retorna role padrão (torre_aprendiz)
   * Admin Master pode atribuir role correto manualmente depois
   * @returns {Promise<Object>} { roleId: string, roleName: string, groups: Array<string> }
   */
  async getUserRole() {
    try {
      let groupNames = [];
      let roleId = 'torre_aprendiz'; // Default role se não houver grupos
      
      try {
        // Tentar obter grupos (pode falhar se não tiver permissão Group.Read.All)
        groupNames = await this.getUserGroupNames();
        roleId = window.mapGroupsToRole(groupNames);
        console.log('[GraphClient] ✅ Grupos obtidos, role mapeado:', roleId);
      } catch (groupError) {
        console.warn('[GraphClient] ⚠️ Não foi possível ler grupos (Group.Read.All não configurado)');
        console.warn('[GraphClient] ⚠️ Usando role padrão: torre_aprendiz');
        console.warn('[GraphClient] ℹ️ Admin Master pode atribuir role correto no painel "Gerenciar Usuários"');
      }
      
      // Buscar role por ID (ROLES usa chaves MAIÚSCULAS, mas IDs em minúsculas)
      const role = Object.values(window.ROLES).find(r => r.id === roleId);
      
      if (!role) {
        console.error('[GraphClient] ❌ Role não encontrado:', roleId);
        throw new Error(`Role ${roleId} não existe em ROLES`);
      }
      
      console.log('[GraphClient] ✅ Role final:', {
        roleId,
        roleName: role.name,
        hierarchy: role.hierarchy,
        groups: groupNames.length > 0 ? groupNames : ['Nenhum grupo (atribuir manualmente)']
      });
      
      return {
        roleId,
        roleName: role.name,
        hierarchy: role.hierarchy,
        permissions: role.permissions,
        groups: groupNames
      };
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao mapear role:', error);
      throw error;
    }
  }

  /**
   * Obtém foto do perfil do usuário
   * @param {string} size - Tamanho ('48x48', '64x64', '96x96', '120x120', '240x240', '360x360', '432x432', '504x504', '648x648')
   * @returns {Promise<string|null>} Data URL da imagem (base64) ou null se não houver foto
   */
  async getUserPhoto(size = '96x96') {
    try {
      console.log('[GraphClient] 📷 Buscando foto do perfil...');
      
      const endpoint = size === 'original' ? '/me/photo/$value' : `/me/photos/${size}/$value`;
      
      const blob = await this._request(endpoint, { returnBlob: true });
      
      // Converter blob para data URL
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    } catch (error) {
      // Foto pode não existir, não é erro crítico
      if (error.message.includes('404')) {
        console.log('[GraphClient] ℹ️ Usuário não possui foto de perfil');
        return null;
      }
      
      console.error('[GraphClient] ❌ Erro ao buscar foto:', error);
      return null;
    }
  }

  /**
   * Obtém metadados da foto (tamanho, tipo, etc.)
   * @returns {Promise<Object|null>} { height, width, id }
   */
  async getUserPhotoMetadata() {
    try {
      const metadata = await this._request('/me/photo');
      return {
        id: metadata.id,
        height: metadata.height,
        width: metadata.width
      };
    } catch (error) {
      if (error.message.includes('404')) {
        return null;
      }
      throw error;
    }
  }

  /**
   * Obtém perfil completo + foto + grupos
   * Útil para inicialização do dashboard
   * @returns {Promise<Object>} { profile, photo, groups, role }
   */
  async getUserFullProfile() {
    try {
      console.log('[GraphClient] 🔄 Buscando perfil completo...');
      
      // Buscar em paralelo
      const [profile, photo, role] = await Promise.all([
        this.getUserProfile(),
        this.getUserPhoto(),
        this.getUserRole()
      ]);
      
      const fullProfile = {
        profile,
        photo,
        role,
        timestamp: Date.now()
      };
      
      console.log('[GraphClient] ✅ Perfil completo obtido:', {
        nome: profile.displayName,
        email: profile.email,
        role: role.roleName,
        temFoto: !!photo
      });
      
      return fullProfile;
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao buscar perfil completo:', error);
      throw error;
    }
  }

  /**
   * Busca usuário por email (requer permissão User.ReadBasic.All)
   * @param {string} email 
   * @returns {Promise<Object>} Perfil do usuário
   */
  async getUserByEmail(email) {
    try {
      console.log('[GraphClient] 🔍 Buscando usuário:', email);
      
      const response = await this._request(`/users/${email}`);
      
      return {
        id: response.id,
        displayName: response.displayName,
        email: response.mail || response.userPrincipalName,
        jobTitle: response.jobTitle,
        department: response.department,
        raw: response
      };
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao buscar usuário:', error);
      throw error;
    }
  }

  /**
   * Lista todos os usuários da organização (requer permissão User.Read.All)
   * @param {number} top - Limite de resultados (padrão: 100)
   * @returns {Promise<Array<Object>>} Lista de usuários
   */
  async listUsers(top = 100) {
    try {
      console.log('[GraphClient] 📋 Listando usuários...');
      
      const response = await this._request(`/users?$top=${top}`);
      
      const users = response.value.map(user => ({
        id: user.id,
        displayName: user.displayName,
        email: user.mail || user.userPrincipalName,
        jobTitle: user.jobTitle,
        department: user.department,
        raw: user
      }));
      
      console.log('[GraphClient] ✅ Usuários listados:', users.length);
      
      return users;
    } catch (error) {
      console.error('[GraphClient] ❌ Erro ao listar usuários:', error);
      throw error;
    }
  }

  /**
   * Busca usuários por filtro (ex: department, jobTitle)
   * @param {string} filter - Filtro OData (ex: "department eq 'TI'")
   * @returns {Promise<Array<Object>>}
   */
  async searchUsers(filter) {
    try {
      console.log('[GraphClient] 🔍 Buscando usuários com filtro:', filter);
      
      const response = await this._request(`/users?$filter=${encodeURIComponent(filter)}`);
      
      const users = response.value.map(user => ({
        id: user.id,
        displayName: user.displayName,
        email: user.mail || user.userPrincipalName,
        jobTitle: user.jobTitle,
        department: user.department
      }));
      
      console.log('[GraphClient] ✅ Usuários encontrados:', users.length);
      
      return users;
    } catch (error) {
      console.error('[GraphClient] ❌ Erro na busca:', error);
      throw error;
    }
  }

  /**
   * Cache de perfil em localStorage
   * Útil para reduzir chamadas ao Graph API
   */
  cacheProfile(profile) {
    try {
      localStorage.setItem('__nexos_graph_profile', JSON.stringify({
        ...profile,
        cachedAt: Date.now()
      }));
      console.log('[GraphClient] 💾 Perfil cacheado localmente');
    } catch (error) {
      console.warn('[GraphClient] ⚠️ Erro ao cachear perfil:', error);
    }
  }

  /**
   * Obtém perfil do cache
   * @param {number} maxAge - Idade máxima do cache em ms (padrão: 1 hora)
   * @returns {Object|null}
   */
  getCachedProfile(maxAge = 60 * 60 * 1000) {
    try {
      const cached = localStorage.getItem('__nexos_graph_profile');
      if (!cached) return null;
      
      const data = JSON.parse(cached);
      const age = Date.now() - data.cachedAt;
      
      if (age > maxAge) {
        console.log('[GraphClient] ⏰ Cache expirado');
        return null;
      }
      
      console.log('[GraphClient] ✅ Perfil obtido do cache');
      return data;
    } catch (error) {
      console.warn('[GraphClient] ⚠️ Erro ao ler cache:', error);
      return null;
    }
  }

  /**
   * Limpa cache de perfil
   */
  clearCache() {
    try {
      localStorage.removeItem('__nexos_graph_profile');
      console.log('[GraphClient] 🧹 Cache limpo');
    } catch (error) {
      console.warn('[GraphClient] ⚠️ Erro ao limpar cache:', error);
    }
  }
}

// ===================================
// EXPORTAÇÃO
// ===================================

if (typeof window !== 'undefined') {
  window.GraphClient = GraphClient;
  console.log('[GraphClient] ✅ Classe exportada para window.GraphClient');
}
