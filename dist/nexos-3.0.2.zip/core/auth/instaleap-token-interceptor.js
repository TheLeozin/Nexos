/**
 * instaleap-token-interceptor.js
 * Content script injetado em control.instaleap.io
 *
 * Responsabilidades:
 *  1. Capturar o Bearer token após login (fetch / XHR / storage)
 *  2. Detectar logout (redirecionamento para /login ou limpeza de storage)
 *  3. Pré-preencher o campo de email com o email corporativo
 */

(function () {
  'use strict';

  // ── Guarda de contexto ──────────────────────────────────────────────────
  function isContextValid() {
    try {
      // Acessa chrome.runtime.id — lança se o contexto foi invalidado
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  function safeSendMessage(msg, cb) {
    if (!isContextValid()) return;
    try {
      chrome.runtime.sendMessage(msg, (response) => {
        if (chrome.runtime.lastError) {
          // silenciar erros de contexto inválido / receiver não encontrado
          return;
        }
        if (cb) cb(response);
      });
    } catch (_) {}
  }

  let tokenSent = false;
  let scanInterval = null; // declarado aqui para ser acessível por sendToken e startScanLoop
  // Indica se esta instância de página já teve uma sessão autenticada com token válido.
  // Evita false-positive de IL_TOKEN_REVOKED quando uma nova aba abre /login sem nunca ter tido token.
  let hadAuthenticatedSession = false;

  // ── Validar candidato a token ───────────────────────────────────────────
  // Aceita:
  //   • JWT completo: começa com 'ey', 3 partes separadas por '.', >= 50 chars
  //   • Token opaco Stytch: string alfanumérica >= 20 chars (não começa com '{' ou '[')
  function isValidToken(val) {
    if (!val || typeof val !== 'string') return false;
    if (val.length < 20) return false;
    // Rejeitar strings que parecem JSON ou URLs
    const first = val[0];
    if (first === '{' || first === '[' || val.startsWith('http') || val.startsWith('//')) return false;
    // Rejeitar valores com espaços (não são tokens)
    if (/\s/.test(val)) return false;
    return true;
  }

  // Preferência: JWT (mais confiável) > token opaco longo
  function tokenScore(val) {
    if (!val) return 0;
    const isJwt = val.startsWith('ey') && val.split('.').length === 3 && val.length > 50;
    if (isJwt) return 2;
    if (val.length >= 64) return 1; // token opaco longo (Stytch session_token)
    return 0;
  }

  // ── Enviar token capturado ──────────────────────────────────────────────
  function sendToken(token, source) {
    if (tokenSent) return;
    if (!isValidToken(token)) return;
    if (tokenScore(token) === 0) return;

    hadAuthenticatedSession = true; // esta página teve token — logout futuro será legítimo
    tokenSent = true;
    // Parar scan loop imediatamente para evitar envios duplicados
    if (scanInterval) { clearInterval(scanInterval); scanInterval = null; }

    console.log('[NexosIL] ✅ Token Instaleap capturado via', source || '?', '— len:', token.length, '— preview:', token.substring(0, 30) + '...');

    // Só enviar se houver um IL_AUTH_REQUEST pendente no background
    // (evitar flood quando a aba está aberta e fazendo chamadas autenticadas normalmente)
    safeSendMessage({ type: 'IL_TOKEN_CAPTURED', token }, (response) => {
      if (!response) return;
      if (response.ignored) {
        // Background não tinha login pendente — resetar para não bloquear próxima tentativa real
        console.log('[NexosIL] ℹ Sem login pendente no background — token ignorado');
        tokenSent = false;
      }
    });
  }

  // ── Varredura do storage ────────────────────────────────────────────────
  function scanStorage() {
    let best = null;
    let bestScore = 0;
    let bestKey = null;
    for (let s of [localStorage, sessionStorage]) {
      for (let i = 0; i < s.length; i++) {
        const key = s.key(i);
        if (!key) continue;
        const val = s.getItem(key);
        if (!val || !isValidToken(val)) continue;
        const score = tokenScore(val);
        console.log('[NexosIL] 🔑 Storage scan — chave:', key, '| len:', val.length, '| score:', score, '| preview:', val.substring(0, 30));
        if (score > bestScore) {
          bestScore = score;
          best = val;
          bestKey = key;
        }
      }
    }
    if (best && bestScore > 0) {
      console.log('[NexosIL] 💾 Melhor candidato no storage — chave:', bestKey, '| score:', bestScore);
      sendToken(best, 'storage-scan[' + bestKey + ']');
      return true;
    }
    return false;
  }

  // ── Interceptar Storage.setItem — ATIVO DESDE O INÍCIO ─────────────────
  // Stytch grava o session_token no storage após autenticação (magic link, OTP, etc.)
  const _origSetItem = Storage.prototype.setItem;
  Storage.prototype.setItem = function (key, value) {
    _origSetItem.call(this, key, value);
    if (value && isValidToken(value) && tokenScore(value) > 0) {
      console.log('[NexosIL] 💾 setItem interceptado — chave:', key, '| len:', value.length, '| preview:', value.substring(0, 30));
      setTimeout(() => sendToken(value, 'setItem[' + key + ']'), 50);
    }
  };

  // ── Detectar logout ─────────────────────────────────────────────────────
  function checkIfLoggedOut() {
    const path = window.location.pathname;
    if (path === '/login' || path === '/' || path.startsWith('/auth')) {
      // GUARD: só reportar logout se esta instância de página já teve uma sessão com token válido.
      // Se nunca tivemos token aqui, provavelmente é uma nova aba que ainda não fez login —
      // não confundir isso com logout, pois causaria revogar o token do painel injustamente.
      if (!hadAuthenticatedSession) {
        console.log('[NexosIL] ℹ Página de login sem sessão prévia nesta aba — ignorando (nova aba)');
        return;
      }
      let hasToken = false;
      for (let s of [localStorage, sessionStorage]) {
        for (let i = 0; i < s.length; i++) {
          const val = s.getItem(s.key(i));
          if (val && isValidToken(val) && tokenScore(val) > 0) { hasToken = true; break; }
        }
        if (hasToken) break;
      }
      if (!hasToken) {
        console.log('[NexosIL] 🔓 Logout detectado (sessão prévia confirmada) — notificando extensão');
        safeSendMessage({ type: 'IL_TOKEN_REVOKED' });
      }
    }
  }

  // Detectar navegação SPA
  const _pushState = history.pushState.bind(history);
  const _replaceState = history.replaceState.bind(history);
  history.pushState = function (...args) {
    _pushState(...args);
    setTimeout(() => { scanStorage(); checkIfLoggedOut(); }, 300);
  };
  history.replaceState = function (...args) {
    _replaceState(...args);
    setTimeout(() => { scanStorage(); checkIfLoggedOut(); }, 300);
  };
  window.addEventListener('popstate', () => setTimeout(() => { scanStorage(); checkIfLoggedOut(); }, 300));

  // Detectar remoção de itens (logout via Stytch)
  const _origRemoveItem = Storage.prototype.removeItem;
  Storage.prototype.removeItem = function (key) {
    _origRemoveItem.call(this, key);
    setTimeout(checkIfLoggedOut, 100);
  };

  // ── 1. Interceptar fetch ────────────────────────────────────────────────
  const originalFetch = window.fetch;
  window.fetch = function (...args) {
    const [input, options] = args;
    const headers = (options && options.headers) || {};
    const url = (typeof input === 'string' ? input : input?.url) || '';

    // Log diagnóstico: capturar URLs da API Instaleap para descobrir parâmetros corretos
    if (url.includes('avt-backend.instaleap.io') || url.includes('/hela/api/') || url.includes('/jobs')) {
      console.log('[NexosIL] 🌐 API Instaleap detectada:', url);
    }

    // Capturar Bearer header de saída (já logado, fazendo chamada autenticada)
    let authHeader = null;
    if (headers instanceof Headers) {
      authHeader = headers.get('Authorization');
    } else if (typeof headers === 'object') {
      authHeader = headers['Authorization'] || headers['authorization'];
    }
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const t = authHeader.replace('Bearer ', '').trim();
      console.log('[NexosIL] 📤 fetch Bearer header detectado — url:', url.substring(0, 80), '| len:', t.length);
      sendToken(t, 'fetch-header');
    }

    return originalFetch.apply(this, args).then(response => {
      const cloned = response.clone();
      const ct = cloned.headers.get('content-type') || '';
      if (ct.includes('application/json')) {
        cloned.json().then(data => {
          // Log diagnóstico: todos os campos que parecem token
          const candidates = [];
          function extractCandidates(obj, prefix) {
            if (!obj || typeof obj !== 'object') return;
            for (const [k, v] of Object.entries(obj)) {
              if (typeof v === 'string' && isValidToken(v) && tokenScore(v) > 0) {
                candidates.push({ key: prefix + k, val: v, score: tokenScore(v) });
              } else if (typeof v === 'object' && v !== null) {
                extractCandidates(v, prefix + k + '.');
              }
            }
          }
          extractCandidates(data, '');
          if (candidates.length > 0) {
            console.log('[NexosIL] 📥 fetch JSON — candidatos de token de', url.substring(0, 60) + ':');
            candidates.forEach(c => console.log('   >', c.key, '| score:', c.score, '| preview:', c.val.substring(0, 30)));
          }
          // Prioridades: session_token (Stytch) > access_token > token genérico
          const token =
            data?.session_token ||
            data?.access_token ||
            data?.token ||
            data?.accessToken ||
            data?.data?.token ||
            data?.data?.access_token ||
            data?.member?.token ||
            data?.session?.access_token ||
            data?.session_jwt;
          if (token) sendToken(token, 'fetch-response[' + url.substring(0, 40) + ']');
        }).catch(() => {});
      }
      return response;
    });
  };

  // ── 2. Interceptar XMLHttpRequest ───────────────────────────────────────
  const OriginalXHR = window.XMLHttpRequest;
  function PatchedXHR() {
    const xhr = new OriginalXHR();
    let xhrUrl = '';
    const origOpen = xhr.open.bind(xhr);
    xhr.open = function (method, url, ...rest) {
      xhrUrl = url || '';
      return origOpen(method, url, ...rest);
    };
    xhr.setRequestHeader = new Proxy(xhr.setRequestHeader, {
      apply(target, thisArg, [name, value]) {
        if ((name || '').toLowerCase() === 'authorization' && value.startsWith('Bearer ')) {
          const t = value.replace('Bearer ', '').trim();
          console.log('[NexosIL] 📤 XHR Bearer header — url:', xhrUrl.substring(0, 60), '| len:', t.length);
          sendToken(t, 'xhr-header');
        }
        return target.call(thisArg, name, value);
      }
    });
    xhr.addEventListener('load', function () {
      try {
        const data = JSON.parse(xhr.responseText);
        const candidates = [];
        function extractCandidates(obj, prefix) {
          if (!obj || typeof obj !== 'object') return;
          for (const [k, v] of Object.entries(obj)) {
            if (typeof v === 'string' && isValidToken(v) && tokenScore(v) > 0) {
              candidates.push({ key: prefix + k, val: v, score: tokenScore(v) });
            } else if (typeof v === 'object' && v !== null) {
              extractCandidates(v, prefix + k + '.');
            }
          }
        }
        extractCandidates(data, '');
        if (candidates.length > 0) {
          console.log('[NexosIL] 📥 XHR JSON — candidatos de token de', xhrUrl.substring(0, 60) + ':');
          candidates.forEach(c => console.log('   >', c.key, '| score:', c.score, '| preview:', c.val.substring(0, 30)));
        }
        const token =
          data?.session_token || data?.access_token || data?.token ||
          data?.accessToken || data?.data?.token || data?.member?.token || data?.session_jwt;
        if (token) sendToken(token, 'xhr-response[' + xhrUrl.substring(0, 40) + ']');
      } catch (_) {}
    });
    return xhr;
  }
  PatchedXHR.prototype = OriginalXHR.prototype;
  window.XMLHttpRequest = PatchedXHR;

  // ── 3. Varredura periódica após login ───────────────────────────────────
  // Começa imediatamente com intervalo largo, acelera após interação do usuário
  let scanCount = 0;

  function startScanLoop(intervalMs, maxScans) {
    if (scanInterval) clearInterval(scanInterval);
    scanCount = 0;
    scanInterval = setInterval(() => {
      if (!isContextValid()) { clearInterval(scanInterval); scanInterval = null; return; }
      if (tokenSent) { clearInterval(scanInterval); scanInterval = null; return; }
      scanStorage();
      if (++scanCount >= maxScans) { clearInterval(scanInterval); scanInterval = null; }
    }, intervalMs);
  }

  // Varredura lenta inicial (pode ter token de sessão anterior válida)
  startScanLoop(2000, 30); // 2s × 30 = 1 min

  // Acelerar varredura após qualquer interação com o formulário
  function onUserInteraction(e) {
    const el = e.target;
    if (!el) return;
    const tag = (el.tagName || '').toUpperCase();
    const text = (el.textContent || '').toLowerCase();
    const isFormEl = tag === 'INPUT' || tag === 'BUTTON' || tag === 'FORM';
    if (isFormEl || text.includes('login') || text.includes('entrar') || text.includes('sign in') || text.includes('continue') || text.includes('verificar')) {
      document.removeEventListener('click', onUserInteraction, true);
      document.removeEventListener('submit', onUserInteraction, true);
      console.log('[NexosIL] 👆 Interação detectada — acelerando varredura');
      startScanLoop(300, 200); // 300ms × 200 = 1 min rápido
    }
  }
  document.addEventListener('click', onUserInteraction, { capture: true });
  document.addEventListener('submit', onUserInteraction, { capture: true });

  // ── 4. Pré-preencher email ──────────────────────────────────────────────
  if (isContextValid()) {
    chrome.storage.local.get(['nexos-il-prefill-email'], (result) => {
      if (chrome.runtime.lastError) return;
      const email = result['nexos-il-prefill-email'];
      if (!email) return;
      const tryFill = setInterval(() => {
        const input = document.querySelector(
          'input[type="email"], input[name="email"], input[placeholder*="mail" i], input[placeholder*="e-mail" i]'
        );
        if (input && !input.value) {
          input.value = email;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          console.log('[NexosIL] 📧 Email pré-preenchido:', email);
          clearInterval(tryFill);
        }
      }, 300);
      setTimeout(() => clearInterval(tryFill), 15000);
    });
  }

  console.log('[NexosIL] 🔍 Interceptor Instaleap ativo —', window.location.href);
})()
