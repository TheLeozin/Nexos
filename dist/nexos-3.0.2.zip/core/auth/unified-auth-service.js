/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - UNIFIED AUTH SERVICE
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Serviço unificado de autenticação que escolhe automaticamente o melhor
 * método baseado no contexto de execução:
 * 
 * - Extensão Chrome: usa chrome.identity.launchWebAuthFlow()
 * - Página web: usa MSAL loginPopup() ou loginRedirect()
 * 
 * Simplifica o código de autenticação eliminando a necessidade de verificar
 * manualmente qual método usar.
 * 
 * @author Leonardo Miguel
 * @date 2026-01-25
 */

class UnifiedAuthService {
  constructor() {
    this.msalAuth = window.msalAuth; // Instância global do MsalAuth
    this.context = this._detectContext();
    this.currentUser = null;
    this.accessToken = null;
    this.tokenExpiry = null;
    
    console.log('[UnifiedAuth] 🎯 Contexto detectado:', this.context);
  }

  /**
   * Detecta o contexto de execução
   * @returns {'extension' | 'web'}
   */
  _detectContext() {
    // Verificar se estamos em uma extensão Chrome
    if (typeof chrome !== 'undefined' && 
        chrome.runtime && 
        chrome.runtime.id &&
        chrome.identity &&
        chrome.identity.launchWebAuthFlow) {
      return 'extension';
    }
    
    return 'web';
  }

  /**
   * Login unificado - escolhe automaticamente o melhor método
   * 
   * @param {object} options - Opções de login
   * @param {string} options.method - Forçar método específico: 'chrome-identity', 'popup', 'redirect'
   * @returns {Promise<{success: boolean, accessToken: string, account: object}>}
   */
  async login(options = {}) {
    console.log('[UnifiedAuth] 🔐 Iniciando login unificado...');
    console.log('[UnifiedAuth] 📍 Contexto:', this.context);

    try {
      // Verificar se já está logado
      if (this.accessToken && this.tokenExpiry && Date.now() < this.tokenExpiry) {
        console.log('[UnifiedAuth] ✅ Já autenticado (token válido)');
        return {
          success: true,
          accessToken: this.accessToken,
          account: this.currentUser,
          cached: true
        };
      }

      let result;

      // Escolher método baseado no contexto ou opção forçada
      const method = options.method || (this.context === 'extension' ? 'chrome-identity' : 'popup');

      console.log('[UnifiedAuth] 🔧 Método escolhido:', method);

      switch (method) {
        case 'chrome-identity':
          if (this.context !== 'extension') {
            throw new Error('Chrome Identity só funciona em extensões Chrome');
          }
          result = await this.msalAuth.loginWithChromeIdentity();
          break;

        case 'popup':
          result = await this.msalAuth.loginPopup();
          break;

        case 'redirect':
          result = await this.msalAuth.loginRedirect();
          // redirect não retorna (faz navegação), então nunca chega aqui
          return { success: true, redirectStarted: true };

        default:
          throw new Error(`Método de login desconhecido: ${method}`);
      }

      if (result.success) {
        // Armazenar em memória
        this.accessToken = result.accessToken;
        this.currentUser = result.account;
        this.tokenExpiry = Date.now() + (result.expiresIn * 1000);

        console.log('[UnifiedAuth] ✅ Login bem-sucedido');
        console.log('[UnifiedAuth] 👤 Usuário:', result.account?.username);
        console.log('[UnifiedAuth] ⏰ Token expira em:', Math.floor(result.expiresIn / 60), 'minutos');

        return result;
      } else {
        throw result.error || new Error('Login falhou');
      }

    } catch (error) {
      console.error('[UnifiedAuth] ❌ Erro no login:', error);
      return {
        success: false,
        error: {
          message: error.message || 'Erro desconhecido',
          code: error.code || 'UNKNOWN_ERROR'
        }
      };
    }
  }

  /**
   * Obtém o access token atual (com renovação automática se expirado)
   * @returns {Promise<string>}
   */
  async getAccessToken() {
    // Se token em memória ainda é válido, retornar
    if (this.accessToken && this.tokenExpiry && Date.now() < this.tokenExpiry) {
      return this.accessToken;
    }

    // Token expirado ou não existe, fazer login novamente
    console.log('[UnifiedAuth] ⚠️ Token expirado ou não existe, renovando...');
    const result = await this.login();
    
    if (!result.success) {
      throw new Error('Falha ao renovar token: ' + (result.error?.message || 'Erro desconhecido'));
    }

    return result.accessToken;
  }

  /**
   * Obtém informações do usuário logado
   * @returns {object|null}
   */
  getCurrentUser() {
    return this.currentUser;
  }

  /**
   * Verifica se o usuário está logado
   * @returns {boolean}
   */
  isAuthenticated() {
    return this.currentUser !== null && 
           this.accessToken !== null && 
           this.tokenExpiry !== null && 
           Date.now() < this.tokenExpiry;
  }

  /**
   * Logout - limpa dados em memória
   */
  logout() {
    console.log('[UnifiedAuth] 🚪 Logout');
    this.accessToken = null;
    this.currentUser = null;
    this.tokenExpiry = null;

    // Se MSAL tem método de logout, chamar também
    if (this.msalAuth && typeof this.msalAuth.logout === 'function') {
      this.msalAuth.logout();
    }
  }

  /**
   * Obtém informações sobre o contexto e estado atual
   * @returns {object}
   */
  getStatus() {
    return {
      context: this.context,
      authenticated: this.isAuthenticated(),
      user: this.currentUser,
      tokenExpiry: this.tokenExpiry ? new Date(this.tokenExpiry) : null,
      msalAvailable: !!this.msalAuth
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════════════════════════════════════

// Criar instância global (singleton)
if (typeof window !== 'undefined') {
  window.UnifiedAuthService = UnifiedAuthService;
  
  // Criar instância automaticamente se msalAuth já existe
  if (window.msalAuth) {
    window.unifiedAuth = new UnifiedAuthService();
    console.log('[UnifiedAuth] ✅ Instância global criada: window.unifiedAuth');
    console.log('[UnifiedAuth] 📊 Status:', window.unifiedAuth.getStatus());
  } else {
    console.log('[UnifiedAuth] ⏳ Aguardando window.msalAuth ser inicializado...');
    
    // Observer para criar instância quando msalAuth estiver pronto
    let checkInterval = setInterval(() => {
      if (window.msalAuth) {
        window.unifiedAuth = new UnifiedAuthService();
        console.log('[UnifiedAuth] ✅ Instância global criada: window.unifiedAuth');
        console.log('[UnifiedAuth] 📊 Status:', window.unifiedAuth.getStatus());
        clearInterval(checkInterval);
      }
    }, 100);
    
    // Timeout após 10 segundos
    setTimeout(() => {
      if (!window.unifiedAuth) {
        console.warn('[UnifiedAuth] ⚠️ Timeout: msalAuth não foi inicializado em 10 segundos');
        clearInterval(checkInterval);
      }
    }, 10000);
  }
}

console.log('[UnifiedAuth] 📦 Módulo carregado');
