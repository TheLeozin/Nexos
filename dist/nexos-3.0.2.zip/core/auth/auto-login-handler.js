/**
 * ═══════════════════════════════════════════════════════════════════════════
 * AUTO LOGIN HANDLER - Sistema de Autenticação Automática
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Detecta quando usuário não está autenticado e solicita login automaticamente
 * Exibe modal amigável e gerencia fluxo de autenticação MSAL
 * 
 * @version 1.0.0
 * @date 2026-01-08
 */

(function() {
  'use strict';

  class AutoLoginHandler {
    constructor() {
      this.isShowingModal = false;
      this.pendingOperations = [];
      this.maxRetries = 2;
    }

    /**
     * Verifica se erro é de autenticação
     */
    isAuthError(error) {
      if (!error) return false;
      
      const errorMsg = error.message || error.toString();
      const authKeywords = [
        'autenticação necessária',
        'authentication required',
        'nenhum token encontrado',
        'no token found',
        'token expirado',
        'token expired',
        'token inválido',
        'invalid token',
        'sem token',
        'please login',
        'faça login',
        'http 401',  // ← NOVO: Detectar HTTP 401 (Unauthorized)
        '401',
        'unauthorized'
      ];
      
      return authKeywords.some(keyword => 
        errorMsg.toLowerCase().includes(keyword.toLowerCase())
      );
    }

    /**
     * Exibe modal de login com UI amigável
     */
    async showLoginModal() {
      if (this.isShowingModal) {
        console.log('[AutoLogin] Modal já está sendo exibido');
        return;
      }

      this.isShowingModal = true;

      return new Promise((resolve) => {
        // Criar overlay
        const overlay = document.createElement('div');
        overlay.id = 'nexos-login-modal';
        overlay.style.cssText = `
          position: fixed;
          top: 0;
          left: 0;
          width: 100vw;
          height: 100vh;
          background: rgba(0, 0, 0, 0.7);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 999999;
          backdrop-filter: blur(5px);
          animation: fadeIn 0.3s ease-out;
        `;

        // Criar modal
        const modal = document.createElement('div');
        modal.style.cssText = `
          background: white;
          border-radius: 16px;
          padding: 32px;
          max-width: 480px;
          box-shadow: 0 20px 60px rgba(0,0,0,0.3);
          animation: slideUp 0.3s ease-out;
        `;

        modal.innerHTML = `
          <style>
            @keyframes fadeIn {
              from { opacity: 0; }
              to { opacity: 1; }
            }
            @keyframes slideUp {
              from { transform: translateY(20px); opacity: 0; }
              to { transform: translateY(0); opacity: 1; }
            }
            @keyframes spin {
              to { transform: rotate(360deg); }
            }
          </style>

          <div style="text-align: center;">
            <!-- Ícone -->
            <div style="
              width: 80px;
              height: 80px;
              margin: 0 auto 24px;
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 40px;
            ">
              🔐
            </div>

            <!-- Título -->
            <h2 style="
              margin: 0 0 12px;
              font-size: 24px;
              font-weight: 700;
              color: #1a202c;
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            ">
              Autenticação Necessária
            </h2>

            <!-- Descrição -->
            <p style="
              margin: 0 0 32px;
              font-size: 16px;
              color: #4a5568;
              line-height: 1.6;
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            ">
              Para salvar pedidos no <strong>SharePoint Online</strong>,<br>
              você precisa fazer login com sua conta <strong>Microsoft 365</strong>.
            </p>

            <!-- Botões -->
            <div style="display: flex; gap: 12px; justify-content: center;">
              <button id="nexos-login-btn" style="
                flex: 1;
                padding: 14px 28px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.2s;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
              ">
                🚀 Fazer Login
              </button>
              
              <button id="nexos-cancel-btn" style="
                flex: 1;
                padding: 14px 28px;
                background: #e2e8f0;
                color: #4a5568;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.2s;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
              ">
                ❌ Cancelar
              </button>
            </div>

            <!-- Info adicional -->
            <div style="
              margin-top: 24px;
              padding: 16px;
              background: #edf2f7;
              border-radius: 8px;
              font-size: 14px;
              color: #4a5568;
              text-align: left;
              line-height: 1.6;
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            ">
              <strong>ℹ️ Informações:</strong><br>
              • Seus dados ficam salvos localmente até o login<br>
              • A autenticação é segura via Microsoft<br>
              • Você só precisa fazer login uma vez
            </div>

            <!-- Spinner de loading (oculto inicialmente) -->
            <div id="nexos-login-spinner" style="display: none; margin-top: 20px;">
              <div style="
                width: 40px;
                height: 40px;
                margin: 0 auto;
                border: 4px solid #e2e8f0;
                border-top-color: #667eea;
                border-radius: 50%;
                animation: spin 0.8s linear infinite;
              "></div>
              <p style="
                margin-top: 12px;
                font-size: 14px;
                color: #4a5568;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
              ">
                Aguardando autenticação...
              </p>
            </div>
          </div>
        `;

        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        // Animações de hover
        const loginBtn = modal.querySelector('#nexos-login-btn');
        const cancelBtn = modal.querySelector('#nexos-cancel-btn');
        
        loginBtn.addEventListener('mouseenter', () => {
          loginBtn.style.transform = 'translateY(-2px)';
          loginBtn.style.boxShadow = '0 10px 30px rgba(102, 126, 234, 0.4)';
        });
        loginBtn.addEventListener('mouseleave', () => {
          loginBtn.style.transform = 'translateY(0)';
          loginBtn.style.boxShadow = 'none';
        });

        cancelBtn.addEventListener('mouseenter', () => {
          cancelBtn.style.transform = 'translateY(-2px)';
          cancelBtn.style.backgroundColor = '#cbd5e0';
        });
        cancelBtn.addEventListener('mouseleave', () => {
          cancelBtn.style.transform = 'translateY(0)';
          cancelBtn.style.backgroundColor = '#e2e8f0';
        });

        // Handlers
        loginBtn.addEventListener('click', async () => {
          console.log('[AutoLogin] 🚀 Usuário clicou em Fazer Login');
          
          // Mostrar spinner
          modal.querySelector('#nexos-login-btn').style.display = 'none';
          modal.querySelector('#nexos-cancel-btn').style.display = 'none';
          modal.querySelector('#nexos-login-spinner').style.display = 'block';
          
          try {
            await this.performLogin();
            
            // Fechar modal
            overlay.style.animation = 'fadeIn 0.2s ease-out reverse';
            setTimeout(() => {
              overlay.remove();
              this.isShowingModal = false;
            }, 200);
            
            resolve(true);
            
          } catch (error) {
            console.error('[AutoLogin] ❌ Erro no login:', error);
            
            // Mostrar erro
            modal.querySelector('#nexos-login-spinner').innerHTML = `
              <div style="color: #e53e3e; font-size: 14px; margin-top: 12px;">
                ❌ Erro ao fazer login: ${error.message}<br>
                <button onclick="location.reload()" style="
                  margin-top: 12px;
                  padding: 8px 16px;
                  background: #667eea;
                  color: white;
                  border: none;
                  border-radius: 6px;
                  cursor: pointer;
                ">
                  🔄 Recarregar página
                </button>
              </div>
            `;
            
            resolve(false);
          }
        });

        cancelBtn.addEventListener('click', () => {
          console.log('[AutoLogin] ❌ Usuário cancelou login');
          
          overlay.style.animation = 'fadeIn 0.2s ease-out reverse';
          setTimeout(() => {
            overlay.remove();
            this.isShowingModal = false;
          }, 200);
          
          resolve(false);
        });
      });
    }

    /**
     * Executa login via MSAL
     */
    async performLogin() {
      console.log('[AutoLogin] 🔐 Iniciando autenticação...');

      // ✅ LIMPAR TOKENS INVÁLIDOS antes de novo login
      await this.clearInvalidTokens();

      try {
        // ✅ USAR AUTHHELPER CORRETO (chrome.identity.launchWebAuthFlow)
        if (typeof window.authHelper !== 'undefined' && window.authHelper) {
          console.log('[AutoLogin] 🔄 Usando authHelper.login() (chrome.identity)');
          await window.authHelper.login();
          
          // Notificar outros componentes
          window.dispatchEvent(new CustomEvent('nexos-auth-success', {
            detail: { source: 'authHelper' }
          }));
          
          return true;
        } else {
          // Fallback para MSAL se authHelper não estiver disponível
          console.warn('[AutoLogin] ⚠️ authHelper não disponível, tentando MSAL...');
          
          if (typeof window.msalAuth === 'undefined') {
            throw new Error('Sistema de autenticação não disponível');
          }

          // ❌ MSALAUTH.LOGINPOPUP NÃO FUNCIONA EM EXTENSÕES
          // Mas deixando como fallback caso algo mude
          console.warn('[AutoLogin] ⚠️ AVISO: msalAuth.loginPopup() pode não funcionar em extensões');
          
          const result = await window.msalAuth.loginPopup();
          
          if (result && result.account) {
            console.log('[AutoLogin] ✅ Login bem-sucedido:', result.account.username);
            
            window.dispatchEvent(new CustomEvent('nexos-auth-success', {
              detail: { account: result.account }
            }));
            
            return true;
          } else {
            throw new Error('Login cancelado ou falhou');
          }
        }
        
      } catch (error) {
        console.error('[AutoLogin] ❌ Erro no login:', error);
        throw error;
      }
    }

    /**
     * Limpa tokens inválidos de todos os caches
     */
    async clearInvalidTokens() {
      console.log('[AutoLogin] 🗑️ Limpando tokens inválidos...');

      try {
        // Limpar cache do UnifiedAuth
        if (window.unifiedAuth) {
          window.unifiedAuth.tokenCache = null;
          window.unifiedAuth.tokenExpiryTime = 0;
        }

        // Limpar cache do TokenInterceptor
        if (window.tokenInterceptor) {
          await window.tokenInterceptor.clearToken();
        }

        // Limpar cache do TokenStorageScanner
        if (window.tokenStorageScanner) {
          await window.tokenStorageScanner.clearToken();
        }

        console.log('[AutoLogin] ✅ Caches limpos');
      } catch (error) {
        console.warn('[AutoLogin] ⚠️ Erro ao limpar caches:', error);
      }
    }

    /**
     * Wrapper para operações que requerem autenticação
     * Detecta falha, solicita login e retenta automaticamente
     */
    async withAutoLogin(operation, operationName = 'Operação') {
      let attempts = 0;
      
      while (attempts < this.maxRetries) {
        try {
          console.log(`[AutoLogin] 🔄 Tentativa ${attempts + 1}/${this.maxRetries}: ${operationName}`);
          
          const result = await operation();
          
          console.log(`[AutoLogin] ✅ ${operationName} concluída com sucesso`);
          return { success: true, data: result };
          
        } catch (error) {
          attempts++;
          
          // Verificar se é erro de autenticação
          if (this.isAuthError(error)) {
            console.warn(`[AutoLogin] ⚠️ Erro de autenticação detectado (tentativa ${attempts})`);
            
            if (attempts >= this.maxRetries) {
              console.error('[AutoLogin] ❌ Máximo de tentativas atingido');
              return { 
                success: false, 
                error: error.message,
                needsLogin: true
              };
            }
            
            // Solicitar login
            const loginSuccess = await this.showLoginModal();
            
            if (!loginSuccess) {
              console.log('[AutoLogin] ❌ Usuário cancelou login');
              return { 
                success: false, 
                error: 'Login cancelado pelo usuário',
                cancelled: true
              };
            }
            
            // Aguardar 1s para token propagar
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            console.log('[AutoLogin] 🔄 Retentando operação após login...');
            continue;
            
          } else {
            // Outro tipo de erro, não tentar novamente
            console.error(`[AutoLogin] ❌ Erro não relacionado à autenticação:`, error);
            return { 
              success: false, 
              error: error.message 
            };
          }
        }
      }
      
      return { 
        success: false, 
        error: 'Máximo de tentativas atingido' 
      };
    }
  }

  // Criar instância global
  window.autoLoginHandler = new AutoLoginHandler();

  console.log('[AutoLogin] 📦 Sistema de auto-login carregado');

})();
