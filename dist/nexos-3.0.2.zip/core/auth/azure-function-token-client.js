/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - AZURE FUNCTION TOKEN CLIENT
 * Cliente para obter tokens via Azure Function Proxy
 * 
 * SUBSTITUI: Client Credentials Flow direto (bloqueado pelo Azure AD)
 * USA: Azure Function como proxy seguro
 * 
 * INTEGRAÇÃO:
 * - Substituir AppOnlyAuth._acquireNewToken() para usar este cliente
 * - Mantém mesma interface (retorna tokenData)
 * - Cache funciona da mesma forma
 * ═══════════════════════════════════════════════════════════════════════════
 */

class AzureFunctionTokenClient {
  constructor(config = {}) {
    // URL da Azure Function (atualizar após deploy)
    this.functionUrl = config.functionUrl || 'http://localhost:7071/api/token';
    
    // Para produção, será algo como:
    // 'https://nexos-torre-proxy.azurewebsites.net/api/token'
    
    this.timeout = config.timeout || 10000; // 10 segundos
    
    console.log('[AzureFunctionTokenClient] Inicializado:', {
      functionUrl: this.functionUrl
    });
  }
  
  /**
   * Obtém access token via Azure Function
   * @returns {Promise<Object>} Token data (access_token, expires_in, etc)
   */
  async getAccessToken() {
    console.log('[AzureFunctionTokenClient] Solicitando token via Azure Function...');
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.timeout);
      
      const response = await fetch(this.functionUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('[AzureFunctionTokenClient] ❌ Request falhou:', {
          status: response.status,
          error: errorData
        });
        
        throw new Error(
          `Azure Function request falhou: ${response.status} - ${errorData.message || 'Unknown error'}`
        );
      }
      
      const tokenData = await response.json();
      
      console.log('[AzureFunctionTokenClient] ✅ Token obtido com sucesso:', {
        token_type: tokenData.token_type,
        expires_in: tokenData.expires_in,
        access_token_length: tokenData.access_token?.length
      });
      
      // Adicionar timestamp de aquisição (compatibilidade com AppOnlyAuth)
      tokenData.acquired_at = Date.now();
      
      return tokenData;
      
    } catch (error) {
      if (error.name === 'AbortError') {
        console.error('[AzureFunctionTokenClient] ❌ Timeout após', this.timeout, 'ms');
        throw new Error(`Azure Function timeout após ${this.timeout}ms`);
      }
      
      console.error('[AzureFunctionTokenClient] ❌ Erro:', error);
      throw error;
    }
  }
  
  /**
   * Testa conectividade com Azure Function
   * @returns {Promise<boolean>}
   */
  async testConnection() {
    try {
      console.log('[AzureFunctionTokenClient] Testando conectividade...');
      await this.getAccessToken();
      console.log('[AzureFunctionTokenClient] ✅ Conectividade OK');
      return true;
    } catch (error) {
      console.error('[AzureFunctionTokenClient] ❌ Conectividade FALHOU:', error);
      return false;
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════════════════════════════════════

if (typeof module !== 'undefined' && module.exports) {
  module.exports = AzureFunctionTokenClient;
}

// Service Worker usa 'self', DOM usa 'window'
if (typeof self !== 'undefined') {
  self.AzureFunctionTokenClient = AzureFunctionTokenClient;
}

console.log('[AzureFunctionTokenClient] Módulo carregado com sucesso');
