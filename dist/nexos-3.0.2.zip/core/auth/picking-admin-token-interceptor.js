/**
 * picking-admin-token-interceptor.js
 * Content script injetado em picking-admin.backoffice.gpa.digital (MAIN world)
 *
 * Responsabilidades:
 *  1. Capturar o Bearer token JWT (HS256) após login na página
 *  2. Enviar PK_TOKEN_CAPTURED ao background para uso no monitor
 *  3. Detectar expiração do token (401 nas chamadas da página)
 */

(function () {
  'use strict';

  // ── Guarda de contexto ──────────────────────────────────────────────────
  function isContextValid() {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  function safeSendMessage(msg, cb) {
    if (!isContextValid()) return;
    try {
      chrome.runtime.sendMessage(msg, (response) => {
        if (chrome.runtime.lastError) return;
        if (cb) cb(response);
      });
    } catch (_) {}
  }

  let tokenSent = false;
  let lastSentToken = null;

  // ── Validar JWT HS256 (token picking-admin) ─────────────────────────────
  function isPickingJwt(val) {
    if (!val || typeof val !== 'string') return false;
    if (!val.startsWith('ey')) return false;
    const parts = val.split('.');
    if (parts.length !== 3) return false;
    if (val.length < 50) return false;
    // Verificar que é HS256 (token do picking-admin), não RS256 (Azure AD)
    try {
      const header = JSON.parse(atob(parts[0].replace(/-/g, '+').replace(/_/g, '/')));
      // Aceitar HS256 (picking) e também RS256/RS384 (compatibilidade)
      return !!header.alg;
    } catch (_) {
      return false;
    }
  }

  // Decodifica audience do JWT sem verificar assinatura
  function decodeAud(jwt) {
    try {
      return JSON.parse(atob(jwt.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).aud || '';
    } catch (_) { return ''; }
  }

  // Rejeitar tokens do Azure AD/Microsoft Graph — eles não funcionam na API picking
  function isAzureAdToken(jwt) {
    const aud = String(decodeAud(jwt));
    const AZURE_AUDS = [
      'https://graph.microsoft.com',
      '00000003-0000-0000-c000-000000000000',
      'https://management.azure.com',
    ];
    return AZURE_AUDS.some(a => aud === a || aud.startsWith(a));
  }

  // ── Enviar token capturado ao background ────────────────────────────────
  function sendToken(token, source) {
    if (!isPickingJwt(token)) return;
    if (isAzureAdToken(token)) return;
    if (token === lastSentToken) return; // não reenviar o mesmo token

    lastSentToken = token;
    tokenSent = true;
    console.log('[NexosPK] ✅ Token picking-admin capturado via', source, '— len:', token.length);

    // Persistir em chave conhecida para que background.js possa ler via executeScript
    try { localStorage.setItem('__nexos_pk_bearer__', token); } catch (_) {}

    safeSendMessage({ type: 'PK_TOKEN_CAPTURED', token }, (response) => {
      if (response && response.ignored) {
        console.log('[NexosPK] ℹ Token salvo no storage (sem login pendente no momento)');
      }
    });
  }

  // Verificar se a URL de destino é o API gateway de produção GPA
  // Capturar token APENAS de chamadas reais à API picking — não de chamadas auth internas
  function isPickingApiUrl(input) {
    try {
      const url = typeof input === 'string' ? input : (input?.url || String(input));
      return url.includes('api-gtw-prod.backoffice.gpa.digital') ||
             url.includes('/picking/api/');
    } catch (_) { return false; }
  }

  // ── Interceptar fetch ───────────────────────────────────────────────────
  const _originalFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    // Capturar token SOMENTE de requests para o API gateway de produção
    if (isPickingApiUrl(input)) {
      const authHeader = (init?.headers instanceof Headers
        ? init.headers.get('authorization')
        : (init?.headers?.['authorization'] || init?.headers?.['Authorization'])) || '';

      if (authHeader.startsWith('Bearer ')) {
        sendToken(authHeader.slice(7), 'fetch-interceptor');
      }
    }

    // Também capturar da resposta 401 (token expirado)
    return _originalFetch(input, init).then(res => {
      if ((res.status === 401 || res.status === 403) && lastSentToken && isPickingApiUrl(input)) {
        console.log('[NexosPK] 🔓', res.status, 'detectado na API picking — token pode ter expirado');
        try { localStorage.removeItem('__nexos_pk_bearer__'); } catch (_) {}
        safeSendMessage({ type: 'PK_TOKEN_EXPIRED' });
        lastSentToken = null;
        tokenSent = false;
      }
      return res;
    });
  };

  // ── Interceptar XMLHttpRequest ──────────────────────────────────────────
  const _originalOpen  = XMLHttpRequest.prototype.open;
  const _originalSetRH = XMLHttpRequest.prototype.setRequestHeader;

  // Rastrear URL aberta pelo XHR para filtrar por domínio
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__nexos_xhr_url__ = String(url || '');
    return _originalOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (name.toLowerCase() === 'authorization' && typeof value === 'string' && value.startsWith('Bearer ')
        && isPickingApiUrl(this.__nexos_xhr_url__ || '')) {
      sendToken(value.slice(7), 'xhr-interceptor');
    }
    return _originalSetRH.apply(this, arguments);
  };

  // ── Ler token direto de localStorage['user'].token (chave nativa da SPA) ────
  (function readNativeToken() {
    try {
      const raw = localStorage.getItem('user');
      if (!raw) return;
      const obj = JSON.parse(raw);
      const token = obj?.token || obj?.accessToken || obj?.access_token || null;
      if (token) sendToken(token, 'localStorage[user.token]');
    } catch (_) {}
  })();

  console.log('[NexosPK] 🚀 Picking Admin token interceptor ativo');
})();
