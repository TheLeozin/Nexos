/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - AUTH TOKEN SERVICE
 * Serviço centralizado de autenticação e token corporativo
 * 
 * Responsabilidades:
 * ✅ Única fonte de verdade para tokens (SharePoint Nexos_TokenVault)
 * ✅ Validação de tokens (expiração, validade)
 * ✅ Renovação silenciosa de tokens
 * ✅ Revogação de tokens
 * ✅ Distribuição segura de tokens para extensão
 * 
 * NUNCA:
 * ❌ Armazenar em chrome.storage.local
 * ❌ Armazenar em IndexedDB
 * ❌ Armazenar em localStorage
 * ❌ Expor token em APIs públicas
 * ═══════════════════════════════════════════════════════════════════════════
 */

class AuthTokenService {
  constructor(graphClient, userContext) {
    this.graphClient = graphClient;
    this.userContext = userContext; // { userPrincipalName, displayName, id, mail }
    this.tokenCache = null;
    this.tokenCacheExpiresAt = null;
    this.renewalInProgress = false;
    this.renewalLock = null;
    
    if (!graphClient) {
      throw new Error('AuthTokenService requer graphClient');
    }
    
    if (!userContext) {
      throw new Error('AuthTokenService requer userContext');
    }
    
    if (!userContext.userPrincipalName) {
      throw new Error('userContext deve conter userPrincipalName');
    }
    
    console.log('[AuthTokenService] Inicializado para:', userContext.userPrincipalName);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // RECUPERAR TOKEN
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Obter token válido (com renovação automática se expirado)
   * @returns {Promise<object>} { accessToken, refreshToken, expiresAt, expiresIn }
   */
  async getToken() {
    try {
      // 1️⃣ Verificar cache em memória
      if (this.isTokenCacheValid()) {
        console.log('[AuthTokenService] ✅ Token encontrado em cache');
        return this.tokenCache;
      }
      
      // 2️⃣ Buscar de SharePoint (fonte única de verdade)
      const tokenRecord = await this.getTokenFromSharePoint();
      
      if (!tokenRecord) {
        throw new Error('Token não encontrado em SharePoint. Faça login.');
      }
      
      // 3️⃣ Verificar validade
      const now = Date.now();
      const expiresAt = new Date(tokenRecord.ExpiresAt).getTime();
      
      if (now > expiresAt) {
        console.warn('[AuthTokenService] ⚠️ Token expirado');
        
        // 4️⃣ Tentar renovar
        if (tokenRecord.RefreshToken) {
          return await this.renewToken(tokenRecord.RefreshToken);
        } else {
          throw new Error('Token expirado e refresh token não disponível. Faça login novamente.');
        }
      }
      
      // 5️⃣ Token válido, atualizar cache e retornar
      const token = {
        accessToken: tokenRecord.AccessToken,
        refreshToken: tokenRecord.RefreshToken,
        expiresAt: expiresAt,
        expiresIn: Math.round((expiresAt - now) / 1000),
        tokenType: 'Bearer'
      };
      
      // Cache por 5 minutos ou até 1 minuto antes de expirar (menor)
      const cacheFor = Math.min(5 * 60 * 1000, (expiresAt - now) - 60 * 1000);
      this.updateTokenCache(token, cacheFor);
      
      console.log('[AuthTokenService] ✅ Token válido, expira em', token.expiresIn, 'segundos');
      
      return token;
      
    } catch (error) {
      console.error('[AuthTokenService] ❌ Erro ao obter token:', {
        message: error.message,
        user: this.userContext.userPrincipalName
      });
      
      // Registrar em auditoria
      await this._logAuditEvent('TOKEN_RETRIEVAL_FAILED', {
        error: error.message,
        user: this.userContext.userPrincipalName
      });
      
      throw error;
    }
  }
  
  /**
   * Obter apenas access token (string)
   * @returns {Promise<string>} Access token
   */
  async getAccessToken() {
    const token = await this.getToken();
    return token.accessToken;
  }
  
  /**
   * Buscar token de SharePoint
   * @private
   */
  async getTokenFromSharePoint() {
    try {
      console.log('[AuthTokenService] Buscando token em SharePoint...');
      
      // Construir filtro: UserID eq 'user@example.com' AND IsValid eq true
      const filter = `UserID eq '${this.userContext.userPrincipalName}' and IsValid eq true`;
      
      // Buscar em Nexos_TokenVault (queryList agora é alias para getListItems)
      const results = await this.graphClient.queryList(
        'Nexos_TokenVault',
        {
          filter: filter,
          select: 'AccessToken,RefreshToken,ExpiresAt,DeviceID,CreatedAt',
          top: 1,
          orderBy: 'Modified desc' // ✅ CORRIGIDO: orderBy (não orderby) e campo correto Modified
        }
      );
      
      if (!results || results.length === 0) {
        console.warn('[AuthTokenService] ⚠️ Nenhum token em SharePoint');
        return null;
      }
      
      const tokenRecord = results[0];
      console.log('[AuthTokenService] ✅ Token encontrado em SharePoint');
      
      return tokenRecord;
      
    } catch (error) {
      console.error('[AuthTokenService] ❌ Erro ao buscar em SharePoint:', error.message);
      throw new Error(`Erro ao buscar token em SharePoint: ${error.message}`);
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // SALVAR TOKEN
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Salvar novo token em SharePoint
   * @param {string} accessToken - Access token do OAuth
   * @param {string} refreshToken - Refresh token
   * @param {number} expiresIn - Segundos até expiração
   */
  async saveToken(accessToken, refreshToken, expiresIn) {
    try {
      console.log('[AuthTokenService] Salvando token em SharePoint...');
      
      if (!accessToken) {
        throw new Error('accessToken não pode ser vazio');
      }
      
      const expiresAt = new Date(Date.now() + expiresIn * 1000).toISOString();
      const now = new Date().toISOString();
      
      const itemData = {
        UserID: this.userContext.userPrincipalName,
        AccessToken: accessToken,
        RefreshToken: refreshToken || null,
        ExpiresAt: expiresAt,
        CreatedAt: now,
        UpdatedAt: now,
        DeviceID: await this._getDeviceID(),
        IsValid: true
      };
      
      // Tentar atualizar existente, se falhar, criar novo
      const result = await this.graphClient.createOrUpdateListItem(
        'Nexos_TokenVault',
        itemData,
        {
          matchField: 'UserID',
          matchValue: this.userContext.userPrincipalName
        }
      );
      
      // Atualizar cache
      const token = {
        accessToken,
        refreshToken,
        expiresAt: new Date(expiresAt).getTime(),
        expiresIn,
        tokenType: 'Bearer'
      };
      
      this.updateTokenCache(token, 5 * 60 * 1000); // Cache por 5 minutos
      
      console.log('[AuthTokenService] ✅ Token salvo em SharePoint');
      
      // Log de auditoria
      await this._logAuditEvent('TOKEN_SAVED', {
        user: this.userContext.userPrincipalName,
        expiresIn,
        deviceID: itemData.DeviceID
      });
      
      return result;
      
    } catch (error) {
      console.error('[AuthTokenService] ❌ Erro ao salvar token:', error.message);
      
      // Log de auditoria
      await this._logAuditEvent('TOKEN_SAVE_FAILED', {
        error: error.message,
        user: this.userContext.userPrincipalName
      });
      
      throw new Error(`Erro ao salvar token: ${error.message}`);
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // RENOVAR TOKEN
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Renovar token silenciosamente usando refresh token
   * @private
   */
  async renewToken(refreshToken) {
    // Evitar renovações simultâneas
    if (this.renewalInProgress) {
      console.log('[AuthTokenService] ⏳ Renovação já em progresso, aguardando...');
      return await this.renewalLock;
    }
    
    this.renewalInProgress = true;
    this.renewalLock = this._performTokenRenewal(refreshToken);
    
    try {
      const result = await this.renewalLock;
      this.renewalInProgress = false;
      return result;
    } catch (error) {
      this.renewalInProgress = false;
      throw error;
    }
  }
  
  /**
   * Executar renovação de token
   * @private
   */
  async _performTokenRenewal(refreshToken) {
    try {
      console.log('[AuthTokenService] 🔄 Renovando token...');
      
      if (!refreshToken) {
        throw new Error('Refresh token não disponível');
      }
      
      // Chamar token endpoint do Azure AD
      const response = await fetch(
        `https://login.microsoftonline.com/${SHAREPOINT_CONFIG.auth.tenantId}/oauth2/v2.0/token`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: new URLSearchParams({
            client_id: SHAREPOINT_CONFIG.auth.clientId,
            client_secret: SHAREPOINT_CONFIG.auth.clientSecret,
            refresh_token: refreshToken,
            grant_type: 'refresh_token',
            scope: SHAREPOINT_CONFIG.auth.scopes.join(' ')
          })
        }
      );
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Renovação falhou: ${errorData.error} - ${errorData.error_description}`);
      }
      
      const { access_token, refresh_token, expires_in } = await response.json();
      
      // Salvar novo token
      await this.saveToken(access_token, refresh_token, expires_in);
      
      console.log('[AuthTokenService] ✅ Token renovado com sucesso');
      
      // Log de auditoria
      await this._logAuditEvent('TOKEN_RENEWED', {
        user: this.userContext.userPrincipalName,
        expiresIn: expires_in
      });
      
      return {
        accessToken: access_token,
        refreshToken: refresh_token,
        expiresAt: Date.now() + expires_in * 1000,
        expiresIn: expires_in,
        tokenType: 'Bearer'
      };
      
    } catch (error) {
      console.error('[AuthTokenService] ❌ Erro ao renovar:', error.message);
      
      // Log de auditoria
      await this._logAuditEvent('TOKEN_RENEWAL_FAILED', {
        error: error.message,
        user: this.userContext.userPrincipalName
      });
      
      // Revogar token inválido
      try {
        await this.revokeToken();
      } catch (e) {
        console.warn('[AuthTokenService] Não foi possível revogar token:', e);
      }
      
      throw error;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // REVOGAR TOKEN
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Revogar token (logout)
   */
  async revokeToken() {
    try {
      console.log('[AuthTokenService] 🚪 Revogando token...');
      
      // Marcar como inválido em SharePoint
      await this.graphClient.updateListItem(
        'Nexos_TokenVault',
        {
          UserID: this.userContext.userPrincipalName,
          IsValid: false,
          RevokedAt: new Date().toISOString()
        },
        { matchField: 'UserID', matchValue: this.userContext.userPrincipalName }
      );
      
      // Limpar cache
      this.clearCache();
      
      console.log('[AuthTokenService] ✅ Token revogado');
      
      // Log de auditoria
      await this._logAuditEvent('TOKEN_REVOKED', {
        user: this.userContext.userPrincipalName
      });
      
    } catch (error) {
      console.error('[AuthTokenService] ❌ Erro ao revogar:', error.message);
      
      // Mesmo se falhar em SharePoint, limpar cache localmente
      this.clearCache();
      
      throw error;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CACHE EM MEMÓRIA
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Verificar se cache de token é válido
   * @private
   */
  isTokenCacheValid() {
    if (!this.tokenCache || !this.tokenCacheExpiresAt) {
      return false;
    }
    
    if (Date.now() >= this.tokenCacheExpiresAt) {
      console.log('[AuthTokenService] Cache expirou');
      this.tokenCache = null;
      return false;
    }
    
    return true;
  }
  
  /**
   * Atualizar cache em memória
   * @private
   */
  updateTokenCache(token, cacheFor = 5 * 60 * 1000) {
    this.tokenCache = token;
    this.tokenCacheExpiresAt = Date.now() + cacheFor;
    console.log('[AuthTokenService] Cache atualizado por', Math.round(cacheFor / 1000), 'segundos');
  }
  
  /**
   * Limpar cache
   */
  clearCache() {
    this.tokenCache = null;
    this.tokenCacheExpiresAt = null;
    console.log('[AuthTokenService] Cache limpo');
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // UTILITÁRIOS
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Obter ID do dispositivo (para rastreamento)
   * @private
   */
  async _getDeviceID() {
    try {
      const manifest = chrome.runtime.getManifest();
      const extensionId = chrome.runtime.id;
      const userAgent = navigator.userAgent;
      
      // Criar hash simples do deviceID
      const combined = `${extensionId}-${userAgent}`;
      const hash = await this._simpleHash(combined);
      
      return hash;
    } catch (error) {
      return 'unknown-device';
    }
  }
  
  /**
   * Hash simples para deviceID
   * @private
   */
  async _simpleHash(str) {
    const encoded = new TextEncoder().encode(str);
    const hashBuffer = await crypto.subtle.digest('SHA-256', encoded);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 16);
  }
  
  /**
   * Registrar evento em auditoria
   * @private
   */
  async _logAuditEvent(action, details = {}) {
    try {
      await this.graphClient.createItem('Nexos_AuditLog', {
        Acao: action,
        Usuario: this.userContext.userPrincipalName,
        Detalhes: JSON.stringify(details),
        Timestamp: new Date().toISOString(),
        IPAddress: 'unknown', // Seria obtido do servidor
        UserAgent: navigator.userAgent
      });
    } catch (error) {
      // Não falhar se auditoria falhar
      console.warn('[AuthTokenService] Erro ao registrar auditoria:', error.message);
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // VERIFICAÇÃO E MONITORAMENTO
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Verificar se usuário está autenticado
   */
  async isAuthenticated() {
    try {
      const token = await this.getToken();
      return !!token && !!token.accessToken;
    } catch (error) {
      return false;
    }
  }
  
  /**
   * Obter informações do token atual
   */
  async getTokenInfo() {
    try {
      const token = await this.getToken();
      
      return {
        user: this.userContext.userPrincipalName,
        expiresAt: new Date(token.expiresAt).toISOString(),
        expiresIn: token.expiresIn,
        isExpiringSoon: token.expiresIn < 5 * 60, // Menos de 5 minutos
        tokenType: token.tokenType,
        cached: this.isTokenCacheValid()
      };
    } catch (error) {
      return {
        user: this.userContext.userPrincipalName,
        authenticated: false,
        error: error.message
      };
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORTAR PARA WINDOW (MAIN WORLD)
// ═══════════════════════════════════════════════════════════════════════════
if (typeof window !== 'undefined') {
  window.AuthTokenService = AuthTokenService;
  console.log('[AuthTokenService] ✅ Classe exportada para window.AuthTokenService');
}
