/**
 * ═══════════════════════════════════════════════════════════════════════════
 * TOKEN SYNC & DIAGNOSTIC - Sincronização e Diagnóstico de Tokens
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Resolve problema de token não encontrado quando usuário já está logado
 * Sincroniza tokens entre MSAL, TokenManager e chrome.storage
 * 
 * @version 1.0.0
 * @date 2026-01-08
 */

(function() {
  'use strict';

  class TokenSyncDiagnostic {
    constructor() {
      this.checkedSources = [];
      this.foundTokens = [];
    }

    /**
     * Busca token em TODAS as fontes possíveis
     */
    async findAllTokens() {
      console.log('[TokenSync] 🔍 Buscando tokens em todas as fontes...');
      
      this.checkedSources = [];
      this.foundTokens = [];

      // 1. Chrome Storage Local
      await this.checkChromeStorage();

      // 2. MSAL Cache
      await this.checkMSALCache();

      // 3. LocalStorage
      await this.checkLocalStorage();

      // 4. SessionStorage
      await this.checkSessionStorage();

      // 5. Window globals
      await this.checkWindowGlobals();

      console.log('[TokenSync] 📊 Fontes verificadas:', this.checkedSources.length);
      console.log('[TokenSync] 🎯 Tokens encontrados:', this.foundTokens.length);

      return {
        sources: this.checkedSources,
        tokens: this.foundTokens
      };
    }

    /**
     * Verifica chrome.storage.local
     */
    async checkChromeStorage() {
      try {
        const keys = [
          'msal-token',
          'auth-token',
          'access-token',
          'graphToken',
          'microsoft-token',
          'nexos-token',
          'msal.token.keys',
          'msal.account.keys'
        ];

        const result = await new Promise((resolve) => {
          chrome.storage.local.get(keys, resolve);
        });

        for (const [key, value] of Object.entries(result)) {
          if (value) {
            this.checkedSources.push({
              source: 'chrome.storage.local',
              key: key,
              hasValue: true,
              preview: this.previewValue(value)
            });
            
            this.foundTokens.push({
              source: 'chrome.storage.local',
              key: key,
              value: value
            });
          }
        }

        // Buscar TODAS as chaves no chrome.storage
        const allKeys = await new Promise((resolve) => {
          chrome.storage.local.get(null, resolve);
        });

        for (const [key, value] of Object.entries(allKeys)) {
          if (key.toLowerCase().includes('token') || 
              key.toLowerCase().includes('msal') ||
              key.toLowerCase().includes('auth')) {
            
            if (!this.foundTokens.some(t => t.key === key)) {
              this.checkedSources.push({
                source: 'chrome.storage.local (scan)',
                key: key,
                hasValue: true,
                preview: this.previewValue(value)
              });
              
              this.foundTokens.push({
                source: 'chrome.storage.local (scan)',
                key: key,
                value: value
              });
            }
          }
        }

      } catch (error) {
        console.warn('[TokenSync] Erro ao verificar chrome.storage:', error);
      }
    }

    /**
     * Verifica MSAL Cache
     */
    async checkMSALCache() {
      try {
        // Verificar se MSAL está disponível
        if (typeof window.msalAuth !== 'undefined' && window.msalAuth) {
          this.checkedSources.push({
            source: 'window.msalAuth',
            key: 'msalAuth',
            hasValue: true,
            preview: 'MSAL Instance disponível'
          });

          // Tentar obter account
          const accounts = window.msalAuth.getAllAccounts?.();
          if (accounts && accounts.length > 0) {
            this.foundTokens.push({
              source: 'MSAL Accounts',
              key: 'accounts',
              value: accounts
            });
          }

          // Tentar obter token silenciosamente
          try {
            const tokenRequest = {
              scopes: ['https://graph.microsoft.com/.default'],
              account: accounts?.[0]
            };

            const response = await window.msalAuth.acquireTokenSilent(tokenRequest);
            
            if (response && response.accessToken) {
              this.foundTokens.push({
                source: 'MSAL Silent Token',
                key: 'accessToken',
                value: response.accessToken,
                expires: response.expiresOn
              });
            }
          } catch (e) {
            console.warn('[TokenSync] MSAL acquireTokenSilent falhou:', e.message);
          }
        }

      } catch (error) {
        console.warn('[TokenSync] Erro ao verificar MSAL:', error);
      }
    }

    /**
     * Verifica localStorage
     */
    async checkLocalStorage() {
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && (key.toLowerCase().includes('token') || 
                      key.toLowerCase().includes('msal') ||
                      key.toLowerCase().includes('auth'))) {
            
            const value = localStorage.getItem(key);
            this.checkedSources.push({
              source: 'localStorage',
              key: key,
              hasValue: !!value,
              preview: this.previewValue(value)
            });

            if (value) {
              this.foundTokens.push({
                source: 'localStorage',
                key: key,
                value: value
              });
            }
          }
        }
      } catch (error) {
        console.warn('[TokenSync] Erro ao verificar localStorage:', error);
      }
    }

    /**
     * Verifica sessionStorage
     */
    async checkSessionStorage() {
      try {
        for (let i = 0; i < sessionStorage.length; i++) {
          const key = sessionStorage.key(i);
          if (key && (key.toLowerCase().includes('token') || 
                      key.toLowerCase().includes('msal') ||
                      key.toLowerCase().includes('auth'))) {
            
            const value = sessionStorage.getItem(key);
            this.checkedSources.push({
              source: 'sessionStorage',
              key: key,
              hasValue: !!value,
              preview: this.previewValue(value)
            });

            if (value) {
              this.foundTokens.push({
                source: 'sessionStorage',
                key: key,
                value: value
              });
            }
          }
        }
      } catch (error) {
        console.warn('[TokenSync] Erro ao verificar sessionStorage:', error);
      }
    }

    /**
     * Verifica variáveis globais window
     */
    async checkWindowGlobals() {
      try {
        const globals = [
          'msalAuth',
          'graphClient',
          'currentUser',
          'authHelper',
          'tokenManager'
        ];

        for (const name of globals) {
          if (typeof window[name] !== 'undefined') {
            this.checkedSources.push({
              source: 'window global',
              key: name,
              hasValue: true,
              preview: typeof window[name]
            });
          }
        }
      } catch (error) {
        console.warn('[TokenSync] Erro ao verificar window globals:', error);
      }
    }

    /**
     * Preview de valor (trunca se muito grande)
     */
    previewValue(value) {
      if (!value) return 'null';
      
      const str = typeof value === 'string' ? value : JSON.stringify(value);
      return str.length > 50 ? str.substring(0, 50) + '...' : str;
    }

    /**
     * Valida se token é um access token válido
     */
    isValidAccessToken(token) {
      if (!token || typeof token !== 'string') return false;
      
      // Token JWT deve começar com "eyJ"
      if (!token.startsWith('eyJ')) return false;
      
      // Token deve ter 3 partes separadas por ponto
      const parts = token.split('.');
      if (parts.length !== 3) return false;
      
      try {
        // Tentar decodificar payload
        const payload = JSON.parse(atob(parts[1]));
        
        // Verificar se tem claims essenciais
        if (!payload.exp || !payload.aud) return false;
        
        // Verificar se não está expirado
        const now = Math.floor(Date.now() / 1000);
        if (payload.exp < now) {
          console.warn('[TokenSync] ⚠️ Token expirado');
          return false;
        }
        
        return true;
      } catch (e) {
        return false;
      }
    }

    /**
     * Inicializa MSAL se não estiver disponível
     */
    async ensureMSALAvailable() {
      // Verificar se já está disponível
      if (window.msalAuth) {
        return true;
      }

      console.log('[TokenSync] 🔄 MSAL não disponível, tentando inicializar...');

      // Aguardar até 10 segundos para MSAL carregar
      for (let i = 0; i < 20; i++) {
        await new Promise(resolve => setTimeout(resolve, 500));
        
        if (window.msalAuth) {
          console.log('[TokenSync] ✅ MSAL disponível após aguardar');
          return true;
        }
      }

      // Se ainda não disponível, tentar inicializar manualmente
      if (window.MsalAuth && !window.msalAuth) {
        try {
          console.log('[TokenSync] 🔧 Inicializando MSAL manualmente...');
          window.msalAuth = new window.MsalAuth();
          await window.msalAuth.init();
          console.log('[TokenSync] ✅ MSAL inicializado manualmente');
          return true;
        } catch (error) {
          console.error('[TokenSync] ❌ Erro ao inicializar MSAL:', error);
        }
      }

      console.error('[TokenSync] ❌ MSAL não disponível após todas tentativas');
      return false;
    }

    /**
     * Tenta obter token válido do MSAL
     */
    async getMSALToken() {
      try {
        // Garantir que MSAL está disponível
        const available = await this.ensureMSALAvailable();
        if (!available) {
          console.warn('[TokenSync] ⚠️ MSAL não disponível');
          return null;
        }

        // Obter accounts
        const accounts = window.msalAuth.getAllAccounts?.();
        if (!accounts || accounts.length === 0) {
          console.warn('[TokenSync] ⚠️ Nenhuma conta MSAL encontrada');
          console.log('[TokenSync] � Para fazer login, use: await window.tokenSyncDiagnostic.triggerLogin()');
          return null;
        }

        console.log('[TokenSync] 📧 Conta MSAL:', accounts[0].username);

        // Tentar obter token silenciosamente
        const tokenRequest = {
          scopes: ['https://graph.microsoft.com/.default'],
          account: accounts[0]
        };

        const response = await window.msalAuth.acquireTokenSilent(tokenRequest);
        
        if (response && response.accessToken) {
          console.log('[TokenSync] ✅ Token MSAL obtido silenciosamente');
          return response.accessToken;
        }

        return null;
      } catch (error) {
        console.warn('[TokenSync] ⚠️ Erro ao obter token MSAL:', error.message);
        
        // Se erro for de interação necessária, solicitar popup
        if (error.errorCode === 'interaction_required' || 
            error.errorCode === 'consent_required' ||
            error.errorCode === 'login_required') {
          
          console.log('[TokenSync] 🔐 Interação necessária, solicitando popup...');
          
          try {
            const popupResponse = await window.msalAuth.acquireTokenPopup({
              scopes: ['https://graph.microsoft.com/.default']
            });
            
            if (popupResponse && popupResponse.accessToken) {
              console.log('[TokenSync] ✅ Token obtido via popup');
              return popupResponse.accessToken;
            }
          } catch (popupError) {
            console.error('[TokenSync] ❌ Erro no popup:', popupError);
          }
        }
        
        return null;
      }
    }

    /**
     * Executa login MSAL via popup
     */
    async performMSALLogin() {
      try {
        console.log('[TokenSync] 🔐 Iniciando login MSAL popup...');

        const loginRequest = {
          scopes: ['https://graph.microsoft.com/.default'],
          prompt: 'select_account'
        };

        const loginResponse = await window.msalAuth.loginPopup(loginRequest);
        
        if (loginResponse && loginResponse.accessToken) {
          console.log('[TokenSync] ✅ Login bem-sucedido:', loginResponse.account.username);
          return loginResponse.accessToken;
        }

        return null;
      } catch (error) {
        console.error('[TokenSync] ❌ Erro no login MSAL:', error);
        return null;
      }
    }

    /**
     * Sincroniza token encontrado para TokenManager
     */
    async syncTokenToManager(token) {
      console.log('[TokenSync] 🔄 Sincronizando token para TokenManager...');

      try {
        // Validar se é um token válido
        if (!this.isValidAccessToken(token)) {
          console.warn('[TokenSync] ⚠️ Token inválido ou debug, tentando obter token MSAL...');
          
          // Tentar obter token válido do MSAL
          const msalToken = await this.getMSALToken();
          
          if (msalToken && this.isValidAccessToken(msalToken)) {
            token = msalToken;
            console.log('[TokenSync] ✅ Token MSAL válido obtido');
          } else {
            console.error('[TokenSync] ❌ Não foi possível obter token válido');
            return false;
          }
        }

        // Salvar em chrome.storage com chave correta
        await new Promise((resolve) => {
          chrome.storage.local.set({
            'auth-token': token,
            'msal-token': token,
            'access-token': token
          }, resolve);
        });

        console.log('[TokenSync] ✅ Token salvo em chrome.storage');

        // Notificar TokenManager
        if (window.tokenManager) {
          // Forçar reload do token
          try {
            await window.tokenManager.getAccessToken();
          } catch (e) {
            console.warn('[TokenSync] TokenManager ainda não consegue usar token:', e.message);
          }
        }

        return true;
      } catch (error) {
        console.error('[TokenSync] ❌ Erro ao sincronizar:', error);
        return false;
      }
    }

    /**
     * Exibe relatório completo no console
     */
    async showDiagnosticReport() {
      const result = await this.findAllTokens();

      console.log('\n%c═══════════════════════════════════════════════', 'color: #667eea; font-weight: bold');
      console.log('%c🔍 RELATÓRIO DE DIAGNÓSTICO DE TOKENS', 'color: #667eea; font-weight: bold; font-size: 14px');
      console.log('%c═══════════════════════════════════════════════', 'color: #667eea; font-weight: bold');

      console.log('\n%c📊 FONTES VERIFICADAS:', 'color: #3b82f6; font-weight: bold');
      console.table(result.sources);

      console.log('\n%c🎯 TOKENS ENCONTRADOS:', 'color: #10b981; font-weight: bold');
      console.table(result.tokens.map(t => ({
        Fonte: t.source,
        Chave: t.key,
        'Tem Valor': !!t.value,
        Preview: this.previewValue(t.value)
      })));

      // Recomendações
      console.log('\n%c💡 RECOMENDAÇÕES:', 'color: #f59e0b; font-weight: bold');
      
      if (result.tokens.length === 0) {
        console.log('%c❌ Nenhum token encontrado - usuário precisa fazer login', 'color: #e53e3e');
        console.log('%cExecute: await window.tokenSyncDiagnostic.triggerLogin()', 'color: #6b7280');
      } else {
        // Verificar se tem token MSAL válido
        const msalToken = result.tokens.find(t => 
          t.source.includes('MSAL') && 
          this.isValidAccessToken(t.value)
        );
        
        if (msalToken) {
          console.log('%c✅ Token MSAL válido encontrado - sincronizando...', 'color: #10b981');
          const synced = await this.syncTokenToManager(msalToken.value);
          
          if (synced) {
            console.log('%c✅ Token sincronizado com sucesso! Teste a extração agora.', 'color: #10b981');
          } else {
            console.log('%c⚠️ Falha ao sincronizar. Execute: await window.tokenSyncDiagnostic.triggerLogin()', 'color: #f59e0b');
          }
        } else {
          // Nenhum token válido encontrado, tentar obter do MSAL
          console.log('%c⚠️ Tokens encontrados não são access tokens válidos', 'color: #f59e0b');
          console.log('%c🔄 Tentando obter token válido do MSAL...', 'color: #3b82f6');
          
          const msalToken = await this.getMSALToken();
          
          if (msalToken && this.isValidAccessToken(msalToken)) {
            console.log('%c✅ Token MSAL obtido e sincronizado!', 'color: #10b981');
            await this.syncTokenToManager(msalToken);
          } else {
            console.log('%c❌ Não foi possível obter token válido', 'color: #e53e3e');
            console.log('%c🔐 Execute: await window.tokenSyncDiagnostic.triggerLogin()', 'color: #6b7280');
          }
        }
      }

      console.log('\n%c═══════════════════════════════════════════════\n', 'color: #667eea; font-weight: bold');

      return result;
    }

    /**
     * Trigger manual de login
     */
    async triggerLogin() {
      console.log('[TokenSync] 🔐 Acionando login manual...');

      if (window.autoLoginHandler) {
        const success = await window.autoLoginHandler.showLoginModal();
        
        if (success) {
          console.log('[TokenSync] ✅ Login concluído, executando novo diagnóstico...');
          await this.showDiagnosticReport();
        }
      } else if (window.msalAuth) {
        try {
          const result = await window.msalAuth.loginPopup();
          console.log('[TokenSync] ✅ Login MSAL concluído:', result);
          await this.showDiagnosticReport();
        } catch (error) {
          console.error('[TokenSync] ❌ Erro no login MSAL:', error);
        }
      } else {
        console.error('[TokenSync] ❌ Nenhum sistema de autenticação disponível');
      }
    }

    /**
     * Auto-sync: Executa a cada X segundos
     */
    startAutoSync(intervalSeconds = 30) {
      console.log(`[TokenSync] ⏰ Auto-sync iniciado (${intervalSeconds}s)`);

      setInterval(async () => {
        const result = await this.findAllTokens();
        
        if (result.tokens.length > 0) {
          const token = result.tokens[0];
          await this.syncTokenToManager(token.value);
        }
      }, intervalSeconds * 1000);
    }
  }

  // Criar instância global
  window.tokenSyncDiagnostic = new TokenSyncDiagnostic();

  // ❌ REMOVIDO: Auto-execução do diagnóstico (causava popup de login automático)
  // setTimeout(async () => {
  //   console.log('[TokenSync] 🚀 Executando diagnóstico inicial...');
  //   await window.tokenSyncDiagnostic.showDiagnosticReport();
  //   
  //   // Iniciar auto-sync (a cada 30s)
  //   window.tokenSyncDiagnostic.startAutoSync(30);
  // }, 3000);

  console.log('[TokenSync] 📦 Módulo carregado (diagnóstico manual apenas)');

  // Exportar comandos úteis para console
  console.log('\n%c💡 Comandos úteis:', 'color: #667eea; font-weight: bold');
  console.log('%c  window.tokenSyncDiagnostic.showDiagnosticReport()', 'color: #6b7280');
  console.log('%c  window.tokenSyncDiagnostic.triggerLogin()', 'color: #6b7280');
  console.log('%c  window.tokenSyncDiagnostic.findAllTokens()', 'color: #6b7280');

})();
