﻿/**
 * 🔍 TOKEN STORAGE SCANNER
 * 
 * Escaneia todos os storages (localStorage, sessionStorage, cookies)
 * em busca de tokens JWT válidos deixados pelo picking-admin.
 * 
 * OBJETIVO: Capturar tokens onde quer que estejam armazenados.
 */

(function() {
  'use strict';

  // console.log('[TokenStorageScanner] 📦 Carregando...');

  class TokenStorageScanner {
    constructor() {
      this.storageKey = 'nexos-scanned-token';
      this.lastToken = null;
      this.lastScanTime = null;
      this.scanInterval = 5000; // Escanear a cada 5 segundos
      this.tokenExpiry = 60 * 60 * 1000; // 1 hora
    }

    /**
     * Inicializa o scanner
     */
    init() {
      // console.log('[TokenStorageScanner] 🚀 Inicializando...');
      
      // Escanear imediatamente
      this.scanAllStorages();
      
      // Escanear periodicamente
      setInterval(() => {
        this.scanAllStorages();
      }, this.scanInterval);
      
      // console.log('[TokenStorageScanner] ✅ Scanner ativo (scan a cada 5s)');
    }

    /**
     * Escaneia todos os storages em busca de tokens JWT
     */
    async scanAllStorages() {
      try {
        const tokens = [];

        // 0. Verificar primeiro o token capturado pelo inject-picking-admin-token.js (MAIN world).
        //    Essa chave tem prioridade máxima pois é o token real que a aplicação usa na API GPA.
        const directPickingToken = localStorage.getItem('nexos-picking-admin-token');
        if (directPickingToken && this.isValidJWT(directPickingToken)) {
          tokens.push({ source: 'localStorage', key: 'nexos-picking-admin-token', value: directPickingToken });
        }

        // 1. Escanear localStorage
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          const value = localStorage.getItem(key);
          if (value && this.isValidJWT(value)) {
            tokens.push({ source: 'localStorage', key, value });
          } else if (value && value.length > 50) {
            // Tentar parsear JSON que pode conter token
            try {
              const parsed = JSON.parse(value);
              const foundToken = this.findTokenInObject(parsed);
              if (foundToken) {
                tokens.push({ source: 'localStorage', key, value: foundToken });
              }
            } catch (e) {
              // Não é JSON, ignorar
            }
          }
        }

        // 2. Escanear sessionStorage
        for (let i = 0; i < sessionStorage.length; i++) {
          const key = sessionStorage.key(i);
          const value = sessionStorage.getItem(key);
          if (value && this.isValidJWT(value)) {
            tokens.push({ source: 'sessionStorage', key, value });
          } else if (value && value.length > 50) {
            try {
              const parsed = JSON.parse(value);
              const foundToken = this.findTokenInObject(parsed);
              if (foundToken) {
                tokens.push({ source: 'sessionStorage', key, value: foundToken });
              }
            } catch (e) {}
          }
        }

        // 3. Escanear cookies
        const cookies = document.cookie.split(';');
        for (const cookie of cookies) {
          const [key, value] = cookie.trim().split('=');
          if (value && this.isValidJWT(value)) {
            tokens.push({ source: 'cookie', key, value });
          }
        }

        // 4. Escanear window globals comuns
        const commonGlobals = [
          'authToken', 'accessToken', 'token', 'jwt', 'bearerToken',
          'auth_token', 'access_token', 'bearer_token', 'user_token',
          'session_token', 'api_token', 'authorization'
        ];
        
        for (const global of commonGlobals) {
          if (window[global] && this.isValidJWT(window[global])) {
            tokens.push({ source: 'window', key: global, value: window[global] });
          }
        }

        // Se encontrou tokens, usar o primeiro válido
        if (tokens.length > 0) {
          const bestToken = tokens[0];

          // Só logar se for token novo
          if (bestToken.value !== this.lastToken) {
            this.lastToken = bestToken.value;
            this.lastScanTime = Date.now();

            // Salvar token genérico (nexos-scanned-token)
            await this.saveToken(bestToken.value);

            // Sincronizar com sistemas de auth
            await this.syncWithAuth(bestToken.value);
          }

          // Separar tokens pela audience: tokens nao-Graph sao candidatos para a API GPA picking.
          // O Graph token tem aud = "https://graph.microsoft.com" e resulta em 403 INVALID_TOKEN
          // na API picking-admin (api-gtw-prod.backoffice.gpa.digital).
          const GRAPH_AUDIENCES = [
            'https://graph.microsoft.com',
            '00000003-0000-0000-c000-000000000000',
          ];
          const _decodeAud = (jwt) => {
            try { return JSON.parse(atob(jwt.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).aud || ''; }
            catch { return ''; }
          };
          const gpaToken = tokens.find(t => {
            const aud = _decodeAud(t.value);
            return aud && !GRAPH_AUDIENCES.some(g => aud === g || String(aud).startsWith(g));
          });
          if (gpaToken) {
            chrome.storage.local.get(['nexos-gpa-api-token'], (existing) => {
              if (gpaToken.value !== existing['nexos-gpa-api-token']) {
                chrome.storage.local.set({ 'nexos-gpa-api-token': gpaToken.value });
                console.log('[TokenStorageScanner] nexos-gpa-api-token salvo — aud:', _decodeAud(gpaToken.value));
              }
            });
          }
        }

      } catch (error) {
        console.error('[TokenStorageScanner] ❌ Erro ao escanear:', error);
      }
    }

    /**
     * Procura recursivamente por tokens JWT em um objeto
     */
    findTokenInObject(obj, depth = 0, maxDepth = 3) {
      if (depth > maxDepth) return null;

      if (typeof obj !== 'object' || obj === null) {
        return null;
      }

      for (const key in obj) {
        const value = obj[key];

        // Verificar se o valor é um JWT
        if (typeof value === 'string' && this.isValidJWT(value)) {
          return value;
        }

        // Recursão para objetos aninhados
        if (typeof value === 'object' && value !== null) {
          const found = this.findTokenInObject(value, depth + 1, maxDepth);
          if (found) return found;
        }
      }

      return null;
    }

    /**
     * Valida se o token é um JWT válido
     */
    isValidJWT(token) {
      if (!token || typeof token !== 'string') return false;

      // JWT tem 3 partes separadas por pontos
      const parts = token.split('.');
      if (parts.length !== 3) return false;

      // Deve começar com eyJ (Base64 de {"alg":...)
      if (!token.startsWith('eyJ')) return false;

      // Limitar tamanho mínimo e máximo
      if (token.length < 100 || token.length > 5000) return false;

      try {
        // Tentar decodificar o payload
        const payload = JSON.parse(atob(parts[1]));

        // Verificar se tem claims básicas
        if (!payload.exp || !payload.iat) return false;

        // Verificar se não está expirado
        const now = Math.floor(Date.now() / 1000);
        if (payload.exp < now) {
          return false;
        }

        return true;
      } catch (e) {
        return false;
      }
    }

    /**
     * Salva token no storage
     */
    async saveToken(token) {
      try {
        // Salvar em chrome.storage.local
        await chrome.storage.local.set({
          [this.storageKey]: token,
          'nexos-token-timestamp': Date.now(),
          'nexos-token-source': 'storage-scanner'
        });

        // Salvar em localStorage também
        localStorage.setItem(this.storageKey, token);
        localStorage.setItem('nexos-token-timestamp', Date.now().toString());

        // console.log('[TokenStorageScanner] 💾 Token salvo no storage');
      } catch (error) {
        console.error('[TokenStorageScanner] ❌ Erro ao salvar token:', error);
      }
    }

    /**
     * Sincroniza token com sistemas de auth
     */
    async syncWithAuth(token) {
      try {
        // Sincronizar com UnifiedAuthManager
        if (window.unifiedAuth) {
          window.unifiedAuth.tokenCache = token;
          window.unifiedAuth.tokenExpiryTime = Date.now() + this.tokenExpiry;
          // console.log('[TokenStorageScanner] ✅ Token sincronizado com UnifiedAuth');
        }

        // Sincronizar com MSAL
        if (window.msalAuth) {
          window.msalAuth.accessToken = token;
          // console.log('[TokenStorageScanner] ✅ Token sincronizado com MSAL');
        }

        // Sincronizar com TokenInterceptor
        if (window.tokenInterceptor) {
          window.tokenInterceptor.lastToken = token;
          window.tokenInterceptor.lastTokenTime = Date.now();
          // console.log('[TokenStorageScanner] ✅ Token sincronizado com TokenInterceptor');
        }

      } catch (error) {
        console.error('[TokenStorageScanner] ❌ Erro ao sincronizar:', error);
      }
    }

    /**
     * Obtém o último token escaneado (se ainda válido)
     */
    async getToken() {
      // Verificar cache em memória
      if (this.lastToken && this.lastScanTime) {
        const age = Date.now() - this.lastScanTime;
        if (age < this.tokenExpiry && this.isValidJWT(this.lastToken)) {
          // console.log('[TokenStorageScanner] ✅ Retornando token do cache (idade: ' + Math.floor(age / 1000) + 's)');
          return this.lastToken;
        }
      }

      // Verificar chrome.storage.local
      try {
        const result = await chrome.storage.local.get([this.storageKey, 'nexos-token-timestamp']);
        const token = result[this.storageKey];
        const timestamp = result['nexos-token-timestamp'];

        if (token && this.isValidJWT(token)) {
          this.lastToken = token;
          this.lastScanTime = timestamp || Date.now();
          return token;
        }
      } catch (error) {
        // console.error('[TokenStorageScanner] ❌ Erro ao obter token:', error);
      }

      // Verificar localStorage
      const localToken = localStorage.getItem(this.storageKey);
      if (localToken && this.isValidJWT(localToken)) {
        return localToken;
      }

      // Fazer scan imediato
      await this.scanAllStorages();
      return this.lastToken;
    }

    /**
     * Limpa o token armazenado
     */
    async clearToken() {
      this.lastToken = null;
      this.lastScanTime = null;

      try {
        await chrome.storage.local.remove([this.storageKey, 'nexos-token-timestamp']);
        localStorage.removeItem(this.storageKey);
        localStorage.removeItem('nexos-token-timestamp');
        // console.log('[TokenStorageScanner] 🗑️ Token limpo');
      } catch (error) {
        console.error('[TokenStorageScanner] ❌ Erro ao limpar token:', error);
      }
    }
  }

  // Inicializar scanner
  const tokenStorageScanner = new TokenStorageScanner();
  tokenStorageScanner.init();
  window.tokenStorageScanner = tokenStorageScanner;

})();
