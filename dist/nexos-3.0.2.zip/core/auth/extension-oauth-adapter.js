/**
 * ExtensionOAuthAdapter
 * Adapter mínimo para usar o OAuthClient (PKCE) dentro de uma extensão Chrome
 * e expor uma interface compatível com o esperado pelo restante do código (MsalAuth)
 *
 * Motivo: em contextos de extensão o uso de window.open / popup direto pode
 * sofrer com COOP/COEP. A API chrome.identity.launchWebAuthFlow é a opção
 * mais confiável dentro de extensões – este adapter delega para OAuthClient.
 */
(function () {
  'use strict';

  class ExtensionOAuthAdapter {
    constructor(config) {
      this.config = config || (typeof AZURE_AD_CONFIG !== 'undefined' ? AZURE_AD_CONFIG : null);
      if (!this.config) throw new Error('ExtensionOAuthAdapter: Azure AD config not provided');

      if (typeof OAuthClient === 'undefined') {
        console.warn('[ExtensionOAuthAdapter] OAuthClient não encontrado globalmente. Certifique-se de que core/auth/oauth-client.js foi carregado.');
      }

      // Instanciar OAuthClient (ele mesmo resolve chrome.runtime.id para redirectUri)
      this.oauth = new window.OAuthClient(this.config);
      this.currentAccount = null;
      this.accessToken = null;
      this.initialized = false;
    }

    async init() {
      // Inicialização é mínima pois OAuthClient não precisa de await para se preparar
      this.initialized = true;
      console.log('[ExtensionOAuthAdapter] ✅ Inicializado');
    }

    // Compatível com MsalAuth.loginPopup()
    async loginPopup() {
      if (!this.initialized) throw new Error('ExtensionOAuthAdapter não inicializado');

      try {
        console.log('[ExtensionOAuthAdapter] 🔐 Iniciando login via chrome.identity / OAuthClient');

        // OAuthClient.authorize usa chrome.identity.launchWebAuthFlow quando disponível.
        const { tokens, user } = await this.oauth.login();

        this.accessToken = tokens.access_token;
        this.currentAccount = {
          username: user.userPrincipalName || user.mail,
          name: user.displayName,
          tenantId: null,
          localAccountId: user.id,
          idTokenClaims: {}
        };

        return {
          success: true,
          account: this.currentAccount,
          token: this.accessToken
        };
      } catch (error) {
        console.error('[ExtensionOAuthAdapter] ❌ Erro no login:', error);
        return { success: false, error };
      }
    }

    // Usado pelo GraphClient
    async getAccessToken() {
      if (this.accessToken) return this.accessToken;
      throw new Error('Nenhum access token disponível. Faça login primeiro.');
    }

    isLoggedIn() {
      return !!this.currentAccount;
    }

    getCurrentAccount() {
      return this.currentAccount;
    }

    async logout() {
      try {
        // Limpar estado local
        this.currentAccount = null;
        this.accessToken = null;
        // OAuthClient.logout apenas dispara evento local; não tenta logout do provider aqui
        if (typeof this.oauth.logout === 'function') {
          await this.oauth.logout();
        }
        console.log('[ExtensionOAuthAdapter] ✅ Logout local concluído');
      } catch (error) {
        console.warn('[ExtensionOAuthAdapter] ⚠️ Erro no logout:', error);
      }
    }
  }

  if (typeof window !== 'undefined') {
    window.ExtensionOAuthAdapter = ExtensionOAuthAdapter;
    console.log('[ExtensionOAuthAdapter] ✅ Exportado para window.ExtensionOAuthAdapter');
  }

})();
