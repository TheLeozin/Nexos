// ===================================================================
// NEXOS - Microsoft Authentication Library (MSAL) Client
// OAuth 2.0 Authentication com Azure AD
// ===================================================================

/**
 * Cliente de autenticação usando MSAL.js 2.x
 * 
 * IMPORTANTE: Esta implementação usa MSAL Browser (vanilla JS)
 * Documentação: https://github.com/AzureAD/microsoft-authentication-library-for-js
 * 
 * FEATURES:
 * - Login com popup Microsoft
 * - Token refresh automático
 * - Logout completo
 * - Cache persistente
 * - Tratamento de erros
 */

class MsalAuth {
  constructor() {
    this.msalInstance = null;
    this.currentAccount = null;
    this.accessToken = null;
    this.initialized = false;
    
    console.log('[MsalAuth] 🔐 Inicializando Microsoft Authentication...');
  }

  /**
   * Inicializa o MSAL
   * DEVE ser chamado antes de qualquer operação
   */
  async init() {
    if (this.initialized) {
      console.log('[MsalAuth] ⚠️ Já inicializado');
      return;
    }

    try {
      // Validar configuração
      const validation = window.validateAzureAdConfig();
      if (!validation.valid) {
        throw new Error('Azure AD Config inválida: ' + validation.errors.join(', '));
      }

      // Verificar se MSAL.js foi carregado
      if (typeof msal === 'undefined') {
        throw new Error('MSAL.js não foi carregado. Adicione <script src="https://alcdn.msauth.net/browser/2.38.1/js/msal-browser.min.js"></script> no HTML');
      }

      // Verificar se PublicClientApplication existe
      if (!msal.PublicClientApplication) {
        throw new Error('MSAL.PublicClientApplication não encontrado. Verifique se a biblioteca MSAL foi carregada corretamente.');
      }

      console.log('[MsalAuth] 📦 MSAL.js carregado, versão:', msal.version || 'desconhecida');

      // Configuração do MSAL
      const msalConfig = {
        auth: {
          clientId: window.AZURE_AD_CONFIG.clientId,
          authority: window.AZURE_AD_CONFIG.authority,
          redirectUri: window.AZURE_AD_CONFIG.redirectUri,
          postLogoutRedirectUri: window.AZURE_AD_CONFIG.redirectUri
        },
        cache: window.AZURE_AD_CONFIG.cache,
        system: {
          loggerOptions: {
            loggerCallback: (level, message, containsPii) => {
              // Logs MSAL desabilitados para performance
            },
            // ✅ Força Warning (Error = 0, Warning = 1) para reduzir logs
            logLevel: msal.LogLevel.Warning,
            // ✅ FIX: Desabilitar verificação de window.closed para evitar COOP errors
            windowHashTimeout: 60000,
            loadFrameTimeout: 60000,
            iframeHashTimeout: 60000,
            navigateFrameWait: 0
          },
          // ✅ FIX: Permitir popups sem COOP strict
          allowRedirectInIframe: false,
          pollIntervalMilliseconds: 50
        }
      };

      // Criar instância MSAL
      this.msalInstance = new msal.PublicClientApplication(msalConfig);
      await this.msalInstance.initialize();

      // Verificar se já existe conta no cache
      const accounts = this.msalInstance.getAllAccounts();
      if (accounts.length > 0) {
        this.currentAccount = accounts[0];
        
        // ✅ CRÍTICO: Definir como conta ativa para MSAL
        this.msalInstance.setActiveAccount(this.currentAccount);
        
        console.log('[MsalAuth] ✅ Conta encontrada no cache:', this.currentAccount.username);
        console.log('[MsalAuth] ✅ Conta ativa definida');
      } else {
        console.log('[MsalAuth] ⚠️ Nenhuma conta no cache (login necessário)');
      }

      this.initialized = true;
      console.log('[MsalAuth] ✅ Inicializado com sucesso');

      // Caso exista um redirect pendente (loginRedirect), processá-lo
      try {
        if (this.msalInstance && typeof this.msalInstance.handleRedirectPromise === 'function') {
          console.log('[MsalAuth] ⏳ Verificando redirect pendente via handleRedirectPromise...');
          const redirectResult = await this.msalInstance.handleRedirectPromise();
          if (redirectResult) {
            console.log('[MsalAuth] ✅ Resultado de redirect processado:', redirectResult);
            try { await this._appendMsalDebug({ ts: Date.now(), action: 'handleRedirectPromise.processed', result: redirectResult }); } catch (e) {}
          }
        }
      } catch (e) {
        console.warn('[MsalAuth] ⚠️ handleRedirectPromise falhou ao inicializar:', e && e.message);
        try { await this._appendMsalDebug({ ts: Date.now(), action: 'handleRedirectPromise.error', error: e && e.message, stack: e && e.stack }); } catch (er) {}
      }
    } catch (error) {
      // Melhor formatação do erro
      const errorMsg = error?.message || error?.errorMessage || String(error) || 'Erro desconhecido';
      const errorCode = error?.errorCode || error?.code || 'UNKNOWN';
      
      console.error('[MsalAuth] ❌ Erro ao inicializar:', {
        message: errorMsg,
        code: errorCode,
        error: error
      });
      
      throw new Error(`[MsalAuth] Falha na inicialização: ${errorMsg} (${errorCode})`);
    }
  }

  /**
   * Realiza login com popup Microsoft
   * @returns {Object} { success: boolean, account: Object, token: string, error?: Error }
   */
  async loginPopup() {
    if (!this.initialized) {
      throw new Error('MsalAuth não foi inicializado. Chame init() primeiro.');
    }

    try {
      console.log('[MsalAuth] 🔐 Iniciando login popup...');

      const loginRequest = {
        scopes: window.AZURE_AD_CONFIG.scopes,
        prompt: 'select_account' // Sempre mostrar seletor de conta
      };

      // DEBUG: criar rastro diagnóstico antes de abrir popup
      const debugEntry = {
        ts: Date.now(),
        action: 'loginPopup.start',
        redirectUri: window.AZURE_AD_CONFIG?.redirectUri || null,
        msalConfigSnapshot: {
          clientId: window.AZURE_AD_CONFIG?.clientId || null,
          scopes: window.AZURE_AD_CONFIG?.scopes || null
        }
      };
      try {
        await this._appendMsalDebug(debugEntry);
      } catch (e) {
        // não interromper por erro no debug
        console.warn('[MsalAuth] ⚠️ Falha ao gravar debug inicial:', e);
      }

      // Abrir popup de login (MSAL)
      const loginResponse = await this.msalInstance.loginPopup(loginRequest);

      if (!loginResponse || !loginResponse.account) {
        throw new Error('Login cancelado ou falhou');
      }

      this.currentAccount = loginResponse.account;
      this.accessToken = loginResponse.accessToken;

      // ✅ CRÍTICO: Definir conta ativa no MSAL para persistência
      this.msalInstance.setActiveAccount(loginResponse.account);
      console.log('[MsalAuth] ✅ Conta ativa definida:', loginResponse.account.username);

      // Validar email
      const email = this.currentAccount.username;
      if (!window.isEmailAllowed(email)) {
        throw new Error(`Email ${email} não é de domínio permitido. Apenas ${window.AZURE_AD_CONFIG.allowedDomains.join(', ')} são aceitos.`);
      }

      console.log('[MsalAuth] ✅ Login bem-sucedido:', email);

      // DEBUG: registrar sucesso
      try {
        await this._appendMsalDebug({ ts: Date.now(), action: 'loginPopup.success', email });
      } catch (e) {}

      return {
        success: true,
        account: this.currentAccount,
        token: this.accessToken
      };
    } catch (error) {
      console.error('[MsalAuth] ❌ Erro no login:', error);

      // Gravar debug completo do erro para análise
      try {
        await this._appendMsalDebug({ ts: Date.now(), action: 'loginPopup.error', error: (error && (error.message || error.errorCode)) ? (error.errorCode || error.message) : String(error), stack: error.stack || null });
      } catch (e) {
        console.warn('[MsalAuth] ⚠️ Falha ao gravar debug de erro:', e);
      }

      // Erros comuns mapeados para mensagens amigáveis
      if (error && (error.errorCode === 'user_cancelled' || /user_cancelled/i.test(error.errorCode || error.message || ''))) {
        return {
          success: false,
          error: new Error('Login cancelado pelo usuário')
        };
      } else if (error && (error.errorCode === 'popup_window_error' || /popup/i.test(error.errorCode || error.message || ''))) {
        return {
          success: false,
          error: new Error('Popup bloqueado. Permita popups para este site.')
        };
      }

      // Capturar ReferenceError 'oad is not defined' e similares explicitamente
      if (error instanceof ReferenceError || /oad is not defined/i.test(error.message || '')) {
        // anexar stack completo ao debug e retornar erro amigável
        try { await this._appendMsalDebug({ ts: Date.now(), action: 'loginPopup.referenceerror', message: error.message, stack: error.stack }); } catch (e) {}
        return {
          success: false,
          error: new Error('Erro interno durante o fluxo de autenticação (ReferenceError). Verifique console para trace.')
        };
      }

      return {
        success: false,
        error
      };
    }
  }

  /**
   * Inicia login via redirect (fallback quando popup falha)
   * OBS: Este fluxo redireciona a página atual para o provedor e retorna quando
   * a aplicação for carregada novamente — chame handleRedirectPromise() na inicialização
   */
  async loginRedirect() {
    if (!this.initialized) throw new Error('MsalAuth não foi inicializado. Chame init() primeiro.');

    try {
      const loginRequest = { scopes: window.AZURE_AD_CONFIG.scopes, prompt: 'select_account' };
      await this._appendMsalDebug({ ts: Date.now(), action: 'loginRedirect.start', redirectUri: window.AZURE_AD_CONFIG?.redirectUri });
      await this.msalInstance.loginRedirect(loginRequest);
      // loginRedirect não resolve até que haja redirect; registrar que iniciamos
      await this._appendMsalDebug({ ts: Date.now(), action: 'loginRedirect.started' });
      return { success: true, redirectStarted: true };
    } catch (error) {
      await this._appendMsalDebug({ ts: Date.now(), action: 'loginRedirect.error', error: error && (error.message || error.errorCode) });
      throw error;
    }
  }

  /**
   * Deve ser chamado na inicialização da página (ex: admin) para processar o resultado
   * quando loginRedirect foi usado. Retorna o response do MSAL quando houver.
   */
  async handleRedirectPromise() {
    if (!this.initialized) throw new Error('MsalAuth não foi inicializado. Chame init() primeiro.');

    if (typeof this.msalInstance.handleRedirectPromise !== 'function') {
      console.warn('[MsalAuth] handleRedirectPromise não disponível na instância MSAL');
      return null;
    }

    try {
      const res = await this.msalInstance.handleRedirectPromise();
      await this._appendMsalDebug({ ts: Date.now(), action: 'handleRedirectPromise.complete', result: res || null });
      return res;
    } catch (error) {
      await this._appendMsalDebug({ ts: Date.now(), action: 'handleRedirectPromise.error', error: error && (error.message || error.errorCode), stack: error && error.stack });
      throw error;
    }
  }

  /**
   * Login usando Chrome Identity API (chrome.identity.launchWebAuthFlow)
   * 
   * Este método é recomendado para extensões Chrome pois:
   * - Usa janela controlada pelo Chrome (não popup bloqueável)
   * - Redirect URI interno (chromiumapp.org) funciona automaticamente
   * - Mais confiável que popup/redirect em contexto de extensão
   * 
   * @returns {Promise<{success: boolean, accessToken: string, expiresIn: number, account: object}>}
   */
  async loginWithChromeIdentity() {
    console.log('[MsalAuth] 🔐 Iniciando login via Chrome Identity API...');
    
    // Verificar se estamos em ambiente Chrome Extension
    if (typeof chrome === 'undefined' || !chrome.identity || !chrome.identity.launchWebAuthFlow) {
      throw new Error('Chrome Identity API não disponível. Use loginPopup() ou loginRedirect().');
    }

    try {
      const config = window.AZURE_AD_CONFIG;
      if (!config) {
        throw new Error('AZURE_AD_CONFIG não encontrado');
      }

      // Construir URL de autenticação OAuth2
      const scopes = encodeURIComponent(config.scopes.join(' '));
      const redirectUri = chrome.identity.getRedirectURL();
      
      console.log('[MsalAuth] 📍 Redirect URI:', redirectUri);
      console.log('[MsalAuth] 🔑 Scopes:', config.scopes.join(', '));

      const authUrl = `https://login.microsoftonline.com/${config.tenantId}/oauth2/v2.0/authorize?` +
        `client_id=${config.clientId}` +
        `&response_type=token` +
        `&redirect_uri=${encodeURIComponent(redirectUri)}` +
        `&scope=${scopes}` +
        `&prompt=select_account`;

      await this._appendMsalDebug({ 
        ts: Date.now(), 
        action: 'loginWithChromeIdentity.start', 
        redirectUri,
        scopes: config.scopes 
      });

      // Abrir janela de autenticação
      const responseUrl = await new Promise((resolve, reject) => {
        chrome.identity.launchWebAuthFlow(
          {
            url: authUrl,
            interactive: true
          },
          (redirectUrl) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(redirectUrl);
            }
          }
        );
      });

      console.log('[MsalAuth] ✅ Autenticação completada');

      // Extrair tokens da URL de resposta
      const params = new URLSearchParams(responseUrl.split('#')[1]);
      const accessToken = params.get('access_token');
      const expiresIn = parseInt(params.get('expires_in')) || 3600;
      const idToken = params.get('id_token');

      if (!accessToken) {
        throw new Error('Access token não encontrado na resposta');
      }

      // Decodificar ID token para obter informações do usuário
      let account = null;
      if (idToken) {
        try {
          const payload = JSON.parse(atob(idToken.split('.')[1]));
          account = {
            username: payload.preferred_username || payload.upn || payload.email,
            name: payload.name,
            localAccountId: payload.oid,
            homeAccountId: `${payload.oid}.${payload.tid}`,
            environment: 'login.microsoftonline.com',
            tenantId: payload.tid
          };
          console.log('[MsalAuth] 👤 Usuário:', account.username);
        } catch (e) {
          console.warn('[MsalAuth] ⚠️ Erro ao decodificar ID token:', e);
        }
      }

      await this._appendMsalDebug({ 
        ts: Date.now(), 
        action: 'loginWithChromeIdentity.success',
        username: account?.username,
        expiresIn
      });

      return {
        success: true,
        accessToken,
        expiresIn,
        account,
        idToken,
        method: 'chrome-identity'
      };

    } catch (error) {
      console.error('[MsalAuth] ❌ Erro no login via Chrome Identity:', error);
      await this._appendMsalDebug({ 
        ts: Date.now(), 
        action: 'loginWithChromeIdentity.error', 
        error: error.message 
      });
      
      return {
        success: false,
        error: {
          message: error.message || 'Erro desconhecido',
          code: 'CHROME_IDENTITY_ERROR'
        }
      };
    }
  }

  // Apende um registro de debug em chrome.storage.local.__nexos_msal_debug (array)
  async _appendMsalDebug(entry) {
    try {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
        // ambiente sem chrome.storage (teste unitário) — log no console
        console.log('[MsalAuth][Debug] (no storage) ', entry);
        return;
      }

      const key = '__nexos_msal_debug';
      const existing = await new Promise((resolve) => chrome.storage.local.get([key], (res) => resolve(res[key] || [])));
      existing.push(entry);
      // limitar tamanho para evitar crescer ilimitadamente
      const max = 50;
      const toSave = existing.slice(-max);
      await new Promise((resolve) => chrome.storage.local.set({ [key]: toSave }, resolve));
    } catch (e) {
      console.warn('[MsalAuth] ⚠️ Falha ao gravar debug em storage:', e);
    }
  }

  /**
   * Obtém token de acesso (renova silenciosamente se expirado)
   * @param {Array<string>} scopes - Scopes necessários (opcional, usa padrão)
   * @returns {string} Access token
   */
  async getAccessToken(scopes = null) {
    if (!this.initialized) {
      throw new Error('MsalAuth não foi inicializado. Chame init() primeiro.');
    }

    if (!this.currentAccount) {
      throw new Error('Nenhuma conta logada. Chame loginPopup() primeiro.');
    }

    try {
      const tokenRequest = {
        scopes: scopes || window.AZURE_AD_CONFIG.scopes,
        account: this.currentAccount
      };

      // Tentar obter token silenciosamente
      const response = await this.acquireTokenSilent(tokenRequest);
      this.accessToken = response.accessToken;
      return this.accessToken;
      
    } catch (error) {
      console.error('[MsalAuth] Erro ao obter token:', error);
      throw error;
    }
  }

  /**
   * Obtém token silenciosamente (sem interação do usuário)
   * @param {Object} request - Token request
   * @returns {Object} Token response
   */
  async acquireTokenSilent(request) {
    if (!this.initialized) {
      throw new Error('MsalAuth não foi inicializado. Chame init() primeiro.');
    }

    try {
      console.log('[MsalAuth] 🔄 Obtendo token silenciosamente...');
      
      // ✅ Se não tem account no request, usar conta ativa
      if (!request.account) {
        const activeAccount = this.msalInstance.getActiveAccount();
        if (activeAccount) {
          request.account = activeAccount;
          console.log('[MsalAuth] 📧 Usando conta ativa:', activeAccount.username);
        } else {
          // Tentar pegar qualquer conta disponível
          const accounts = this.msalInstance.getAllAccounts();
          if (accounts.length > 0) {
            request.account = accounts[0];
            this.msalInstance.setActiveAccount(accounts[0]);
            console.log('[MsalAuth] 📧 Definindo primeira conta como ativa:', accounts[0].username);
          } else {
            throw new Error('Nenhuma conta disponível. Por favor, faça login primeiro.');
          }
        }
      }
      
      const response = await this.msalInstance.acquireTokenSilent(request);
      
      if (response && response.accessToken) {
        console.log('[MsalAuth] ✅ Token obtido silenciosamente');
        this.accessToken = response.accessToken;
        this.currentAccount = response.account;
        
        // Atualizar conta ativa
        this.msalInstance.setActiveAccount(response.account);
        
        return response;
      }
      
      throw new Error('Resposta sem access token');
      
    } catch (error) {
      console.error('[MsalAuth] ❌ acquireTokenSilent falhou:', error);
      throw error;
    }
  }

  /**
   * Obtém todas as contas logadas
   * @returns {Array} Lista de contas
   */
  getAllAccounts() {
    if (!this.initialized || !this.msalInstance) {
      console.warn('[MsalAuth] ⚠️ MSAL não inicializado');
      return [];
    }

    try {
      return this.msalInstance.getAllAccounts();
    } catch (error) {
      console.error('[MsalAuth] ❌ Erro ao obter contas:', error);
      return [];
    }
  }

  /**
   * Verifica se usuário está logado
   * @returns {boolean}
   */
  isLoggedIn() {
    return this.currentAccount !== null;
  }

  /**
   * Obtém informações da conta atual
   * @returns {Object|null} { username, name, tenantId, localAccountId }
   */
  getCurrentAccount() {
    if (!this.currentAccount) {
      return null;
    }

    return {
      username: this.currentAccount.username, // Email
      name: this.currentAccount.name, // Nome completo
      tenantId: this.currentAccount.tenantId,
      localAccountId: this.currentAccount.localAccountId,
      idTokenClaims: this.currentAccount.idTokenClaims // Claims adicionais
    };
  }

  /**
   * Realiza logout completo
   * Remove tokens do cache e redireciona para logout do Azure AD
   */
  async logout() {
    if (!this.initialized) {
      console.warn('[MsalAuth] ⚠️ Não inicializado, limpando dados locais apenas');
      this.currentAccount = null;
      this.accessToken = null;
      return;
    }

    try {
      console.log('[MsalAuth] 🚪 Realizando logout...');

      const logoutRequest = {
        account: this.currentAccount,
        postLogoutRedirectUri: window.AZURE_AD_CONFIG.redirectUri
      };

      // Limpar dados locais
      this.currentAccount = null;
      this.accessToken = null;

      // Logout do Azure AD (popup)
      await this.msalInstance.logoutPopup(logoutRequest);

      console.log('[MsalAuth] ✅ Logout concluído');
    } catch (error) {
      console.error('[MsalAuth] ❌ Erro ao fazer logout:', error);
      
      // Mesmo com erro, limpar localmente
      this.currentAccount = null;
      this.accessToken = null;
    }
  }

  /**
   * Limpa apenas cache local (sem logout do Azure AD)
   */
  clearLocalCache() {
    console.log('[MsalAuth] 🧹 Limpando cache local...');
    this.currentAccount = null;
    this.accessToken = null;
    
    if (this.msalInstance) {
      const accounts = this.msalInstance.getAllAccounts();
      accounts.forEach(account => {
        this.msalInstance.getTokenCache().removeAccount(account);
      });
    }
    
    console.log('[MsalAuth] ✅ Cache local limpo');
  }

  /**
   * Inicia renovação automática de tokens
   * Checa a cada 5 minutos e renova se próximo de expirar
   * @returns {number} IntervalId para clearInterval
   */
  startTokenRenewal() {
    const checkInterval = 5 * 60 * 1000; // 5 minutos

    const intervalId = setInterval(async () => {
      if (!this.isLoggedIn()) {
        console.log('[MsalAuth] ⏸️ Não logado, pulando renovação');
        return;
      }

      try {
        console.log('[MsalAuth] 🔄 Verificando necessidade de renovação de token...');
        await this.getAccessToken(); // Renova automaticamente se necessário
        console.log('[MsalAuth] ✅ Token verificado/renovado com sucesso');
      } catch (error) {
        console.error('[MsalAuth] ❌ Erro ao renovar token:', error);
        // Não interromper loop, tentar novamente no próximo ciclo
      }
    }, checkInterval);

    console.log(`[MsalAuth] ⏰ Renovação automática iniciada (a cada ${checkInterval / 1000}s)`);
    return intervalId;
  }

  /**
   * Tratamento de erros MSAL
   * @param {Error} error 
   * @returns {Object} { code: string, message: string, userFriendly: string }
   */
  handleError(error) {
    const errorMap = {
      'user_cancelled': {
        code: 'USER_CANCELLED',
        message: 'Login cancelado pelo usuário',
        userFriendly: 'Você cancelou o login. Tente novamente.'
      },
      'popup_window_error': {
        code: 'POPUP_BLOCKED',
        message: 'Popup bloqueado pelo navegador',
        userFriendly: 'Permita popups para este site nas configurações do navegador.'
      },
      'interaction_required': {
        code: 'INTERACTION_REQUIRED',
        message: 'Interação do usuário necessária',
        userFriendly: 'É necessário fazer login novamente.'
      },
      'consent_required': {
        code: 'CONSENT_REQUIRED',
        message: 'Consentimento de admin necessário',
        userFriendly: 'Entre em contato com o administrador para conceder permissões.'
      },
      'login_required': {
        code: 'LOGIN_REQUIRED',
        message: 'Login necessário',
        userFriendly: 'Faça login para continuar.'
      },
      'network_error': {
        code: 'NETWORK_ERROR',
        message: 'Erro de rede',
        userFriendly: 'Verifique sua conexão com a internet e tente novamente.'
      }
    };

    const errorCode = error.errorCode || error.code || 'UNKNOWN';
    const mappedError = errorMap[errorCode] || {
      code: 'UNKNOWN',
      message: error.message || 'Erro desconhecido',
      userFriendly: 'Ocorreu um erro. Tente novamente ou entre em contato com o suporte.'
    };

    console.error('[MsalAuth] ❌ Erro MSAL:', {
      code: errorCode,
      message: error.message,
      details: error
    });

    return mappedError;
  }
}

// ===================================
// EXPORTAÇÃO E INICIALIZAÇÃO
// ===================================

if (typeof window !== 'undefined') {
  window.MsalAuth = MsalAuth;
  console.log('[MsalAuth] ✅ Classe exportada para window.MsalAuth');
  
  // ✅ AUTO-INICIALIZAR window.msalAuth
  if (!window.msalAuth) {
    console.log('[MsalAuth] 🚀 Criando instância window.msalAuth...');
    window.msalAuth = new MsalAuth();
    
    // Inicializar automaticamente após 500ms (dar tempo para configs carregarem)
    setTimeout(async () => {
      try {
        if (window.msalAuth && !window.msalAuth.initialized) {
          console.log('[MsalAuth] 🔧 Auto-inicializando...');
          await window.msalAuth.init();
          console.log('[MsalAuth] ✅ Auto-inicialização completa');
        }
      } catch (error) {
        // Melhor formatação do erro
        const errorMsg = error?.message || error?.errorMessage || String(error) || 'Erro desconhecido';
        const errorCode = error?.errorCode || error?.code || 'UNKNOWN';
        
        console.error('[MsalAuth] ❌ Erro na auto-inicialização:', {
          message: errorMsg,
          code: errorCode,
          fullError: error
        });
      }
    }, 500);
  }
}
