/**
 * ════════════════════════════════════════════════════════════════════════════
 * PICKING STATE MANAGER - Gerenciamento Centralizado de Estado
 * ════════════════════════════════════════════════════════════════════════════
 * 
 * Responsável por:
 * - Gerenciar estado global de pedidos
 * - Sincronizar com chrome.storage
 * - Notificar mudanças para componentes
 * - Validar integridade dos dados
 */

class PickingStateManager {
  constructor() {
    this.state = {
      orders: {},           // { [pedido_id]: OrderData }
      locks: {},            // { [pedido_id]: LockInfo }
      timeline: {},         // { [pedido_id]: Event[] }
      queue: [],            // [QueuedJob]
      currentUser: null,    // UserInfo
      lastSync: null        // timestamp
    };
    
    this.listeners = new Set();
    this.syncInProgress = false;
    this.autoSyncInterval = null;
    
    // 🆕 V3.0: SharePoint Manager
    this.sharepointManager = null;
    this.sharepointEnabled = false;
    this.cache = {
      orders: {},
      lastRefresh: null,
      ttl: 5000 // 🔥 5 segundos para tempo real
    };
    
    // 🔄 Auto-refresh de UI (timestamps)
    this.uiRefreshInterval = null;
    
    console.log('[PickingState] 🎯 State Manager inicializado');
  }

  /**
   * Verifica se o contexto da extensão ainda é válido
   */
  isExtensionContextValid() {
    try {
      if (typeof chrome === 'undefined' || !chrome.runtime) {
        return false;
      }
      // Tenta acessar uma propriedade para verificar se o contexto é válido
      const id = chrome.runtime.id;
      return !!id;
    } catch (error) {
      return false;
    }
  }
  
  /**
   * Inicializar - Carregar estado do storage
   */
  async init() {
    // console.log('[PickingState] 🔄 Inicializando...');
    
    try {
      // 🆕 V3.0: Tentar inicializar SharePoint primeiro
      await this.initSharePoint();
      
      // � Registrar listener de broadcast cross-tab (onChanged)
      // Deve ser feito antes do primeiro loadFromStorage para não perder eventos
      this._setupStorageChangeListener();

      // �🔥 LIMPAR cache local antigo antes de carregar
      await this.clearLocalCache();
      
      // Carregar dados do storage (SharePoint ou fallback local)
      // 🔥 FORÇAR refresh para garantir dados atualizados do SharePoint
      await this.loadFromStorage(true); // forceRefresh = true
      
      // Iniciar sincronização automática (a cada 10s)
      this.startAutoSync();
      
      // Limpar locks expirados
      await this.cleanExpiredLocks();
      
      // Inicializado silenciosamente
      // console.log('[PickingState] 📊 Pedidos carregados:', Object.keys(this.state.orders).length);
      // console.log('[PickingState] 🔒 Locks ativos:', Object.keys(this.state.locks).length);
      // console.log('[PickingState] 🌐 SharePoint:', this.sharepointEnabled ? 'ATIVO' : 'Desabilitado (fallback local)');
      
      return true;
    } catch (error) {
      // TOKEN_EXPIRED é esperado — não logar como erro crítico
      if (error.message === 'TOKEN_EXPIRED') {
        return false;
      }
      console.error('[PickingState] ❌ Erro ao inicializar:', error);
      return false;
    }
  }
  
  /**
   * 🧹 Limpar cache local antigo
   */
  async clearLocalCache() {
    try {
      // console.log('[PickingState] 🧹 Limpando cache local antigo...');
      
      // Limpar chrome.storage
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        const keys = ['nexos-picking-data', 'nexos-picking-locks', 'nexos-picking-timeline'];
        await chrome.storage.local.remove(keys);
        // console.log('[PickingState] ✅ Cache do chrome.storage limpo');
      }
      
      // Limpar localStorage
      try {
        localStorage.removeItem('nexos-picking-data');
        localStorage.removeItem('nexos-picking-locks');
        localStorage.removeItem('nexos-picking-timeline');
        localStorage.removeItem('nexos-picking-state');
        // console.log('[PickingState] ✅ Cache do localStorage limpo');
      } catch (e) {
        // Silencioso - pode não ter permissão em alguns contextos
      }
      
      // Limpar cache em memória
      this.cache.orders = {};
      this.cache.lastRefresh = null;
      
      // console.log('[PickingState] ✅ Cache local completamente limpo');
    } catch (error) {
      console.warn('[PickingState] ⚠️ Erro ao limpar cache:', error);
    }
  }
  
  /**
   * 🆕 V3.0: Inicializar SharePoint Manager
   */
  async initSharePoint() {
    try {
      // ✅ Guard clause: Se já inicializado e com usuário válido, retornar true
      if (this.sharepointEnabled && this.sharepointManager && window.nexos_current_user) {
        // console.log('[PickingState] ✅ SharePoint já inicializado, reutilizando sessão');
        return true;
      }
      
      // console.log('[PickingState] 🌐 Tentando inicializar SharePoint...');
      
      // 🔐 VERIFICAR AUTENTICAÇÃO (MÚLTIPLAS FONTES)
      let currentUser = null;
      
      // 1️⃣ Tentar NexosAuth
      // console.log('[PickingState] 🔍 Verificando NexosAuth...');
      // console.log('[PickingState]   window.NexosAuth existe?', !!window.NexosAuth);
      // console.log('[PickingState]   window.NexosAuth.getCurrentUser existe?', !!window.NexosAuth?.getCurrentUser);
      
      if (window.NexosAuth?.getCurrentUser) {
        try {
          currentUser = window.NexosAuth.getCurrentUser();
          // console.log('[PickingState] 📊 Resultado de NexosAuth.getCurrentUser():', currentUser);
        } catch (e) {
          console.warn('[PickingState] ⚠️ Erro ao chamar NexosAuth.getCurrentUser():', e);
        }
      }
      
      // 2️⃣ Fallback: window.nexos_current_user
      if (!currentUser) {
        // console.log('[PickingState] 🔍 Tentando window.nexos_current_user...');
        // console.log('[PickingState]   window.nexos_current_user:', window.nexos_current_user);
        
        if (window.nexos_current_user) {
          currentUser = window.nexos_current_user;
          // console.log('[PickingState] ✅ Usuário obtido de window.nexos_current_user');
        }
      }
      
      // 3️⃣ Fallback: localStorage
      if (!currentUser) {
        // console.log('[PickingState] 🔍 Tentando localStorage...');
        try {
          const storedUser = localStorage.getItem('nexos_current_user');
          // console.log('[PickingState]   localStorage nexos_current_user:', storedUser ? 'ENCONTRADO' : 'NULL');
          
          if (storedUser) {
            currentUser = JSON.parse(storedUser);
            // console.log('[PickingState] ✅ Usuário obtido de localStorage:', currentUser?.email);
          }
        } catch (e) {
          console.warn('[PickingState] ⚠️ Erro ao ler localStorage:', e);
        }
      }
      
      // 4️⃣ Fallback CRÍTICO: msalAuth.currentAccount (se tem token, tem usuário)
      if (!currentUser && window.msalAuth) {
        // console.log('[PickingState] 🔍 Tentando window.msalAuth.currentAccount...');
        try {
          if (window.msalAuth.currentAccount) {
            currentUser = {
              email: window.msalAuth.currentAccount.username,
              displayName: window.msalAuth.currentAccount.name || window.msalAuth.currentAccount.username,
              userPrincipalName: window.msalAuth.currentAccount.username
            };
            // console.log('[PickingState] ✅ Usuário obtido de msalAuth.currentAccount:', currentUser.email);
          } else {
            // console.log('[PickingState] ⚠️ msalAuth.currentAccount é null, tentando getAllAccounts()...');
            
            // Último recurso: pegar primeira conta do MSAL
            const msalInstance = window.msalAuth.msalInstance || window.msalAuth;
            if (msalInstance && typeof msalInstance.getAllAccounts === 'function') {
              const accounts = msalInstance.getAllAccounts();
              // console.log('[PickingState] 📊 Contas MSAL encontradas:', accounts?.length || 0);
              
              if (accounts && accounts.length > 0) {
                const account = accounts[0];
                currentUser = {
                  email: account.username,
                  displayName: account.name || account.username,
                  userPrincipalName: account.username
                };
                // console.log('[PickingState] ✅ Usuário criado a partir de conta MSAL:', currentUser.email);
              }
            }
          }
        } catch (e) {
          console.warn('[PickingState] ⚠️ Erro ao obter usuário do msalAuth:', e);
        }
      }
      
      // 5️⃣ Validar autenticação
      // console.log('[PickingState] 📊 currentUser final:', currentUser);
      const userEmail = currentUser?.email || currentUser?.userPrincipalName;
      // console.log('[PickingState] 📧 Email extraído:', userEmail);
      
      if (!currentUser || !userEmail) {
        // Log silencioso - não é erro antes do login
        this.sharepointEnabled = false;
        return false;
      }
      
      const userName = currentUser.displayName || currentUser.name || userEmail.split('@')[0];
      // console.log('[PickingState] ✅ Usuário autenticado:', userName, `(${userEmail})`);
      
      // 🔥 Garantir disponibilidade global
      if (!window.nexos_current_user) {
        window.nexos_current_user = currentUser;
        // console.log('[PickingState] 💾 Usuário salvo em window.nexos_current_user');
      }
      
      // Verificar se PickingSharePointManager está disponível
      if (typeof window.PickingSharePointManager === 'undefined') {
        console.warn('[PickingState] ⚠️ PickingSharePointManager não encontrado. Usando fallback local.');
        return false;
      }
      
      // Criar instância do manager
      this.sharepointManager = new window.PickingSharePointManager();
      
      // Tentar inicializar (obtém token via UnifiedAuth automaticamente)
      const result = await this.sharepointManager.initialize();
      
      if (result.success) {
        this.sharepointEnabled = true;
        
        // 🆕 EXPORTAR GLOBALMENTE para acesso em extractPickingData e testes
        window.pickingSharePointManager = this.sharepointManager;
        
        console.log('[PickingState] ✅ SharePoint inicializado com sucesso!');
        console.log('[PickingState] 🆔 Site ID:', result.siteId);
        console.log('[PickingState] 🌐 Manager exportado: window.pickingSharePointManager');
        return true;
      } else {
        // 🔥 ERRO - SharePoint não inicializou
        // Não logar como erro — pode ser token expirado (esperado)
        
        // 🔥 Verificar se é erro de permissão (403)
        if (result.error && (result.error.includes('403') || result.error.includes('accessDenied'))) {
          console.error('[PickingState] 🔒 ERRO DE PERMISSÃO: Usuário não tem acesso ao SharePoint');
          console.error('[PickingState] 📋 Para resolver:');
          console.error('   1. Verifique se você tem permissão no site: https://gpabr.sharepoint.com/sites/Nexos');
          console.error('   2. Solicite acesso ao administrador do SharePoint');
          console.error('   3. Certifique-se de estar na lista de usuários autorizados');
          
          // 🔥 Lançar erro para bloquear operações
          throw new Error(`❌ ACESSO NEGADO AO SHAREPOINT\n\n` +
            `Você não tem permissão para acessar o site Nexos.\n\n` +
            `✅ Você está autenticado como: ${window.nexos_current_user?.displayName || 'usuário'}\n` +
            `❌ Mas não tem acesso ao SharePoint /sites/Nexos\n\n` +
            `📞 SOLUÇÃO:\n` +
            `   • Solicite acesso ao administrador do SharePoint\n` +
            `   • Ou peça para ser adicionado ao grupo de usuários autorizados`
          );
        }
        
        // Token expirado — lançar para o overlay tratar (não é erro inesperado)
        if (result.error && result.error.includes('TOKEN_EXPIRED')) {
          this.sharepointEnabled = false;
          // Sinalizar para o popup mostrar "Reconectar"
          try { chrome.storage.local.set({ 'nexos-sp-token-expired': true }); } catch(_) {}
          throw new Error('TOKEN_EXPIRED');
        }

        // Outros erros: logar e continuar sem SharePoint
        console.warn('[PickingState] ⚠️ SharePoint não disponível:', result.error);
        this.sharepointEnabled = false;
        return false;
      }
      
    } catch (error) {
      this.sharepointEnabled = false;

      // TOKEN_EXPIRED — re-lançar para que o overlay possa bloquear e pedir re-login
      if (error.message === 'TOKEN_EXPIRED') {
        throw error;
      }

      // Erro de permissão — logar e re-lançar
      if (error.message && (error.message.includes('403') || error.message.includes('Acesso negado'))) {
        console.error('[PickingState] ❌ Erro ao inicializar SharePoint:', error.message);
        throw error;
      }

      // Outros erros inesperados
      console.warn('[PickingState] ⚠️ Erro ao inicializar SharePoint:', error.message);
    }
  }
  
  /**
   * Carregar estado do SharePoint ou fallback local
   */
  async loadFromStorage(forceRefresh = false) {
    // ─────────────────────────────────────────────────────────────────────────
    // � CACHE COMPARTILHADO ENTRE TABS (chrome.storage.local)
    //
    // Problema: 20 usuários × polling a cada 10s = centenas de requests/min ao SP.
    // Solução: 1 tab busca os dados e grava em chrome.storage.local com TTL de 20s.
    //          As outras tabs leem do storage — sem request ao SP.
    //
    // Fluxo:
    //   1. Cache local em memória válido?  → usa (sem I/O)
    //   2. Cache compartilhado no storage válido? → usa (sem SP)
    //   3. Outra tab está buscando agora?  → aguarda até 8s e usa o resultado dela
    //   4. Nenhuma das anteriores:         → busca no SP, grava no storage compartilhado
    // ─────────────────────────────────────────────────────────────────────────
    const SHARED_CACHE_KEY    = 'nexos-sp-orders-shared-cache';
    const SHARED_CACHE_TTL_MS = 20_000; // 20s: equilibrio entre frescor e carga no SP
    const LOADING_FLAG_KEY    = 'nexos-sp-orders-loading-flag';
    const LOADING_WAIT_MS     = 8_000;  // máximo de espera por outra tab
    const LOADING_POLL_MS     = 400;    // intervalo de polling do flag

    try {
      // 🆕 V3.0: Tentar carregar do SharePoint primeiro (SE autenticado e manager inicializado)
      if (this.sharepointEnabled && this.sharepointManager && this.sharepointManager.initialized) {

        // ── Passo 1: cache em memória (TTL 5s) — deduplica chamadas rápidas na mesma tab ──
        const now = Date.now();
        if (!forceRefresh && this.cache.lastRefresh && (now - this.cache.lastRefresh) < this.cache.ttl) {
          this.state.orders = this.cache.orders;
          return;
        }

        // ── Passo 2: broadcast recente? Outra tab já trouxe dados frescos via onChanged ──
        // chrome.storage.onChanged propaga em < 1ms — se recebemos broadcast recente,
        // o state já está atualizado sem precisar ir ao SP.
        const BROADCAST_SKIP_MS = 12_000;
        if (!forceRefresh && this._lastBroadcastReceivedAt && (now - this._lastBroadcastReceivedAt) < BROADCAST_SKIP_MS) {
          return; // dados frescos recebidos via broadcast — pular SP
        }

        // ── Passo 3: guard single-tab — evita duas requests simultâneas na mesma tab ──
        if (this._loadingFromSP) {
          return this._loadingFromSP;
        }

        let resolveLoading;
        this._loadingFromSP = new Promise(r => { resolveLoading = r; });

        try {
          //  Filtrar apenas pedidos do dia atual (evita trazer histórico de dias anteriores)
          const todayUtc = new Date();
          todayUtc.setUTCHours(0, 0, 0, 0);
          const todayFilter = `fields/Created ge '${todayUtc.toISOString()}'`;

          const result = await this.sharepointManager.getOrdersFromStatus(null, {
            limit: 500,
            filter: todayFilter
          });

          if (result.success && result.orders.length > 0) {
            this._applyOrdersResult(result.orders, now);
            // 📡 Propagar para todas as outras tabs via onChanged (< 1ms)
            this._broadcastState();
            return;
          } else {
            // Log silencioso - lista vazia não é erro
            this.state.orders = {};
            this.cache.orders = {};
            this.cache.lastRefresh = now;
            this._broadcastState();
            return;
          }

        } catch (spError) {
          // Token expirado — propagar silenciosamente (esperado)
          if (spError.isTokenExpired || spError.message === 'TOKEN_EXPIRED') {
            throw spError; // Propagar para tratamento superior
          }

          console.warn('[PickingState] ⚠️ Erro ao carregar do SharePoint — usando fallback:', spError?.message || spError);
          // Continuar para fallback local
        } finally {
          this._loadingFromSP = null;
          resolveLoading();
        }
      }

      // 🔄 FALLBACK: Carregar do localStorage se SharePoint falhar ou não estiver ativo
      console.log('[PickingState] 📁 Carregando do localStorage (fallback)...');

      // Tentar chrome.storage primeiro, fallback para localStorage
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        const keys = ['nexos-picking-data', 'nexos-picking-locks', 'nexos-picking-timeline'];
        const result = await chrome.storage.local.get(keys);

        if (result['nexos-picking-data']) {
          this.state.orders = result['nexos-picking-data'];
        }

        if (result['nexos-picking-locks']) {
          this.state.locks = result['nexos-picking-locks'];
        }

        if (result['nexos-picking-timeline']) {
          this.state.timeline = result['nexos-picking-timeline'];
        }

        console.log('[PickingState] 💾 Dados carregados do chrome.storage');
      } else {
        // Fallback para localStorage (main world)
        const ordersData = localStorage.getItem('nexos-picking-data');
        const locksData = localStorage.getItem('nexos-picking-locks');
        const timelineData = localStorage.getItem('nexos-picking-timeline');
        
        if (ordersData) {
          this.state.orders = JSON.parse(ordersData);
        }
        
        if (locksData) {
          this.state.locks = JSON.parse(locksData);
        }
        
        if (timelineData) {
          this.state.timeline = JSON.parse(timelineData);
        }
        
        console.log('[PickingState] 💾 Dados carregados do localStorage (main world)');
      }
      
      this.state.lastSync = Date.now();
    } catch (error) {
      // ✅ FIX: Se extension context invalidated, usar fallback para localStorage
      if (error.message && error.message.includes('Extension context invalidated')) {
        console.debug('[PickingState] contexto invalidado, usando localStorage...');
        try {
          const mainData = localStorage.getItem('nexos-picking-state');
          if (mainData) {
            const parsed = JSON.parse(mainData);
            this.state = { ...this.state, ...parsed };
          }
          return; // Sucesso com fallback
        } catch (fallbackError) {
          console.error('[PickingState] ❌ Fallback também falhou:', fallbackError);
        }
      }
      console.error('[PickingState] ❌ Erro ao carregar storage:', error);
      throw error;
    }
  }

  /**
   * Normaliza e aplica um array de orders (vindos do SP ou do broadcast)
   * ao state local e ao cache em memória.
   * @param {Array} spOrders - Array retornado por getOrdersFromStatus
   * @param {number} now - timestamp atual (Date.now())
   */
  _applyOrdersResult(spOrders, now) {
    const FINISHED_STATUSES = ['entregue', 'cancelado', 'finalizado', 'concluido'];
    const ACTIVE_STATUSES   = ['pendente', 'solicitado', 'em_andamento'];
    const allOrders = {};

    for (const order of spOrders) {
      const loja    = order.loja || 'unknown';
      const pedidoId = order.pedido_id;
      if (!allOrders[loja]) allOrders[loja] = {};

      const newStatus = (order.status || '').toLowerCase();
      const existingEntry = allOrders[loja][pedidoId];

      if (existingEntry) {
        const existingStatus = (existingEntry.status || '').toLowerCase();
        const existingIsActive = ACTIVE_STATUSES.includes(existingStatus);
        const newIsFinished    = FINISHED_STATUSES.includes(newStatus);
        if (existingIsActive && newIsFinished) continue;
        const newTs      = new Date(order.created).getTime();
        const existingTs = existingEntry.timestamp || 0;
        if (newTs < existingTs) continue;
      }

      allOrders[loja][pedidoId] = {
        pedido: pedidoId,
        loja,
        status: order.status,
        platform: order.platform,
        timestamp: new Date(order.created).getTime(),
        orderID: order.orderID,
        itemId: order.itemId,
        extractedBy: order.extractedBy,
        extractedByEmail: order.extractedByEmail,
        ...order.data,
        nome_cliente:      order.nome_cliente || order.data?.nomeCliente || '',
        celular_cliente:   order.telefone || order.data?.celularCliente || order.data?.telefone || '',
        telefone_cliente:  order.telefone || order.data?.celularCliente || order.data?.telefone || '',
        endereco_completo: order.endereco_completo || order.data?.enderecoCompleto || order.data?.endereco || '',
        complemento:       order.complemento || order.data?.complemento || '',
        valor_pedido:      order.valor || order.data?.valorPedido || order.data?.valor || '',
        modalidade:        order.modalidade || order.data?.modalidade || '',
        // Preservar timestamp_carregamento local para evitar drift de minuto ao re-renderizar
        timestamp_carregamento: order.data?.timestamp_carregamento
          || existingEntry?.timestamp_carregamento
          || existingEntry?.data?.timestamp_carregamento
          || new Date(order.created).getTime(),
      };
    }

    this.state.orders  = allOrders;
    this.cache.orders  = { ...allOrders };
    this.cache.lastRefresh = now;
    if (!this.state.lastSync) {
      console.log('[PickingState] ✅ Pedidos aplicados — lojas:', Object.keys(allOrders).length, '| pedidos:', spOrders.length);
    }
    this.state.lastSync = Date.now();
  }

  /**
   * Aguarda que outra tab conclua a busca ao SP verificando o cache compartilhado.
   * Faz polling no chrome.storage a cada `pollMs` até encontrar o cache ou atingir `timeoutMs`.
   * @returns {Object|null} objeto { orders, fetchedAt } ou null se timeout
   * @deprecated substituído pelo mecanismo de broadcast via chrome.storage.onChanged
   */
  async _waitForSharedCache(cacheKey, flagKey, timeoutMs, pollMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      await new Promise(r => setTimeout(r, pollMs));
      try {
        const flagStored = await chrome.storage.local.get(flagKey);
        const flagGone   = !flagStored[flagKey];
        const cached     = await chrome.storage.local.get(cacheKey);
        const shared     = cached[cacheKey];
        if (shared && Array.isArray(shared.orders)) return shared;
        if (flagGone) break;
      } catch (_) { break; }
    }
    return null;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 📡 BROADCAST EM TEMPO REAL VIA chrome.storage.onChanged
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Registra o listener de onChanged do chrome.storage.
   * Deve ser chamado UMA vez no init(). Quando qualquer tab grava
   * 'nexos-sp-orders-broadcast', todas as outras tabs recebem o evento
   * em < 1ms e atualizam a UI sem nenhuma request ao SP.
   */
  _setupStorageChangeListener() {
    if (typeof chrome === 'undefined' || !chrome.storage?.onChanged) return;

    // Rastrear eventos de platform já processados para evitar duplicatas
    this._processedPlatformEventTs = this._processedPlatformEventTs || new Set();

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;

      // ── 1. Broadcast cross-tab de pedidos ────────────────────────────────
      if (changes['nexos-sp-orders-broadcast']) {
        const newVal = changes['nexos-sp-orders-broadcast'].newValue;
        if (newVal && newVal.orders && newVal.ts && newVal.ts !== this._lastBroadcastSentTs) {
          console.log('[PickingState] 📡 Broadcast recebido — atualizando UI instantaneamente');
          this._lastBroadcastReceivedAt = Date.now();
          this.state.orders      = newVal.orders;
          this.cache.orders      = { ...newVal.orders };
          this.cache.lastRefresh = Date.now();
          this.state.lastSync    = Date.now();
          this.notifyListeners('orders_updated_remote', { source: 'broadcast' });
          window.dispatchEvent(new CustomEvent('nexos-picking-refresh', {
            detail: { reason: 'broadcast_recebido', ts: newVal.ts }
          }));
        }
      }

      // ── 2. Eventos de plataforma (tracking_captured etc.) ────────────────
      if (changes['nexos_platform_events'] && this.sharepointEnabled && this.sharepointManager?.initialized) {
        const events = changes['nexos_platform_events'].newValue;
        if (!Array.isArray(events)) return;
        // Processar apenas eventos novos não processados
        for (const evt of events) {
          if (!evt || !evt.ts) continue;
          const key = `${evt.type}|${evt.ts}|${evt.pedidoId}`;
          if (this._processedPlatformEventTs.has(key)) continue;
          this._processedPlatformEventTs.add(key);
          // Limpar cache de keys antigas (manter apenas os últimos 200)
          if (this._processedPlatformEventTs.size > 200) {
            const iter = this._processedPlatformEventTs.values();
            this._processedPlatformEventTs.delete(iter.next().value);
          }
          if (evt.type === 'tracking_captured' && evt.pedidoId && evt.trackingLink) {
            const trackingVal = String(evt.trackingLink).trim();
            if (!trackingVal) continue;
            console.log('[PickingState] 📡 tracking_captured recebido — atualizando SP:', evt.pedidoId, trackingVal);
            // Fire-and-forget: atualizar TrackingLink no SP
            this.sharepointManager.updateOrder(evt.loja || '', evt.pedidoId, {
              tracking_link: trackingVal,
              ...(evt.value ? { valor_transporte: String(evt.value) } : {}),
              ...(evt.platform ? { platform: evt.platform } : {})
            }).then(() => {
              console.log('[PickingState] ✅ TrackingLink atualizado no SP via platform_event:', evt.pedidoId, trackingVal);
              // Atualizar state local imediatamente sem re-fetch
              for (const loja of Object.keys(this.state.orders)) {
                if (this.state.orders[loja]?.[evt.pedidoId]) {
                  this.state.orders[loja][evt.pedidoId].tracking_link = trackingVal;
                  if (evt.value) this.state.orders[loja][evt.pedidoId].valor_pedido = String(evt.value);
                  break;
                }
              }
            }).catch(e => {
              console.warn('[PickingState] ⚠️ Falha ao salvar tracking no SP (via platform_event):', evt.pedidoId, e?.message || e);
            });
          }
        }
      }
    });

    console.log('[PickingState] 📡 Listener de broadcast cross-tab registrado');
  }

  /**
   * Grava o state normalizado em chrome.storage.local.
   * Isso dispara onChanged em TODAS as outras tabs instantaneamente (< 1ms).
   * Fire-and-forget — não bloqueia o fluxo principal.
   */
  _broadcastState() {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) return;
    const ts = Date.now();
    this._lastBroadcastSentTs = ts;
    chrome.storage.local.set({
      'nexos-sp-orders-broadcast': { orders: this.state.orders, ts }
    }).catch(() => {}); // silencioso
  }

  /**
   * Salvar estado no chrome.storage
   * 🆕 V3.0: NÃO salva localmente se SharePoint estiver ativo
   */
  async saveToStorage() {
    // 🆕 V3.0: Se SharePoint ativo, não salvar localmente (source of truth é SharePoint)
    if (this.sharepointEnabled) {
      console.log('[PickingState] 🌐 SharePoint ativo - Não salvando localmente (SharePoint é a fonte de verdade)');
      return;
    }
    
    if (this.syncInProgress) {
      console.log('[PickingState] ⏳ Sync já em andamento, aguardando...');
      return;
    }
    
    this.syncInProgress = true;
    
    try {
      const data = {
        'nexos-picking-data': this.state.orders,
        'nexos-picking-locks': this.state.locks,
        'nexos-picking-timeline': this.state.timeline
      };
      
      // Verifica se o contexto da extensão é válido antes de usar chrome.storage
      if (this.isExtensionContextValid() && chrome.storage && chrome.storage.local) {
        try {
          await chrome.storage.local.set(data);
          // console.log('[PickingState] 💾 Dados salvos no chrome.storage (fallback mode)');
        } catch (chromeError) {
          // Se chrome.storage falhar (context invalidated), usar localStorage silenciosamente
          localStorage.setItem('nexos-picking-data', JSON.stringify(this.state.orders));
          localStorage.setItem('nexos-picking-locks', JSON.stringify(this.state.locks));
          localStorage.setItem('nexos-picking-timeline', JSON.stringify(this.state.timeline));
          // Não loga warning, é comportamento esperado durante recarregamento
        }
      } else {
        // Fallback para localStorage (main world ou contexto inválido)
        localStorage.setItem('nexos-picking-data', JSON.stringify(this.state.orders));
        localStorage.setItem('nexos-picking-locks', JSON.stringify(this.state.locks));
        localStorage.setItem('nexos-picking-timeline', JSON.stringify(this.state.timeline));
      }
      
      this.state.lastSync = Date.now();
    } catch (error) {
      console.error('[PickingState] ❌ Erro ao salvar storage:', error);
      // Não fazer throw, apenas logar o erro para não quebrar a aplicação
    } finally {
      this.syncInProgress = false;
    }
  }
  
  /**
   * Iniciar sincronização automática
   * 🆕 V3.0: Inclui sync com SharePoint
   * 🔥 TEMPO REAL: Sync a cada 10s, UI refresh a cada 1s
   */
  startAutoSync() {
    if (this.autoSyncInterval) {
      clearInterval(this.autoSyncInterval);
    }
    
    // 🔄 Sync de dados do SharePoint (30s — onChanged cobre o tempo real entre tabs)
    this.autoSyncInterval = setInterval(async () => {
      // 🛡️ Parar silenciosamente se o contexto da extensão foi invalidado
      // (ocorre quando a extensão é recarregada enquanto a aba permanece aberta)
      if (!this.isExtensionContextValid()) {
        clearInterval(this.autoSyncInterval);
        this.autoSyncInterval = null;
        if (this.uiRefreshInterval) { clearInterval(this.uiRefreshInterval); this.uiRefreshInterval = null; }
        console.debug('[PickingState] contexto invalidado — auto-sync encerrado');
        return;
      }

      // 🆕 V3.0: Se SharePoint ativo, sincronizar com SharePoint
      if (this.sharepointEnabled && this.sharepointManager && this.sharepointManager.initialized) {
        await this.syncWithSharePoint();
      } else {
        // Fallback: salvar localmente
        await this.saveToStorage();
      }
      
      await this.cleanExpiredLocks();
      await this.cleanExpiredSolicitados();
    }, 8000); // ⚡ 8s — delta query retorna só itens alterados, custo mínimo no SP

    // 🎨 Auto-refresh visual de timestamps (1 segundo)
    if (this.uiRefreshInterval) {
      clearInterval(this.uiRefreshInterval);
    }

    this.uiRefreshInterval = setInterval(() => {
      this._refreshUITimestamps();
    }, 1000);

    console.log('[PickingState] ⏰ Auto-sync iniciado (delta: 8s, UI: 1s)');
    if (this.sharepointEnabled) {
      console.log('[PickingState] 🌐 Sync SharePoint via delta query habilitado');
    }
  }

  /**
   * 🆕 V3.0: Sincronizar com SharePoint usando delta query.
   *
   * Fluxo:
   *   1ª chamada (sem _spDeltaToken): full-fetch filtrado por hoje → armazena deltaToken
   *   Chamadas seguintes: envia deltaToken → SP retorna só os itens alterados
   *   → payload de bytes, não de KB → polling a 8s sem risco de 429
   *
   * Itens deletados chegam com { '@removed': { reason: 'deleted' } }.
   * Itens criados/modificados chegam normalmente.
   */
  async syncWithSharePoint() {
    if (this.syncInProgress) return;

    // ── CSP guard: não tentar chamar SP em páginas que bloqueiam graph.microsoft.com ──
    const _hostname = window.location.hostname || '';
    const _CSP_BLOCKED_HOSTS = ['uber.com', 'lalamove.com', '99app.com', 'logistics.uber.com'];
    if (_CSP_BLOCKED_HOSTS.some(h => _hostname.includes(h))) return;

    // ── Backoff exponencial em erros consecutivos ──────────────────────────────────────
    if (this._syncErrorCount > 0) {
      const backoffMs = Math.min(8_000 * Math.pow(2, this._syncErrorCount - 1), 5 * 60_000);
      const elapsed   = Date.now() - (this._syncLastErrorAt || 0);
      if (elapsed < backoffMs) return;
    }

    this.syncInProgress = true;

    try {
      const previousCount = Object.values(this.state.orders).reduce((n, o) => n + Object.keys(o).length, 0);

      // Filtro de data — só pedidos de hoje
      const todayUtc = new Date();
      todayUtc.setUTCHours(0, 0, 0, 0);
      const todayFilter = `fields/Created ge '${todayUtc.toISOString()}'`;

      // ── Full-fetch via getOrdersFromStatus (confiável, sem $delta instável) ─────────
      const result = await this.sharepointManager.getOrdersFromStatus(null, {
        limit: 500,
        filter: todayFilter,
        silent: true
      });

      if (!result.success) {
        throw new Error(result.error || 'getOrdersFromStatus falhou');
      }

      // Resetar contador de erros após sucesso
      this._syncErrorCount  = 0;
      this._syncLastErrorAt = 0;

      // ── Fingerprint antes do apply para detectar mudanças reais ───────────
      const _fingerprint = orders => {
        let s = '';
        for (const loja of Object.keys(orders).sort()) {
          for (const id of Object.keys(orders[loja]).sort()) {
            const o = orders[loja][id];
            s += `${id}:${o.status}:${o.timestamp};`;
          }
        }
        return s;
      };
      const fingerprintBefore = _fingerprint(this.state.orders);

      this._applyOrdersResult(result.orders, Date.now());

      const newCount = Object.values(this.state.orders).reduce((n, o) => n + Object.keys(o).length, 0);
      const fingerprintAfter = _fingerprint(this.state.orders);
      const hasChanges = fingerprintBefore !== fingerprintAfter;

      if (newCount !== previousCount) {
        console.log(`[PickingState] 🔄 Sync SP — pedidos: ${previousCount} → ${newCount}`);
      }

      this._broadcastState();

      // Só notificar a UI se algo realmente mudou — evita re-render desnecessário
      if (hasChanges) {
        window.dispatchEvent(new CustomEvent('nexos-picking-refresh', {
          detail: { reason: 'sp_sync', ts: Date.now() }
        }));
      }

      await this._detectConflicts();

      // ── Processar confirmações pendentes (order_confirmed que não atingiram SP) ──
      await this._processPendingConfirmations();

      // ── Exibir toasts pendentes gravados pela aba Uber (fill_complete / order_confirmed) ──
      await this._processPendingToasts();

      // ── Verificar alertas de outros usuários (alerta_usuario na timeline SP) ──
      await this._checkPendingAlerts();

    } catch (error) {
      const errMsg = error.message || String(error);
      // Contexto invalidado: parar o sync silenciosamente (não incrementar backoff)
      if (errMsg.includes('Extension context invalidated')) {
        console.debug('[PickingState] contexto invalidado durante sync — interrompendo');
        if (this.autoSyncInterval) { clearInterval(this.autoSyncInterval); this.autoSyncInterval = null; }
        if (this.uiRefreshInterval) { clearInterval(this.uiRefreshInterval); this.uiRefreshInterval = null; }
      } else {
        this._syncErrorCount  = (this._syncErrorCount  || 0) + 1;
        this._syncLastErrorAt = Date.now();
        const backoffSec = Math.min(8 * Math.pow(2, this._syncErrorCount - 1), 300);
        console.error(`[PickingState] ❌ Erro na sincronização (tentativa ${this._syncErrorCount}, próxima em ~${backoffSec}s):`, errMsg);
        if (error.isTokenExpired) {
          await this._handleTokenExpired();
        }
      }
    } finally {
      this.syncInProgress = false;
    }
  }

  /**
   * Converte os itens brutos retornados pelo endpoint delta (sem processamento de Pedidos)
   * para o formato de array esperado por _applyOrdersResult.
   * Nota: diferente de getOrdersFromStatus, o delta não busca Nexos_Pedidos por item —
   * usamos apenas os campos disponíveis no próprio item de status.
   */
  async _normalizeRawDeltaItems(items) {
    return items
      .filter(item => item.fields?.PedidoGPAID)
      .map(item => {
        const f = item.fields || {};

        // Observacoes contém o JSON completo do pedido (salvo em savePedidoExtraido)
        // Inclui nome_cliente, celular_cliente, endereco_completo, etc.
        let obs = {};
        try { obs = JSON.parse(f.Observacoes || '{}'); } catch (_) {}

        const extraidoPor      = obs.extraido_por      || obs.usuario           || null;
        const extraidoPorEmail = obs.usuario            || obs.usuario_email     || null;

        // Dados do cliente — presentes diretamente no obs (dados do pedido completo)
        const nome_cliente    = obs.nome_cliente    || obs.nomeCliente    || obs.cliente    || null;
        const telefone        = obs.celular_cliente || obs.telefone_cliente || obs.celularCliente || obs.telefone || null;
        const endereco_completo = f.EnderecoCompleto || obs.endereco_completo || obs.enderecoCompleto || obs.endereco || null;
        const valor           = f.ValorSolicitacao  || obs.valor_pedido  || obs.valorPedido || obs.valor || null;
        const modalidade      = f.ModalidadedeEnvio || f.Modalidade      || obs.modalidade  || null;

        return {
          id:               item.id,
          itemId:           item.id,
          orderID:          f.Title || f.LinkTitle,
          pedido_id:        f.PedidoGPAID,
          loja:             f.Title?.split('-')[2] || obs.loja || obs.numero_loja || '',
          status:           f.StatusPicking,
          platform:         f.PlataformadeEnvio || f.Plataforma || obs.platform || null,
          modalidade_envio: modalidade,
          modalidade,
          created:          f.DataCriacao || item.createdDateTime || null,
          extractedBy:      extraidoPor,
          extractedByEmail: extraidoPorEmail,
          // ✅ Dados do cliente extraídos do JSON completo em Observacoes
          nome_cliente,
          telefone,
          endereco_completo,
          complemento: f.Complemento || obs.complemento || null,
          valor,
          data: {
            // Mesclar o obs completo como base + campos específicos garantidos
            ...obs,
            observacoes:        f.Observacoes,
            log:                f.LogOperacoes,
            tracking_link:      (typeof f.TrackingLink === 'string' ? f.TrackingLink : f.TrackingLink?.Url) || f.LinkdeRastreamento || obs.tracking_link || null,
            valor:              valor,
            modalidade_envio:   modalidade,
            extraido_por:       extraidoPor,
            extraido_por_email: extraidoPorEmail,
          },
          raw: item
        };
      });
  }

  /**
   * 🆕 V3.0: Detectar conflitos de edição
   */
  async _detectConflicts() {
    // TODO: Implementar detecção de conflitos
    // Por enquanto, apenas executa (sem log)
  }

  /**
   * 🔄 Processar confirmações de pedido pendentes (order_confirmed que falharam ao atingir o SP).
   * Executado após cada sync bem-sucedido com o SharePoint.
   */
  async _processPendingConfirmations() {
    if (!this.sharepointEnabled || !this.sharepointManager || !this.sharepointManager.initialized) return;
    if (!this.isExtensionContextValid()) return;

    try {
      const res = await new Promise(resolve =>
        chrome.storage.local.get(['nexos_pending_confirmations'], resolve)
      );
      const pending = Array.isArray(res?.nexos_pending_confirmations) ? res.nexos_pending_confirmations : [];
      if (pending.length === 0) return;

      const TTL_MS = 24 * 60 * 60 * 1000; // 24h
      const now = Date.now();
      const toProcess = pending.filter(p => p.savedAt && (now - p.savedAt) < TTL_MS);
      const remaining = [];

      for (const entry of toProcess) {
        const { pedidoId, loja, confirmUpdates } = entry;
        if (!pedidoId) continue;
        try {
          await this.sharepointManager.updateOrder(loja || '', pedidoId, confirmUpdates);
          console.log('[PickingState] ✅ Confirmação pendente processada:', pedidoId);
          window.dispatchEvent(new CustomEvent('nexos-picking-refresh', {
            detail: { reason: 'pending_confirmation', pedidoId, loja, ts: Date.now() }
          }));
        } catch (e) {
          console.warn('[PickingState] ⚠️ Falha ao processar confirmação pendente:', pedidoId, e?.message || e);
          remaining.push(entry);
        }
      }

      const updatedPending = remaining; // expirados são descartados
      chrome.storage.local.set({ nexos_pending_confirmations: updatedPending.length ? updatedPending : null });

      if (toProcess.length > remaining.length) {
        console.log(`[PickingState] ✅ ${toProcess.length - remaining.length} confirmações pendentes sincronizadas com SP.`);
        window.dispatchEvent(new CustomEvent('nexos-picking-refresh', {
          detail: { reason: 'sp_sync', ts: Date.now() }
        }));
      }
    } catch (e) {
      console.warn('[PickingState] ⚠️ Erro ao processar confirmações pendentes:', e?.message || e);
    }
  }

  /**
   * 🔔 Exibir toasts pendentes gravados pelo content.js quando o overlay estava inativo.
   * Chamado no mesmo ciclo de syncWithSharePoint, após _processPendingConfirmations.
   */
  async _processPendingToasts() {
    if (!this.isExtensionContextValid()) return;
    try {
      const res = await new Promise(resolve =>
        chrome.storage.local.get(['nexos_pending_toasts'], resolve)
      );
      const toasts = Array.isArray(res?.nexos_pending_toasts) ? res.nexos_pending_toasts : [];
      if (toasts.length === 0) return;

      const TTL_MS = 5 * 60 * 1000; // descartar toasts com mais de 5 min (já irrelevantes)
      const now = Date.now();
      const fresh = toasts.filter(t => t.savedAt && (now - t.savedAt) < TTL_MS);

      if (fresh.length > 0) {
        // Exibir via NexosUI.showToast (overlay) ou dispatchEvent como fallback
        for (const t of fresh) {
          try {
            if (window.NexosUI?.showToast) {
              window.NexosUI.showToast(t.message, t.type || 'info', t.duration || 6000);
            } else {
              window.dispatchEvent(new CustomEvent('nexos-show-toast', { detail: t }));
            }
          } catch (_) {}
        }
        console.log(`[PickingState] 🔔 ${fresh.length} toast(s) pendente(s) exibido(s).`);
      }

      // Limpar tudo (exibidos + expirados)
      chrome.storage.local.set({ nexos_pending_toasts: null });
    } catch (e) {
      console.warn('[PickingState] ⚠️ Erro ao processar toasts pendentes:', e?.message || e);
    }
  }

  /**
   * 🔔 Verificar alertas de outros usuários na Nexos_TimelinePedidos (tipo alerta_usuario).
   * Executa no máximo 1x por minuto para não sobrecarregar o SP.
   */
  async _checkPendingAlerts() {
    if (!this.sharepointEnabled || !this.sharepointManager || !this.sharepointManager.initialized) return;
    if (!this.isExtensionContextValid()) return;

    // Throttle: 1x por minuto
    const THROTTLE_MS = 60 * 1000;
    const now = Date.now();
    if (this._lastAlertCheckAt && (now - this._lastAlertCheckAt) < THROTTLE_MS) return;

    const sinceMs = this._lastAlertCheckAt || (now - 5 * 60 * 1000); // na 1ª vez, checar últimos 5min
    this._lastAlertCheckAt = now;

    try {
      const currentUser = this.state?.currentUser || window._nexosCurrentUser || window.NexosAuth?.getCurrentUser();
      const myEmail = (currentUser?.email || '').toLowerCase().trim();
      if (!myEmail) return;

      const alerts = await this.sharepointManager.getRecentAlerts(myEmail, sinceMs);
      for (const alert of alerts) {
        // Notificação desktop (background.js)
        try {
          chrome.runtime.sendMessage({
            action: 'notify',
            title: `🔔 Alerta — Pedido #${alert.pedidoId}`,
            message: alert.message
          });
        } catch (_) {}
        // Toast no overlay
        window.NexosUI?.showToast(
          `🔔 ${alert.message}`,
          'warning', 8000
        );
        console.log(`[PickingState] 🔔 Alerta recebido de ${alert.from}: pedido ${alert.pedidoId}`);
      }
    } catch (e) {
      console.warn('[PickingState] ⚠️ Erro ao verificar alertas:', e?.message || e);
    }
  }

  /**
   * Limpar locks expirados (>5 minutos)
   */
  async cleanExpiredLocks() {
    // 🆕 V3.0: Limpar locks expirados do SharePoint (pedidos pendentes > 10 min)
    if (this.sharepointEnabled && this.sharepointManager && this.sharepointManager.initialized) {
      try {
        // ⏱️ Re-sincronizar relógio com servidor no máximo 1x a cada 5 minutos.
        // Evita centenas de HEAD requests ao Graph a cada ciclo de 10s.
        const SYNC_INTERVAL_MS = 5 * 60 * 1000;
        const now0 = Date.now();
        if (!this._lastServerSync || (now0 - this._lastServerSync) >= SYNC_INTERVAL_MS) {
          try {
            await this.sharepointManager._syncServerTime();
            this._lastServerSync = now0;
          } catch (_) { /* silencioso — offset permanece o último valor válido */ }
        }

        // Buscar todos os pedidos pendentes
        const result = await this.sharepointManager.getOrdersFromStatus('pendente', {
          limit: 500,
          silent: true
        });
        
        if (result.success && result.orders.length > 0) {
        // ⏱️ Usar UTC real do servidor (corrige relógio local errado)
        const now = this.sharepointManager._nowUtcMs();
          let cleaned = 0;
          
          for (const order of result.orders) {
            // � Cada cliente só limpa seus próprios locks — evita que máquinas com
            // relógio errado deletem pedidos de outros usuários.
            const myEmail = (this.state?.currentUser?.email || window._nexosCurrentUser?.email || '').toLowerCase().trim();
            const lockOwnerEmail = (order.extractedByEmail || '').toLowerCase().trim();
            if (myEmail && lockOwnerEmail && lockOwnerEmail !== myEmail) {
              // Lock pertence a outro usuário — pular, deixa ele mesmo limpar
              continue;
            }

            // 🛡️ Usar DataCriacao como fonte para checar expiração do lock.
            // Fallback para createdDateTime (campo de sistema do SP, sempre preenchido).
            if (!order.created) {
              console.warn(`[PickingState] ⚠️ Pedido ${order.pedido_id} sem DataCriacao — ignorado no cleanup`);
              continue;
            }
            const createdTs = new Date(order.created).getTime();
            if (isNaN(createdTs) || createdTs <= 0) {
              console.warn(`[PickingState] ⚠️ Pedido ${order.pedido_id} com DataCriacao inválida (${order.created}) — ignorado`);
              continue;
            }

            // 🛡️ Grace period: nunca deletar item com menos de 60s de vida (evita race condition com criação)
            if ((now - createdTs) < 60 * 1000) {
              continue; // item muito recente — aguardar próximo ciclo
            }

            const lockTimeout = 10 * 60 * 1000; // 10 minutos
            if ((now - createdTs) <= lockTimeout) continue; // ainda dentro do prazo

            // ── Lock expirado: deletar pedido (hardDelete) ──
            console.log(`[PickingState] ⏰ Lock expirado — deletando pedido automaticamente: ${order.pedido_id} (${order.orderID})`);
            
            try {
              // ✅ Deletar o item do SharePoint (hardDelete = true)
              await this.sharepointManager.deleteOrderByItemId(order.itemId, true);
              
              // Registrar na timeline com o OrderID correto
              await this.sharepointManager.addTimelineEvent(order.pedido_id, 'lock_expirado', {
                usuario: 'Sistema',
                detalhes: `Lock expirado após 10 minutos — pedido removido automaticamente`,
                loja: order.loja,
                orderID: order.orderID  // ✅ NEXOS-timestamp-loja-pedido
              });
              
              // ✅ Disparar evento de refresh visual
              window.dispatchEvent(new CustomEvent('nexos-picking-refresh', {
                detail: { 
                  reason: 'pedido_expirado', 
                  pedidoId: order.pedido_id,
                  timestamp: Date.now()
                }
              }));
              
              cleaned++;
            } catch (expireError) {
              console.error(`[PickingState] ❌ Erro ao cancelar pedido expirado ${order.pedido_id}:`, expireError);
            }
          }
          
          if (cleaned > 0) {
            console.log(`[PickingState] ✅ ${cleaned} pedidos expirados removidos do SharePoint`);
            // Forçar refresh para atualizar UI
            await this.syncWithSharePoint();
          }
        }
      } catch (error) {
        console.error('[PickingState] ❌ Erro ao limpar locks expirados:', error);
      }
      
      return; // Não processar locks locais se SharePoint ativo
    }
    
    // 🔄 FALLBACK: Limpar locks locais (quando SharePoint não disponível)
    const now = Date.now();
    const timeout = 5 * 60 * 1000; // 5 minutos
    let cleaned = 0;
    
    for (const [pedidoId, lock] of Object.entries(this.state.locks)) {
      if (now - lock.timestamp > timeout) {
        delete this.state.locks[pedidoId];
        cleaned++;
        
        // Adicionar evento de unlock automático
        this.addTimelineEvent(pedidoId, {
          type: 'lock_expired',
          user: 'Sistema',
          message: `Lock expirado (>5min) - ${lock.user}`
        });
      }
    }
    
    if (cleaned > 0) {
      console.log(`[PickingState] 🧹 ${cleaned} locks locais expirados removidos`);
      await this.saveToStorage();
      this.notifyListeners('locks_cleaned', { count: cleaned });
    }
  }

  /**
   * ⏰ Finalizar automaticamente pedidos SOLICITADOS com mais de 2 horas sem interação.
   * Executado no mesmo ciclo de cleanExpiredLocks (a cada 8s, mas a query ao SP ocorre max 1x/5min).
   */
  async cleanExpiredSolicitados() {
    if (!this.sharepointEnabled || !this.sharepointManager || !this.sharepointManager.initialized) return;
    if (!this.isExtensionContextValid()) return;

    // ⏱️ Throttle: executar no máximo 1x a cada 5 minutos (evitar excesso de requests ao SP)
    const THROTTLE_MS = 5 * 60 * 1000;
    const now = Date.now();
    if (this._lastSolicitadoCleanAt && (now - this._lastSolicitadoCleanAt) < THROTTLE_MS) return;
    this._lastSolicitadoCleanAt = now;

    try {
      const result = await this.sharepointManager.getOrdersFromStatus('solicitado', {
        limit: 200,
        silent: true
      });
      if (!result.success || result.orders.length === 0) return;

      const TWO_HOURS_MS = 2 * 60 * 60 * 1000;
      const nowUtc = this.sharepointManager._nowUtcMs ? this.sharepointManager._nowUtcMs() : now;
      let autoFinalized = 0;

      for (const order of result.orders) {
        // Usar timestamp de carregamento (solicitação) como referência; fallback: DataCriacao
        const ref = order.data?.horario_envio || order.timestamp_carregamento
          || order.data?.timestamp_carregamento || order.created || null;
        if (!ref) continue;

        const refTs = typeof ref === 'number' ? ref : new Date(ref).getTime();
        if (isNaN(refTs) || refTs <= 0) continue;
        if ((nowUtc - refTs) < TWO_HOURS_MS) continue; // ainda dentro do prazo

        const pedidoId = order.pedido_id || order.pedido;
        const loja = order.loja || '';
        console.log(`[PickingState] ⏰ Pedido solicitado há +2h — finalizando automaticamente: ${pedidoId}`);

        try {
          await this.sharepointManager.updateOrder(loja, pedidoId, {
            status: 'finalizado',
            __skipTimeline: true
          });
          await this.sharepointManager.addTimelineEvent(pedidoId, 'finalizado_automatico', {
            orderID: order.orderID || null,
            loja,
            detalhes: 'Pedido finalizado automaticamente após 2 horas em status Solicitado',
            usuario: 'Sistema'
          });
          window.dispatchEvent(new CustomEvent('nexos-picking-refresh', {
            detail: { reason: 'auto_finalizado', pedidoId, loja, ts: Date.now() }
          }));
          autoFinalized++;
        } catch (e) {
          console.warn(`[PickingState] ⚠️ Falha ao auto-finalizar pedido ${pedidoId}:`, e?.message || e);
        }
      }

      if (autoFinalized > 0) {
        console.log(`[PickingState] ✅ ${autoFinalized} pedido(s) solicitado(s) finalizados automaticamente (>2h).`);
        window.NexosUI?.showToast(
          `⏰ ${autoFinalized} pedido(s) finalizado(s) automaticamente por inatividade (>2h).`,
          'warning', 7000
        );
        await this.syncWithSharePoint();
      }
    } catch (e) {
      console.warn('[PickingState] ⚠️ Erro em cleanExpiredSolicitados:', e?.message || e);
    }
  }

  /**
   * Obter pedido por ID
   */
  getOrder(loja, pedidoId) {
    const orders = this.state.orders[loja];
    if (!orders) return null;
    return orders[pedidoId] || null;
  }
  
  /**
   * Obter todos os pedidos
   */
  getAllOrders() {
    return this.state.orders;
  }
  
  /**
   * Obter pedidos filtrados
   */
  getOrdersFiltered(filters = {}) {
    const { status, loja, search } = filters;
    const result = {};
    
    for (const [lojaNum, orders] of Object.entries(this.state.orders)) {
      if (loja && lojaNum !== loja) continue;
      
      for (const [pedidoId, order] of Object.entries(orders)) {
        // Filtro de status
        if (status && order.status !== status) continue;
        
        // Filtro de busca
        if (search) {
          const searchLower = search.toLowerCase();
          const matchPedido = pedidoId.toLowerCase().includes(searchLower);
          const matchLoja = lojaNum.includes(searchLower);
          const matchCliente = order.nome_cliente?.toLowerCase().includes(searchLower);
          
          if (!matchPedido && !matchLoja && !matchCliente) continue;
        }
        
        if (!result[lojaNum]) result[lojaNum] = {};
        result[lojaNum][pedidoId] = order;
      }
    }
    
    return result;
  }
  
  /**
   * Adicionar ou atualizar pedido
   */
  async setOrder(loja, pedidoId, orderData) {
    if (!this.state.orders[loja]) {
      this.state.orders[loja] = {};
    }
    
    const isNew = !this.state.orders[loja][pedidoId];
    this.state.orders[loja][pedidoId] = orderData;
    
    // 🆕 V3.0: Salvar no SharePoint primeiro
    if (this.sharepointEnabled && this.sharepointManager && this.sharepointManager.initialized) {
      try {
        console.log(`[PickingState] 🌐 Salvando pedido no SharePoint: ${loja}/${pedidoId}`);
        
        // Verificar se pedido já existe no SharePoint
        let existing = await this.sharepointManager.getOrder(loja, pedidoId, { maxRetries: 1 });
        // Se não encontrado por OrderID/LinkTitle, tentar buscar em Nexos_StatusPedidos por PedidoGPAID
        if (!existing || !existing.success) {
          try {
            const fallback = await this.sharepointManager.getOrdersFromStatus(null, { filter: `fields/PedidoGPAID eq '${pedidoId}'`, limit: 1, silent: true });
            if (fallback && fallback.success && fallback.orders && fallback.orders.length > 0) {
              existing = { success: true, orders: fallback.orders, itemId: fallback.orders[0].itemId, orderID: fallback.orders[0].orderID };
              console.log('[PickingState] 🔎 Pedido encontrado em Nexos_StatusPedidos via fallback PedidoGPAID');
            }
          } catch (e) {
            console.warn('[PickingState] ⚠️ Fallback getOrdersFromStatus falhou:', e.message || e);
          }
        }

        if (existing && existing.success) {
          // UPDATE — passar itemId para evitar nova busca interna (já resolvemos acima)
          console.log('[PickingState] 📝 Atualizando pedido existente no SharePoint...');
          await this.sharepointManager.updateOrder(loja, pedidoId, {
            itemId:              existing.itemId || null,
            status:              orderData.status || 'pendente',
            platform:            orderData.platform || orderData.plataforma || 'manual',
            tracking_link:       orderData.tracking_link || orderData.trackingLink || null,
            valor_transporte:    orderData.valor_transporte || orderData.valor || orderData.valor_pedido || null,
            veiculo:             orderData.veiculo || orderData.vehicle || null,
            timestamp_carregamento: orderData.timestamp_carregamento || null,
            data: orderData
          });
        } else {
          // CREATE
          console.log('[PickingState] ➕ Criando novo pedido no SharePoint...');
          await this.sharepointManager.createOrder({
            loja: loja,
            pedido_id: pedidoId,
            status: orderData.status || 'pendente',
            platform: orderData.platform || 'manual',
            data: orderData
          });
        }
        
  console.log('[PickingState] ✅ Pedido salvo no SharePoint com sucesso!');
  // 📡 Propagar mudança para todas as tabs instantaneamente via onChanged
  this._broadcastState();
  // Disparar evento global para atualizar outras abas/overlays
  window.dispatchEvent(new CustomEvent('nexos-picking-refresh', { detail: { reason: 'setOrder_saved', loja, pedidoId } }));
        
        // Invalidar cache para forçar refresh na próxima leitura
        this.cache.lastRefresh = null;
        
      } catch (spError) {
        console.error('[PickingState] ❌ Erro ao salvar no SharePoint:', spError);
        console.warn('[PickingState] ⚠️ Salvando apenas localmente como fallback');
        // Continua para salvar localmente como fallback
      }
    }
    
    // Adicionar evento de timeline
    if (isNew) {
      this.addTimelineEvent(pedidoId, {
        type: 'extracted',
        user: this.state.currentUser?.name || 'Desconhecido',
        message: 'Pedido extraído do sistema'
      });
    }

    // Notificar listeners que o pedido foi atualizado/definido localmente
    try {
      this.notifyListeners('order_updated', { loja, pedidoId, order: orderData });
    } catch (e) {
      console.warn('[PickingState] ⚠️ Erro ao notificar listeners de order_updated:', e?.message || e);
    }
    
    // 🆕 V3.0: Salvar localmente apenas se SharePoint não estiver ativo
    if (!this.sharepointEnabled) {
      await this.saveToStorage();
    }
    
    this.notifyListeners('order_updated', { loja, pedidoId, orderData, isNew });
    
    console.log(`[PickingState] 📦 Pedido ${isNew ? 'adicionado' : 'atualizado'}: ${loja}/${pedidoId}`);
  }
  
  /**
   * Remover pedido
   */
  async removeOrder(loja, pedidoId) {
    if (!this.state.orders[loja] || !this.state.orders[loja][pedidoId]) {
      return false;
    }
    
    // 🆕 V3.0: Deletar do SharePoint primeiro (soft delete)
    if (this.sharepointEnabled && this.sharepointManager && this.sharepointManager.initialized) {
      try {
        console.log(`[PickingState] 🌐 Removendo pedido do SharePoint: ${loja}/${pedidoId}`);
        await this.sharepointManager.deleteOrder(loja, pedidoId, false); // Soft delete (marca como inativo)
        console.log('[PickingState] ✅ Pedido removido do SharePoint com sucesso!');
        
        // Invalidar cache
        this.cache.lastRefresh = null;
      } catch (spError) {
        console.error('[PickingState] ❌ Erro ao remover do SharePoint:', spError);
        console.warn('[PickingState] ⚠️ Continuando com remoção local...');
      }
    }
    
    delete this.state.orders[loja][pedidoId];
    
    // Limpar dados relacionados
    delete this.state.locks[pedidoId];
    delete this.state.timeline[pedidoId];
    
    // 🆕 V3.0: Salvar localmente apenas se SharePoint não estiver ativo
    if (!this.sharepointEnabled) {
      await this.saveToStorage();
    }
    
    this.notifyListeners('order_removed', { loja, pedidoId });
    
    console.log(`[PickingState] 🗑️ Pedido removido: ${loja}/${pedidoId}`);
    return true;
  }
  
  /**
   * Adicionar evento na timeline
   */
  addTimelineEvent(pedidoId, event) {
    if (!this.state.timeline[pedidoId]) {
      this.state.timeline[pedidoId] = [];
    }
    
    const timelineEvent = {
      ...event,
      timestamp: Date.now(),
      id: `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };
    
    this.state.timeline[pedidoId].push(timelineEvent);
    
    // Limitar a 50 eventos por pedido
    if (this.state.timeline[pedidoId].length > 50) {
      this.state.timeline[pedidoId] = this.state.timeline[pedidoId].slice(-50);
    }
    
    console.log(`[PickingState] 📝 Evento adicionado: ${pedidoId} - ${event.type}`);
  }
  
  /**
   * Obter timeline de um pedido
   */
  getTimeline(pedidoId) {
    return this.state.timeline[pedidoId] || [];
  }
  
  /**
   * Definir usuário atual
   */
  setCurrentUser(user) {
    if (!user) return; // ignorar chamada sem usuário válido
    this.state.currentUser = user;
    const displayName = user.name || user.displayName || user.email || 'desconhecido';
    console.log('[PickingState] 👤 Usuário definido:', displayName);
  }
  
  /**
   * Obter usuário atual
   */
  getCurrentUser() {
    return this.state.currentUser;
  }
  
  /**
   * Registrar listener para mudanças
   */
  addListener(callback) {
    this.listeners.add(callback);
    console.log('[PickingState] 👂 Listener registrado');
  }
  
  /**
   * Remover listener
   */
  removeListener(callback) {
    this.listeners.delete(callback);
    console.log('[PickingState] 👋 Listener removido');
  }
  
  /**
   * Notificar todos os listeners
   */
  notifyListeners(event, data) {
    for (const listener of this.listeners) {
      try {
        listener(event, data);
      } catch (error) {
        console.error('[PickingState] ❌ Erro ao notificar listener:', error);
      }
    }
  }
  
  /**
   * 🔐 Lidar com token expirado
   */
  async _handleTokenExpired() {
    console.log('[PickingState] 🔐 Token SP expirado — desativando SP para esta sessão.');
    // Não tenta renovação de rede aqui: em páginas de terceiro (Uber/Lalamove) o CSP
    // bloqueia login.microsoftonline.com. A renovação real ocorre quando o usuário
    // abre o Nexos Admin e faz login lá.
    this.sharepointEnabled = false;
    this.sharepointManager = null;
  }
  
  /**
   * Destruir manager
   */
  destroy() {
    this.stopAutoSync();
    this.listeners.clear();
    console.log('[PickingState] 💥 State Manager destruído');
  }
  
  /**
   * 🔥 TEMPO REAL: Atualizar timestamps visuais sem API calls
   */
  _refreshUITimestamps() {
    try {
      // Atualizar todos os badges de "extraído há X minutos"
      const timestampElements = document.querySelectorAll('[data-nexos-timestamp]');
      
      timestampElements.forEach(el => {
        const timestamp = parseInt(el.getAttribute('data-nexos-timestamp'), 10);
        if (!timestamp || isNaN(timestamp)) return;
        
        const timeAgo = this._formatTimeAgo(Date.now() - timestamp);
        el.textContent = timeAgo;
      });
      
      // Notificar listeners de atualização de UI
      this._notifyListeners('ui-refresh', { timestamp: Date.now() });
      
    } catch (error) {
      // Silencioso - não logar erro de UI refresh
    }
  }
  
  /**
   * Formatar tempo decorrido
   */
  _formatTimeAgo(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (seconds < 60) return 'Agora';
    if (minutes < 60) return `${minutes}min atrás`;
    if (hours < 24) return `${hours}h atrás`;
    return `${days}d atrás`;
  }
  
  /**
   * Parar sincronização automática
   */
  stopAutoSync() {
    if (this.autoSyncInterval) {
      clearInterval(this.autoSyncInterval);
      this.autoSyncInterval = null;
    }
    
    if (this.uiRefreshInterval) {
      clearInterval(this.uiRefreshInterval);
      this.uiRefreshInterval = null;
    }
    
    console.log('[PickingState] ⏹️ Auto-sync parado');
  }
}

// Singleton global
window.PickingStateManager = window.PickingStateManager || new PickingStateManager();

// 🆕 Exportar também como window.pickingState para facilitar acesso
window.pickingState = window.PickingStateManager;

console.log('[PickingState] 🎯 Módulo carregado');
