/**
 * SMART SEARCH - Sistema de Busca Inteligente
 * Substitui Ollama com performance < 100ms
 * 
 * Funcionalidades:
 * - Fuzzy search (busca aproximada)
 * - Detecção de intenção
 * - Extração de entidades (números de loja, códigos de erro)
 * - Sugestões contextuais
 * - Respostas naturais sem LLM
 */

class SmartSearch {
  constructor(knowledgeBase) {
    this.kb = knowledgeBase;
    this.cache = new Map(); // Cache de respostas
    this.history = []; // Histórico de consultas
    
    // Índice invertido para busca rápida
    this.index = this.buildIndex();
  }

  /**
   * Constrói índice invertido de todas as tags/palavras-chave
   */
  buildIndex() {
    const index = new Map();
    
    // Indexar procedimentos
    Object.values(this.kb.procedimentos || {}).forEach(proc => {
      proc.tags.forEach(tag => {
        if (!index.has(tag)) index.set(tag, []);
        index.get(tag).push({ tipo: 'procedimento', id: proc.id, item: proc });
      });
    });
    
    // Indexar erros
    Object.values(this.kb.erros || {}).forEach(erro => {
      erro.tags.forEach(tag => {
        if (!index.has(tag)) index.set(tag, []);
        index.get(tag).push({ tipo: 'erro', id: erro.id, item: erro });
      });
      // Indexar também pelo código
      if (!index.has(erro.codigo)) index.set(erro.codigo, []);
      index.get(erro.codigo).push({ tipo: 'erro', id: erro.id, item: erro });
    });
    
    // Indexar plataformas
    Object.values(this.kb.plataformas || {}).forEach(plat => {
      plat.tags.forEach(tag => {
        if (!index.has(tag)) index.set(tag, []);
        index.get(tag).push({ tipo: 'plataforma', id: plat.id, item: plat });
      });
    });
    
    // Indexar FAQ
    Object.values(this.kb.faq || {}).forEach(faq => {
      faq.tags.forEach(tag => {
        if (!index.has(tag)) index.set(tag, []);
        index.get(tag).push({ tipo: 'faq', id: faq.id, item: faq });
      });
    });
    
    return index;
  }

  /**
   * Busca principal - Instantânea (< 100ms)
   */
  search(query) {
    const normalized = this.normalizeQuery(query);
    
    // Cache hit?
    if (this.cache.has(normalized)) {
      return this.cache.get(normalized);
    }
    
    // Detectar tipo de consulta
    const tipo = this.detectQueryType(normalized);
    
    let resultado;
    switch (tipo.categoria) {
      case 'saudacao':
        resultado = this.handleSaudacao(tipo.subtipo);
        break;
      case 'erro':
        resultado = this.handleErro(tipo.codigo);
        break;
      case 'procedimento':
        resultado = this.handleProcedimento(normalized);
        break;
      case 'loja':
        resultado = this.handleLoja(tipo.numero);
        break;
      case 'faq':
        resultado = this.handleFAQ(normalized);
        break;
      default:
        resultado = this.fuzzySearch(normalized);
    }
    
    // Salvar em cache
    this.cache.set(normalized, resultado);
    
    // Adicionar ao histórico
    this.history.push({ query, resultado, timestamp: Date.now() });
    if (this.history.length > 100) this.history.shift();
    
    return resultado;
  }

  /**
   * Normaliza query (remove acentos, lowercase, etc)
   */
  normalizeQuery(query) {
    return query
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '') // Remove acentos
      .trim();
  }

  /**
   * Detecta tipo de consulta por padrões
   */
  detectQueryType(query) {
    // Saudações
    if (/^(oi|ola|olá|hey|e ai|eai|opa|salve)/.test(query)) {
      return { categoria: 'saudacao', subtipo: 'oi' };
    }
    if (/tudo bem|como (vai|esta|esta)|beleza/.test(query)) {
      return { categoria: 'saudacao', subtipo: 'tudo_bem' };
    }
    if (/obrigad[oa]|valeu|vlw|thanks/.test(query)) {
      return { categoria: 'saudacao', subtipo: 'obrigado' };
    }
    if (/tchau|ate logo|ate|flw|falou/.test(query)) {
      return { categoria: 'saudacao', subtipo: 'tchau' };
    }
    
    // Erros (401, 404, 500, etc)
    const erroMatch = query.match(/erro\s*(\d{3})|(\d{3})\s*erro|^(\d{3})$/);
    if (erroMatch) {
      const codigo = erroMatch[1] || erroMatch[2] || erroMatch[3];
      return { categoria: 'erro', codigo };
    }
    
    // Número de loja (0001, 1234, etc)
    const lojaMatch = query.match(/loja\s*(\d{1,4})|^(\d{1,4})$/);
    if (lojaMatch) {
      const numero = (lojaMatch[1] || lojaMatch[2]).padStart(4, '0');
      return { categoria: 'loja', numero };
    }
    
    // Procedimentos (palavras-chave)
    if (/cancelar|cancelamento/.test(query) && /pedido|picking/.test(query)) {
      return { categoria: 'procedimento', procedimento: 'cancelar_pedido_picking' };
    }
    if (/rota|tms/.test(query) && /criar|nova/.test(query)) {
      return { categoria: 'procedimento', procedimento: 'criar_rota_tms' };
    }
    if (/orkestra|comentario/.test(query)) {
      return { categoria: 'procedimento', procedimento: 'comentario_orkestra' };
    }
    
    // FAQ
    if (/turno|horario/.test(query)) {
      return { categoria: 'faq', faq: 'qual_meu_turno' };
    }
    if (/extensao|como usar/.test(query)) {
      return { categoria: 'faq', faq: 'como_usar_extensao' };
    }
    if (/sla|prazo/.test(query)) {
      return { categoria: 'faq', faq: 'sla_entregas' };
    }
    
    return { categoria: 'desconhecido' };
  }

  /**
   * Handle saudações
   */
  handleSaudacao(subtipo) {
    const saudacoes = this.kb.saudacoes[subtipo] || this.kb.saudacoes.oi;
    const resposta = saudacoes[Math.floor(Math.random() * saudacoes.length)];
    return {
      tipo: 'saudacao',
      confianca: 1.0,
      resposta
    };
  }

  /**
   * Handle erros (401, 404, 500)
   */
  handleErro(codigo) {
    const erro = this.kb.erros[codigo];
    if (!erro) {
      return {
        tipo: 'erro',
        confianca: 0,
        resposta: `Não encontrei informações sobre o erro ${codigo}. 🤔\n\nPode me dar mais detalhes sobre o problema?`
      };
    }
    
    // Formatar resposta
    let resposta = `**${erro.titulo}**\n\n`;
    resposta += `${erro.descricao}\n\n`;
    
    if (erro.causas && erro.causas.length > 0) {
      resposta += `**Possíveis causas:**\n`;
      erro.causas.forEach(causa => resposta += `${causa}\n`);
      resposta += '\n';
    }
    
    if (erro.solucoes && erro.solucoes.length > 0) {
      erro.solucoes.forEach(sol => {
        resposta += `**${sol.titulo}:**\n`;
        sol.passos.forEach((passo, i) => {
          resposta += `${i + 1}. ${passo}\n`;
        });
        resposta += '\n';
      });
    }
    
    if (erro.prevencao && erro.prevencao.length > 0) {
      resposta += `**Como evitar:**\n`;
      erro.prevencao.forEach(dica => resposta += `${dica}\n`);
    }
    
    return {
      tipo: 'erro',
      confianca: 1.0,
      dados: erro,
      resposta
    };
  }

  /**
   * Handle procedimentos
   */
  handleProcedimento(query) {
    // Buscar no índice
    const matches = [];
    
    Object.values(this.kb.procedimentos || {}).forEach(proc => {
      const score = this.calculateRelevanceScore(query, proc);
      if (score > 0.3) {
        matches.push({ proc, score });
      }
    });
    
    // Ordenar por relevância
    matches.sort((a, b) => b.score - a.score);
    
    if (matches.length === 0) {
      return {
        tipo: 'procedimento',
        confianca: 0,
        resposta: 'Não encontrei um procedimento específico para isso. Tenta reformular ou digita "ajuda" para ver o que posso fazer!'
      };
    }
    
    const melhor = matches[0].proc;
    
    // Formatar resposta
    let resposta = `**${melhor.titulo}**\n\n`;
    
    if (melhor.passos && melhor.passos.length > 0) {
      resposta += `**Passo a passo:**\n`;
      melhor.passos.forEach((passo, i) => {
        resposta += `${i + 1}. ${passo}\n`;
      });
      resposta += '\n';
    }
    
    if (melhor.avisos && melhor.avisos.length > 0) {
      resposta += `**Atenção:**\n`;
      melhor.avisos.forEach(aviso => resposta += `${aviso}\n`);
      resposta += '\n';
    }
    
    if (melhor.dicas && melhor.dicas.length > 0) {
      resposta += `**Dicas:**\n`;
      melhor.dicas.forEach(dica => resposta += `${dica}\n`);
    }
    
    return {
      tipo: 'procedimento',
      confianca: matches[0].score,
      dados: melhor,
      resposta
    };
  }

  /**
   * Handle consulta de loja (delegado para sistema existente)
   */
  handleLoja(numero) {
    return {
      tipo: 'loja',
      confianca: 1.0,
      numero,
      resposta: null, // Será tratado pelo sistema existente de lojas
      delegarPara: 'sistema_lojas'
    };
  }

  /**
   * Handle FAQ
   */
  handleFAQ(query) {
    const matches = [];
    
    Object.values(this.kb.faq || {}).forEach(faq => {
      const score = this.calculateRelevanceScore(query, faq);
      if (score > 0.3) {
        matches.push({ faq, score });
      }
    });
    
    matches.sort((a, b) => b.score - a.score);
    
    if (matches.length === 0) {
      return { tipo: 'faq', confianca: 0, resposta: null };
    }
    
    const melhor = matches[0].faq;
    
    return {
      tipo: 'faq',
      confianca: matches[0].score,
      dados: melhor,
      resposta: `**${melhor.pergunta}**\n\n${melhor.resposta}`
    };
  }

  /**
   * Fuzzy search quando não detecta categoria específica
   */
  fuzzySearch(query) {
    const palavras = query.split(/\s+/);
    const matches = new Set();
    
    // Buscar por cada palavra no índice
    palavras.forEach(palavra => {
      // Exata
      if (this.index.has(palavra)) {
        this.index.get(palavra).forEach(m => matches.add(m));
      }
      
      // Aproximada (Levenshtein simplificado)
      this.index.forEach((items, tag) => {
        if (this.similaridade(palavra, tag) > 0.7) {
          items.forEach(m => matches.add(m));
        }
      });
    });
    
    if (matches.size === 0) {
      return {
        tipo: 'desconhecido',
        confianca: 0,
        resposta: 'Hmm, não entendi muito bem... 🤔\n\nPode reformular? Ou digita "ajuda" que eu te mostro o que posso fazer!'
      };
    }
    
    // Retornar melhor match
    const melhorMatch = Array.from(matches)[0];
    
    // Delegar para handler específico
    switch (melhorMatch.tipo) {
      case 'erro':
        return this.handleErro(melhorMatch.item.codigo);
      case 'procedimento':
        return this.handleProcedimento(query);
      case 'faq':
        return this.handleFAQ(query);
      default:
        return { tipo: 'desconhecido', confianca: 0.5, resposta: 'Encontrei algo, mas não tenho certeza...' };
    }
  }

  /**
   * Calcula score de relevância entre query e item
   */
  calculateRelevanceScore(query, item) {
    let score = 0;
    const palavrasQuery = query.split(/\s+/);
    
    // Checar tags
    if (item.tags) {
      item.tags.forEach(tag => {
        palavrasQuery.forEach(palavra => {
          if (tag.includes(palavra) || palavra.includes(tag)) {
            score += 0.5;
          }
        });
      });
    }
    
    // Checar título
    if (item.titulo) {
      const tituloNorm = this.normalizeQuery(item.titulo);
      palavrasQuery.forEach(palavra => {
        if (tituloNorm.includes(palavra)) {
          score += 0.3;
        }
      });
    }
    
    // Checar descrição
    if (item.descricao) {
      const descNorm = this.normalizeQuery(item.descricao);
      palavrasQuery.forEach(palavra => {
        if (descNorm.includes(palavra)) {
          score += 0.1;
        }
      });
    }
    
    return Math.min(score, 1.0); // Max 1.0
  }

  /**
   * Calcula similaridade entre duas strings (Levenshtein simplificado)
   */
  similaridade(s1, s2) {
    if (s1 === s2) return 1.0;
    if (s1.length === 0 || s2.length === 0) return 0;
    
    // Substring comum
    if (s1.includes(s2) || s2.includes(s1)) return 0.8;
    
    // Levenshtein básico
    const maxLen = Math.max(s1.length, s2.length);
    let distance = 0;
    
    for (let i = 0; i < Math.min(s1.length, s2.length); i++) {
      if (s1[i] !== s2[i]) distance++;
    }
    distance += Math.abs(s1.length - s2.length);
    
    return 1 - (distance / maxLen);
  }

  /**
   * Gera sugestões de auto-complete
   */
  suggest(partialQuery) {
    if (partialQuery.length < 2) return [];
    
    const normalized = this.normalizeQuery(partialQuery);
    const sugestoes = new Set();
    
    // Buscar em procedimentos
    Object.values(this.kb.procedimentos || {}).forEach(proc => {
      if (this.normalizeQuery(proc.titulo).includes(normalized)) {
        sugestoes.add(proc.titulo);
      }
    });
    
    // Buscar em erros
    Object.values(this.kb.erros || {}).forEach(erro => {
      if (erro.codigo.includes(normalized) || 
          this.normalizeQuery(erro.titulo).includes(normalized)) {
        sugestoes.add(`Erro ${erro.codigo}`);
      }
    });
    
    // Buscar em FAQ
    Object.values(this.kb.faq || {}).forEach(faq => {
      if (this.normalizeQuery(faq.pergunta).includes(normalized)) {
        sugestoes.add(faq.pergunta);
      }
    });
    
    // Limitar a 5 sugestões
    return Array.from(sugestoes).slice(0, 5);
  }

  /**
   * Limpa cache
   */
  clearCache() {
    this.cache.clear();
  }

  /**
   * Obtém estatísticas de uso
   */
  getStats() {
    const categorias = {};
    this.history.forEach(h => {
      const cat = h.resultado.tipo || 'desconhecido';
      categorias[cat] = (categorias[cat] || 0) + 1;
    });
    
    return {
      totalConsultas: this.history.length,
      categorias,
      cacheSize: this.cache.size,
      indexSize: this.index.size
    };
  }
}

// Exportar para uso global
if (typeof window !== 'undefined') {
  window.SmartSearch = SmartSearch;
}
