/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - OVERLAY TEMPLATE
 * Template base padronizado para todos os overlays
 * Versão: 2.2.2
 * ═══════════════════════════════════════════════════════════════════════════
 */

(function() {
  'use strict';

  // Garantir que só inicialize uma vez
  if (window.NexosOverlay) {
    console.log('[NexosOverlay] Já inicializado');
    return;
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     OVERLAY BUILDER
     ══════════════════════════════════════════════════════════════════════════ */

  class OverlayBuilder {
    constructor(config) {
      this.config = {
        title: 'Nexos Torre',
        subtitle: '',
        platform: 'generic',
        requireAuth: true,
        showSidebar: true,
        showFooter: true,
        theme: 'auto',
        layout: 'side-panel', // 'fullscreen' ou 'side-panel' (padrão: side-panel 1/3 direita)
        ...config
      };

      this.overlay = null;
      this.header = null;
      this.sidebar = null;
      this.content = null;
      this.footer = null;
      this.themeManager = null;
      this.user = null;
    }

    /**
     * Aguarda NexosAuth estar disponível
     */
    async waitForNexosAuth(timeout = 5000) {
      const startTime = Date.now();
      
      while (!window.NexosAuth || !window.NexosAuth.authManager) {
        if (Date.now() - startTime > timeout) {
          console.error('[OverlayBuilder] ⏱️ Timeout aguardando NexosAuth');
          return false;
        }
        
        console.log('[OverlayBuilder] ⏳ Aguardando NexosAuth...');
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      
      console.log('[OverlayBuilder] ✅ NexosAuth disponível');
      return true;
    }

    /**
     * Constrói overlay completo
     */
    async build() {
      console.log('[OverlayBuilder] Construindo overlay:', this.config.platform);

      // 1. Injeta dependências PRIMEIRO
      await this.injectDependencies();

      // 2. Cria estrutura do overlay ANTES da autenticação
      this.createStructure();

      // 3. Verifica autenticação (agora pode renderizar DENTRO do overlay)
      if (this.config.requireAuth) {
        // Se user foi passado na config, usa ele diretamente
        if (this.config.user) {
          console.log('[OverlayBuilder] ✅ Usuário fornecido na config:', this.config.user.displayName || this.config.user.name);
          this.user = this.config.user;
        } else {
          // Aguarda NexosAuth estar disponível (com timeout de 5s)
          const authAvailable = await this.waitForNexosAuth();
          
          if (!authAvailable) {
            console.error('[OverlayBuilder] ❌ NexosAuth não disponível após timeout!');
            console.error('[OverlayBuilder] 💡 Certifique-se que nexos-auth-system.js foi carregado antes');
            if (this.overlay && this.overlay.parentNode) {
              this.overlay.remove();
            }
            return null;
          }

          // Verifica se já está autenticado
          const isAuth = await window.NexosAuth.isAuthenticated();
          console.log('[OverlayBuilder] 🔐 Status de autenticação:', isAuth);
          
          if (!isAuth) {
            // Não está autenticado, mostra login DENTRO do content do overlay
            console.log('[OverlayBuilder] ⚠️ Usuário não autenticado, mostrando login no overlay...');
            
            // ⚠️ ESCONDER TOAST DE LOADING (se existir)
            if (typeof window.hidePickingLoadingProgress === 'function') {
              window.hidePickingLoadingProgress();
              console.log('[OverlayBuilder] 🔄 Toast de loading escondido para mostrar login');
            }
            
            // ⚠️ IMPORTANTE: Adiciona overlay ao DOM ANTES de mostrar login inline
            // para que o login seja visível na tela
          document.body.appendChild(this.overlay);
          console.log('[OverlayBuilder] 📍 Overlay adicionado ao DOM antes do login inline');
          
          // Adiciona evento para fechar ao clicar fora do overlay
          this.loginClickOutsideHandler = (e) => {
            // Se clicou fora do overlay (no backdrop virtual)
            if (e.target === this.overlay) {
              console.log('[OverlayBuilder] 👆 Clique fora do overlay detectado, fechando...');
              this.close();
            }
          };
          this.overlay.addEventListener('click', this.loginClickOutsideHandler);
          
          this.user = await window.NexosAuth.requireAuth({ 
            silent: false,
            container: this.content  // ← Login aparece DENTRO do overlay
          });
          
          // Se ainda não tem usuário após tentar login, fecha overlay
          if (!this.user) {
            console.error('[OverlayBuilder] ❌ Autenticação cancelada pelo usuário');
            
            // Esconder toast de loading se ainda existir
            if (typeof window.hidePickingLoadingProgress === 'function') {
              window.hidePickingLoadingProgress();
            }
            
            // Remove listener
            if (this.loginClickOutsideHandler) {
              this.overlay.removeEventListener('click', this.loginClickOutsideHandler);
              this.loginClickOutsideHandler = null;
            }
            if (this.overlay && this.overlay.parentNode) {
              this.overlay.remove();
            }
            return null;
          }
          
          // Login bem-sucedido: Remove listener e limpa content
          if (this.loginClickOutsideHandler) {
            this.overlay.removeEventListener('click', this.loginClickOutsideHandler);
            this.loginClickOutsideHandler = null;
          }
          this.content.innerHTML = '';
          
          // 🎉 MOSTRAR ANIMAÇÃO DE BOAS-VINDAS
          await this.showWelcomeAnimation(this.user);

          // 🛡️ VERIFICAR STATUS DO USUÁRIO NO SHAREPOINT APÓS LOGIN
          // Estratégia: aproveitar o _silentUserStatusCheck já executado em page load
          // para evitar chamar SP duas vezes (que causaria duplicata de registros).
          // Só chama ensureUserRegistered se o silent check ainda não determinou o status.
          {
            // Esperar nexosAccessCheckPending terminar (max 5s)
            let waited = 0;
            while (window.nexosAccessCheckPending && waited < 50) {
              await new Promise(r => setTimeout(r, 100));
              waited++;
            }

            if (window.nexosUserBlocked) {
              // Flag setado pelo silent check — usuário pendente/rejeitado.
              // Buscar status do cache e renderizar DENTRO do overlay (não tela cheia).
              console.log('[OverlayBuilder] 🚫 Usuário bloqueado — exibindo aviso no overlay.');
              const CACHE_KEY = 'nexos-user-status-cache';
              let cachedStatus = 'pendente';
              try {
                cachedStatus = await new Promise(res => chrome.storage.local.get([CACHE_KEY], r => {
                  res(((r[CACHE_KEY]) || {})[this.user?.email] || 'pendente');
                }));
              } catch { /* usa 'pendente' */ }
              if (typeof window._renderBlockedInsideOverlay === 'function') {
                window._renderBlockedInsideOverlay(cachedStatus, this.user, this.content, this.overlay);
              }
              if (typeof window.hidePickingLoadingProgress === 'function') {
                window.hidePickingLoadingProgress();
              }
              window.__nexos_overlay_building = false;
              return null;
            }

            // Silent check OK — se usuário ainda não existe no SP (primeiro acesso),
            // ensureUserRegistered cria o registro UMA ÚNICA VEZ e confirma status.
            if (typeof window.ensureUserRegistered === 'function') {
              const accessAllowed = await window.ensureUserRegistered(this.user);
              if (!accessAllowed) {
                console.log('[OverlayBuilder] 🚫 ensureUserRegistered bloqueou — exibindo aviso no overlay.');
                // _showAccessBlockedScreen já foi chamado; substituir por versão inline
                document.getElementById('nexos-access-blocked')?.remove(); // remover fullscreen se criado
                const CACHE_KEY2 = 'nexos-user-status-cache';
                let cachedStatus2 = 'pendente';
                try {
                  cachedStatus2 = await new Promise(res => chrome.storage.local.get([CACHE_KEY2], r => {
                    res(((r[CACHE_KEY2]) || {})[this.user?.email] || 'pendente');
                  }));
                } catch { /* usa 'pendente' */ }
                if (typeof window._renderBlockedInsideOverlay === 'function') {
                  window._renderBlockedInsideOverlay(cachedStatus2, this.user, this.content, this.overlay);
                }
                if (typeof window.hidePickingLoadingProgress === 'function') {
                  window.hidePickingLoadingProgress();
                }
                window.__nexos_overlay_building = false;
                return null;
              }
            }
          }
          
          // Continuar mostrando progresso após animação de boas-vindas
          if (typeof window.showPickingLoadingProgress === 'function') {
            window.showPickingLoadingProgress(7, 8, 'Configurando overlay...');
          }
        } else {
          // Já está autenticado, apenas pega os dados do usuário
          this.user = window.NexosAuth.getCurrentUser();
          console.log('[OverlayBuilder] ✅ Usuário já autenticado:', this.user?.displayName || this.user?.name);

          // Verificar status (aguardar silent check do page load)
          {
            let waited = 0;
            while (window.nexosAccessCheckPending && waited < 50) {
              await new Promise(r => setTimeout(r, 100));
              waited++;
            }

            const getStatusFromCache = async (email) => {
              const CK = 'nexos-user-status-cache';
              try {
                return await new Promise(res => chrome.storage.local.get([CK], r => {
                  res(((r[CK]) || {})[email] || 'pendente');
                }));
              } catch { return 'pendente'; }
            };

            if (window.nexosUserBlocked) {
              console.log('[OverlayBuilder] 🚫 Usuário bloqueado (já autenticado) — exibindo aviso no overlay.');
              const st = await getStatusFromCache(this.user?.email);
              if (!this.overlay.parentNode) document.body.appendChild(this.overlay);
              if (typeof window.hidePickingLoadingProgress === 'function') window.hidePickingLoadingProgress();
              if (typeof window._renderBlockedInsideOverlay === 'function') {
                window._renderBlockedInsideOverlay(st, this.user, this.content, this.overlay);
              }
              window.__nexos_overlay_building = false;
              return null;
            }

            // Verificar com SP se ainda não foi verificado (flag pode ter sido resolvido sem block)
            if (typeof window.ensureUserRegistered === 'function') {
              const accessAllowed = await window.ensureUserRegistered(this.user);
              if (!accessAllowed) {
                document.getElementById('nexos-access-blocked')?.remove();
                const st2 = await getStatusFromCache(this.user?.email);
                if (!this.overlay.parentNode) document.body.appendChild(this.overlay);
                if (typeof window.hidePickingLoadingProgress === 'function') window.hidePickingLoadingProgress();
                if (typeof window._renderBlockedInsideOverlay === 'function') {
                  window._renderBlockedInsideOverlay(st2, this.user, this.content, this.overlay);
                }
                window.__nexos_overlay_building = false;
                return null;
              }
            }
          }
        }
        }
        
        // Atualiza header com informações do usuário autenticado
        this.updateHeader();
      }

      // 4. Aplica tema
      this.setupTheme();

      // 5. Configura eventos
      this.setupEvents();

      console.log('[OverlayBuilder] ✅ Overlay construído');
      return this.overlay;
    }

    /**
     * Injeta CSS e JS necessários
     */
    async injectDependencies() {
      // CSS do Design System
      // Só injetar se chrome.runtime estiver disponível (contexto content script)
      if (!document.getElementById('nexos-design-system-css')) {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
          const cssLink = document.createElement('link');
          cssLink.id = 'nexos-design-system-css';
          cssLink.rel = 'stylesheet';
          cssLink.href = chrome.runtime.getURL('styles/nexos-design-system.css');
          document.head.appendChild(cssLink);
        } else {
          // No contexto da página (main world), o CSS já foi injetado pelo manifest
          console.log('[NexosOverlay] CSS já injetado pelo content script');
        }
      }

      // Aguarda componentes e auth estarem disponíveis
      let attempts = 0;
      while ((!window.NexosUI || !window.NexosAuth) && attempts < 50) {
        await new Promise(resolve => setTimeout(resolve, 100));
        attempts++;
      }

      if (!window.NexosUI || !window.NexosAuth) {
        throw new Error('Dependências não carregadas (NexosUI, NexosAuth)');
      }
    }

    /**
     * Cria estrutura HTML do overlay
     */
    createStructure() {
      // Container principal
      this.overlay = document.createElement('div');
      this.overlay.className = 'nexos-overlay';
      this.overlay.id = `nexos-overlay-${this.config.platform}`;
      this.overlay.setAttribute('data-platform', this.config.platform);
      
      // Adiciona classe de layout
      if (this.config.layout === 'side-panel') {
        this.overlay.classList.add('nexos-overlay-side-panel');
      } else {
        this.overlay.classList.add('nexos-overlay-fullscreen');
      }

      // Header
      this.createHeader();

      // Body (sidebar + content)
      const body = document.createElement('div');
      body.className = 'nexos-body';
      body.style.cssText = `
        display: flex;
        flex: 1;
        overflow: hidden;
      `;

      if (this.config.showSidebar) {
        this.createSidebar();
        body.appendChild(this.sidebar);
      }

      this.createContent();
      body.appendChild(this.content);

      this.overlay.appendChild(this.header);
      this.overlay.appendChild(body);

      // Footer
      if (this.config.showFooter) {
        this.createFooter();
        this.overlay.appendChild(this.footer);
      }
    }

    /**
     * Cria header
     */
    createHeader() {
      const actions = [];

      // Botão de fechar removido: o usuário fecha clicando fora do overlay (backdrop) ou pressionando ESC.

      // User avatar com informações corretas
      const userConfig = this.user ? {
        name: this.user.displayName || this.user.name || 'Usuário',
        role: this.user.jobTitle || this.user.role || 'Colaborador',
        photo: this.user.photo || this.user.photoUrl,
        menuItems: [
          {
            icon: '⚙️',
            text: 'Configurações',
            onClick: () => this.openSettings()
          },
          {
            icon: '🌙',
            text: 'Alternar Tema',
            onClick: () => this.toggleTheme()
          },
          { divider: true },
          {
            icon: '🚪',
            text: 'Sair',
            onClick: () => this.logout()
          }
        ]
      } : null;

      this.header = window.NexosUI.createHeader({
        title: this.config.title,
        subtitle: this.config.subtitle,
        actions,
        userConfig
      });
    }

    /**
     * Atualiza header com informações do usuário após login
     */
    updateHeader() {
      if (!this.header || !this.user) return;
      
      console.log('[OverlayBuilder] 🔄 Atualizando header com dados do usuário');
      
      // Remove header antigo
      const oldHeader = this.overlay.querySelector('.nexos-header');
      if (oldHeader) {
        oldHeader.remove();
      }
      
      // Cria novo header com dados do usuário
      this.createHeader();
      
      // Insere no início do overlay
      this.overlay.insertBefore(this.header, this.overlay.firstChild);
    }

    /**
     * Cria sidebar
     */
    createSidebar() {
      this.sidebar = document.createElement('aside');
      this.sidebar.className = 'nexos-sidebar';
      this.sidebar.style.cssText = `
        width: 280px;
        background: var(--nexos-bg-secondary);
        border-right: 1px solid var(--nexos-border);
        overflow-y: auto;
        overflow-x: hidden;
        display: flex;
        flex-direction: column;
      `;
    }

    /**
     * Cria área de conteúdo
     */
    createContent() {
      this.content = document.createElement('main');
      this.content.className = 'nexos-content';
      this.content.style.cssText = `
        flex: 1;
        overflow-y: auto;
        padding: var(--nexos-spacing-lg);
        background: var(--nexos-bg-primary);
      `;
    }

    /**
     * Cria footer
     */
    createFooter() {
      this.footer = document.createElement('footer');
      this.footer.className = 'nexos-footer';
      this.footer.style.cssText = `
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: var(--nexos-spacing-md) var(--nexos-spacing-lg);
        background: var(--nexos-bg-elevated);
        border-top: 1px solid var(--nexos-border);
        min-height: 56px;
      `;

      // Status
      const status = document.createElement('div');
      status.className = 'nexos-footer-status';
      status.style.cssText = `
        display: flex;
        align-items: center;
        gap: var(--nexos-spacing-sm);
        font-size: var(--nexos-font-size-sm);
        color: var(--nexos-text-secondary);
      `;
      
      const statusDot = document.createElement('span');
      statusDot.style.cssText = `
        width: 8px;
        height: 8px;
        background: var(--nexos-success);
        border-radius: 50%;
      `;
      status.appendChild(statusDot);
      
      const statusText = document.createElement('span');
      statusText.textContent = 'Sistema operacional';
      status.appendChild(statusText);

      this.footer.appendChild(status);

      // Actions (preenchido depois)
      const actions = document.createElement('div');
      actions.className = 'nexos-footer-actions';
      actions.style.cssText = `
        display: flex;
        align-items: center;
        gap: var(--nexos-spacing-sm);
      `;
      this.footer.appendChild(actions);
    }

    /**
     * Configura tema
     */
    setupTheme() {
      this.themeManager = new window.NexosUI.ThemeManager();
      
      if (this.config.theme === 'auto') {
        this.themeManager.applyTheme(this.overlay);
      } else {
        this.themeManager.saveTheme(this.config.theme);
        this.themeManager.applyTheme(this.overlay);
      }

      // Atualiza ícone do botão
      this.updateThemeIcon();
    }

    /**
     * Alterna tema
     */
    toggleTheme() {
      console.log('[NexosOverlay] 🎨 Alternando tema...');
      const newTheme = this.themeManager.toggle(this.overlay);
      this.updateThemeIcon();
      console.log('[NexosOverlay] ✅ Tema alterado para:', newTheme);
      window.NexosUI.showToast(
        `Tema ${newTheme === 'dark' ? 'escuro' : 'claro'} ativado`,
        'info',
        2000
      );
    }

    /**
     * Atualiza ícone do botão de tema
     */
    updateThemeIcon() {
      const btn = this.overlay.querySelector('.nexos-theme-toggle');
      if (btn) {
        const icon = this.themeManager.currentTheme === 'dark' ? '☀️' : '🌙';
        btn.innerHTML = icon;
      }
    }

    /**
     * Configura eventos globais
     */
    setupEvents() {
      // Previne scroll do body
      document.body.style.overflow = 'hidden';

      // ESC para fechar
      this.escHandler = (e) => {
        if (e.key === 'Escape') {
          this.close();
        }
      };
      document.addEventListener('keydown', this.escHandler);
      
      // Click fora do overlay para fechar
      this.clickOutsideHandler = (e) => {
        // Só fecha se clicar diretamente no overlay (backdrop)
        if (e.target === this.overlay) {
          console.log('[OverlayBuilder] 🖱️ Clique fora detectado - fechando overlay');
          this.close();
        }
      };
      this.overlay.addEventListener('click', this.clickOutsideHandler);

      // Logout fecha overlay automaticamente
      // Usa debounce + re-check para ignorar logouts transitórios (ex: nova aba de plataforma
      // inicializando o auth e limpando storage temporariamente via cross-tab storage change)
      if (this.config.requireAuth && window.NexosAuth) {
        this.logoutHandler = () => {
          console.log('[OverlayBuilder] 👋 Logout detectado, verificando em 1.5s...');
          clearTimeout(this._logoutDebounce);
          this._logoutDebounce = setTimeout(async () => {
            try {
              const stillAuth = await window.NexosAuth?.isAuthenticated();
              if (!stillAuth) {
                console.log('[OverlayBuilder] 👋 Logout confirmado, fechando overlay.');
                this.close();
              } else {
                console.log('[OverlayBuilder] ✅ Logout transitório ignorado — sessão ainda válida.');
              }
            } catch (_) {
              // Se der erro ao verificar, fechar por precaução
              this.close();
            }
          }, 1500);
        };
        window.NexosAuth.on('onLogout', this.logoutHandler);
      }

      // Focus trap
      this.trapFocus();
    }

    /**
     * Focus trap
     */
    trapFocus() {
      const focusableElements = this.overlay.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      
      if (focusableElements.length === 0) return;

      const firstElement = focusableElements[0];
      const lastElement = focusableElements[focusableElements.length - 1];

      this.tabHandler = (e) => {
        if (e.key !== 'Tab') return;

        if (e.shiftKey) {
          if (document.activeElement === firstElement) {
            e.preventDefault();
            lastElement.focus();
          }
        } else {
          if (document.activeElement === lastElement) {
            e.preventDefault();
            firstElement.focus();
          }
        }
      };

      this.overlay.addEventListener('keydown', this.tabHandler);
      
      // Foca primeiro elemento
      setTimeout(() => firstElement.focus(), 100);
    }

    /**
     * Adiciona item à sidebar
     */
    addSidebarSection(title, content) {
      if (!this.sidebar) return;

      const section = document.createElement('div');
      section.className = 'nexos-sidebar-section';
      section.style.cssText = `
        padding: var(--nexos-spacing-lg);
        border-bottom: 1px solid var(--nexos-border);
      `;

      if (title) {
        const titleEl = document.createElement('h3');
        titleEl.style.cssText = `
          font-size: var(--nexos-font-size-sm);
          font-weight: var(--nexos-font-weight-semibold);
          color: var(--nexos-text-secondary);
          text-transform: uppercase;
          letter-spacing: 0.05em;
          margin-bottom: var(--nexos-spacing-md);
        `;
        titleEl.textContent = title;
        section.appendChild(titleEl);
      }

      if (typeof content === 'string') {
        section.innerHTML += content;
      } else {
        section.appendChild(content);
      }

      this.sidebar.appendChild(section);
    }

    /**
     * Adiciona botão ao footer
     */
    addFooterButton(button) {
      if (!this.footer) return;
      const actions = this.footer.querySelector('.nexos-footer-actions');
      if (actions) {
        actions.appendChild(button);
      }
    }

    /**
     * Atualiza status do footer
     */
    updateFooterStatus(text, variant = 'success') {
      if (!this.footer) return;
      const statusText = this.footer.querySelector('.nexos-footer-status span:last-child');
      const statusDot = this.footer.querySelector('.nexos-footer-status span:first-child');
      
      if (statusText) statusText.textContent = text;
      
      if (statusDot) {
        const colors = {
          success: 'var(--nexos-success)',
          warning: 'var(--nexos-warning)',
          error: 'var(--nexos-error)',
          info: 'var(--nexos-info)'
        };
        statusDot.style.background = colors[variant] || colors.success;
      }
    }

    /**
     * Abre configurações
     */
    openSettings() {
      window.NexosUI.showToast('Configurações em desenvolvimento', 'info');
    }

    /**
     * Mostra animação de boas-vindas após login
     */
    async showWelcomeAnimation(user) {
      console.log('[OverlayBuilder] 🎉 Mostrando animação de boas-vindas...');
      
      // Criar overlay de boas-vindas que ocupa TODO o espaço
      const welcomeScreen = document.createElement('div');
      welcomeScreen.style.cssText = `
        position: absolute;
        inset: 0;
        z-index: 999999;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        opacity: 0;
        transition: opacity 0.8s cubic-bezier(0.4, 0, 0.2, 1);
      `;
      
      // Foto do usuário (com fallback para ícone)
      const userPhotoUrl = user.photo || user.photoUrl || null;
      const photoElement = document.createElement('div');
      photoElement.style.cssText = `
        width: 120px;
        height: 120px;
        border-radius: 50%;
        background: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 64px;
        margin-bottom: 24px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        overflow: hidden;
        opacity: 0;
        transform: scale(0.8);
        transition: all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1);
      `;
      
      if (userPhotoUrl) {
        photoElement.innerHTML = `<img src="${userPhotoUrl}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.parentElement.innerHTML='👤'">`;
      } else {
        photoElement.textContent = '👤';
      }
      
      // Nome do usuário
      const userName = user.displayName || user.name || user.firstName || 'Usuário';
      const nameElement = document.createElement('h1');
      nameElement.textContent = `Bem-vindo, ${userName}!`;
      nameElement.style.cssText = `
        color: white;
        font-size: 32px;
        font-weight: 700;
        margin: 0 0 12px 0;
        text-align: center;
        text-shadow: 0 2px 20px rgba(0, 0, 0, 0.2);
        opacity: 0;
        transform: translateY(20px);
        transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
      `;
      
      // Mensagem
      const messageElement = document.createElement('p');
      messageElement.textContent = 'Preparando seu ambiente...';
      messageElement.style.cssText = `
        color: rgba(255, 255, 255, 0.9);
        font-size: 16px;
        font-weight: 400;
        margin: 24px 0 0 0;
        opacity: 0;
        transform: translateY(20px);
        transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
      `;
      
      welcomeScreen.appendChild(photoElement);
      welcomeScreen.appendChild(nameElement);
      welcomeScreen.appendChild(messageElement);
      
      this.overlay.appendChild(welcomeScreen);
      
      // Trigger animations com delay
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          welcomeScreen.style.opacity = '1';
          
          setTimeout(() => {
            photoElement.style.opacity = '1';
            photoElement.style.transform = 'scale(1)';
          }, 200);
          
          setTimeout(() => {
            nameElement.style.opacity = '1';
            nameElement.style.transform = 'translateY(0)';
          }, 400);
          
          setTimeout(() => {
            messageElement.style.opacity = '1';
            messageElement.style.transform = 'translateY(0)';
          }, 600);
        });
      });
      
      // Aguardar 4 segundos (2.5s + 1.5s) e remover com fade out suave
      await new Promise(resolve => setTimeout(resolve, 4000));
      
      // Fade out suave de todos os elementos
      messageElement.style.opacity = '0';
      messageElement.style.transform = 'translateY(-20px)';
      
      setTimeout(() => {
        nameElement.style.opacity = '0';
        nameElement.style.transform = 'translateY(-20px)';
      }, 100);
      
      setTimeout(() => {
        photoElement.style.opacity = '0';
        photoElement.style.transform = 'scale(0.8)';
      }, 200);
      
      setTimeout(() => {
        welcomeScreen.style.opacity = '0';
      }, 400);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (welcomeScreen.parentNode) {
        welcomeScreen.remove();
      }
      
      console.log('[OverlayBuilder] ✅ Animação de boas-vindas concluída');
    }

    /**
     * Logout
     */
    logout() {
      console.log('[OverlayBuilder] 🚪 Logout iniciado pelo usuário');
      
      // Fecha o overlay primeiro
      this.close();
      
      // Depois faz o logout (isso vai limpar a sessão)
      window.NexosAuth.logout();
      
      // Toast de confirmação
      window.NexosUI.showToast('Logout realizado com sucesso', 'success');
    }

    /**
     * Fecha overlay
     */
    close() {
      // Restaura scroll do body
      document.body.style.overflow = '';

      // Remove event listeners
      if (this.escHandler) {
        document.removeEventListener('keydown', this.escHandler);
      }
      if (this.tabHandler) {
        this.overlay.removeEventListener('keydown', this.tabHandler);
      }
      if (this.clickOutsideHandler) {
        this.overlay.removeEventListener('click', this.clickOutsideHandler);
        this.clickOutsideHandler = null;
      }
      
      // Remove listener de logout
      if (this.logoutHandler && window.NexosAuth) {
        window.NexosAuth.off('onLogout', this.logoutHandler);
      }

      // Remove backdrop (se existir)
      if (this.backdrop && this.backdrop.parentNode) {
        this.backdrop.style.animation = 'nexosFadeOut 200ms ease-out';
        setTimeout(() => {
          if (this.backdrop && this.backdrop.parentNode) {
            this.backdrop.remove();
          }
        }, 200);
      }

      // Remove overlay
      if (this.overlay && this.overlay.parentNode) {
        const animation = this.config.layout === 'side-panel' ? 'nexosSlideOutRight' : 'nexosSlideOut';
        this.overlay.style.animation = `${animation} 200ms ease-out`;
        setTimeout(() => {
          if (this.overlay && this.overlay.parentNode) {
            this.overlay.remove();
          }
        }, 200);
      }

      // Restaurar botão flutuante ao fechar o overlay, independente do status de bloqueio.
      // Se o usuário fechou o overlay (ESC, backdrop ou botão), o botão deve voltar a aparecer.
      try {
        const floatBtn = document.getElementById('nexos-float-btn');
        if (floatBtn && floatBtn.style.display === 'none') floatBtn.style.display = '';
      } catch (e) {}

      // Se o overlay foi fechado sem usar "Verificar novamente", liberar o flag para
      // permitir nova tentativa na próxima abertura.
      if (window.nexosUserBlocked) {
        window.nexosUserBlocked = false;
      }

      // Invocar callback de fechamento (ex: overlayVisible = false em buildPickingOverlayV3)
      try {
        if (typeof this.config.onClose === 'function') this.config.onClose();
      } catch (e) {}

      console.log('[OverlayBuilder] Overlay fechado');
    }

    /**
     * Mostra overlay na página
     */
    show() {
      if (!this.overlay) {
        console.error('[OverlayBuilder] Overlay não construído. Chame build() primeiro.');
        return;
      }

      // Se for side-panel, adiciona backdrop
      if (this.config.layout === 'side-panel') {
        this.backdrop = document.createElement('div');
        this.backdrop.className = 'nexos-overlay-backdrop';
        this.backdrop.style.cssText = `
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0, 0, 0, 0.5);
          z-index: ${parseInt(getComputedStyle(document.documentElement).getPropertyValue('--nexos-z-overlay') || '9000') - 1};
          animation: nexosFadeIn 200ms ease-out;
        `;
        
        // Fecha ao clicar no backdrop
        this.backdrop.addEventListener('click', () => this.close());
        document.body.appendChild(this.backdrop);
      }

      // Adiciona animação de saída ao CSS se não existir
      if (!document.getElementById('nexos-overlay-animations')) {
        const style = document.createElement('style');
        style.id = 'nexos-overlay-animations';
        style.textContent = `
          @keyframes nexosSlideOut {
            from {
              opacity: 1;
              transform: translateY(0);
            }
          @keyframes nexosSlideOutRight {
            from {
              opacity: 1;
              transform: translateX(0);
            }
            to {
              opacity: 0;
              transform: translateX(100%);
            }
          }
          @keyframes nexosFadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
          }
          @keyframes nexosFadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
          }
          @keyframes nexosScaleIn {
            from {
              opacity: 0;
              transform: scale(0.5);
            }
            to {
              opacity: 1;
              transform: scale(1);
            }
          }
          @keyframes nexosSlideUp {
            from {
              opacity: 0;
              transform: translateY(30px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }
          @keyframes nexosSpin {
            from {
              transform: rotate(0deg);
            }
            to {
              transform: rotate(360deg);
            }
          }
            to {
              opacity: 0;
              transform: translateY(-10px);
            }
          }
        `;
        document.head.appendChild(style);
      }

      // Adiciona overlay ao body apenas se ainda não estiver no DOM
      if (!this.overlay.parentNode) {
        document.body.appendChild(this.overlay);
        console.log('[OverlayBuilder] Overlay exibido');
      } else {
        console.log('[OverlayBuilder] Overlay já está no DOM');
      }
    }
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     EXPORT API
     ══════════════════════════════════════════════════════════════════════════ */

  window.NexosOverlay = {
    Builder: OverlayBuilder,
    
    /**
     * Helper para criar overlay rapidamente
     */
    async create(config) {
      const builder = new OverlayBuilder(config);
      const result = await builder.build();
      
      // Se build() retornou null (falha), não mostra overlay
      if (!result) {
        console.error('[NexosOverlay] ❌ Falha ao construir overlay');
        return null;
      }
      
      builder.show();
      return builder;
    }
  };

  // Sistema de overlay template inicializado silenciosamente

})();
