// ===================================================================
// NEXOS - Sistema de Supervisão e Autorização Hierárquica
// Gerencia aprovações, supervisores designados e validações
// ===================================================================

/**
 * Gerenciador de Supervisão
 * Controla autorizações, supervisores designados e hierarquia
 */
class SupervisionManager {
  constructor() {
    this.storageKey = '__nexos_supervision';
    this.pendingApprovalsKey = '__nexos_pending_approvals';
    this.supervisorAssignmentsKey = '__nexos_supervisor_assignments';
    
    this.data = {
      supervisorAssignments: {}, // { userEmail: supervisorEmail }
      pendingApprovals: [],       // Array de requests pendentes
      approvalHistory: []         // Histórico de aprovações
    };
    
    this.initialized = false;
  }

  /**
   * Inicializa o gerenciador
   */
  async init() {
    if (this.initialized) return;

    try {
      await this.loadData();
      this.initialized = true;
      console.log('[SupervisionManager] ✅ Inicializado');
    } catch (error) {
      console.error('[SupervisionManager] ❌ Erro ao inicializar:', error);
      throw error;
    }
  }

  /**
   * Carrega dados do storage
   */
  async loadData() {
    try {
      const stored = await chrome.storage.local.get([
        this.storageKey,
        this.pendingApprovalsKey,
        this.supervisorAssignmentsKey
      ]);

      this.data.supervisorAssignments = stored[this.supervisorAssignmentsKey] || {};
      this.data.pendingApprovals = stored[this.pendingApprovalsKey] || [];
      
      // Carregar histórico do storage principal
      const mainData = stored[this.storageKey] || {};
      this.data.approvalHistory = mainData.approvalHistory || [];

      console.log('[SupervisionManager] Dados carregados:', {
        supervisors: Object.keys(this.data.supervisorAssignments).length,
        pending: this.data.pendingApprovals.length,
        history: this.data.approvalHistory.length
      });
    } catch (error) {
      console.error('[SupervisionManager] Erro ao carregar dados:', error);
    }
  }

  /**
   * Salva dados no storage
   */
  async saveData() {
    try {
      await chrome.storage.local.set({
        [this.supervisorAssignmentsKey]: this.data.supervisorAssignments,
        [this.pendingApprovalsKey]: this.data.pendingApprovals,
        [this.storageKey]: {
          approvalHistory: this.data.approvalHistory
        }
      });
      console.log('[SupervisionManager] ✅ Dados salvos');
    } catch (error) {
      console.error('[SupervisionManager] ❌ Erro ao salvar:', error);
    }
  }

  /**
   * Atribui um supervisor para um usuário
   * @param {string} userEmail - Email do usuário supervisionado
   * @param {string} supervisorEmail - Email do supervisor
   */
  async assignSupervisor(userEmail, supervisorEmail) {
    if (!userEmail || !supervisorEmail) {
      throw new Error('Email inválido');
    }

    // Verificar se supervisor tem hierarquia suficiente
    const userRole = window.userRoleManager?.getUserRole(userEmail);
    const supervisorRole = window.userRoleManager?.getUserRole(supervisorEmail);

    if (!userRole || !supervisorRole) {
      throw new Error('Usuário ou supervisor não cadastrado');
    }

    const userHierarchy = this._getRoleHierarchy(userRole);
    const supervisorHierarchy = this._getRoleHierarchy(supervisorRole);

    if (supervisorHierarchy <= userHierarchy) {
      const userRoleName = window.ROLES ? Object.values(window.ROLES).find(r => r.id === userRole)?.name || userRole : userRole;
      const supervisorRoleName = window.ROLES ? Object.values(window.ROLES).find(r => r.id === supervisorRole)?.name || supervisorRole : supervisorRole;
      throw new Error(`❌ Hierarquia inválida: ${supervisorRoleName} (${supervisorHierarchy}) não pode supervisionar ${userRoleName} (${userHierarchy}). O supervisor deve ter hierarquia MAIOR.`);
    }

    this.data.supervisorAssignments[userEmail] = supervisorEmail;
    await this.saveData();

    console.log(`[SupervisionManager] ✅ ${supervisorEmail} atribuído como supervisor de ${userEmail}`);
    return true;
  }

  /**
   * Remove supervisor de um usuário
   */
  async removeSupervisor(userEmail) {
    delete this.data.supervisorAssignments[userEmail];
    await this.saveData();
    console.log(`[SupervisionManager] ✅ Supervisor removido de ${userEmail}`);
  }

  /**
   * Obtém o supervisor de um usuário
   */
  getSupervisor(userEmail) {
    return this.data.supervisorAssignments[userEmail] || null;
  }

  /**
   * Lista todos os supervisionados de um supervisor
   */
  getSupervisedUsers(supervisorEmail) {
    return Object.entries(this.data.supervisorAssignments)
      .filter(([_, supervisor]) => supervisor === supervisorEmail)
      .map(([user, _]) => user);
  }

  /**
   * Verifica se uma ação requer aprovação
   * @param {string} action - Nome da ação (ex: 'extract_orders', 'post_comments')
   * @param {string} userEmail - Email do usuário
   * @returns {boolean}
   */
  requiresApproval(action, userEmail) {
    const userRole = window.userRoleManager?.getUserRole(userEmail);
    if (!userRole) return true; // Seguro: sem role = requer aprovação

    const hierarchy = this._getRoleHierarchy(userRole);

    // Ações que requerem aprovação por hierarquia
    const restrictedActions = {
      'extract_orders': 40,        // Auxiliar precisa de aprovação
      'post_comments': 40,         // Auxiliar precisa de aprovação
      'delete_logs': 70,           // Encarregado precisa de aprovação
      'clear_storage': 80,         // Gestão precisa de aprovação
      'manage_users': 90,          // Admin precisa de aprovação
      'force_update': 90           // Admin precisa de aprovação
    };

    const minHierarchy = restrictedActions[action];
    if (!minHierarchy) return false; // Ação não restrita

    return hierarchy < minHierarchy;
  }

  /**
   * Solicita aprovação para uma ação
   * @param {Object} request - { user, action, details, timestamp }
   * @returns {string} requestId
   */
  async requestApproval(request) {
    const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const approval = {
      id: requestId,
      user: request.user,
      action: request.action,
      details: request.details || {},
      timestamp: Date.now(),
      status: 'pending',
      supervisor: this.getSupervisor(request.user),
      expiresAt: Date.now() + (15 * 60 * 1000) // 15 minutos
    };

    this.data.pendingApprovals.push(approval);
    await this.saveData();

    console.log('[SupervisionManager] 🔔 Nova solicitação de aprovação:', requestId);

    // Notificar supervisor se online
    if (approval.supervisor && window.notificationManager) {
      await window.notificationManager.notifyInfo(
        'Aprovação Necessária',
        `${request.user} solicita aprovação para: ${this._getActionLabel(request.action)}`,
        { requestId, user: request.user, action: request.action }
      );
    }

    return requestId;
  }

  /**
   * Aprova uma solicitação
   */
  async approveRequest(requestId, approverEmail) {
    const request = this.data.pendingApprovals.find(r => r.id === requestId);
    
    if (!request) {
      throw new Error('Solicitação não encontrada');
    }

    if (request.status !== 'pending') {
      throw new Error('Solicitação já foi processada');
    }

    // Verificar se aprovador tem autoridade
    const canApprove = await this._canApprove(approverEmail, request.user);
    if (!canApprove) {
      throw new Error('Você não tem autoridade para aprovar esta solicitação');
    }

    // Atualizar status
    request.status = 'approved';
    request.approver = approverEmail;
    request.approvedAt = Date.now();

    // Mover para histórico
    this.data.approvalHistory.push(request);
    this.data.pendingApprovals = this.data.pendingApprovals.filter(r => r.id !== requestId);

    await this.saveData();

    console.log(`[SupervisionManager] ✅ Solicitação ${requestId} aprovada por ${approverEmail}`);

    // Notificar solicitante
    if (window.notificationManager) {
      await window.notificationManager.notifySuccess(
        'Aprovação Concedida',
        `Sua solicitação para ${this._getActionLabel(request.action)} foi aprovada por ${approverEmail}`
      );
    }

    return request;
  }

  /**
   * Rejeita uma solicitação
   */
  async rejectRequest(requestId, approverEmail, reason) {
    const request = this.data.pendingApprovals.find(r => r.id === requestId);
    
    if (!request) {
      throw new Error('Solicitação não encontrada');
    }

    if (request.status !== 'pending') {
      throw new Error('Solicitação já foi processada');
    }

    // Verificar se aprovador tem autoridade
    const canApprove = await this._canApprove(approverEmail, request.user);
    if (!canApprove) {
      throw new Error('Você não tem autoridade para rejeitar esta solicitação');
    }

    // Atualizar status
    request.status = 'rejected';
    request.approver = approverEmail;
    request.rejectedAt = Date.now();
    request.rejectionReason = reason;

    // Mover para histórico
    this.data.approvalHistory.push(request);
    this.data.pendingApprovals = this.data.pendingApprovals.filter(r => r.id !== requestId);

    await this.saveData();

    console.log(`[SupervisionManager] ❌ Solicitação ${requestId} rejeitada por ${approverEmail}`);

    // Notificar solicitante
    if (window.notificationManager) {
      await window.notificationManager.notifyWarning(
        'Aprovação Negada',
        `Sua solicitação para ${this._getActionLabel(request.action)} foi rejeitada. Motivo: ${reason || 'Não especificado'}`
      );
    }

    return request;
  }

  /**
   * Lista solicitações pendentes (todas ou de um supervisor)
   */
  getPendingRequests(supervisorEmail = null) {
    if (!supervisorEmail) {
      return this.data.pendingApprovals;
    }

    return this.data.pendingApprovals.filter(r => r.supervisor === supervisorEmail);
  }

  /**
   * Obtém histórico completo de aprovações (processadas)
   * @param {Object} filters - Filtros opcionais { user, supervisor, status, dateFrom, dateTo }
   * @returns {Array} Histórico ordenado por data (mais recente primeiro)
   */
  getApprovalHistory(filters = {}) {
    let history = [...this.data.approvalHistory];

    // Aplicar filtros
    if (filters.user) {
      history = history.filter(h => 
        h.user?.toLowerCase().includes(filters.user.toLowerCase())
      );
    }

    if (filters.supervisor) {
      history = history.filter(h => 
        h.approver?.toLowerCase().includes(filters.supervisor.toLowerCase())
      );
    }

    if (filters.status) {
      history = history.filter(h => h.status === filters.status);
    }

    if (filters.dateFrom) {
      history = history.filter(h => h.timestamp >= filters.dateFrom);
    }

    if (filters.dateTo) {
      history = history.filter(h => h.timestamp <= filters.dateTo);
    }

    // Ordenar por data (mais recente primeiro)
    history.sort((a, b) => b.timestamp - a.timestamp);

    return history;
  }

  /**
   * Verifica se aprovador pode aprovar solicitação de um usuário
   * @private
   */
  async _canApprove(approverEmail, userEmail) {
    // 1. Verificar se é o supervisor designado
    if (this.getSupervisor(userEmail) === approverEmail) {
      return true;
    }

    // 2. Verificar hierarquia
    const approverRole = window.userRoleManager?.getUserRole(approverEmail);
    const userRole = window.userRoleManager?.getUserRole(userEmail);

    if (!approverRole || !userRole) return false;

    const approverHierarchy = this._getRoleHierarchy(approverRole);
    const userHierarchy = this._getRoleHierarchy(userRole);

    // Aprovador deve ter hierarquia superior
    return approverHierarchy > userHierarchy;
  }

  /**
   * Obtém hierarquia de um role
   * @private
   */
  _getRoleHierarchy(roleId) {
    if (!window.ROLES) return 0;
    const role = Object.values(window.ROLES).find(r => r.id === roleId);
    return role?.hierarchy || 0;
  }

  /**
   * Obtém label legível de uma ação
   * @private
   */
  _getActionLabel(action) {
    const labels = {
      'extract_orders': 'Extrair Pedidos',
      'post_comments': 'Postar Comentários',
      'delete_logs': 'Deletar Logs',
      'clear_storage': 'Limpar Storage',
      'manage_users': 'Gerenciar Usuários',
      'force_update': 'Forçar Atualização'
    };
    return labels[action] || action;
  }

  /**
   * Limpa solicitações expiradas
   */
  async cleanupExpiredRequests() {
    const now = Date.now();
    const expired = this.data.pendingApprovals.filter(r => r.expiresAt < now);

    if (expired.length > 0) {
      // Mover expiradas para histórico
      expired.forEach(r => {
        r.status = 'expired';
        this.data.approvalHistory.push(r);
      });

      // Remover de pendentes
      this.data.pendingApprovals = this.data.pendingApprovals.filter(r => r.expiresAt >= now);
      
      await this.saveData();
      console.log(`[SupervisionManager] 🧹 ${expired.length} solicitações expiradas removidas`);
    }
  }

  /**
   * Obtém estatísticas
   */
  getStatistics() {
    return {
      totalSupervisors: new Set(Object.values(this.data.supervisorAssignments)).size,
      totalSupervised: Object.keys(this.data.supervisorAssignments).length,
      pendingApprovals: this.data.pendingApprovals.length,
      totalApprovals: this.data.approvalHistory.filter(a => a.status === 'approved').length,
      totalRejections: this.data.approvalHistory.filter(a => a.status === 'rejected').length,
      totalExpired: this.data.approvalHistory.filter(a => a.status === 'expired').length
    };
  }
}

// Exportar para uso global
if (typeof window !== 'undefined') {
  window.SupervisionManager = SupervisionManager;
}
