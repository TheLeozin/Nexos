// ===================================================================
// NEXOS - Sistema de Exportação de Relatórios
// Exporta logs, estatísticas e dados em múltiplos formatos
// ===================================================================

/**
 * Formatos de exportação disponíveis
 */
const EXPORT_FORMATS = {
  CSV: 'csv',
  JSON: 'json',
  EXCEL: 'xlsx',
  HTML: 'html',
  PDF: 'pdf'
};

/**
 * Tipos de relatório disponíveis
 */
const REPORT_TYPES = {
  LOGS: 'logs',
  STATISTICS: 'statistics',
  PERFORMANCE: 'performance',
  USER_ACTIVITY: 'user_activity',
  ERROR_SUMMARY: 'error_summary',
  PLATFORM_USAGE: 'platform_usage'
};

/**
 * Classe para gerenciamento de exportação de relatórios
 */
class ReportExporter {
  constructor() {
    this.logManager = null;
    this.permissionManager = null;
    this.initialized = false;
  }
  
  /**
   * Inicializa o exportador
   */
  async initialize(logManager, permissionManager) {
    this.logManager = logManager;
    this.permissionManager = permissionManager;
    this.initialized = true;
    console.log('[ReportExporter] ✅ Inicializado');
  }
  
  /**
   * Helper para buscar logs (usa searchLogs do LogManager)
   */
  async _getLogs() {
    try {
      const result = await this.logManager.searchLogs({ limit: 10000 });
      return result.logs || [];
    } catch (error) {
      console.error('[ReportExporter] Erro ao buscar logs:', error);
      return [];
    }
  }
  
  /**
   * Verifica permissão para exportar
   */
  _checkPermission(reportType) {
    if (!this.permissionManager) {
      console.warn('[ReportExporter] PermissionManager não inicializado');
      return false;
    }
    
    // Logs requerem EXPORT_LOGS
    if (reportType === REPORT_TYPES.LOGS || reportType === REPORT_TYPES.ERROR_SUMMARY) {
      return this.permissionManager.hasPermission('export_logs');
    }
    
    // Outros relatórios requerem EXPORT_REPORTS
    return this.permissionManager.hasPermission('export_reports');
  }
  
  // ===================================================================
  // EXPORTAÇÃO DE LOGS
  // ===================================================================
  
  /**
   * Exporta logs em CSV
   */
  async exportLogsToCSV(filters = {}) {
    if (!this._checkPermission(REPORT_TYPES.LOGS)) {
      this.permissionManager.showAccessDenied('Exportar Logs');
      return;
    }
    
    console.log('[ReportExporter] Exportando logs para CSV...');
    
    // Buscar logs (com filtros se fornecidos)
    const logs = await this._getFilteredLogs(filters);
    
    if (logs.length === 0) {
      alert('⚠️ Nenhum log encontrado com os filtros aplicados.');
      return;
    }
    
    // Cabeçalho do CSV
    let csv = 'Data/Hora,Nível,Módulo,Ação,Mensagem,Usuário,Pedido,Loja,Plataforma,Duração (ms),Status,Erro\n';
    
    // Adicionar cada log
    logs.forEach(log => {
      const timestamp = new Date(log.timestamp).toLocaleString('pt-BR');
      const level = this._escapeCSV(log.level || '');
      const module = this._escapeCSV(log.module || '');
      const action = this._escapeCSV(log.action || '');
      const message = this._escapeCSV(log.message || '');
      const user = this._escapeCSV(log.user || '');
      const pedido = this._escapeCSV(log.metadata?.pedido || '');
      const loja = this._escapeCSV(log.metadata?.loja || '');
      const platform = this._escapeCSV(log.metadata?.platform || '');
      const duration = log.metadata?.duration || '';
      const status = this._escapeCSV(log.metadata?.status || '');
      const error = this._escapeCSV(log.metadata?.error || '');
      
      csv += `"${timestamp}","${level}","${module}","${action}","${message}","${user}","${pedido}","${loja}","${platform}","${duration}","${status}","${error}"\n`;
    });
    
    // Download do arquivo
    this._downloadFile(csv, `nexos-logs-${this._getTimestamp()}.csv`, 'text/csv;charset=utf-8;');
    
    console.log('[ReportExporter] ✅ CSV exportado:', logs.length, 'logs');
    
    // Log da exportação
    if (this.logManager) {
      await this.logManager.log('INFO', 'reports', 'export_logs_csv', 
        `Logs exportados para CSV (${logs.length} registros)`,
        { count: logs.length, filters });
    }
  }
  
  /**
   * Exporta logs em JSON
   */
  async exportLogsToJSON(filters = {}) {
    if (!this._checkPermission(REPORT_TYPES.LOGS)) {
      this.permissionManager.showAccessDenied('Exportar Logs');
      return;
    }
    
    console.log('[ReportExporter] Exportando logs para JSON...');
    
    const logs = await this._getFilteredLogs(filters);
    
    if (logs.length === 0) {
      alert('⚠️ Nenhum log encontrado com os filtros aplicados.');
      return;
    }
    
    const exportData = {
      exportDate: new Date().toISOString(),
      totalLogs: logs.length,
      filters: filters,
      logs: logs
    };
    
    const json = JSON.stringify(exportData, null, 2);
    this._downloadFile(json, `nexos-logs-${this._getTimestamp()}.json`, 'application/json');
    
    console.log('[ReportExporter] ✅ JSON exportado:', logs.length, 'logs');
    
    if (this.logManager) {
      await this.logManager.log('INFO', 'reports', 'export_logs_json',
        `Logs exportados para JSON (${logs.length} registros)`,
        { count: logs.length, filters });
    }
  }
  
  // ===================================================================
  // RELATÓRIO DE PERFORMANCE
  // ===================================================================
  
  /**
   * Gera relatório de performance
   */
  async exportPerformanceReport(format = 'json') {
    if (!this._checkPermission(REPORT_TYPES.PERFORMANCE)) {
      this.permissionManager.showAccessDenied('Exportar Relatório de Performance');
      return;
    }
    
    console.log('[ReportExporter] Gerando relatório de performance...');
    
    const stats = await this._calculatePerformanceStats();
    
    const report = {
      titulo: 'Relatório de Performance Nexos',
      dataGeracao: new Date().toISOString(),
      periodo: {
        inicio: stats.startDate,
        fim: new Date().toISOString()
      },
      resumo: {
        totalOperacoes: stats.totalOperations,
        operacoesComSucesso: stats.successful,
        operacoesComFalha: stats.failed,
        taxaSucesso: `${stats.successRate.toFixed(2)}%`,
        tempoMedioOperacao: `${stats.avgDuration.toFixed(0)}ms`
      },
      porPlataforma: stats.byPlatform,
      porModulo: stats.byModule,
      usuariosMaisAtivos: stats.topUsers,
      horariosPico: stats.peakHours,
      errosFrequentes: stats.commonErrors
    };
    
    if (format === 'json') {
      const json = JSON.stringify(report, null, 2);
      this._downloadFile(json, `nexos-performance-${this._getTimestamp()}.json`, 'application/json');
    } else if (format === 'csv') {
      // CSV simplificado com resumo
      let csv = 'Métrica,Valor\n';
      csv += `"Total de Operações","${report.resumo.totalOperacoes}"\n`;
      csv += `"Operações com Sucesso","${report.resumo.operacoesComSucesso}"\n`;
      csv += `"Operações com Falha","${report.resumo.operacoesComFalha}"\n`;
      csv += `"Taxa de Sucesso","${report.resumo.taxaSucesso}"\n`;
      csv += `"Tempo Médio de Operação","${report.resumo.tempoMedioOperacao}"\n`;
      
      this._downloadFile(csv, `nexos-performance-${this._getTimestamp()}.csv`, 'text/csv;charset=utf-8;');
    }
    
    console.log('[ReportExporter] ✅ Relatório de performance exportado');
    
    if (this.logManager) {
      await this.logManager.log('INFO', 'reports', 'export_performance',
        'Relatório de performance exportado',
        { format, ...stats });
    }
  }
  
  // ===================================================================
  // RELATÓRIO DE ATIVIDADE DE USUÁRIOS
  // ===================================================================
  
  /**
   * Gera relatório de atividade de usuários
   */
  async exportUserActivityReport() {
    if (!this._checkPermission(REPORT_TYPES.USER_ACTIVITY)) {
      this.permissionManager.showAccessDenied('Exportar Atividade de Usuários');
      return;
    }
    
    console.log('[ReportExporter] Gerando relatório de atividade de usuários...');
    
    const logs = await this._getLogs();
    const userStats = {};
    
    logs.forEach(log => {
      if (!log.user) return;
      
      if (!userStats[log.user]) {
        userStats[log.user] = {
          usuario: log.user,
          totalOperacoes: 0,
          sucessos: 0,
          falhas: 0,
          plataformas: {},
          primeiroAcesso: log.timestamp,
          ultimoAcesso: log.timestamp
        };
      }
      
      const user = userStats[log.user];
      user.totalOperacoes++;
      
      if (log.metadata?.status === 'success') user.sucessos++;
      if (log.metadata?.status === 'error') user.falhas++;
      
      if (log.metadata?.platform) {
        user.plataformas[log.metadata.platform] = (user.plataformas[log.metadata.platform] || 0) + 1;
      }
      
      if (log.timestamp < user.primeiroAcesso) user.primeiroAcesso = log.timestamp;
      if (log.timestamp > user.ultimoAcesso) user.ultimoAcesso = log.timestamp;
    });
    
    // Converter para array e calcular taxa de sucesso
    const report = Object.values(userStats).map(user => ({
      ...user,
      taxaSucesso: user.totalOperacoes > 0 ? 
        `${((user.sucessos / user.totalOperacoes) * 100).toFixed(2)}%` : '0%',
      primeiroAcesso: new Date(user.primeiroAcesso).toLocaleString('pt-BR'),
      ultimoAcesso: new Date(user.ultimoAcesso).toLocaleString('pt-BR')
    }));
    
    // Ordenar por total de operações
    report.sort((a, b) => b.totalOperacoes - a.totalOperacoes);
    
    // CSV
    let csv = 'Usuário,Total Operações,Sucessos,Falhas,Taxa Sucesso,Primeiro Acesso,Último Acesso\n';
    report.forEach(user => {
      csv += `"${user.usuario}","${user.totalOperacoes}","${user.sucessos}","${user.falhas}","${user.taxaSucesso}","${user.primeiroAcesso}","${user.ultimoAcesso}"\n`;
    });
    
    this._downloadFile(csv, `nexos-user-activity-${this._getTimestamp()}.csv`, 'text/csv;charset=utf-8;');
    
    console.log('[ReportExporter] ✅ Relatório de atividade de usuários exportado');
    
    if (this.logManager) {
      await this.logManager.log('INFO', 'reports', 'export_user_activity',
        `Relatório de atividade exportado (${report.length} usuários)`,
        { userCount: report.length });
    }
  }
  
  // ===================================================================
  // RELATÓRIO DE ERROS
  // ===================================================================
  
  /**
   * Gera relatório resumido de erros
   */
  async exportErrorSummary() {
    if (!this._checkPermission(REPORT_TYPES.ERROR_SUMMARY)) {
      this.permissionManager.showAccessDenied('Exportar Resumo de Erros');
      return;
    }
    
    console.log('[ReportExporter] Gerando resumo de erros...');
    
    const logs = await this._getLogs();
    const errorLogs = logs.filter(log => log.level === 'ERROR');
    
    // Agrupar erros por mensagem
    const errorGroups = {};
    errorLogs.forEach(log => {
      const key = log.message;
      if (!errorGroups[key]) {
        errorGroups[key] = {
          mensagem: key,
          ocorrencias: 0,
          usuarios: new Set(),
          plataformas: new Set(),
          primeiraOcorrencia: log.timestamp,
          ultimaOcorrencia: log.timestamp
        };
      }
      
      const group = errorGroups[key];
      group.ocorrencias++;
      if (log.user) group.usuarios.add(log.user);
      if (log.metadata?.platform) group.plataformas.add(log.metadata.platform);
      if (log.timestamp < group.primeiraOcorrencia) group.primeiraOcorrencia = log.timestamp;
      if (log.timestamp > group.ultimaOcorrencia) group.ultimaOcorrencia = log.timestamp;
    });
    
    // Converter para array
    const report = Object.values(errorGroups).map(group => ({
      ...group,
      usuarios: Array.from(group.usuarios).join(', '),
      plataformas: Array.from(group.plataformas).join(', '),
      primeiraOcorrencia: new Date(group.primeiraOcorrencia).toLocaleString('pt-BR'),
      ultimaOcorrencia: new Date(group.ultimaOcorrencia).toLocaleString('pt-BR')
    }));
    
    // Ordenar por número de ocorrências
    report.sort((a, b) => b.ocorrencias - a.ocorrencias);
    
    // CSV
    let csv = 'Mensagem de Erro,Ocorrências,Usuários Afetados,Plataformas,Primeira Ocorrência,Última Ocorrência\n';
    report.forEach(error => {
      csv += `"${this._escapeCSV(error.mensagem)}","${error.ocorrencias}","${this._escapeCSV(error.usuarios)}","${this._escapeCSV(error.plataformas)}","${error.primeiraOcorrencia}","${error.ultimaOcorrencia}"\n`;
    });
    
    this._downloadFile(csv, `nexos-error-summary-${this._getTimestamp()}.csv`, 'text/csv;charset=utf-8;');
    
    console.log('[ReportExporter] ✅ Resumo de erros exportado:', report.length, 'tipos de erro');
    
    if (this.logManager) {
      await this.logManager.log('INFO', 'reports', 'export_error_summary',
        `Resumo de erros exportado (${report.length} tipos de erro)`,
        { errorTypes: report.length, totalErrors: errorLogs.length });
    }
  }
  
  // ===================================================================
  // HELPERS
  // ===================================================================
  
  /**
   * Busca logs com filtros aplicados
   */
  async _getFilteredLogs(filters) {
    const allLogs = await this._getLogs();
    
    return allLogs.filter(log => {
      // Filtro por nível
      if (filters.level && log.level !== filters.level) return false;
      
      // Filtro por módulo
      if (filters.module && log.module !== filters.module) return false;
      
      // Filtro por data (início)
      if (filters.startDate && log.timestamp < new Date(filters.startDate).getTime()) return false;
      
      // Filtro por data (fim)
      if (filters.endDate && log.timestamp > new Date(filters.endDate).getTime()) return false;
      
      // Filtro por usuário
      if (filters.user && log.user !== filters.user) return false;
      
      // Filtro por busca de texto
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        const messageMatch = log.message.toLowerCase().includes(searchLower);
        const actionMatch = log.action?.toLowerCase().includes(searchLower);
        if (!messageMatch && !actionMatch) return false;
      }
      
      return true;
    });
  }
  
  /**
   * Calcula estatísticas de performance
   */
  async _calculatePerformanceStats() {
    const logs = await this._getLogs();
    
    const stats = {
      totalOperations: logs.length,
      successful: 0,
      failed: 0,
      successRate: 0,
      avgDuration: 0,
      byPlatform: {},
      byModule: {},
      topUsers: [],
      peakHours: {},
      commonErrors: [],
      startDate: logs.length > 0 ? new Date(logs[logs.length - 1].timestamp).toISOString() : null
    };
    
    let totalDuration = 0;
    let durationCount = 0;
    const userCounts = {};
    
    logs.forEach(log => {
      // Contagem de sucesso/falha
      if (log.metadata?.status === 'success') stats.successful++;
      if (log.metadata?.status === 'error' || log.level === 'ERROR') stats.failed++;
      
      // Duração média
      if (log.metadata?.duration) {
        totalDuration += log.metadata.duration;
        durationCount++;
      }
      
      // Por plataforma
      if (log.metadata?.platform) {
        stats.byPlatform[log.metadata.platform] = (stats.byPlatform[log.metadata.platform] || 0) + 1;
      }
      
      // Por módulo
      if (log.module) {
        stats.byModule[log.module] = (stats.byModule[log.module] || 0) + 1;
      }
      
      // Usuários ativos
      if (log.user) {
        userCounts[log.user] = (userCounts[log.user] || 0) + 1;
      }
      
      // Horários de pico
      const hour = new Date(log.timestamp).getHours();
      stats.peakHours[hour] = (stats.peakHours[hour] || 0) + 1;
    });
    
    stats.successRate = stats.totalOperations > 0 ? (stats.successful / stats.totalOperations) * 100 : 0;
    stats.avgDuration = durationCount > 0 ? totalDuration / durationCount : 0;
    
    // Top 10 usuários
    stats.topUsers = Object.entries(userCounts)
      .map(([user, count]) => ({ user, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
    
    return stats;
  }
  
  /**
   * Escapa aspas duplas para CSV
   */
  _escapeCSV(value) {
    if (typeof value !== 'string') return value;
    return value.replace(/"/g, '""');
  }
  
  /**
   * Gera timestamp para nome de arquivo
   */
  _getTimestamp() {
    const now = new Date();
    return now.toISOString().replace(/:/g, '-').split('.')[0];
  }
  
  /**
   * Faz download de arquivo
   */
  _downloadFile(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}

// ===================================================================
// EXPORT
// ===================================================================

if (typeof window !== 'undefined') {
  window.EXPORT_FORMATS = EXPORT_FORMATS;
  window.REPORT_TYPES = REPORT_TYPES;
  window.ReportExporter = ReportExporter;
  console.log('[ReportExporter] ✅ Exportado para window');
}

if (typeof globalThis !== 'undefined') {
  globalThis.EXPORT_FORMATS = EXPORT_FORMATS;
  globalThis.REPORT_TYPES = REPORT_TYPES;
  globalThis.ReportExporter = ReportExporter;
}
