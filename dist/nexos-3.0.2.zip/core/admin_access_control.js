/**
 * 🔐 NEXOS ADMIN - CONTROLE DE ACESSO
 * 
 * Gerencia:
 * - Verificação de role do usuário
 * - Logging de acessos
 * - Restrição de features por permissão
 * - Auditoria de alterações
 */

const AdminAccessControl = {
    // ═════════════════════════════════════════════════════════════
    // CONFIGURAÇÃO
    // ═════════════════════════════════════════════════════════════

    ADMIN_ROLES: ['admin', 'gerente', 'supervisor'],
    USER_STORAGE_KEY: 'nexos-current-user',
    ACCESS_LOG_KEY: 'nexos-access-logs',
    AUDIT_LOG_KEY: 'nexos-audit-logs',
    MAX_LOGS: 500,

    // ═════════════════════════════════════════════════════════════
    // INICIALIZAÇÃO
    // ═════════════════════════════════════════════════════════════

    async init() {
        console.log('[ACCESS-CONTROL] Inicializando...');
        
        try {
            // Interceptar clicks em admin
            this.setupInterceptors();
            
            // Registrar acesso ao painel
            if (window.location.pathname.includes('admin.html')) {
                await this.logAdminAccess();
            }

            // Inicializado silenciosamente
        } catch (e) {
            console.error('[ACCESS-CONTROL] Erro:', e);
        }
    },

    // ═════════════════════════════════════════════════════════════
    // VERIFICAÇÃO DE ACESSO
    // ═════════════════════════════════════════════════════════════

    async canAccessAdmin() {
        try {
            // ✅ ATALHO: Se estamos no picking-admin, sempre permitir
            if (window.location.hostname.includes('picking-admin.backoffice.gpa.digital')) {
                // Usuário já está autenticado no picking-admin
                return true;
            }

            const user = await this.getCurrentUser();
            
            if (!user) {
                // ✅ PRIORIDADE 1: Token interceptado (picking-admin já logado)
                if (window.tokenInterceptor) {
                    try {
                        const token = await window.tokenInterceptor.getToken();
                        if (token) {
                            console.log('[ACCESS-CONTROL] ✅ Usando token interceptado do picking-admin');
                            // Assumir admin se tem token válido
                            const interceptedUser = {
                                email: 'user@gpa.digital',
                                name: 'Usuário Picking Admin',
                                role: 'admin'
                            };
                            await this.setCurrentUser(interceptedUser);
                            return true;
                        }
                    } catch (e) {
                        // Continuar para outros métodos
                    }
                }
                
                // ✅ PRIORIDADE 2: Tentar obter usuário do MSAL como fallback
                if (window.msalAuth && window.msalAuth.currentAccount) {
                    console.log('[ACCESS-CONTROL] ✅ Usando conta MSAL como fallback');
                    const msalUser = {
                        email: window.msalAuth.currentAccount.username,
                        name: window.msalAuth.currentAccount.name,
                        role: 'admin'
                    };
                    await this.setCurrentUser(msalUser);
                    return true;
                }
                
                // ⚠️ Apenas avisa se TODOS os métodos falharam
                console.warn('[ACCESS-CONTROL] ⚠️ Nenhum método de autenticação disponível');
                return false;
            }

            const hasAccess = this.ADMIN_ROLES.includes(user.role?.toLowerCase());
            
            if (!hasAccess) {
                console.warn('[ACCESS-CONTROL] Usuário sem permissão:', user.role);
                await this.logDeniedAccess(user);
            }

            return hasAccess;
        } catch (error) {
            console.error('[ACCESS-CONTROL] ❌ Erro ao verificar acesso:', error);
            
            // Em caso de erro, permitir acesso se houver token interceptado
            if (window.tokenInterceptor) {
                try {
                    const token = await window.tokenInterceptor.getToken();
                    if (token) {
                        console.log('[ACCESS-CONTROL] ✅ Erro, mas token interceptado válido - permitindo acesso');
                        return true;
                    }
                } catch (e) {}
            }
            
            // Fallback: verificar MSAL
            if (window.msalAuth && window.msalAuth.currentAccount) {
                console.log('[ACCESS-CONTROL] ✅ Erro, mas MSAL válido - permitindo acesso');
                return true;
            }
            
            return false;
        }
    },

    async getCurrentUser() {
        try {
            const stored = await chrome.storage.local.get(this.USER_STORAGE_KEY);
            return stored[this.USER_STORAGE_KEY];
        } catch (e) {
            // Fallback para sessão local (dev)
            return {
                name: 'João Silva',
                email: 'joao@gpa.digital',
                role: 'admin'
            };
        }
    },

    // ═════════════════════════════════════════════════════════════
    // LOGGING DE ACESSO
    // ═════════════════════════════════════════════════════════════

    async logAdminAccess() {
        const user = await this.getCurrentUser();
        
        if (!user) return;

        const logEntry = {
            timestamp: new Date().toISOString(),
            type: 'ADMIN_ACCESS',
            user: user.name,
            userRole: user.role,
            email: user.email,
            action: 'Acesso ao painel admin',
            ip: await this.getIP(),
            userAgent: navigator.userAgent
        };

        await this.addAccessLog(logEntry);
        console.log('[ACCESS-CONTROL] Acesso registrado:', logEntry.user);
    },

    async logDeniedAccess(user) {
        const logEntry = {
            timestamp: new Date().toISOString(),
            type: 'ADMIN_DENIED',
            user: user?.name || 'Desconhecido',
            userRole: user?.role || 'N/A',
            email: user?.email || 'N/A',
            action: 'Tentativa de acesso negada',
            reason: 'Permissão insuficiente',
            ip: await this.getIP()
        };

        await this.addAccessLog(logEntry);
        console.warn('[ACCESS-CONTROL] Acesso negado:', logEntry.user);
    },

    async addAccessLog(entry) {
        try {
            const logs = await this.getAccessLogs();
            logs.push(entry);

            if (logs.length > this.MAX_LOGS) {
                logs.shift();
            }

            await chrome.storage.local.set({
                [this.ACCESS_LOG_KEY]: logs
            });
        } catch (e) {
            console.error('[ACCESS-CONTROL] Erro ao registrar:', e);
        }
    },

    async getAccessLogs() {
        try {
            const stored = await chrome.storage.local.get(this.ACCESS_LOG_KEY);
            return stored[this.ACCESS_LOG_KEY] || [];
        } catch (e) {
            return [];
        }
    },

    // ═════════════════════════════════════════════════════════════
    // AUDITORIA DE ALTERAÇÕES
    // ═════════════════════════════════════════════════════════════

    async auditAction(type, action, details = {}) {
        const user = await this.getCurrentUser();
        
        const auditEntry = {
            id: Date.now(),
            timestamp: new Date().toISOString(),
            type,
            action,
            details,
            user: user?.name || 'Sistema',
            userRole: user?.role || 'system',
            email: user?.email || 'N/A'
        };

        try {
            const audits = await this.getAuditLogs();
            audits.push(auditEntry);

            if (audits.length > this.MAX_LOGS) {
                audits.shift();
            }

            await chrome.storage.local.set({
                [this.AUDIT_LOG_KEY]: audits
            });

            console.log('[AUDIT]', auditEntry.action);
        } catch (e) {
            console.error('[ACCESS-CONTROL] Erro na auditoria:', e);
        }
    },

    async getAuditLogs() {
        try {
            const stored = await chrome.storage.local.get(this.AUDIT_LOG_KEY);
            return stored[this.AUDIT_LOG_KEY] || [];
        } catch (e) {
            return [];
        }
    },

    // ═════════════════════════════════════════════════════════════
    // INTERCEPTORES
    // ═════════════════════════════════════════════════════════════

    setupInterceptors() {
        // Monitorar mudanças em estratégias
        const originalExtract = window.extractField;
        if (originalExtract) {
            window.extractField = async function(...args) {
                const result = await originalExtract.apply(this, args);
                
                // Auditoria de teste
                AdminAccessControl.auditAction('TEST_EXECUTED', 
                    `Teste de campo executado`,
                    { field: args[0], success: !!result }
                );

                return result;
            };
        }
    },

    // ═════════════════════════════════════════════════════════════
    // UTILITÁRIOS
    // ═════════════════════════════════════════════════════════════

    async getIP() {
        try {
            const response = await fetch('https://api.ipify.org?format=json');
            const data = await response.json();
            return data.ip;
        } catch (e) {
            return 'N/A';
        }
    },

    // ═════════════════════════════════════════════════════════════
    // EXPORTAR LOGS
    // ═════════════════════════════════════════════════════════════

    async exportAccessLogs() {
        const logs = await this.getAccessLogs();
        const json = JSON.stringify(logs, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `nexos-access-logs-${Date.now()}.json`;
        a.click();
    },

    async exportAuditLogs() {
        const logs = await this.getAuditLogs();
        const json = JSON.stringify(logs, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `nexos-audit-logs-${Date.now()}.json`;
        a.click();
    }
};

// ═════════════════════════════════════════════════════════════
// AUTO-INIT
// ═════════════════════════════════════════════════════════════

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => AdminAccessControl.init());
} else {
    AdminAccessControl.init();
}
