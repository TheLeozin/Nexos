// ===================================================================
// NEXOS - Sistema de Notificações Push
// Notificações desktop com controle por permissão
// ===================================================================

/**
 * Tipos de notificação
 */
const NOTIFICATION_TYPES = {
  SUCCESS: {
    id: 'success',
    icon: 'images/logo.png',
    color: '#22C55E',
    priority: 0,
    sound: false
  },
  INFO: {
    id: 'info',
    icon: 'images/logo.png',
    color: '#3B82F6',
    priority: 0,
    sound: false
  },
  WARNING: {
    id: 'warning',
    icon: 'images/logo.png',
    color: '#F59E0B',
    priority: 1,
    sound: true
  },
  ERROR: {
    id: 'error',
    icon: 'images/logo.png',
    color: '#EF4444',
    priority: 2,
    sound: true
  },
  CRITICAL: {
    id: 'critical',
    icon: 'images/logo.png',
    color: '#DC2626',
    priority: 2,
    sound: true,
    requireInteraction: true // Fica na tela até usuário clicar
  }
};

/**
 * Classe para gerenciamento de notificações
 */
class NotificationManager {
  constructor() {
    this.storageKey = '__nexos_notifications';
    this.configKey = '__nexos_notification_config';
    this.maxNotifications = 100; // Histórico
    this.permissionManager = null;
    this.logManager = null;
    this.initialized = false;
  }
  
  /**
   * Inicializa o sistema de notificações
   */
  async initialize(permissionManager, logManager) {
    if (this.initialized) return;
    
    this.permissionManager = permissionManager;
    this.logManager = logManager;
    
    // Carregar configurações
    const config = await this._getFromStorage(this.configKey);
    this.config = config || {
      enabled: true,
      sound: true,
      desktop: true,
      badge: true,
      criticalOnly: false // Se true, só mostra notificações críticas
    };
    
    // Configurar listener de cliques
    if (chrome.notifications) {
      chrome.notifications.onClicked.addListener((notificationId) => {
        this.handleNotificationClick(notificationId);
      });
      
      chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
        this.handleNotificationButtonClick(notificationId, buttonIndex);
      });
    }
    
    this.initialized = true;
    console.log('[NotificationManager] ✅ Inicializado');
  }
  
  /**
   * Envia uma notificação (verifica permissões automaticamente)
   */
  async notify(type, title, message, options = {}) {
    if (!this.config.enabled) {
      console.log('[NotificationManager] Notificações desabilitadas');
      return null;
    }
    
    const notificationType = NOTIFICATION_TYPES[type.toUpperCase()] || NOTIFICATION_TYPES.INFO;
    
    // Verificar se deve filtrar por tipo crítico
    if (this.config.criticalOnly && type !== 'CRITICAL') {
      console.log('[NotificationManager] Modo crítico ativado, ignorando notificação:', type);
      return null;
    }
    
    // Criar notificação
    const notification = {
      id: `nexos-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: type,
      title: title,
      message: message,
      timestamp: Date.now(),
      read: false,
      user: options.targetUser || null, // Se for erro de outro usuário
      metadata: options.metadata || {}
    };
    
    // Salvar no histórico
    await this._saveNotification(notification);
    
    // Mostrar notificação desktop (se permitido)
    if (this.config.desktop && chrome.notifications) {
      await this._showDesktopNotification(notification, notificationType, options);
    }
    
    // Atualizar badge no ícone da extensão
    if (this.config.badge && chrome.action) {
      await this._updateBadge(type);
    }
    
    // Log da notificação
    if (this.logManager) {
      await this.logManager.log(
        type === 'CRITICAL' || type === 'ERROR' ? 'ERROR' : 'INFO',
        'notifications',
        'notification_sent',
        `Notificação enviada: ${title}`,
        { type, title, message, ...options.metadata }
      );
    }
    
    return notification.id;
  }
  
  /**
   * Notifica erro crítico (visível para admins e gestão)
   */
  async notifyCriticalError(title, message, errorDetails = {}) {
    // Verificar se usuário atual tem permissão para ver alertas críticos
    if (!this.permissionManager) {
      console.log('[NotificationManager] PermissionManager não inicializado - notificação não enviada');
      return null;
    }
    
    try {
      const hasPermission = this.permissionManager.hasPermission('receive_critical_alerts');
      
      if (!hasPermission) {
        console.log('[NotificationManager] Usuário atual não tem permissão para alertas críticos');
        return null;
      }
    } catch (error) {
      console.log('[NotificationManager] Erro ao verificar permissão (usuário não autenticado)');
      return null;
    }
    
    // Enviar notificação crítica
    return await this.notify('CRITICAL', title, message, {
      metadata: errorDetails,
      buttons: [
        { title: '🔍 Ver Detalhes' },
        { title: '✅ Marcar como Lido' }
      ]
    });
  }
  
  /**
   * Notifica erro de outro usuário (visível apenas para quem tem permissão)
   */
  async notifyUserError(userEmail, platform, errorMessage, errorDetails = {}) {
    // Verificar se usuário atual pode ver erros de outros
    const hasPermission = this.permissionManager?.hasPermission('receive_all_user_alerts');
    
    if (!hasPermission) {
      console.log('[NotificationManager] Usuário não tem permissão para ver erros de outros usuários');
      return null;
    }
    
    const title = `❌ Erro de Usuário: ${userEmail}`;
    const message = `Plataforma: ${platform}\nErro: ${errorMessage}`;
    
    return await this.notify('ERROR', title, message, {
      targetUser: userEmail,
      metadata: {
        userEmail,
        platform,
        errorMessage,
        ...errorDetails
      },
      buttons: [
        { title: '📞 Contatar Usuário' },
        { title: '🔍 Ver Logs' }
      ]
    });
  }
  
  /**
   * Notifica sucesso de operação
   */
  async notifySuccess(message, details = {}) {
    return await this.notify('SUCCESS', '✅ Sucesso', message, { metadata: details });
  }
  
  /**
   * Notifica informação geral
   */
  async notifyInfo(title, message, details = {}) {
    return await this.notify('INFO', title, message, { metadata: details });
  }
  
  /**
   * Notifica warning
   */
  async notifyWarning(title, message, details = {}) {
    return await this.notify('WARNING', `⚠️ ${title}`, message, { metadata: details });
  }
  
  /**
   * Mostra notificação desktop do Chrome
   */
  async _showDesktopNotification(notification, notificationType, options) {
    try {
      // Converter path relativo para URL absoluta
      const iconUrl = chrome.runtime.getURL(notificationType.icon);
      
      const notificationOptions = {
        type: 'basic',
        iconUrl: iconUrl,
        title: notification.title,
        message: notification.message,
        priority: notificationType.priority,
        requireInteraction: notificationType.requireInteraction || false,
        silent: !this.config.sound
      };
      
      // Adicionar botões se fornecidos
      if (options.buttons && options.buttons.length > 0) {
        notificationOptions.buttons = options.buttons;
      }
      
      // Adicionar informações extras se for erro de usuário
      if (notification.user) {
        notificationOptions.contextMessage = `Usuário: ${notification.user}`;
      }
      
      await chrome.notifications.create(notification.id, notificationOptions);
      
      console.log('[NotificationManager] 🔔 Notificação desktop enviada:', notification.id);
    } catch (error) {
      console.error('[NotificationManager] Erro ao criar notificação:', error);
    }
  }
  
  /**
   * Atualiza badge no ícone da extensão
   */
  async _updateBadge(type) {
    try {
      let badgeText = '';
      let badgeColor = '#3B82F6';
      
      switch (type.toUpperCase()) {
        case 'CRITICAL':
          badgeText = '!!';
          badgeColor = '#DC2626';
          break;
        case 'ERROR':
          badgeText = '!';
          badgeColor = '#EF4444';
          break;
        case 'WARNING':
          badgeText = '⚠';
          badgeColor = '#F59E0B';
          break;
        default:
          // Limpar badge após 3 segundos
          setTimeout(async () => {
            await chrome.action.setBadgeText({ text: '' });
          }, 3000);
          return;
      }
      
      await chrome.action.setBadgeText({ text: badgeText });
      await chrome.action.setBadgeBackgroundColor({ color: badgeColor });
      
      // Para erros/críticos, manter badge até ser lido
      if (type === 'CRITICAL' || type === 'ERROR') {
        console.log('[NotificationManager] ⚠️ Badge de erro persistente definido');
      }
    } catch (error) {
      console.error('[NotificationManager] Erro ao atualizar badge:', error);
    }
  }
  
  /**
   * Manipula clique na notificação
   */
  async handleNotificationClick(notificationId) {
    console.log('[NotificationManager] Notificação clicada:', notificationId);
    
    // Marcar como lida
    await this.markAsRead(notificationId);
    
    // Abrir dashboard de admin
    await chrome.runtime.openOptionsPage();
    
    // Limpar notificação
    await chrome.notifications.clear(notificationId);
  }
  
  /**
   * Manipula clique em botão da notificação
   */
  async handleNotificationButtonClick(notificationId, buttonIndex) {
    console.log('[NotificationManager] Botão clicado:', notificationId, buttonIndex);
    
    const notification = await this.getNotificationById(notificationId);
    if (!notification) return;
    
    // Botão 0: Ver Detalhes / Contatar Usuário
    if (buttonIndex === 0) {
      if (notification.user) {
        // Abrir WhatsApp ou email
        console.log('[NotificationManager] Contatar usuário:', notification.user);
      } else {
        // Abrir dashboard com detalhes
        await chrome.runtime.openOptionsPage();
      }
    }
    
    // Botão 1: Marcar como Lido / Ver Logs
    if (buttonIndex === 1) {
      await this.markAsRead(notificationId);
      await chrome.runtime.openOptionsPage();
    }
    
    await chrome.notifications.clear(notificationId);
  }
  
  /**
   * Marca notificação como lida
   */
  async markAsRead(notificationId) {
    const notifications = await this._getFromStorage(this.storageKey) || [];
    const index = notifications.findIndex(n => n.id === notificationId);
    
    if (index !== -1) {
      notifications[index].read = true;
      await this._saveToStorage(this.storageKey, notifications);
      console.log('[NotificationManager] ✅ Notificação marcada como lida:', notificationId);
      
      // Verificar se há mais notificações não lidas
      const unreadCount = notifications.filter(n => !n.read).length;
      if (unreadCount === 0) {
        // Limpar badge
        await chrome.action.setBadgeText({ text: '' });
      }
    }
  }
  
  /**
   * Retorna todas as notificações
   */
  async getAllNotifications() {
    return await this._getFromStorage(this.storageKey) || [];
  }
  
  /**
   * Retorna notificações não lidas
   */
  async getUnreadNotifications() {
    const notifications = await this.getAllNotifications();
    return notifications.filter(n => !n.read);
  }
  
  /**
   * Retorna notificação por ID
   */
  async getNotificationById(notificationId) {
    const notifications = await this.getAllNotifications();
    return notifications.find(n => n.id === notificationId);
  }
  
  /**
   * Limpa todas as notificações lidas
   */
  async clearReadNotifications() {
    const notifications = await this.getAllNotifications();
    const unread = notifications.filter(n => !n.read);
    await this._saveToStorage(this.storageKey, unread);
    console.log('[NotificationManager] ✅ Notificações lidas removidas');
  }
  
  /**
   * Atualiza configurações de notificação
   */
  async updateConfig(newConfig) {
    this.config = { ...this.config, ...newConfig };
    await this._saveToStorage(this.configKey, this.config);
    console.log('[NotificationManager] ✅ Configurações atualizadas:', this.config);
  }
  
  // ===================================================================
  // HELPERS DE STORAGE
  // ===================================================================
  
  async _saveNotification(notification) {
    let notifications = await this._getFromStorage(this.storageKey) || [];
    
    // Adicionar no início
    notifications.unshift(notification);
    
    // Limitar a maxNotifications
    if (notifications.length > this.maxNotifications) {
      notifications = notifications.slice(0, this.maxNotifications);
    }
    
    await this._saveToStorage(this.storageKey, notifications);
  }
  
  async _getFromStorage(key) {
    // Tentar chrome.storage primeiro
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        const result = await chrome.storage.local.get(key);
        return result[key] || null;
      } catch (error) {
        console.warn('[NotificationManager] chrome.storage não disponível, usando localStorage');
      }
    }
    
    // Fallback: localStorage
    try {
      const item = localStorage.getItem(`nexos-notification-${key}`);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.warn('[NotificationManager] Erro ao ler do localStorage:', error);
      return null;
    }
  }
  
  async _saveToStorage(key, value) {
    // Tentar chrome.storage primeiro
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        await chrome.storage.local.set({ [key]: value });
        return;
      } catch (error) {
        console.warn('[NotificationManager] chrome.storage não disponível, usando localStorage');
      }
    }
    
    // Fallback: localStorage
    try {
      localStorage.setItem(`nexos-notification-${key}`, JSON.stringify(value));
    } catch (error) {
      console.warn('[NotificationManager] Erro ao salvar no localStorage:', error);
    }
  }
}

// ===================================================================
// EXPORT
// ===================================================================

if (typeof window !== 'undefined') {
  window.NOTIFICATION_TYPES = NOTIFICATION_TYPES;
  window.NotificationManager = NotificationManager;
  console.log('[NotificationManager] ✅ Exportado para window');
}

if (typeof globalThis !== 'undefined') {
  globalThis.NOTIFICATION_TYPES = NOTIFICATION_TYPES;
  globalThis.NotificationManager = NotificationManager;
}
