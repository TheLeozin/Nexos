/**
 * ════════════════════════════════════════════════════════════════════════════
 * PICKING 3.0 - INICIALIZAÇÃO
 * ════════════════════════════════════════════════════════════════════════════
 * 
 * Este código deve ser executado no content.js após o carregamento da página
 * e após a autenticação do usuário.
 * 
 * NOTA: Este script roda em MAIN WORLD (injected), não tem acesso a chrome.*
 * Verificação de versão deve ser feita no content.js antes de injetar.
 */

// ══════════════════════════════════════════════════════════════════════════
// FUNÇÕES AUXILIARES
// ══════════════════════════════════════════════════════════════════════════

/**
 * Limpa cache do overlay (chamada pelo content.js quando detecta update)
 */
window.clearPickingOverlayCacheIfNeeded = function() {
  
  // Limpar cache do overlay em memória
  if (window.clearPickingOverlayCache) {
    window.clearPickingOverlayCache();
  }
  
  // Limpar overlay do DOM se existir
  const oldOverlay = document.getElementById('picking-overlay-v3');
  if (oldOverlay) {
    oldOverlay.remove();
    console.log('[Picking 3.0] �️ Overlay antigo removido do DOM');
  }
  
  // Limpar dados temporários do localStorage (manter dados de pedidos)
  const keysToKeep = [
    'nexos-picking-data',      // Dados dos pedidos (manter)
    'nexos-user-session',       // Sessão do usuário (manter)
    'nexos_current_user'        // Usuário atual (manter)
  ];
  
  // Limpar outras chaves temporárias
  const allKeys = Object.keys(localStorage);
  allKeys.forEach(key => {
    if (key.startsWith('nexos-') && !keysToKeep.includes(key)) {
      localStorage.removeItem(key);
    }
  });
  
};

// ══════════════════════════════════════════════════════════════════════════
// FUNÇÃO DE DIAGNÓSTICO (definida antes da inicialização)
// ══════════════════════════════════════════════════════════════════════════

/**
 * Verificar status do sistema Picking 3.0
 */
window.checkPicking30Status = function() {
  console.log('═══════════════════════════════════════════════════════════');
  console.log('🔍 DIAGNÓSTICO PICKING 3.0');
  console.log('═══════════════════════════════════════════════════════════');
  
  const checks = {
    '✅ Sistema Inicializado': window.Picking30Initialized === true,
    '✅ NexosOverlay': typeof window.NexosOverlay?.create === 'function',
    '✅ NexosUI': typeof window.NexosUI !== 'undefined',
    '✅ NexosAuth': typeof window.NexosAuth !== 'undefined',
    '✅ StateManager': typeof window.PickingStateManager !== 'undefined',
    '✅ LockManager': typeof window.lockManager !== 'undefined',
    '✅ TimelineManager': typeof window.timelineManager !== 'undefined',
    '✅ QueueManager': typeof window.queueManager !== 'undefined',
    '✅ PlatformManager': typeof window.platformManager !== 'undefined',
    '✅ ContextDetector': typeof window.PickingContextDetector !== 'undefined',
    '✅ buildPickingOverlayV3': typeof window.buildPickingOverlayV3 === 'function'
  };
  
  let allOk = true;
  for (const [name, status] of Object.entries(checks)) {
    const icon = status ? '✅' : '❌';
    const label = name.replace('✅ ', '');
    console.log(`${icon} ${label}: ${status ? 'OK' : 'FALHOU'}`);
    if (!status) allOk = false;
  }
  
  console.log('═══════════════════════════════════════════════════════════');
  
  if (allOk) {
    console.log('✅ Todos os componentes carregados!');
    console.log('📦 Execute: buildPickingOverlayV3()');
  } else {
    console.log('❌ Alguns componentes falharam ao carregar');
    console.log('💡 Recarregue a página e tente novamente');
  }
  
  // Retornar contexto se disponível
  if (window.PickingContextDetector) {
    console.log('\n📍 Contexto Atual:');
    const context = window.PickingContextDetector.getContext();
    const capabilities = window.PickingContextDetector.getCapabilities();
    console.log(`   Nome: ${context.name}`);
    console.log(`   ID: ${context.id}`);
    console.log('   Capacidades:', capabilities);
  }
  
  // Retornar dados do StateManager se disponível
  if (window.PickingStateManager) {
    console.log('\n📊 Dados do StateManager:');
    const allOrders = window.PickingStateManager.getAllOrders();
    
    if (Array.isArray(allOrders)) {
      console.log(`   Total de pedidos: ${allOrders.length}`);
      
      const byStatus = {};
      allOrders.forEach(order => {
        byStatus[order.status] = (byStatus[order.status] || 0) + 1;
      });
      console.log('   Por status:', byStatus);
    } else {
      console.log('   ⚠️ getAllOrders() não retornou array:', typeof allOrders);
    }
  }
  
  console.log('═══════════════════════════════════════════════════════════\n');
  
  return checks;
};


// ══════════════════════════════════════════════════════════════════════════
// VERIFICAÇÃO / AUTO-REGISTRO NO NEXOS_USUARIOS
// ══════════════════════════════════════════════════════════════════════════

/**
 * Garante que o usuário autenticado está registrado em Nexos_Usuarios.
 * Fluxo:
 *  1. Se não existe → cria com Status = 'pendente' e exibe tela de bloqueio.
 *  2. Se existe com Status = 'pendente' → exibe tela de bloqueio.
 *  3. Se existe com Status = 'rejeitado' → exibe tela de bloqueio com mensagem de rejeição.
 *  4. Se existe com Status = 'aprovado' → prossegue normalmente.
 *
 * Retorna true se o acesso está liberado, false caso contrário.
 */
// ─────────────────────────────────────────────────────────────────────────────
// _silentUserStatusCheck — chamada no page load.
// NUNCA exibe UI. Apenas seta window.nexosUserBlocked e atualiza o cache.
// Retorna: 'aprovado' | 'pendente' | 'rejeitado' | null (desconhecido/erro)
// ─────────────────────────────────────────────────────────────────────────────
async function _silentUserStatusCheck(currentUser) {
  if (!currentUser?.email) return null;

  const CACHE_KEY = 'nexos-user-status-cache';
  async function _getCache(email) {
    try {
      return await new Promise(res => chrome.storage.local.get([CACHE_KEY], r => {
        res((r[CACHE_KEY] || {})[email] || null);
      }));
    } catch { return null; }
  }
  async function _setCache(email, status) {
    try {
      await new Promise(res => chrome.storage.local.get([CACHE_KEY], r => {
        const c = r[CACHE_KEY] || {};
        c[email] = status;
        chrome.storage.local.set({ [CACHE_KEY]: c }, res);
      }));
    } catch { /* silencioso */ }
  }

  const um = window.NexosUserManager;
  if (!um) {
    // Sem UserManager — usar cache
    const cached = await _getCache(currentUser.email);
    if (cached && cached !== 'aprovado') window.nexosUserBlocked = true;
    return cached;
  }

  try {
    await um.initialize();
    const userRecord = await um.getUserByEmail(currentUser.email);
    if (!userRecord) {
      // Usuário ainda não registrado — não bloquear, ensureUserRegistered criará ao abrir overlay
      return null;
    }
    const status = (userRecord.Status || '').toLowerCase() || 'pendente';
    await _setCache(currentUser.email, status);
    if (status !== 'aprovado') window.nexosUserBlocked = true;
    return status;
  } catch (e) {
    console.warn('[Picking 3.0] ⚠️ _silentUserStatusCheck falhou:', e.message);
    const cached = await _getCache(currentUser.email);
    if (cached && cached !== 'aprovado') window.nexosUserBlocked = true;
    return cached;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _syncUserPhotoIfNeeded
// Atualiza FotoURL no SharePoint com a foto atual do Microsoft Graph.
// Roda no máximo 1× por dia para não sobrecarregar o SP.
// ─────────────────────────────────────────────────────────────────────────────
async function _syncUserPhotoIfNeeded(currentUser, userRecord, um) {
  if (!currentUser?.email || !currentUser?.id || !um) return;

  // Throttle: só atualiza 1× por dia por usuário
  const PHOTO_SYNC_KEY = 'nexos-photo-sync-ts';
  try {
    const stored = await new Promise(res => chrome.storage.local.get([PHOTO_SYNC_KEY], r => res(r[PHOTO_SYNC_KEY] || {})));
    const lastSync = stored[currentUser.email] || 0;
    if (Date.now() - lastSync < 24 * 60 * 60 * 1000) return; // menos de 24h

    const graphPhotoUrl = `https://graph.microsoft.com/v1.0/users/${currentUser.id}/photo/$value`;
    const currentFotoURL = userRecord?.FotoURL || '';

    // Verificar se a URL mudou ou estava vazia
    const urlMudou = currentFotoURL !== graphPhotoUrl;
    if (!urlMudou && currentFotoURL) {
      // Só atualizar o timestamp sem chamar SP
      const updated = { ...stored, [currentUser.email]: Date.now() };
      chrome.storage.local.set({ [PHOTO_SYNC_KEY]: updated });
      return;
    }

    // Atualizar FotoURL no SP
    console.log('[Picking 3.0] 🖼️ Sincronizando foto do usuário no SP...');
    await um.updateUser(currentUser.email, { FotoURL: graphPhotoUrl });

    // Invalidar cache do userManager para refletir na próxima busca
    um.usersCache?.delete(currentUser.email);

    // Registrar timestamp
    const updated = { ...stored, [currentUser.email]: Date.now() };
    chrome.storage.local.set({ [PHOTO_SYNC_KEY]: updated });
    console.log('[Picking 3.0] ✅ FotoURL atualizada no SP.');
  } catch (e) {
    console.warn('[Picking 3.0] ⚠️ _syncUserPhotoIfNeeded falhou:', e.message);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ensureUserRegistered — chamada APENAS quando o usuário tenta usar a extensão.
// Cria o registro no SP se não existir (primeiro acesso) e exibe tela de bloqueio
// se o status for pendente/rejeitado. Nunca chamada em page load.
// ─────────────────────────────────────────────────────────────────────────────
async function ensureUserRegistered(currentUser) {
  if (!currentUser?.email) return true; // Sem auth → modo offline, não bloquear

  // 🔒 Guard contra chamadas paralelas (evita criar 2 registros no SP)
  if (window._nexosEnsureRegisteringFor === currentUser.email) {
    // Aguardar resolução da chamada em curso (max 10s)
    let waited = 0;
    while (window._nexosEnsureRegisteringFor === currentUser.email && waited < 100) {
      await new Promise(r => setTimeout(r, 100));
      waited++;
    }
    // Após aguardar, usar o resultado já cacheado
    const CACHE_KEY_CHK = 'nexos-user-status-cache';
    try {
      const status = await new Promise(res => chrome.storage.local.get([CACHE_KEY_CHK], r => {
        res(((r[CACHE_KEY_CHK]) || {})[currentUser.email] || null);
      }));
      return !status || status === 'aprovado';
    } catch { return true; }
  }
  window._nexosEnsureRegisteringFor = currentUser.email;

  // Verificar cache de status para manter bloqueio mesmo em falha de rede
  const CACHE_KEY = 'nexos-user-status-cache';
  async function _getCachedStatus(email) {
    try {
      return await new Promise(res => chrome.storage.local.get([CACHE_KEY], r => {
        const cache = r[CACHE_KEY] || {};
        res(cache[email] || null);
      }));
    } catch { return null; }
  }
  async function _setCachedStatus(email, status) {
    try {
      await new Promise(res => chrome.storage.local.get([CACHE_KEY], r => {
        const cache = r[CACHE_KEY] || {};
        cache[email] = status;
        chrome.storage.local.set({ [CACHE_KEY]: cache }, res);
      }));
    } catch { /* silencioso */ }
  }

  try {
    const um = window.NexosUserManager;
    if (!um) {
      console.warn('[Picking 3.0] ⚠️ NexosUserManager não disponível — verificando cache...');
      const cached = await _getCachedStatus(currentUser.email);
      if (cached && cached !== 'aprovado') {
        _showAccessBlockedScreen(cached, currentUser);
        return false;
      }
      return true;
    }

    try {
      await um.initialize();
    } catch (e) {
      console.warn('[Picking 3.0] ⚠️ NexosUserManager.initialize() falhou:', e.message);
      const cached = await _getCachedStatus(currentUser.email);
      if (cached && cached !== 'aprovado') {
        _showAccessBlockedScreen(cached, currentUser);
        return false;
      }
      return true; // Falha silenciosa — não bloquear por problema técnico
    }

    // 1. Buscar / criar registro
    let userRecord = await um.getUserByEmail(currentUser.email);

    if (!userRecord) {
      console.log('[Picking 3.0] 🆕 Primeiro acesso — registrando em Nexos_Usuarios...');
      const created = await um.createUser({
        id:          currentUser.id || '',
        email:       currentUser.email,
        name:        currentUser.name || currentUser.displayName || '',
        displayName: currentUser.displayName || currentUser.name || '',
        jobTitle:    currentUser.jobTitle || '',
        department:  currentUser.department || '',
        photo:       currentUser.photo || ''
      });
      if (created.success) {
        userRecord = created.user;
      } else {
        console.warn('[Picking 3.0] ⚠️ Falha ao criar usuário no SP:', created.error);
        const cached = await _getCachedStatus(currentUser.email);
        if (cached && cached !== 'aprovado') {
          _showAccessBlockedScreen(cached, currentUser);
          return false;
        }
        return true; // Não bloquear por falha técnica
      }
    }

    const status = (userRecord.Status || '').toLowerCase();

    // Persistir status no cache para uso offline
    await _setCachedStatus(currentUser.email, status || 'pendente');

    // 2. Acesso aprovado — aproveitar para sincronizar foto (1x por dia)
    if (status === 'aprovado') {
      _syncUserPhotoIfNeeded(currentUser, userRecord, um).catch(() => {});
      return true;
    }

    // 3. Acesso bloqueado — exibir tela adequada
    _showAccessBlockedScreen(status, currentUser);
    return false;

  } finally {
    // 🔓 Liberar o lock independente de sucesso ou erro
    if (window._nexosEnsureRegisteringFor === currentUser.email) {
      window._nexosEnsureRegisteringFor = null;
    }
  }
}

/**
 * Renderiza tela de acesso bloqueado sobre a página inteira.
 * Não pode ser fechada pelo usuário; admin deve aprovar no painel.
 */
function _showAccessBlockedScreen(status, currentUser) {
  // 🔒 Sinalizar globalmente que o acesso está bloqueado
  window.nexosUserBlocked = true;

  // Fechar o overlay de picking caso esteja aberto
  const pickingOverlay = document.getElementById('picking-overlay-v3');
  if (pickingOverlay) pickingOverlay.style.display = 'none';

  // 🛡️ Exibir tela de bloqueio APENAS na página de Picking Admin.
  // Em outras páginas (Orkestra, Uber, 99, etc.) apenas o flag é suficiente —
  // a tela cheia seria invasiva e fora de contexto.
  // O botão flutuante só é ocultado aqui quando a tela de bloqueio é exibida (Picking).
  // Nas demais páginas, _renderBlockedInsideOverlay cuida de ocultar/restaurar o botão.
  const isPickingAdminPage = /picking-admin\.backoffice\.gpa\.digital/i.test(window.location.hostname);
  if (!isPickingAdminPage) {
    console.log('[Nexos] 🔒 Acesso bloqueado nesta aba (picking-init). Tela de bloqueio omitida fora da página de Picking.');
    return;
  }

  // Ocultar o botão flutuante para não aparecer sobre a tela de bloqueio (apenas Picking)
  const floatBtn = document.getElementById('nexos-float-btn');
  if (floatBtn) floatBtn.style.display = 'none';

  // Remover instância anterior se houver
  document.getElementById('nexos-access-blocked')?.remove();

  const isPending  = status === 'pendente';
  const isRejected = status === 'rejeitado';

  const overlay = document.createElement('div');
  overlay.id = 'nexos-access-blocked';
  overlay.style.cssText = [
    'position:fixed', 'inset:0', 'z-index:2147483647',
    'display:flex', 'align-items:center', 'justify-content:center',
    'background:rgba(15,23,42,0.92)', 'backdrop-filter:blur(6px)',
    'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif'
  ].join(';');

  const icon    = isPending ? '⏳' : '🚫';
  const title   = isPending ? 'Aguardando Aprovação' : 'Acesso Negado';
  const color   = isPending ? '#F59E0B' : '#EF4444';
  const bgCard  = isPending ? '#FFFBEB' : '#FEF2F2';
  const border  = isPending ? '#FDE68A' : '#FECACA';

  const nameDisplay = currentUser?.name || currentUser?.email || '';

  const message = isPending
    ? `Seu cadastro foi recebido e está aguardando aprovação pelo administrador Nexos.<br>
       <span style="font-size:13px;color:#78716C;">Você receberá acesso assim que um administrador aprovar seu perfil.</span>`
    : `Seu acesso foi negado pelo administrador Nexos.<br>
       <span style="font-size:13px;color:#78716C;">Entre em contato com o suporte para mais informações.</span>`;

  overlay.innerHTML = `
    <div style="
      background:${bgCard};
      border:1.5px solid ${border};
      border-radius:16px;
      padding:40px 48px;
      max-width:460px;
      width:90%;
      text-align:center;
      box-shadow:0 20px 60px rgba(0,0,0,0.4);
    ">
      <div style="font-size:56px;margin-bottom:16px;line-height:1;">${icon}</div>
      <div style="font-size:22px;font-weight:700;color:${color};margin-bottom:12px;">${title}</div>
      ${nameDisplay ? `<div style="font-size:14px;color:#6B7280;margin-bottom:16px;">👤 ${nameDisplay}</div>` : ''}
      <div style="font-size:15px;color:#374151;line-height:1.6;margin-bottom:28px;">${message}</div>
      ${isPending ? `
        <div style="
          background:#FFF7ED;
          border:1px solid #FED7AA;
          border-radius:8px;
          padding:12px 16px;
          font-size:12px;
          color:#92400E;
          margin-bottom:24px;
        ">
          💡 <strong>Administradores:</strong> acesse o Painel Admin da Nexos para aprovar este usuário.
        </div>
      ` : ''}
      <button id="nexos-access-blocked-refresh" style="
        background:${color};
        color:#fff;
        border:none;
        border-radius:8px;
        padding:10px 24px;
        font-size:14px;
        font-weight:600;
        cursor:pointer;
        margin-right:8px;
      ">🔄 Verificar novamente</button>
      <button id="nexos-access-blocked-logout" style="
        background:transparent;
        color:#6B7280;
        border:1.5px solid #D1D5DB;
        border-radius:8px;
        padding:10px 20px;
        font-size:14px;
        cursor:pointer;
      ">Sair</button>
    </div>
  `;

  document.documentElement.appendChild(overlay);

  // Verificar novamente ao clicar
  overlay.querySelector('#nexos-access-blocked-refresh')?.addEventListener('click', async () => {
    overlay.remove();
    window.nexosUserBlocked = false; // liberar temporariamente para re-checagem
    const allowed = await ensureUserRegistered(currentUser);
    if (allowed) {
      window.nexosUserBlocked = false;
      // Restaurar botão flutuante
      const floatBtn = document.getElementById('nexos-float-btn');
      if (floatBtn) floatBtn.style.display = '';
      // Reiniciar picking
      window.Picking30?.init?.();
    }
  });

  // Botão sair
  overlay.querySelector('#nexos-access-blocked-logout')?.addEventListener('click', () => {
    window.nexosUserBlocked = false;
    window.NexosAuth?.logout?.();
    overlay.remove();
  });
}

// Expor globalmente para uso em picking-overlay-v3.js (condição de corrida)
window._showAccessBlockedScreen = _showAccessBlockedScreen;
window.ensureUserRegistered = ensureUserRegistered;
window._silentUserStatusCheck = _silentUserStatusCheck;

// ─────────────────────────────────────────────────────────────────────────────
// _renderBlockedInsideOverlay
// Renderiza a mensagem de acesso bloqueado DENTRO do overlay (contentEl),
// sem criar tela cheia. O overlay permanece aberto com o card de bloqueio.
// ─────────────────────────────────────────────────────────────────────────────
function _renderBlockedInsideOverlay(status, currentUser, contentEl, overlayEl) {
  if (!contentEl) return;

  window.nexosUserBlocked = true;

  // Ocultar botão flutuante apenas quando o overlay for o de picking completo (não o mínimo)
  const floatBtn = document.getElementById('nexos-float-btn');
  if (floatBtn && overlayEl?.id !== 'nexos-block-overlay') floatBtn.style.display = 'none';

  // Garantir overlay no DOM
  if (overlayEl && !overlayEl.parentNode) {
    document.body.appendChild(overlayEl);
  }

  const isPending  = (status || '') !== 'rejeitado';
  const icon    = isPending ? '⏳' : '🚫';
  const title   = isPending ? 'Aguardando Aprovação' : 'Acesso Negado';
  const color   = isPending ? '#F59E0B' : '#EF4444';
  const bgCard  = isPending ? '#FFFBEB' : '#FEF2F2';
  const border  = isPending ? '#FDE68A' : '#FECACA';
  const nameDisplay = currentUser?.displayName || currentUser?.name || currentUser?.email || '';
  const message = isPending
    ? `Seu cadastro foi recebido e está aguardando aprovação pelo administrador Nexos.<br>
       <span style="font-size:13px;color:#78716C;">Você receberá acesso assim que um administrador aprovar seu perfil.</span>`
    : `Seu acesso foi negado pelo administrador Nexos.<br>
       <span style="font-size:13px;color:#78716C;">Entre em contato com o suporte para mais informações.</span>`;

  contentEl.innerHTML = `
    <div style="
      display:flex;flex-direction:column;align-items:center;justify-content:center;
      min-height:340px;padding:40px 32px;text-align:center;
    ">
      <div style="font-size:56px;margin-bottom:16px;line-height:1;">${icon}</div>
      <div style="font-size:22px;font-weight:700;color:${color};margin-bottom:12px;">${title}</div>
      ${nameDisplay ? `<div style="font-size:14px;color:#6B7280;margin-bottom:14px;">👤 ${nameDisplay}</div>` : ''}
      <div style="
        background:${bgCard};border:1.5px solid ${border};border-radius:12px;
        padding:20px 28px;max-width:380px;margin-bottom:24px;
        font-size:14px;color:#374151;line-height:1.6;
      ">${message}</div>
      ${isPending ? `
        <div style="
          background:#FFF7ED;border:1px solid #FED7AA;border-radius:8px;
          padding:10px 14px;font-size:11px;color:#92400E;max-width:380px;margin-bottom:20px;
        ">
          💡 <strong>Administradores:</strong> acesse o Painel Admin Nexos para aprovar.
        </div>
      ` : ''}
      <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center;">
        <button id="nexos-blocked-in-overlay-refresh" style="
          background:${color};color:#fff;border:none;border-radius:8px;
          padding:10px 24px;font-size:14px;font-weight:600;cursor:pointer;
        ">🔄 Verificar novamente</button>
        <button id="nexos-blocked-in-overlay-logout" style="
          background:transparent;color:#6B7280;border:1.5px solid #D1D5DB;
          border-radius:8px;padding:10px 20px;font-size:14px;cursor:pointer;
        ">Sair</button>
      </div>
    </div>
  `;

  // "Verificar novamente" — fecha o overlay e libera o botão para o usuário tentar de novo
  contentEl.querySelector('#nexos-blocked-in-overlay-refresh')?.addEventListener('click', async () => {
    window.nexosUserBlocked = false;
    window._nexosEnsureRegisteringFor = null;
    if (overlayEl && overlayEl.parentNode) overlayEl.remove();
    const fb = document.getElementById('nexos-float-btn');
    if (fb) fb.style.display = '';
  });

  // "Sair" — desloga e fecha
  contentEl.querySelector('#nexos-blocked-in-overlay-logout')?.addEventListener('click', () => {
    window.nexosUserBlocked = false;
    if (overlayEl && overlayEl.parentNode) overlayEl.remove();
    const fb = document.getElementById('nexos-float-btn');
    if (fb) fb.style.display = '';
    window.NexosAuth?.logout?.();
  });
}

window._renderBlockedInsideOverlay = _renderBlockedInsideOverlay;


// ══════════════════════════════════════════════════════════════════════════
// INICIALIZAÇÃO ASSÍNCRONA
// ══════════════════════════════════════════════════════════════════════════

(async function initializePicking30() {

  // 🔒 Sinalizar que a verificação de acesso está em curso
  // buildPickingOverlayV3 aguardará este flag antes de prosseguir
  window.nexosAccessCheckPending = true;
  window.nexosUserBlocked = false;

  try {
    // ════════════════════════════════════════════════════════════════════════
    // 1. AGUARDAR NEXOS AUTH
    // ════════════════════════════════════════════════════════════════════════
    
    // Esperar até NexosAuth estar pronto (timeout 10s)
    let attempts = 0;
    while ((!window.NexosAuth || !window.NexosAuth.getCurrentUser()) && attempts < 20) {
      await new Promise(resolve => setTimeout(resolve, 500));
      attempts++;
    }
    
    const hasAuth = window.NexosAuth && window.NexosAuth.getCurrentUser();
    if (!hasAuth) {
    }

    // ════════════════════════════════════════════════════════════════════════
    // 1.5 VERIFICAR STATUS DO USUÁRIO EM NEXOS_USUARIOS (silencioso)
    // Apenas seta flags — sem exibir qualquer DOM.
    // A tela de bloqueio só aparece quando o usuário tentar usar a extensão.
    // ════════════════════════════════════════════════════════════════════════

    const authUser = window.NexosAuth?.getCurrentUser() || null;
    const statusResult = await _silentUserStatusCheck(authUser);
    window.nexosAccessCheckPending = false; // verificação concluída

    if (window.nexosUserBlocked) {
      console.log('[Picking 3.0] 🚫 Inicialização suspensa — usuário pendente/rejeitado (status:', statusResult, ').');
      return;
    }

    // ════════════════════════════════════════════════════════════════════════
    // 2. INICIALIZAR STATE MANAGER
    // ════════════════════════════════════════════════════════════════════════
    
    
    if (!window.PickingStateManager) {
      throw new Error('PickingStateManager não encontrado!');
    }
    
    await window.PickingStateManager.init();
    
    // Definir usuário atual — aguarda resolução async do auth antes de definir no stateManager
    let currentUser = window.NexosAuth?.getCurrentUser();
    if (!currentUser) {
      // Auth pode não ter resolvido ainda — forçar restore da sessão
      try {
        const isAuth = await window.NexosAuth?.isAuthenticated();
        if (isAuth) currentUser = window.NexosAuth?.getCurrentUser();
      } catch (_) {}
    }
    if (!currentUser) {
      // Tentativa final: nexos_current_user ou localStorage
      currentUser = window.nexos_current_user
        || (() => { try { const s = localStorage.getItem('nexos_current_user'); return s ? JSON.parse(s) : null; } catch { return null; } })();
    }
    if (currentUser) {
      // Normalizar campo .name caso venha como .displayName (MSAL)
      if (!currentUser.name && (currentUser.displayName || currentUser.email)) {
        currentUser = { ...currentUser, name: currentUser.displayName || currentUser.email?.split('@')[0] };
      }
      window.PickingStateManager.setCurrentUser(currentUser);
    }
    // Removido: fallback "Usuário Temporário" — resolveCurrentUser() no overlay lê NexosAuth diretamente em tempo de render
    
    // ════════════════════════════════════════════════════════════════════════
    // 2.1 PRÉ-CARREGAR LOJAS DO SHAREPOINT (se autenticado)
    // ════════════════════════════════════════════════════════════════════════
    
    if (window.PickingStateManager.sharepointManager) {
      
      try {
        const lojasCount = await window.PickingStateManager.sharepointManager.preloadLojas();
      } catch (error) {
        console.warn('[Picking 3.0] ⚠️ Erro ao pré-carregar lojas:', error.message);
      }
    } else {
    }
    
    // ════════════════════════════════════════════════════════════════════════
    // 3. DETECTAR CONTEXTO DA PÁGINA
    // ════════════════════════════════════════════════════════════════════════
    
    
    if (!window.PickingContextDetector) {
      console.warn('[Picking 3.0] ⚠️ PickingContextDetector não encontrado, continuando sem detecção');
    } else {
      const context = window.PickingContextDetector.detectContext();
    }
    
    // ════════════════════════════════════════════════════════════════════════
    // 4. CRIAR INSTÂNCIAS DOS MANAGERS
    // ════════════════════════════════════════════════════════════════════════
    
    
    // Lock Manager
    if (!window.PickingLockManager) {
      throw new Error('PickingLockManager não encontrado!');
    }
    window.lockManager = new window.PickingLockManager(window.PickingStateManager);
    
    // Timeline Manager
    if (!window.PickingTimelineManager) {
      throw new Error('PickingTimelineManager não encontrado!');
    }
    window.timelineManager = new window.PickingTimelineManager(window.PickingStateManager);
    
    // Queue Manager
    if (!window.PickingQueueManager) {
      throw new Error('PickingQueueManager não encontrado!');
    }
    window.queueManager = new window.PickingQueueManager(window.PickingStateManager, window.lockManager);
    
    // Platform Manager
    if (!window.PickingPlatformManager) {
      throw new Error('PickingPlatformManager não encontrado!');
    }
    window.platformManager = new window.PickingPlatformManager(window.PickingStateManager, window.queueManager);
    
    // ════════════════════════════════════════════════════════════════════════
    // 5. REGISTRAR EVENT LISTENERS GLOBAIS
    // ════════════════════════════════════════════════════════════════════════
    
    
    window.PickingStateManager.addListener((event, data) => {
      
      switch (event) {
        case 'order_locked':
          // Mostrar notificação de lock
          if (typeof window.NexosUI !== 'undefined') {
            window.NexosUI.showToast(
              `🔒 Pedido ${data.lock.pedidoId} travado por ${data.lock.userName}`,
              'info',
              3000
            );
          }
          break;
          
        case 'order_unlocked':
          // Notificar destravamento
          if (typeof window.NexosUI !== 'undefined') {
            window.NexosUI.showToast(
              `🔓 Pedido ${data.pedidoId} destravado`,
              'info',
              2000
            );
          }
          break;
          
        case 'locks_cleaned':
          // Locks expirados removidos
          if (data.count > 0) {
            console.log(`[Picking 3.0] 🧹 ${data.count} lock(s) expirado(s) removido(s)`);
          }
          break;
          
        case 'job_queued':
          // Job adicionado à fila
          if (typeof window.NexosUI !== 'undefined') {
            window.NexosUI.showToast(
              `📋 Pedido ${data.job.pedidoId} adicionado à fila`,
              'info',
              2000
            );
          }
          break;
          
        case 'job_completed':
          // Job processado
          const job = data.job;
          if (job.status === 'completed') {
            console.log(`[Picking 3.0] ✅ Job ${job.id} concluído com sucesso`);
          } else if (job.status === 'failed') {
            console.error(`[Picking 3.0] ❌ Job ${job.id} falhou:`, job.error);
          }
          break;
          
        case 'queue_completed':
          // Fila processada completamente
          const { results } = data;
          const total = results.success.length + results.failed.length + results.skipped.length;
          
          if (typeof window.NexosUI !== 'undefined') {
            const message = `✅ ${results.success.length}/${total} pedidos enviados com sucesso`;
            const type = results.failed.length === 0 ? 'success' : 'warning';
            window.NexosUI.showToast(message, type, 5000);
          }
          
          break;
          
        case 'queue_started':
          // Fila iniciada
          break;
          
        case 'queue_stopped':
          // Fila parada
          break;
      }
    });
    
    // ════════════════════════════════════════════════════════════════════════
    // 6. HELPERS GLOBAIS
    // ════════════════════════════════════════════════════════════════════════
    
    /**
     * Helper: Enviar pedido individual
     */
    window.sendOrderToPlatform = async function(loja, pedidoId) {
      
      // Verificar capacidade de envio
      if (window.PickingContextDetector && !window.PickingContextDetector.canSendDirect()) {
        const method = window.PickingContextDetector.getRecommendedSendingMethod();
        if (method === 'background') {
        }
      }
      
      // 1. Obter pedido
      const order = window.PickingStateManager.getOrder(loja, pedidoId);
      if (!order) {
        throw new Error('Pedido não encontrado');
      }
      
      // ✅ 2. Verificar se pedido já está travado (desde a extração)
      const isLocked = window.lockManager.isLocked(pedidoId);
      const hasLock = window.lockManager.hasLock(pedidoId);
      
      
      // Se não tem lock, significa que é de outro usuário ou lock expirou
      if (isLocked && !hasLock) {
        const lockInfo = window.lockManager.getLockInfo(pedidoId);
        window.lockManager.showLockWarning(lockInfo);
        throw new Error('Pedido travado por outro usuário');
      }
      
      // ✅ Não precisa travar novamente - pedido já está travado desde a extração!
      
      try {
        // 3. Mostrar modal de seleção
        const selection = await window.platformManager.showPlatformSelectionModal(order);
        if (!selection) {
          return null; // Cancelado, mas não é erro
        }
        
        // 4. Validar
        const validation = window.platformManager.validateOrder(order, selection.platform);
        if (!validation.valid) {
          throw new Error(validation.errors.join(', '));
        }
        
        // 5. Enviar
        const result = await window.platformManager.sendOrder({
          loja,
          pedidoId,
          platform: selection.platform,
          vehicle: selection.vehicle,
          order
        });
        
        // 6. Atualizar pedido e liberar lock
        // Se awaitingFill=true, o preenchimento ainda acontecerá na aba da plataforma;
        // marcamos como 'enviando' para indicar que a nova aba foi aberta.
        order.status        = result.awaitingFill ? 'enviando' : 'solicitado';
        order.plataforma    = result.platform;
        order.veiculo       = result.vehicle;
        order.id_solicitacao   = result.trackingId || null;
        order.valor_transporte = result.value      || null;
        order.timestamp_carregamento = Date.now();
        
        await window.PickingStateManager.setOrder(loja, pedidoId, order);
        
        // ✅ DESTRAVAR após envio bem-sucedido
        await window.lockManager.unlock(pedidoId);
        
        return result;
        
      } catch (error) {
        // ✅ Em caso de erro, manter o lock (pedido volta para pendente)
        console.error('[Picking 3.0] ❌ Erro ao enviar, lock mantido:', error);
        throw error;
      }
    };
    
    /**
     * Helper: Enviar múltiplos pedidos em lote
     */
    window.sendOrdersBatch = async function(orders) {
      
      // 1. Selecionar plataforma/veículo
      const selection = await window.platformManager.showPlatformSelectionModal(orders[0]);
      if (!selection) {
        throw new Error('Seleção cancelada');
      }
      
      // 2. Enfileirar todos
      const jobs = [];
      for (const order of orders) {
        const result = await window.queueManager.enqueue({
          loja: order.loja,
          pedidoId: order.pedido,
          platform: selection.platform,
          vehicle: selection.vehicle,
          priority: 0
        });
        
        if (result.success) {
          jobs.push(result.job);
        } else {
          console.warn(`[Picking 3.0] ⚠️ Não foi possível enfileirar ${order.pedido}:`, result.reason);
        }
      }
      
      
      // 3. Processar automaticamente (QueueManager inicia sozinho)
      
      return jobs;
    };
    
    /**
     * Helper: Mostrar timeline de um pedido
     */
    window.showOrderTimeline = function(pedidoId, container) {
      const timeline = window.timelineManager.createTimeline(pedidoId, {
        maxEvents: 50,
        showHeader: true,
        compact: false
      });
      
      if (container) {
        container.innerHTML = '';
        container.appendChild(timeline);
      }
      
      return timeline;
    };
    
    /**
     * Helper: Status da fila
     */
    window.getQueueStatus = function() {
      return window.queueManager.getQueueStatus();
    };
    
    /**
     * Helper: Obter contexto atual
     */
    window.getPickingContext = function() {
      return window.PickingContextDetector?.getContext() || null;
    };
    
    /**
     * Helper: Verificar capacidade
     */
    window.hasCapability = function(capability) {
      return window.PickingContextDetector?.hasCapability(capability) || false;
    };
    
    // ════════════════════════════════════════════════════════════════════════
    // 7. FINALIZAÇÃO
    // ════════════════════════════════════════════════════════════════════════
    
    
    // Marcar como inicializado
    window.Picking30Initialized = true;
    
    // ════════════════════════════════════════════════════════════════════════
    // 7.5. PRÉ-CONSTRUIR OVERLAY (Background) - DESABILITADO
    // ════════════════════════════════════════════════════════════════════════
    
    // ⚠️ PRÉ-CONSTRUÇÃO DESABILITADA: Overlay só deve abrir quando usuário solicitar
    // O cache singleton já garante performance na segunda abertura
    
    // ════════════════════════════════════════════════════════════════════════
    // 8. NAVIGATION LISTENER - Re-detectar contexto ao navegar
    // ════════════════════════════════════════════════════════════════════════
    
    let lastUrl = window.location.href;
    
    // Observer para detectar mudanças de URL (SPAs como React Router)
    const urlObserver = setInterval(() => {
      const currentUrl = window.location.href;
      if (currentUrl !== lastUrl) {
        
        lastUrl = currentUrl;
        
        // Re-detectar contexto
        if (window.PickingContextDetector) {
          window.PickingContextDetector.refresh();
        }
        
        // Disparar evento customizado
        window.dispatchEvent(new CustomEvent('picking30:navigation', {
          detail: { oldUrl: lastUrl, newUrl: currentUrl }
        }));
      }
    }, 500); // Verificar a cada 500ms
    
    // Listener de popstate (navegação com botões voltar/avançar)
    window.addEventListener('popstate', () => {
      if (window.PickingContextDetector) {
        window.PickingContextDetector.refresh();
      }
    });
    
    
    // Disparar evento customizado
    window.dispatchEvent(new CustomEvent('picking30:ready'));
    
    // Mensagem de sucesso
    console.log('\n═══════════════════════════════════════════════════════════');
    console.log('🎉 PICKING 3.0 PRONTO!');
    console.log('═══════════════════════════════════════════════════════════');
    console.log('📦 Para abrir o overlay, execute:');
    console.log('   buildPickingOverlayV3()');
    console.log('\n🔍 Para diagnóstico, execute:');
    console.log('   checkPicking30Status()');
    console.log('\n💡 Ambas as funções estão disponíveis globalmente!');
    console.log('═══════════════════════════════════════════════════════════\n');
    
  } catch (error) {
    window.nexosAccessCheckPending = false; // garantir que o flag é limpo mesmo em erro
    console.error('[Picking 3.0] ❌ Erro na inicialização:', error);
    
    if (typeof window.NexosUI !== 'undefined') {
      window.NexosUI.showToast(
        '❌ Erro ao inicializar Picking 3.0: ' + error.message,
        'error',
        5000
      );
    }
  }
})();
