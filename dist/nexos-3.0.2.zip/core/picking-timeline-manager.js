/**
 * ════════════════════════════════════════════════════════════════════════════
 * PICKING TIMELINE MANAGER - Componente Visual de Linha do Tempo
 * ════════════════════════════════════════════════════════════════════════════
 * 
 * Responsável por:
 * - Renderizar timeline visual com eventos
 * - Ícones e cores por tipo de evento
 * - Expandir/colapsar detalhes
 * - Formatação de datas/horas
 * - Integração com NexosUI
 */

class PickingTimelineManager {
  constructor(stateManager) {
    this.stateManager = stateManager;
    
    // Configuração de ícones e cores por tipo de evento
    this.eventConfig = {
      'extracted': {
        icon: '📥',
        color: '#10b981',
        label: 'Extraído'
      },
      'locked': {
        icon: '🔒',
        color: '#f59e0b',
        label: 'Travado'
      },
      'unlocked': {
        icon: '🔓',
        color: '#6b7280',
        label: 'Destravado'
      },
      'lock_expired': {
        icon: '⏰',
        color: '#ef4444',
        label: 'Trava Expirada'
      },
      'queued': {
        icon: '📋',
        color: '#3b82f6',
        label: 'Enfileirado'
      },
      'dequeued': {
        icon: '🗑️',
        color: '#6b7280',
        label: 'Removido da Fila'
      },
      'sending': {
        icon: '📤',
        color: '#8b5cf6',
        label: 'Enviando'
      },
      'sent': {
        icon: '✅',
        color: '#10b981',
        label: 'Enviado'
      },
      'send_retry': {
        icon: '🔄',
        color: '#f59e0b',
        label: 'Tentando Novamente'
      },
      'send_failed': {
        icon: '❌',
        color: '#ef4444',
        label: 'Falha no Envio'
      },
      'cancelled': {
        icon: '🚫',
        color: '#ef4444',
        label: 'Cancelado'
      },
      'completed': {
        icon: '🎉',
        color: '#10b981',
        label: 'Concluído'
      },
      'note': {
        icon: '📝',
        color: '#6b7280',
        label: 'Nota'
      }
    };
    
    // Timeline Manager inicializado silenciosamente
  }
  
  /**
   * Criar componente de timeline completo
   */
  createTimeline(pedidoId, options = {}) {
    const {
      maxEvents = 50,
      showHeader = true,
      compact = false,
      containerClass = ''
    } = options;
    
    // Obter eventos
    const events = this.stateManager.getTimeline(pedidoId) || [];
    
    // Container principal
    const container = document.createElement('div');
    container.className = `nexos-timeline-container ${containerClass}`;
    container.style.cssText = `
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding: 16px;
      background: var(--nexos-bg-primary);
      border-radius: 8px;
    `;
    
    // Header (opcional)
    if (showHeader) {
      const header = this.createTimelineHeader(events.length);
      container.appendChild(header);
    }
    
    // Lista de eventos
    const eventsList = document.createElement('div');
    eventsList.className = 'nexos-timeline-events';
    eventsList.style.cssText = `
      display: flex;
      flex-direction: column;
      gap: ${compact ? '8px' : '12px'};
      max-height: 600px;
      overflow-y: auto;
      padding-right: 8px;
    `;
    
    // Eventos ordenados (mais recente primeiro)
    const sortedEvents = [...events].sort((a, b) => b.timestamp - a.timestamp);
    const displayEvents = sortedEvents.slice(0, maxEvents);
    
    if (displayEvents.length === 0) {
      const emptyState = this.createEmptyState();
      eventsList.appendChild(emptyState);
    } else {
      displayEvents.forEach(event => {
        const eventEl = this.createTimelineEvent(event, compact);
        eventsList.appendChild(eventEl);
      });
    }
    
    container.appendChild(eventsList);
    
    return container;
  }
  
  /**
   * Criar header da timeline
   */
  createTimelineHeader(eventCount) {
    const header = document.createElement('div');
    header.style.cssText = `
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding-bottom: 12px;
      border-bottom: 1px solid var(--nexos-border-light);
      margin-bottom: 8px;
    `;
    
    const title = document.createElement('h3');
    title.textContent = 'Linha do Tempo';
    title.style.cssText = `
      margin: 0;
      font-size: 16px;
      font-weight: 600;
      color: var(--nexos-text-primary);
    `;
    
    const badge = document.createElement('span');
    badge.textContent = eventCount;
    badge.style.cssText = `
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 24px;
      height: 24px;
      padding: 0 8px;
      background: var(--nexos-primary);
      color: white;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
    `;
    
    header.appendChild(title);
    header.appendChild(badge);
    
    return header;
  }
  
  /**
   * Criar item de evento individual
   */
  createTimelineEvent(event, compact = false) {
    const config = this.eventConfig[event.type] || this.eventConfig['note'];
    
    const eventEl = document.createElement('div');
    eventEl.className = 'nexos-timeline-event';
    eventEl.dataset.eventId = event.id;
    eventEl.dataset.eventType = event.type;
    eventEl.style.cssText = `
      display: flex;
      gap: 12px;
      padding: ${compact ? '8px' : '12px'};
      background: var(--nexos-bg-secondary);
      border-radius: 8px;
      border-left: 3px solid ${config.color};
      cursor: pointer;
      transition: all 0.2s;
    `;
    
    // Hover effect
    eventEl.addEventListener('mouseenter', () => {
      eventEl.style.background = 'var(--nexos-bg-hover)';
      eventEl.style.transform = 'translateX(4px)';
    });
    
    eventEl.addEventListener('mouseleave', () => {
      eventEl.style.background = 'var(--nexos-bg-secondary)';
      eventEl.style.transform = 'translateX(0)';
    });
    
    // Ícone
    const iconEl = document.createElement('div');
    iconEl.className = 'nexos-timeline-icon';
    iconEl.textContent = config.icon;
    iconEl.style.cssText = `
      font-size: ${compact ? '20px' : '24px'};
      line-height: 1;
      flex-shrink: 0;
    `;
    
    // Conteúdo
    const contentEl = document.createElement('div');
    contentEl.className = 'nexos-timeline-content';
    contentEl.style.cssText = `
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 4px;
    `;
    
    // Linha principal: label + timestamp
    const mainLine = document.createElement('div');
    mainLine.style.cssText = `
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    `;
    
    const label = document.createElement('span');
    label.textContent = config.label;
    label.style.cssText = `
      font-weight: 600;
      color: ${config.color};
      font-size: ${compact ? '13px' : '14px'};
    `;
    
    const timestamp = document.createElement('span');
    timestamp.textContent = this.formatTimestamp(event.timestamp);
    timestamp.style.cssText = `
      font-size: ${compact ? '11px' : '12px'};
      color: var(--nexos-text-secondary);
      white-space: nowrap;
    `;
    
    mainLine.appendChild(label);
    mainLine.appendChild(timestamp);
    
  // Mensagem (priorizar detalhes/motivo fornecidos pelo SharePoint)
  const message = document.createElement('div');
  const messageText = event.details || event.detalhes || event.message || (event.dados && (event.dados.motivo || event.dados.detalhes)) || '';
  message.textContent = messageText;
    message.style.cssText = `
      font-size: ${compact ? '12px' : '13px'};
      color: var(--nexos-text-primary);
      line-height: 1.4;
    `;
    
    // Usuário (se disponível)
    if (event.user) {
      const user = document.createElement('div');
      user.style.cssText = `
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: ${compact ? '11px' : '12px'};
        color: var(--nexos-text-secondary);
        margin-top: 2px;
      `;
      
      const userIcon = document.createElement('span');
      userIcon.textContent = '👤';
      userIcon.style.fontSize = compact ? '12px' : '14px';
      
      const userName = document.createElement('span');
      userName.textContent = event.user;
      
      user.appendChild(userIcon);
      user.appendChild(userName);
      
      contentEl.appendChild(mainLine);
      contentEl.appendChild(message);
      contentEl.appendChild(user);
    } else {
      contentEl.appendChild(mainLine);
      contentEl.appendChild(message);
    }
    
    // Metadata expandível (se houver)
    if (event.platform || event.vehicle || event.trackingId || event.value || event.error || (event.dados && event.dados.motivo)) {
      const metadataBtn = this.createMetadataButton(event);
      contentEl.appendChild(metadataBtn);
    }
    
    eventEl.appendChild(iconEl);
    eventEl.appendChild(contentEl);
    
    return eventEl;
  }
  
  /**
   * Criar botão de metadata expandível
   */
  createMetadataButton(event) {
    const container = document.createElement('div');
    container.style.cssText = `
      margin-top: 8px;
    `;
    
    const btn = document.createElement('button');
    btn.textContent = '📋 Ver Detalhes';
    btn.className = 'nexos-btn-ghost';
    btn.style.cssText = `
      padding: 4px 8px;
      font-size: 11px;
      border: 1px solid var(--nexos-border-light);
      border-radius: 4px;
      background: transparent;
      color: var(--nexos-text-secondary);
      cursor: pointer;
      transition: all 0.2s;
    `;
    
    btn.addEventListener('mouseenter', () => {
      btn.style.background = 'var(--nexos-bg-hover)';
      btn.style.color = 'var(--nexos-text-primary)';
    });
    
    btn.addEventListener('mouseleave', () => {
      btn.style.background = 'transparent';
      btn.style.color = 'var(--nexos-text-secondary)';
    });
    
    const detailsEl = document.createElement('div');
    detailsEl.className = 'nexos-timeline-metadata';
    detailsEl.style.cssText = `
      display: none;
      margin-top: 8px;
      padding: 8px;
      background: var(--nexos-bg-primary);
      border-radius: 4px;
      border: 1px solid var(--nexos-border-light);
      font-size: 12px;
      color: var(--nexos-text-secondary);
    `;
    
  const details = [];
    
    if (event.platform) {
      details.push(`<strong>Plataforma:</strong> ${event.platform.toUpperCase()}`);
    }
    
    if (event.vehicle) {
      details.push(`<strong>Veículo:</strong> ${event.vehicle}`);
    }
    
    if (event.trackingId) {
      details.push(`<strong>ID Rastreio:</strong> ${event.trackingId}`);
    }
    
    if (event.value) {
      details.push(`<strong>Valor:</strong> R$ ${event.value}`);
    }
    
    if (event.error) {
      details.push(`<strong style="color: var(--nexos-error);">Erro:</strong> ${event.error}`);
    }

    // Incluir motivo/detalhes caso venham via dados
    try {
      if (event.dados && event.dados.motivo) {
        details.push(`<strong>Motivo:</strong> ${event.dados.motivo}`);
      } else if (event.detalhes) {
        details.push(`<strong>Detalhes:</strong> ${event.detalhes}`);
      } else if (event.details) {
        details.push(`<strong>Detalhes:</strong> ${event.details}`);
      }
    } catch (e) {
      // ignore
    }
    
    detailsEl.innerHTML = details.join('<br>');
    
    // Toggle ao clicar
    let expanded = false;
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      expanded = !expanded;
      detailsEl.style.display = expanded ? 'block' : 'none';
      btn.textContent = expanded ? '📋 Ocultar Detalhes' : '📋 Ver Detalhes';
    });
    
    container.appendChild(btn);
    container.appendChild(detailsEl);
    
    return container;
  }
  
  /**
   * Criar estado vazio
   */
  createEmptyState() {
    const empty = document.createElement('div');
    empty.className = 'nexos-timeline-empty';
    empty.style.cssText = `
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 48px 24px;
      text-align: center;
      color: var(--nexos-text-secondary);
    `;
    
    const icon = document.createElement('div');
    icon.textContent = '📭';
    icon.style.cssText = `
      font-size: 48px;
      margin-bottom: 16px;
      opacity: 0.5;
    `;
    
    const text = document.createElement('p');
    text.textContent = 'Nenhum evento registrado';
    text.style.cssText = `
      margin: 0;
      font-size: 14px;
    `;
    
    empty.appendChild(icon);
    empty.appendChild(text);
    
    return empty;
  }
  
  /**
   * Formatar timestamp
   */
  formatTimestamp(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    // Menos de 1 minuto
    if (diff < 60000) {
      return 'Agora mesmo';
    }
    
    // Menos de 1 hora
    if (diff < 3600000) {
      const minutes = Math.floor(diff / 60000);
      return `Há ${minutes} min`;
    }
    
    // Menos de 24 horas
    if (diff < 86400000) {
      const hours = Math.floor(diff / 3600000);
      return `Há ${hours}h`;
    }
    
    // Menos de 7 dias
    if (diff < 604800000) {
      const days = Math.floor(diff / 86400000);
      return `Há ${days} dia${days > 1 ? 's' : ''}`;
    }
    
    // Data completa
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    
    return `${day}/${month}/${year} ${hours}:${minutes}`;
  }
  
  /**
   * Adicionar evento e atualizar UI dinamicamente
   */
  addEventToUI(pedidoId, event, timelineContainer) {
    if (!timelineContainer) return;
    
    const eventsList = timelineContainer.querySelector('.nexos-timeline-events');
    if (!eventsList) return;
    
    // Remover empty state se existir
    const emptyState = eventsList.querySelector('.nexos-timeline-empty');
    if (emptyState) {
      emptyState.remove();
    }
    
    // Criar novo evento
    const eventEl = this.createTimelineEvent(event, false);
    
    // Inserir no topo (mais recente primeiro)
    eventsList.insertBefore(eventEl, eventsList.firstChild);
    
    // Animação de entrada
    eventEl.style.opacity = '0';
    eventEl.style.transform = 'translateX(-20px)';
    
    requestAnimationFrame(() => {
      eventEl.style.transition = 'all 0.3s ease';
      eventEl.style.opacity = '1';
      eventEl.style.transform = 'translateX(0)';
    });
    
    // Atualizar badge do header
    const badge = timelineContainer.querySelector('.nexos-timeline-container h3 + span');
    if (badge) {
      const currentCount = parseInt(badge.textContent) || 0;
      badge.textContent = currentCount + 1;
    }
    
    console.log(`[PickingTimeline] ✅ Evento adicionado à UI: ${event.type}`);
  }
  
  /**
   * Criar timeline compacta (para cards)
   */
  createCompactTimeline(pedidoId, maxEvents = 3) {
    return this.createTimeline(pedidoId, {
      maxEvents,
      showHeader: false,
      compact: true,
      containerClass: 'compact'
    });
  }
  
  /**
   * Criar último evento (para preview)
   */
  createLastEvent(pedidoId) {
    const events = this.stateManager.getTimeline(pedidoId) || [];
    
    if (events.length === 0) {
      return null;
    }
    
    // Pegar evento mais recente
    const lastEvent = events.reduce((latest, current) => 
      current.timestamp > latest.timestamp ? current : latest
    );
    
    const config = this.eventConfig[lastEvent.type] || this.eventConfig['note'];
    
    const container = document.createElement('div');
    container.className = 'order-last-event';
    container.dataset.pedidoId = pedidoId;
    container.style.cssText = `
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 6px 10px;
      background: var(--nexos-bg-secondary);
      border-radius: 6px;
      border-left: 2px solid ${config.color};
      font-size: 12px;
    `;
    
    // ✅ Avatar do usuário
    const userName = lastEvent.userName || lastEvent.user || 'Usuário';
    const avatar = document.createElement('div');
    avatar.style.cssText = `
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 600;
      font-size: 11px;
      flex-shrink: 0;
    `;
    avatar.textContent = userName.charAt(0).toUpperCase();
    avatar.title = userName;
    
    const icon = document.createElement('span');
    icon.textContent = config.icon;
    icon.style.fontSize = '14px';
    icon.style.flexShrink = '0';
    
    const text = document.createElement('span');
  // Preferir detalhes/motivo para o preview também
  const previewText = lastEvent.details || lastEvent.detalhes || lastEvent.message || (lastEvent.dados && (lastEvent.dados.motivo || lastEvent.dados.detalhes)) || '';
  text.textContent = previewText;
    text.style.cssText = `
      flex: 1;
      color: var(--nexos-text-primary);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    `;
    
    const time = document.createElement('span');
    time.textContent = this.formatTimestamp(lastEvent.timestamp);
    time.style.cssText = `
      color: var(--nexos-text-secondary);
      font-size: 11px;
      white-space: nowrap;
      flex-shrink: 0;
    `;
    
    container.appendChild(avatar);
    container.appendChild(icon);
    container.appendChild(text);
    container.appendChild(time);
    
    return container;
  }
}

// Exportar
window.PickingTimelineManager = PickingTimelineManager;

console.log('[PickingTimeline] 📅 Módulo carregado');
