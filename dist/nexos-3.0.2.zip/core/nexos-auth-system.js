/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - AUTHENTICATION SYSTEM
 * Sistema de autenticação corporativa para overlays
 * Versão: 2.2.2
 * ═══════════════════════════════════════════════════════════════════════════
 */

(function() {
  'use strict';

  // Garantir que só inicialize uma vez
  if (window.NexosAuth) {
    console.log('[NexosAuth] Já inicializado');
    return;
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     AUTH MANAGER
     ══════════════════════════════════════════════════════════════════════════ */

  class AuthManager {
    constructor() {
      this.storageKey = 'nexos-user-session';
      this.user = null;
      this.callbacks = {
        onLogin: [],
        onLogout: []
      };
      this.initialized = false;
      // NÃO chamar loadSession() aqui - será lazy loaded
      // Apenas carregar do cache local se existir
      this.loadSessionSync();

      // ── Sincronização cross-origin via chrome.storage.onChanged ──
      // Detecta em tempo real quando outra página faz login ou logout,
      // sem depender de postMessage ou eventos compartilhados.
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area !== 'local' || !changes[this.storageKey]) return;

          const { oldValue, newValue } = changes[this.storageKey];

          if (!newValue) {
            // Sessão removida em outra página → logout local
            if (this.user) {
              console.log('[NexosAuth] 🔔 Logout detectado via storage (outra página)');
              localStorage.removeItem(this.storageKey);
              this.triggerCallbacks('onLogout', this.user);
              this.user = null;
            }
          } else if (newValue && newValue.user) {
            // Sessão criada/atualizada em outra página → login local
            const validity = this.checkTokenValidity(newValue);
            if (validity.isValid && !this.user) {
              console.log('[NexosAuth] 🔔 Login detectado via storage (outra página):', newValue.user.displayName);
              this.user = newValue.user;
              localStorage.setItem(this.storageKey, JSON.stringify(newValue));
              this.triggerCallbacks('onLogin', this.user);
            }
          }
        });
      }
    }

    /**
     * Carrega sessão SINCRONA do localStorage (sem SharePoint)
     * Usada apenas na inicialização para não bloquear
     */
    loadSessionSync() {
      try {
        const cached = localStorage.getItem(this.storageKey);
        if (cached) {
          const session = JSON.parse(cached);
          const validity = this.checkTokenValidity(session);
          
          if (validity.isValid) {
            this.user = session.user;
            const minutes = Math.floor(validity.timeRemaining / 60000);
            console.log('[NexosAuth] ✅ Sessão restaurada do cache:', this.user.displayName || this.user.name);
            console.log('[NexosAuth] ⏱️ Token expira em', minutes, 'minutos');
            this.initialized = true;
            return;
          }
        }
        
        // Fallback: tentar restaurar do chrome.storage.local (compartilhado entre páginas da extensão)
        // Isso permite que a sessão criada em qualquer página (ex: Picking) seja reutilizada aqui
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          console.log('[NexosAuth] 🔍 Buscando sessão no chrome.storage.local (cross-origin)...');
          try {
            chrome.storage.local.get([this.storageKey], (result) => {
              try {
                const session = result[this.storageKey];
                if (!session) {
                  console.log('[NexosAuth] ℹ️ Nenhuma sessão no chrome.storage.local');
                  return;
                }
                const validity = this.checkTokenValidity(session);
                if (validity.isValid) {
                  this.user = session.user;
                  // Espelhar no localStorage desta origem para acelerar próximas cargas
                  localStorage.setItem(this.storageKey, JSON.stringify(session));
                  const minutes = Math.floor(validity.timeRemaining / 60000);
                  console.log('[NexosAuth] ✅ Sessão restaurada do chrome.storage:', this.user.displayName || this.user.name);
                  console.log('[NexosAuth] ⏱️ Token expira em', minutes, 'minutos');
                  // Disparar callbacks de login para notificar ouvintes (ex: monitor)
                  this.triggerCallbacks('onLogin', this.user);
                } else {
                  console.log('[NexosAuth] ⚠️ Sessão no chrome.storage.local está expirada');
                }
              } catch (err) {
                console.warn('[NexosAuth] ⚠️ Erro ao processar sessão do chrome.storage:', err);
              }
            });
          } catch (_ctxErr) {
            // Extension context invalidated — ignorar silenciosamente
          }
        }

        console.log('[NexosAuth] ℹ️ Nenhuma sessão local válida encontrada');
        this.initialized = true;
      } catch (error) {
        console.error('[NexosAuth] ❌ Erro ao carregar sessão sync:', error);
        this.initialized = true;
      }
    }

    /**
     * 🆕 V3.0: Verifica validade do token
     * @returns {Object} {isValid: boolean, needsRefresh: boolean, timeRemaining: number}
     */
    checkTokenValidity(session) {
      if (!session || !session.expiresAt) {
        return { isValid: false, needsRefresh: false, timeRemaining: 0 };
      }

      const now = Date.now();
      const expiresAt = session.expiresAt;
      const timeRemaining = expiresAt - now;
      
      // Token expirado
      if (timeRemaining <= 0) {
        return { isValid: false, needsRefresh: true, timeRemaining: 0 };
      }
      
      // Token expira em menos de 5 minutos (refresh preventivo)
      const fiveMinutes = 5 * 60 * 1000;
      if (timeRemaining < fiveMinutes) {
        return { isValid: true, needsRefresh: true, timeRemaining };
      }
      
      // Token válido
      return { isValid: true, needsRefresh: false, timeRemaining };
    }

    /**
     * 🆕 V3.0: Carrega sessão do SharePoint
     * Busca token do SharePoint se não houver cache local válido
     */
    async loadSession() {
      try {
        this.initialized = true;
        
        // ETAPA 1: Verificar cache local (localStorage)
        const sessionData = localStorage.getItem(this.storageKey);
        if (sessionData) {
          const session = JSON.parse(sessionData);
          const validity = this.checkTokenValidity(session);
          
          // Cache válido e não precisa refresh
          if (validity.isValid && !validity.needsRefresh) {
            if (session.user && session.user.displayName && (session.user.email || session.user.id)) {
              this.user = session.user;
              console.log('[NexosAuth] ✅ Sessão restaurada do cache:', this.user.displayName || this.user.email);
              console.log(`[NexosAuth] ⏱️ Token expira em ${Math.floor(validity.timeRemaining / 60000)} minutos`);
              return true;
            }
          }
          
          // Token precisa refresh
          if (validity.needsRefresh) {
            console.log('[NexosAuth] 🔄 Token expirado ou próximo de expirar, tentando refresh...');
            const refreshed = await this.refreshToken();
            if (refreshed) {
              return true;
            }
          }
        }
        
        // ETAPA 2: Não há cache válido, buscar do SharePoint
        console.log('[NexosAuth] 📡 Buscando sessão do SharePoint...');
        const sharePointSession = await this.loadFromSharePoint();
        if (sharePointSession) {
          return true;
        }
        
        // ETAPA 3: Nenhuma sessão válida encontrada
        console.log('[NexosAuth] ℹ️ Nenhuma sessão válida encontrada');
        this.clearSession();
        return false;
        
      } catch (error) {
        console.error('[NexosAuth] ❌ Erro ao carregar sessão:', error);
        this.clearSession();
        return false;
      }
    }

    /**
     * 🆕 V3.0: Carrega sessão do SharePoint
     */
    async loadFromSharePoint() {
      try {
        console.log('[NexosAuth] 📡 Buscando sessão do SharePoint...');
        
        if (typeof TokenVaultManager === 'undefined') {
          console.warn('[NexosAuth] ⚠️ TokenVaultManager não disponível');
          return false;
        }

        // IMPORTANTE: Aguardar MSAL inicializar (timeout 5s)
        if (!window.msalAuth || !window.msalAuth.instance) {
          console.log('[NexosAuth] ⏳ Aguardando MSAL inicializar...');
          const maxWait = 5000;
          const startTime = Date.now();
          
          while ((!window.msalAuth || !window.msalAuth.instance) && (Date.now() - startTime) < maxWait) {
            await new Promise(resolve => setTimeout(resolve, 100));
          }
          
          if (!window.msalAuth || !window.msalAuth.instance) {
            console.warn('[NexosAuth] ⚠️ MSAL não disponível após timeout');
            return false;
          }
        }

        // Verificar se há conta logada no MSAL
        const accounts = window.msalAuth.instance.getAllAccounts();
        if (!accounts || accounts.length === 0) {
          console.log('[NexosAuth] ℹ️ Nenhuma conta MSAL encontrada');
          return false;
        }

        const userEmail = accounts[0].username;
        console.log('[NexosAuth] 🔍 Buscando token para:', userEmail);

        // Obter token MSAL para consultar SharePoint
        let msalToken;
        try {
          msalToken = await window.msalAuth.instance.acquireTokenSilent({
            scopes: ['User.Read', 'Sites.ReadWrite.All'],
            account: accounts[0]
          });
        } catch (error) {
          console.warn('[NexosAuth] ⚠️ Erro ao obter token MSAL:', error.message);
          return false;
        }

        if (!msalToken || !msalToken.accessToken) {
          console.warn('[NexosAuth] ⚠️ Não foi possível obter token MSAL');
          return false;
        }

        // Inicializar TokenVaultManager com token MSAL
        const vault = new TokenVaultManager();
        const initResult = await vault.initializeWithToken(msalToken.accessToken);
        
        if (!initResult.success) {
          console.warn('[NexosAuth] ⚠️ Falha ao inicializar TokenVaultManager:', initResult.error);
          return false;
        }

        // Buscar token salvo do SharePoint
        const result = await vault.getToken(userEmail);
        
        if (!result.success) {
          console.log('[NexosAuth] ℹ️ Token não encontrado no SharePoint para:', userEmail);
          return false;
        }

        // Validar token do SharePoint
        const tokenData = result.data.fields;
        if (!tokenData.IsValid) {
          console.warn('[NexosAuth] ⚠️ Token no SharePoint está marcado como inválido');
          return false;
        }

        const expiresAt = new Date(tokenData.ExpiresAt).getTime();
        const validity = this.checkTokenValidity({ expiresAt });
        
        if (!validity.isValid) {
          console.log('[NexosAuth] ⚠️ Token do SharePoint está expirado');
          // Tentar refresh
          const refreshed = await this.refreshToken();
          return refreshed;
        }

        // Token válido! Reconstruir sessão
        console.log('[NexosAuth] ✅ Token válido encontrado no SharePoint!');
        
        const user = {
          id: userEmail,
          email: userEmail,
          displayName: accounts[0].name || userEmail.split('@')[0],
          name: accounts[0].name || userEmail.split('@')[0],
          accessToken: tokenData.AccessToken,
          refreshToken: tokenData.RefreshToken,
          provider: 'microsoft',
          role: 'Operador'
        };

        // Salvar no cache local
        const session = {
          user,
          expiresAt: expiresAt
        };
        localStorage.setItem(this.storageKey, JSON.stringify(session));
        this.user = user;
        
        console.log('[NexosAuth] ✅ Sessão restaurada do SharePoint:', user.displayName);
        console.log(`[NexosAuth] ⏱️ Token expira em ${Math.floor(validity.timeRemaining / 60000)} minutos`);
        
        return true;
        
      } catch (error) {
        console.error('[NexosAuth] ❌ Erro ao carregar do SharePoint:', error);
        return false;
      }
    }

    /**
     * 🆕 V3.0: Renova token expirado
     * Usa MSAL para obter novo token e atualiza no SharePoint
     */
    async refreshToken() {
      try {
        console.log('[NexosAuth] 🔄 Iniciando refresh de token...');
        
        // unifiedAuth está disponível em content scripts; msalAuth em páginas do Monitor/Admin
        const msalProvider = window.unifiedAuth || window.msalAuth;
        if (!msalProvider) {
          console.warn('[NexosAuth] ⚠️ UnifiedAuth/MsalAuth não disponível para refresh');
          return false;
        }

        // Obter novo token via MSAL (silencioso)
        const tokenResponse = await msalProvider.acquireTokenSilent({
          scopes: ['User.Read', 'Sites.ReadWrite.All']
        });

        if (!tokenResponse || !tokenResponse.accessToken) {
          console.warn('[NexosAuth] ⚠️ Falha ao obter novo token via MSAL');
          return false;
        }

        const accounts = await msalProvider.getAllAccounts();
        if (!accounts || accounts.length === 0) {
          console.warn('[NexosAuth] ⚠️ Nenhuma conta MSAL encontrada');
          return false;
        }

        const account = accounts[0];
        const userEmail = account.username;

        console.log('[NexosAuth] ✅ Novo token obtido via MSAL');
        console.log('[NexosAuth] 💾 Atualizando token no SharePoint...');

        // Atualizar no SharePoint
        if (typeof TokenVaultManager !== 'undefined') {
          const vault = new TokenVaultManager();
          const initResult = await vault.initializeWithToken(tokenResponse.accessToken);
          
          if (initResult.success) {
            const expiresAt = new Date(Date.now() + 24*60*60*1000).toISOString();
            
            // Atualizar token existente
            const updateResult = await vault.updateToken(userEmail, {
              accessToken: tokenResponse.accessToken,
              expiresAt: expiresAt,
              isValid: true
            });
            
            if (updateResult.success) {
              console.log('[NexosAuth] ✅ Token atualizado no SharePoint!');
            } else {
              console.warn('[NexosAuth] ⚠️ Falha ao atualizar SharePoint:', updateResult.error);
            }
          }
        }

        // Atualizar cache local
        const user = {
          id: account.homeAccountId,
          email: userEmail,
          displayName: account.name || userEmail.split('@')[0],
          name: account.name || userEmail.split('@')[0],
          accessToken: tokenResponse.accessToken,
          provider: 'microsoft',
          role: 'Operador'
        };

        const session = {
          user,
          expiresAt: Date.now() + (24 * 60 * 60 * 1000)
        };

        localStorage.setItem(this.storageKey, JSON.stringify(session));
        this.user = user;

        console.log('[NexosAuth] ✅ Token renovado com sucesso!');
        return true;

      } catch (error) {
        // Erros esperados em contextos sem MSAL (content script, monitor) — suprimir
        const _msg = error?.message || '';
        const _isExpected = (
          (error instanceof TypeError && _msg.includes('is not a function')) ||
          _msg.includes('não foi inicializado') ||
          _msg.includes('Chame init()') ||
          error.errorCode === 'interaction_required' ||
          error.errorCode === 'consent_required'
        );
        if (!_isExpected) {
          console.warn('[NexosAuth] ⚠️ Falha ao renovar token:', _msg);
        }
        return false;
      }
    }

    /**
     * Salva sessão
     */
    async saveSession(user) {
      try {
        const expiresAt = Date.now() + (24 * 60 * 60 * 1000); // 24 horas
        const session = {
          user,
          expiresAt
        };
        
        // Salvar no localStorage (principal)
        localStorage.setItem(this.storageKey, JSON.stringify(session));
        this.user = user;
        
        // Também salvar no chrome.storage para sincronizar com popup
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({
            'nexos_current_user': user,
            'nexos-user-session': session
          }).catch(err => {
            console.warn('[NexosAuth] ⚠️ Falha ao salvar no chrome.storage:', err);
          });
        }
        
        // Disparar callback de login
        this.triggerCallbacks('onLogin', user);
        
        console.log('[NexosAuth] ✅ Sessão salva:', user.displayName || user.name);
        
        // 🆕 INTEGRAÇÃO V3.0: Salvar token no SharePoint via TokenVaultManager
        try {
          if (typeof TokenVaultManager !== 'undefined' && user.accessToken) {
            console.log('[NexosAuth] 💾 Salvando token no SharePoint via TokenVaultManager...');
            
            const vault = new TokenVaultManager();
            const userEmail = user.email || user.username || 'unknown';
            
            // Inicializar com o token do usuário
            const initResult = await vault.initializeWithToken(user.accessToken);
            
            if (initResult.success) {
              // 🆕 V3.0: Verificar se token já existe (UPDATE vs CREATE)
              console.log('[NexosAuth] 🔍 Verificando se token já existe...');
              const existingToken = await vault.getToken(userEmail);
              console.log('[NexosAuth] 📊 Resultado da busca:', existingToken ? 'ENCONTRADO' : 'NÃO ENCONTRADO');
              
              if (existingToken && existingToken.id) {
                // TOKEN EXISTE: Atualizar
                console.log('[NexosAuth] 🔄 Token já existe (ID: ' + existingToken.id + '), atualizando...');
                try {
                  const updated = await vault.updateToken(userEmail, {
                    accessToken: user.accessToken,
                    refreshToken: user.refreshToken || 'N/A',
                    expiresAt: new Date(expiresAt).toISOString(),
                    isValid: true,
                    lastUsedAt: new Date().toISOString()
                  });
                  
                  console.log('[NexosAuth] ✅ Token atualizado no SharePoint!');
                  console.log('[NexosAuth] 📊 Campos atualizados:', updated);
                } catch (updateError) {
                  console.warn('[NexosAuth] ⚠️ Erro ao atualizar token:', updateError);
                }
              } else {
                // TOKEN NÃO EXISTE: Criar novo
                console.log('[NexosAuth] 🆕 Token não encontrado, criando novo...');
                try {
                  const created = await vault.createToken({
                    userId: userEmail,
                    accessToken: user.accessToken,
                    refreshToken: user.refreshToken || 'N/A',
                    expiresAt: new Date(expiresAt).toISOString(),
                    isValid: true,
                    deviceId: 'Nexos-Extension-Auto-Save',
                    scopes: 'User.Read Sites.ReadWrite.All'
                  });
                  
                  console.log('[NexosAuth] ✅ Token criado no SharePoint!');
                  console.log('[NexosAuth] 📊 Item ID:', created.id);
                } catch (createError) {
                  console.warn('[NexosAuth] ⚠️ Erro ao criar token:', createError);
                }
              }
            } else {
              console.warn('[NexosAuth] ⚠️ Falha ao inicializar TokenVaultManager:', initResult.error);
            }
          } else if (window.authTokenService && user.accessToken) {
            // Fallback para AuthTokenServiceV1 (legado)
            console.log('[NexosAuth] 💾 Salvando token via AuthTokenServiceV1 (fallback)...');
            
            const refreshToken = user.refreshToken || 'N/A';
            const expiresInSeconds = Math.floor((expiresAt - Date.now()) / 1000);
            
            await window.authTokenService.saveToken(
              user.accessToken,
              refreshToken,
              expiresInSeconds
            );
            
            console.log('[NexosAuth] ✅ Token salvo via fallback!');
          } else {
            console.log('[NexosAuth] ℹ️ TokenVaultManager não disponível, token não salvo no SharePoint');
          }
        } catch (sharePointError) {
          console.warn('[NexosAuth] ⚠️ Erro ao salvar token no SharePoint:', sharePointError.message);
          // Não bloquear o fluxo, continuar mesmo se SharePoint falhar
        }
      } catch (error) {
        console.error('[NexosAuth] Erro ao salvar sessão:', error);
      }
    }

    /**
     * 🆕 V3.0: Limpa sessão e invalida no SharePoint
     */
    async clearSession() {
      try {
        // Invalidar token no SharePoint (best effort - não bloqueia logout se falhar)
        if (this.user && this.user.email && typeof TokenVaultManager !== 'undefined') {
          try {
            // Obter token MSAL para acessar SharePoint
            let msalToken = null;
            
            // Opção 1: Via UnifiedAuth (preferencial)
            if (window.unifiedAuth && window.unifiedAuth.getMSALToken) {
              msalToken = await window.unifiedAuth.getMSALToken();
            } 
            // Opção 2: Via MSAL direto
            else if (window.msalAuth && window.msalAuth.instance) {
              const accounts = window.msalAuth.instance.getAllAccounts();
              if (accounts && accounts.length > 0) {
                const silentRequest = {
                  account: accounts[0],
                  scopes: ['https://graph.microsoft.com/.default']
                };
                try {
                  const response = await window.msalAuth.instance.acquireTokenSilent(silentRequest);
                  msalToken = response.accessToken;
                } catch (msalError) {
                  // Token expirado ou erro MSAL - ignorar silenciosamente
                }
              }
            }
            // Opção 3: Via localStorage (token interceptado)
            else if (typeof localStorage !== 'undefined') {
              msalToken = localStorage.getItem('nexos-intercepted-token') || 
                         localStorage.getItem('access-token');
            }

            if (msalToken) {
              const vault = new TokenVaultManager();
              const initResult = await vault.initializeWithToken(msalToken);
              
              if (initResult.success) {
                // Atualizar LastUsedAt e marcar token como inválido
                try {
                  await vault.updateToken(this.user.email, {
                    isValid: false,
                    lastUsedAt: new Date().toISOString()
                  });
                } catch (updateError) {
                  // Ignorar erro de atualização (token pode já estar expirado)
                }
              }
            }
          } catch (sharePointError) {
            // Ignorar erros de SharePoint durante logout (token pode estar expirado)
          }
        }

        // Limpar localStorage
        localStorage.removeItem(this.storageKey);
        localStorage.removeItem('nexos-intercepted-token');
        localStorage.removeItem('access-token');
        
        // Limpar chrome.storage
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.remove(['nexos_current_user', 'nexos-user-session']).catch(() => {
            // Ignorar erro silenciosamente
          });
        }

        // Disparar callback de logout
        this.triggerCallbacks('onLogout', this.user);
        
        this.user = null;
        
      } catch (error) {
        // Garantir limpeza local mesmo se houver erro
        localStorage.removeItem(this.storageKey);
        localStorage.removeItem('nexos-intercepted-token');
        localStorage.removeItem('access-token');
        this.user = null;
      }
    }

    /**
     * 🆕 V3.0: Verifica se está autenticado (com validação de token)
     */
    async isAuthenticated() {
      if (!this.user) {
        // Fallback: tentar restaurar do chrome.storage.local antes de desistir
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          try {
            const result = await new Promise(resolve =>
              chrome.storage.local.get([this.storageKey], resolve)
            );
            const session = result[this.storageKey];
            if (session) {
              const validity = this.checkTokenValidity(session);
              if (validity.isValid) {
                this.user = session.user;
                localStorage.setItem(this.storageKey, JSON.stringify(session));
                console.log('[NexosAuth] ✅ isAuthenticated: sessão restaurada do chrome.storage:', this.user.displayName || this.user.name);
              }
            }
          } catch (e) {
            console.warn('[NexosAuth] ⚠️ isAuthenticated: erro ao ler chrome.storage:', e.message);
          }
        }
        if (!this.user) return false;
      }

      try {
        // Verificar validade do token
        const sessionData = localStorage.getItem(this.storageKey);
        if (!sessionData) {
          this.user = null;
          return false;
        }

        const session = JSON.parse(sessionData);
        const validity = this.checkTokenValidity(session);
        
        // Token expirado
        if (!validity.isValid) {
          console.log('[NexosAuth] ⚠️ Token expirado, tentando renovar...');
          const refreshed = await this.refreshToken();
          return refreshed;
        }
        
        // Token expirando em breve (< 5 min), renovar preventivamente
        if (validity.needsRefresh) {
          console.log('[NexosAuth] 🔄 Token próximo de expirar, renovando preventivamente...');
          // Não esperar o resultado, renovar em background
          this.refreshToken().catch(err => {
            console.warn('[NexosAuth] ⚠️ Erro ao renovar preventivamente:', err);
          });
        }

        // Verificar expiração real do JWT — o accessToken Microsoft expira em ~1h,
        // mas a janela de sessão é de 24h. Sem esta verificação, chamadas de API
        // falham com 401 mesmo que isAuthenticated() retorne true.
        const _jwtExp = (() => {
          try {
            const jwt = session?.user?.accessToken;
            if (!jwt) return null;
            const parts = jwt.split('.');
            if (parts.length < 2) return null;
            const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
            return payload.exp ? payload.exp * 1000 : null;
          } catch (_) { return null; }
        })();
        if (_jwtExp !== null && _jwtExp <= Date.now()) {
          console.log('[NexosAuth] ⚠️ JWT expirado (' + new Date(_jwtExp).toISOString() + '), tentando renovar...');
          const refreshed = await this.refreshToken();
          if (!refreshed) {
            // Se a renovação falhou mas a janela de sessão de 24h ainda é válida,
            // NÃO invalidar a sessão — o usuário continua autenticado pelo Nexos.
            // O token novo será obtido na próxima ação que exija Graph API.
            const sessionStillValid = session && session.expiresAt && session.expiresAt > Date.now();
            if (sessionStillValid) {
              // JWT expirado e refresh não disponível (content script sem MSAL)
              // Retornar false para que o overlay possa pedir re-login ao usuário
              return false;
            }
            console.warn('[NexosAuth] ⚠️ Renovação falhou — sessão inválida, forçando re-login');
            this.user = null;
            localStorage.removeItem(this.storageKey);
            return false;
          }
        }

        return true;
        
      } catch (error) {
        console.error('[NexosAuth] ❌ Erro ao verificar autenticação:', error);
        return this.user !== null;
      }
    }

    /**
     * Obtém usuário atual
     */
    getCurrentUser() {
      return this.user;
    }

    /**
     * Verifica se há redirect pendente (volta do Microsoft)
     */
    async handleRedirectIfNeeded() {
      try {
        // Verificar se tem redirect pendente
        const hasPendingAuth = sessionStorage.getItem('nexos-auth-pending') === 'true';
        if (!hasPendingAuth) {
          return null;
        }

        console.log('[NexosAuth] 🔄 Processando retorno do redirect Microsoft...');

        if (!window.AZURE_AD_CONFIG || typeof msal === 'undefined') {
          console.warn('[NexosAuth] ⚠️ MSAL ou config não disponível');
          sessionStorage.removeItem('nexos-auth-pending');
          return null;
        }

        // Inicializar MSAL
        const msalConfig = {
          auth: {
            clientId: window.AZURE_AD_CONFIG.clientId,
            authority: window.AZURE_AD_CONFIG.authority,
            redirectUri: window.AZURE_AD_CONFIG.redirectUri,
          },
          cache: window.AZURE_AD_CONFIG.cache
        };

        const msalInstance = new msal.PublicClientApplication(msalConfig);
        await msalInstance.initialize();

        // Processar o redirect
        const redirectResponse = await msalInstance.handleRedirectPromise();

        if (redirectResponse && redirectResponse.account) {
          console.log('[NexosAuth] ✅ Redirect processado com sucesso');

          // Buscar dados completos
          const graphClient = new window.AuthGraphClient(this.msalAuth);
          const userData = await graphClient.getUserProfile();
          const photoUrl = await graphClient.getUserPhoto();

          const user = {
            id: userData.id,
            email: userData.mail || userData.userPrincipalName,
            name: userData.displayName,
            firstName: userData.givenName || userData.displayName.split(' ')[0],
            lastName: userData.surname || userData.displayName.split(' ').slice(1).join(' '),
            photo: photoUrl,
            jobTitle: userData.jobTitle || 'Sem cargo definido',
            department: userData.department || 'Não especificado',
            officeLocation: userData.officeLocation || '',
            mobilePhone: userData.mobilePhone || '',
            businessPhones: userData.businessPhones || [],
            role: 'Operador',
            provider: 'microsoft',
            accessToken: redirectResponse.accessToken
          };

          await this.saveSession(user);
          this.triggerCallbacks('onLogin', user);

          // Limpar flag
          sessionStorage.removeItem('nexos-auth-pending');

          return user;
        }

        sessionStorage.removeItem('nexos-auth-pending');
        return null;

      } catch (error) {
        console.error('[NexosAuth] ❌ Erro ao processar redirect:', error);
        sessionStorage.removeItem('nexos-auth-pending');
        return null;
      }
    }

    /**
     * Login com Microsoft usando webview embutido ou popup fallback
     * @param {HTMLElement} statusContainer - Container para mostrar progresso visual
     * @param {HTMLElement} webview - Webview para exibir login embutido (opcional)
     * @param {HTMLElement} loadingOverlay - Overlay de loading para esconder após carregar
     */
    async loginWithMicrosoft(statusContainer = null, webview = null, loadingOverlay = null) {
      try {
        console.log('[NexosAuth] 🔐 Iniciando login Microsoft...');

        // ========================================
        // MODO VISUAL: Mostrar progresso no container
        // ========================================
        const updateStatus = (emoji, title, message, isSuccess = false, isError = false) => {
          if (!statusContainer) return;
          
          let bgColor = 'white';
          
          if (isSuccess) {
            bgColor = 'var(--nexos-success-light, #e8f5e9)';
          } else if (isError) {
            bgColor = 'var(--nexos-error-light, #ffebee)';
          }
          
          statusContainer.innerHTML = `
            <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; background: ${bgColor}; transition: all 0.3s;">
              <div style="font-size: 64px; margin-bottom: 24px; animation: ${!isSuccess && !isError ? 'nexosPulse 2s ease-in-out infinite' : 'none'};">
                ${emoji}
              </div>
              <h3 style="font-size: 20px; margin: 0 0 12px; color: var(--nexos-text-primary);">
                ${title}
              </h3>
              <p style="font-size: 14px; color: var(--nexos-text-secondary); line-height: 1.6; max-width: 400px; text-align: center;">
                ${message}
              </p>
            </div>
          `;
        };

        // ========================================
        // ========================================
        // WEBVIEW DESATIVADO - Usar apenas popup
        // ========================================
        if (false && webview && typeof chrome !== 'undefined' && chrome.runtime) {
          console.log('[NexosAuth] �️ Tentando login com webview embutido...');
          
          try {
            // Solicitar URL de autenticação
            const authUrlResponse = await new Promise((resolve, reject) => {
              const timeout = setTimeout(() => reject(new Error('Timeout')), 10000);
              
              chrome.runtime.sendMessage({ type: 'GET_AUTH_URL' }, (response) => {
                clearTimeout(timeout);
                if (chrome.runtime.lastError || !response?.url) {
                  reject(new Error('Falha ao obter URL'));
                  return;
                }
                resolve(response);
              });
            });

            // Esconder loading e mostrar webview
            if (loadingOverlay) {
              loadingOverlay.style.display = 'none';
            }
            webview.style.display = 'block';
            
            // Carregar URL no webview
            webview.src = authUrlResponse.url;
            console.log('[NexosAuth] ✅ Webview carregado com URL de autenticação');

            // Monitorar redirect via polling de storage
            const result = await new Promise((resolve, reject) => {
              const timeout = setTimeout(() => {
                reject(new Error('Timeout: login não completado em 5 minutos'));
              }, 300000);

              const pollInterval = setInterval(async () => {
                try {
                  // Verificar se contexto da extensão ainda é válido
                  if (!chrome?.runtime?.id) {
                    console.debug('[NexosAuth] contexto invalidado - interrompendo polling');
                    clearTimeout(timeout);
                    clearInterval(pollInterval);
                    resolve({ success: false, aborted: true });
                    return;
                  }
                  
                  const pending = await new Promise((res) => {
                    chrome.storage.local.get(['nexos-oauth-pending'], (result) => {
                      res(result['nexos-oauth-pending']);
                    });
                  });
                  
                  if (pending?.accessToken) {
                    console.log('[NexosAuth] ✅ Token detectado via storage');
                    clearTimeout(timeout);
                    clearInterval(pollInterval);
                    
                    // Limpar storage
                    chrome.storage.local.remove(['nexos-oauth-pending']);
                    
                    // Buscar dados do usuário
                    const graphResponse = await fetch('https://graph.microsoft.com/v1.0/me', {
                      headers: { 'Authorization': `Bearer ${pending.accessToken}` }
                    });
                    
                    if (!graphResponse.ok) {
                      throw new Error(`Graph API retornou ${graphResponse.status}`);
                    }
                    
                    const userData = await graphResponse.json();
                    
                    resolve({
                      success: true,
                      user: {
                        id: userData.id,
                        email: userData.mail || userData.userPrincipalName,
                        displayName: userData.displayName,
                        givenName: userData.givenName,
                        surname: userData.surname,
                        jobTitle: userData.jobTitle || 'Colaborador',
                        department: userData.department || 'Geral'
                      }
                    });
                  }
                } catch (e) {
                  // Ignorar erro de extension context invalidated
                  if (e.message && e.message.includes('Extension context invalidated')) {
                    console.debug('[NexosAuth] contexto invalidado - interrompendo polling');
                    clearInterval(pollInterval);
                    resolve({ success: false, aborted: true });
                  } else {
                    console.warn('[NexosAuth] Erro no polling:', e);
                  }
                }
              }, 1000);
            });

            if (result.success && result.user) {
              updateStatus(
                '✅',
                'Login realizado com sucesso!',
                `Bem-vindo(a), ${result.user.displayName}`,
                true
              );
              
              await this.saveSession(result.user);
              await new Promise(resolve => setTimeout(resolve, 1500));
              
              return { success: true, user: result.user };
            }
          } catch (webviewError) {
            console.warn('[NexosAuth] ⚠️ Webview falhou, usando popup:', webviewError);
            // Continua para fallback de popup
          }
        }

        // ========================================
        // LOGIN VIA POPUP (método principal)
        // ========================================
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
          console.log('[NexosAuth] 🪟 Abrindo popup de autenticação...');
          
          // Atualizar UI para indicar popup
          if (loadingOverlay) {
            loadingOverlay.innerHTML = `
              <div style="font-size: 64px; margin-bottom: 24px;">⭕</div>
              <h3 style="font-size: 20px; margin: 0 0 12px; color: var(--nexos-text-primary);">
                Abrindo janela de login...
              </h3>
              <p style="font-size: 14px; color: var(--nexos-text-secondary); line-height: 1.6; max-width: 400px; margin: 0 auto;">
                Complete o login na janela popup que será aberta.
              </p>
            `;
            loadingOverlay.style.display = 'flex';
          }
          
          try {
            // ═══════════════════════════════════════════════════════════════
            // VERIFICAÇÃO CRÍTICA: Contexto da extensão
            // ═══════════════════════════════════════════════════════════════
            // Se usuário deu F5 ou extensão foi recarregada, chrome.runtime pode
            // não estar mais disponível. Detectar ANTES de tentar usar.
            
            if (!chrome?.runtime?.id) {
              console.debug('[NexosAuth] contexto invalidado');
              
              updateStatus(
                '🔄',
                'Extensão recarregada',
                'Recarregue a página (F5) para continuar',
                false,
                true
              );
              
              // Aguardar 3 segundos e auto-recarregar
              setTimeout(() => {
                console.log('[NexosAuth] 🔄 Auto-recarregando página...');
                window.location.reload();
              }, 3000);
              
              return { success: false, error: 'CONTEXT_INVALIDATED' };
            }
            
            const result = await new Promise((resolve, reject) => {
              const timeout = setTimeout(() => {
                reject(new Error('TIMEOUT'));
              }, 60000);

              chrome.runtime.sendMessage(
                { type: 'MS_AUTH_REQUEST' },
                (response) => {
                  clearTimeout(timeout);
                  
                  if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                  }
                  
                  if (!response) {
                    reject(new Error('ABORTED')); // Login abortado
                    return;
                  }
                  
                  if (response.success) {
                    resolve(response);
                  } else {
                    reject(new Error(response?.error || 'Falha na autenticação'));
                  }
                }
              );
            });

            if (result.user) {
              updateStatus(
                '✅',
                'Login realizado com sucesso!',
                `Bem-vindo(a), ${result.user.displayName}`,
                true
              );
              
              await this.saveSession(result.user);
              await new Promise(resolve => setTimeout(resolve, 1500));
              
              return { success: true, user: result.user };
            }
          } catch (authError) {
            // Verificar se foi abortado pelo usuário
            if (authError.message === 'ABORTED' || authError.message === 'TIMEOUT') {
              console.log('[NexosAuth] 🚫 Login abortado pelo usuário');
              
              updateStatus(
                '🚫',
                'Login cancelado',
                'Você fechou a janela de autenticação',
                false,
                true
              );
              
              await new Promise(resolve => setTimeout(resolve, 2000));
              
              // Retornar como abortado (não erro, não sucesso)
              return { success: false, aborted: true };
            }
            
            // Verificar se usuário negou acesso (não é erro, é decisão do usuário)
            if (authError.message && authError.message.includes('user did not approve')) {
              console.log('[NexosAuth] 🚫 Usuário negou acesso');
              
              updateStatus(
                '🚫',
                'Acesso negado',
                'Você negou o acesso à sua conta Microsoft',
                false,
                true
              );
              
              await new Promise(resolve => setTimeout(resolve, 2000));
              
              return { success: false, denied: true };
            }
            
            console.warn('[NexosAuth] ⚠️ Erro no popup:', authError);
            
            updateStatus(
              '❌',
              'Erro na autenticação',
              authError.message || 'Falha ao conectar com Microsoft',
              false,
              true
            );
            
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            return { success: false, error: 'ABORTED' };
          }
        }

        // ========================================
        // Sem chrome.runtime disponível
        // ========================================
        console.error('[NexosAuth] ❌ chrome.runtime não disponível');
        return { success: false, error: 'NO_CHROME_RUNTIME' };

      } catch (error) {
        console.error('[NexosAuth] ❌ Erro no login Microsoft:', error);
        return { success: false, error: error.message };
      }
    }

    /**
     * Logout
     */
    async logout() {
      try {
        const user = this.user;
        await this.clearSession();
        this.triggerCallbacks('onLogout', user);
        
        // Recarregar página para limpar estado completamente
        if (typeof window !== 'undefined' && window.location) {
          setTimeout(() => {
            window.location.reload();
          }, 300);
        }
      } catch (error) {
        console.error('[NexosAuth] ❌ Erro no logout:', error);
        // Garantir limpeza mínima
        this.user = null;
        localStorage.clear();
        
        // Recarregar mesmo com erro
        if (typeof window !== 'undefined' && window.location) {
          setTimeout(() => {
            window.location.reload();
          }, 300);
        }
      }
    }

    /**
     * Registra callback
     */
    on(event, callback) {
      if (this.callbacks[event]) {
        this.callbacks[event].push(callback);
      }
    }

    /**
     * Remove callback
     */
    off(event, callback) {
      if (this.callbacks[event]) {
        const index = this.callbacks[event].indexOf(callback);
        if (index > -1) {
          this.callbacks[event].splice(index, 1);
        }
      }
    }

    /**
     * Dispara callbacks
     */
    triggerCallbacks(event, data) {
      if (this.callbacks[event]) {
        this.callbacks[event].forEach(cb => cb(data));
      }
    }
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     LOGIN OVERLAY
     ══════════════════════════════════════════════════════════════════════════ */

  let loginOverlayOpen = false; // Flag para evitar duplicação
  let currentLoginElements = null; // Armazena elementos do login atual

  async function showLoginOverlay(options = {}) {
    const { container = null } = options;
    
    // Se já tem um modal aberto, fecha antes de abrir novo
    if (loginOverlayOpen && currentLoginElements) {
      console.warn('[NexosAuth] ⚠️ Fechando modal de login anterior...');
      
      // Remove elementos antigos
      if (currentLoginElements.backdrop && currentLoginElements.backdrop.parentNode) {
        currentLoginElements.backdrop.remove();
      }
      if (currentLoginElements.overlay && currentLoginElements.overlay.parentNode) {
        currentLoginElements.overlay.remove();
      }
      // Se tinha container, limpa ele também
      if (currentLoginElements.container) {
        currentLoginElements.container.innerHTML = '';
      }
      
      loginOverlayOpen = false;
      currentLoginElements = null;
      
      // Pequeno delay para garantir que o DOM foi limpo
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    
    loginOverlayOpen = true;

    return new Promise((resolveOuter) => {
      let backdrop, overlay;

      // ── Wrapper: garante que só resolve uma vez e limpa listener cross-tab ──
      let _loginResolved = false;
      let _crossTabLoginListener = null;
      const resolve = (val) => {
        if (_loginResolved) return;
        _loginResolved = true;
        if (_crossTabLoginListener && typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
          try { chrome.storage.onChanged.removeListener(_crossTabLoginListener); } catch (_) {}
          _crossTabLoginListener = null;
        }
        resolveOuter(val);
      };

      // ── Detecção cross-tab: se o usuário logar em outra aba/contexto, ──
      // ── o chrome.storage.onChanged dispara aqui também e resolve o login ──
      if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
        _crossTabLoginListener = (changes, area) => {
          if (area !== 'local' || !changes['nexos-user-session']) return;
          const { newValue } = changes['nexos-user-session'];
          if (!newValue?.user || !newValue.expiresAt || newValue.expiresAt <= Date.now()) return;
          console.log('[NexosAuth] 🔔 Login cross-tab detectado → fechando login overlay automaticamente:', newValue.user.displayName || newValue.user.name || '');
          try { if (backdrop?.parentNode) backdrop.remove(); } catch (_) {}
          try { if (overlay?.parentNode) overlay.remove(); } catch (_) {}
          if (container) { try { container.innerHTML = ''; } catch (_) {} }
          loginOverlayOpen = false;
          currentLoginElements = null;
          resolve(newValue.user);
        };
        chrome.storage.onChanged.addListener(_crossTabLoginListener);
      }

      if (container) {
        // ════════════════════════════════════════════════════════════════════
        // MODO INLINE: Renderiza dentro do container (sem backdrop global)
        // Ocupa TODO o espaço do overlay (aside, header, footer, tudo)
        // ════════════════════════════════════════════════════════════════════
        overlay = document.createElement('div');
        overlay.className = 'nexos-login-inline';
        overlay.style.cssText = `
          position: absolute;
          inset: 0;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: var(--nexos-bg-primary, #FFFFFF);
          z-index: 1000;
        `;
      } else {
        // ════════════════════════════════════════════════════════════════════
        // MODO MODAL: Backdrop global que escurece tela
        // ════════════════════════════════════════════════════════════════════
        backdrop = document.createElement('div');
        backdrop.className = 'nexos-login-backdrop';
        
        // Fechar ao clicar fora do overlay
        backdrop.addEventListener('click', (e) => {
          // Só fecha se clicou diretamente no backdrop (não no overlay)
          if (e.target === backdrop) {
            console.log('[NexosAuth] 🚪 Fechando overlay por clique no backdrop');
            if (backdrop) backdrop.remove();
            if (overlay && overlay.parentNode) overlay.remove();
            loginOverlayOpen = false;
            currentLoginElements = null;
            resolve(null); // Resolve como cancelado
          }
        });

        overlay = document.createElement('div');
        overlay.className = 'nexos-overlay nexos-modal nexos-login-modal';
      }

      const contentContainer = document.createElement('div');
      contentContainer.className = 'nexos-login-container';
      contentContainer.style.cssText = container ? `
        width: 100%;
        max-width: 400px;
        text-align: center;
      ` : '';

      // Logo
      const logo = document.createElement('img');
      logo.src = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL)
        ? chrome.runtime.getURL('images/logo.png')
        : 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128"><circle cx="64" cy="64" r="50" fill="%234CAF50"/></svg>';
      logo.className = 'nexos-login-logo';
      contentContainer.appendChild(logo);

      // Título
      const title = document.createElement('h1');
      title.textContent = 'Nexos';
      title.className = 'nexos-login-title';
      contentContainer.appendChild(title);

      // Subtítulo
      const subtitle = document.createElement('p');
      subtitle.textContent = 'Faça login para continuar';
      subtitle.className = 'nexos-login-subtitle';
      contentContainer.appendChild(subtitle);

      // Botão de login
      const loginBtn = document.createElement('button');
      loginBtn.className = 'nexos-btn nexos-btn-primary nexos-btn-lg nexos-login-btn';
      loginBtn.textContent = '🔐 Entrar com Conta Corporativa';
      loginBtn.type = 'button';
      
      loginBtn.addEventListener('click', async (e) => {
        // Previne múltiplos cliques
        if (loginBtn.disabled) return;
        
        loginBtn.disabled = true;
        loginBtn.textContent = '⏳ Autenticando...';

        // Cria container simulando janela de login embutida
        const windowContainer = document.createElement('div');
        windowContainer.className = 'nexos-login-window-container';
        windowContainer.style.cssText = `
          margin-top: 16px;
          width: 100%;
          height: 520px;
          border: 2px solid var(--nexos-primary, #1976d2);
          border-radius: 12px;
          overflow: hidden;
          background: #f5f5f5;
          position: relative;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        `;

        // Barra de título simulando janela
        const titleBar = document.createElement('div');
        titleBar.className = 'nexos-window-titlebar';
        titleBar.style.cssText = `
          height: 40px;
          background: linear-gradient(180deg, #ffffff 0%, #f0f0f0 100%);
          border-bottom: 1px solid #ddd;
          display: flex;
          align-items: center;
          padding: 0 16px;
          gap: 12px;
        `;
        titleBar.innerHTML = `
          <div style="display: flex; gap: 6px;">
            <div style="width: 12px; height: 12px; border-radius: 50%; background: #ff5f57;"></div>
            <div style="width: 12px; height: 12px; border-radius: 50%; background: #febc2e;"></div>
            <div style="width: 12px; height: 12px; border-radius: 50%; background: #28c840;"></div>
          </div>
          <div style="flex: 1; text-align: center; font-size: 13px; font-weight: 500; color: #666;">
            🔐 Login Microsoft - login.microsoftonline.com
          </div>
        `;

        const contentArea = document.createElement('div');
        contentArea.className = 'nexos-window-content';
        contentArea.style.cssText = `
          height: calc(100% - 40px);
          background: white;
          display: flex;
          flex-direction: column;
          align-items: stretch;
          justify-content: stretch;
          padding: 0;
          text-align: center;
          position: relative;
          overflow: hidden;
        `;

        const loadingContent = document.createElement('div');
        loadingContent.style.cssText = `
          animation: nexosPulse 2s ease-in-out infinite;
          position: absolute;
          inset: 0;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 40px;
          background: white;
          z-index: 10;
        `;
        loadingContent.innerHTML = `
          <div style="font-size: 64px; margin-bottom: 24px;">🔐</div>
          <h3 style="font-size: 20px; margin: 0 0 12px; color: var(--nexos-text-primary);">
            Carregando autenticação Microsoft...
          </h3>
          <p style="font-size: 14px; color: var(--nexos-text-secondary); line-height: 1.6; max-width: 400px; margin: 0 auto 24px;">
            Complete o login <strong>dentro desta janela</strong>.<br>
            Ela fechará automaticamente após autenticação.
          </p>
          <div style="margin-top: 20px; padding: 16px; background: var(--nexos-info-light, #e3f2fd); border-radius: 8px; font-size: 13px; color: var(--nexos-text-primary);">
            💡 <strong>Dica:</strong> O login acontece aqui mesmo, sem abrir novas abas
          </div>
        `;
        
        // Adiciona animação de pulse
        if (!document.getElementById('nexos-pulse-animation')) {
          const style = document.createElement('style');
          style.id = 'nexos-pulse-animation';
          style.textContent = `
            @keyframes nexosPulse {
              0%, 100% { opacity: 1; }
              50% { opacity: 0.7; }
            }
          `;
          document.head.appendChild(style);
        }

        contentArea.appendChild(loadingContent);
        windowContainer.appendChild(titleBar);
        windowContainer.appendChild(contentArea);
        contentContainer.appendChild(windowContainer);

        // ════════════════════════════════════════════════════════════════════
        // ESTRATÉGIA: USAR WEBVIEW (Chrome Extension específico)
        // webview é mais seguro que iframe e permite carregar conteúdo externo
        // Sem vulnerabilidades de sandbox
        // ════════════════════════════════════════════════════════════════════
        
        const webview = document.createElement('webview');
        webview.className = 'nexos-auth-webview';
        webview.style.cssText = `
          width: 100%;
          height: 100%;
          border: none;
          position: absolute;
          inset: 0;
          background: white;
          z-index: 5;
          display: none;
        `;
        webview.partition = 'persist:nexos-auth'; // Sessão isolada
        
        contentArea.appendChild(webview);

        // Pequeno delay para mostrar a UI antes de iniciar OAuth
        await new Promise(resolve => setTimeout(resolve, 500));

        const result = await authManager.loginWithMicrosoft(contentArea, webview, loadingContent);

        // Remove window container
        if (windowContainer && windowContainer.parentNode) {
          windowContainer.remove();
        }

        if (result.success) {
          // ✅ AUTO-REGISTRO: Criar/atualizar usuário no SharePoint
          try {
            // Diagnóstico: verificar estado do NexosUserManager
            console.log('[NexosAuth] 🔍 Diagnóstico NexosUserManager:');
            console.log('  - typeof window:', typeof window);
            console.log('  - typeof window.NexosUserManager:', typeof window.NexosUserManager);
            console.log('  - window.NexosUserManager existe?', !!window.NexosUserManager);
            console.log('  - Métodos disponíveis:', window.NexosUserManager ? Object.getOwnPropertyNames(Object.getPrototypeOf(window.NexosUserManager)) : 'N/A');
            
            // Aguardar NexosUserManager estar disponível (verificação simples)
            if (typeof window.NexosUserManager !== 'undefined') {
              console.log('[NexosAuth] ✅ NexosUserManager disponível, inicializando...');
              // Tentar inicializar primeiro
              const initSuccess = await window.NexosUserManager.initialize();
              if (!initSuccess) {
                throw new Error('Falha ao inicializar NexosUserManager');
              }
              
              const userCheck = await window.NexosUserManager.checkUserAccess(result.user.email);
              
              if (userCheck.status === 'nao_cadastrado') {
                // Primeiro login - criar usuário
                const createResult = await window.NexosUserManager.createUser({
                  email: result.user.email,
                  name: result.user.name,
                  displayName: result.user.displayName || result.user.name,
                  id: result.user.id,
                  photo: result.user.photo,
                  jobTitle: result.user.jobTitle,
                  department: result.user.department
                });
                
                if (createResult.success) {
                  // Se não é admin, avisar sobre aprovação
                  if (createResult.status === 'pendente') {
                    window.NexosUI?.showToast(
                      '⏳ Seu acesso está pendente de aprovação pelo administrador',
                      'warning',
                      5000
                    );
                  }
                } else {
                  console.error('[NexosAuth] ❌ Erro ao criar usuário:', createResult.error);
                }
              } else if (!userCheck.hasAccess) {
                // Usuário existe mas não tem acesso
                if (userCheck.status === 'pendente') {
                  window.NexosUI?.showToast(
                    '⏳ Seu acesso está pendente de aprovação pelo administrador',
                    'warning',
                    5000
                  );
                } else if (userCheck.status === 'rejeitado') {
                  window.NexosUI?.showToast(
                    '❌ Seu acesso foi negado. Entre em contato com o administrador',
                    'error',
                    5000
                  );
                }
              }
            } else {
              console.log('[NexosAuth] 📝 Criando usuário diretamente via Graph API...');
              
              // Usar token do storage (já foi salvo pelo TokenVaultManager)
              let token = result.token;
              
              // Se result.token não funcionar, tentar pegar do localStorage
              if (!token || token === 'undefined' || token.length < 100) {
                console.log('[NexosAuth] ⚠️ Token inválido em result, buscando do storage...');
                token = localStorage.getItem('nexos-intercepted-token') || 
                        localStorage.getItem('access-token') ||
                        (window.tokenInterceptor && await window.tokenInterceptor.getToken()) ||
                        (window.unifiedAuth && await window.unifiedAuth.getMSALToken());
              }
              
              if (!token || token === 'undefined') {
                console.error('[NexosAuth] ❌ Token não encontrado em nenhuma fonte');
                throw new Error('Token não disponível');
              }
              
              console.log('[NexosAuth] 🔑 Token obtido, preview:', token.substring(0, 50) + '...');
              
              const graphUrl = 'https://graph.microsoft.com/v1.0';
              
              // Obter Site ID
              const siteResponse = await fetch(
                `${graphUrl}/sites/gpabr.sharepoint.com:/sites/nexos`,
                { headers: { 'Authorization': `Bearer ${token}` } }
              );
              
              if (!siteResponse.ok) {
                throw new Error(`Erro ao obter site: ${siteResponse.status}`);
              }
              
              const siteData = await siteResponse.json();
              const siteId = siteData.id;
              
              // Obter List ID
              const listResponse = await fetch(
                `${graphUrl}/sites/${siteId}/lists?$filter=displayName eq 'Nexos_Usuarios'`,
                { headers: { 'Authorization': `Bearer ${token}` } }
              );
              
              if (!listResponse.ok) {
                throw new Error(`Erro ao obter lista: ${listResponse.status}`);
              }
              
              const listData = await listResponse.json();
              
              if (!listData.value || listData.value.length === 0) {
                console.warn('[NexosAuth] ⚠️ Lista Nexos_Usuarios não encontrada');
                console.log('[NexosAuth] 💡 Execute: scripts/create-usuarios-sharepoint-console.js');
              } else {
                const listId = listData.value[0].id;
                
                // Verificar se usuário já existe
                const checkResponse = await fetch(
                  `${graphUrl}/sites/${siteId}/lists/${listId}/items?$expand=fields&$filter=fields/Email eq '${result.user.email}'`,
                  { headers: { 'Authorization': `Bearer ${token}` } }
                );
                
                if (!checkResponse.ok) {
                  throw new Error(`Erro ao verificar usuário: ${checkResponse.status}`);
                }
                
                const checkData = await checkResponse.json();
                
                // Admin fixo
                const FIXED_ADMIN = 'leonardo.miguel@gpabr.com';
                const isAdmin = result.user.email === FIXED_ADMIN;
                
                if (!checkData.value || checkData.value.length === 0) {
                  // Usuário não existe - criar
                  console.log('[NexosAuth] 🆕 Primeiro login, criando registro...');
                  
                  // Converter foto base64 para URL do Graph API
                  let fotoUrl = '';
                  if (result.user.photo && result.user.photo.startsWith('data:image')) {
                    fotoUrl = `https://graph.microsoft.com/v1.0/users/${result.user.id}/photo/$value`;
                  } else if (result.user.photo && result.user.photo.startsWith('http')) {
                    fotoUrl = result.user.photo;
                  }
                  
                  const createBody = {
                    fields: {
                      Title: result.user.displayName || result.user.name,
                      Email: result.user.email,
                      NomeCompleto: result.user.displayName || result.user.name,
                      NomeExibicao: result.user.displayName || result.user.name,
                      UserID: result.user.id,
                      FotoURL: fotoUrl,
                      Cargo: result.user.jobTitle || '',
                      Departamento: result.user.department || '',
                      Ativo: true,
                      Status: isAdmin ? 'aprovado' : 'pendente',
                      DataCriacao: new Date().toISOString(),
                      UltimaAtualizacao: new Date().toISOString()
                    }
                  };
                  
                  const createResponse = await fetch(
                    `${graphUrl}/sites/${siteId}/lists/${listId}/items`,
                    {
                      method: 'POST',
                      headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                      },
                      body: JSON.stringify(createBody)
                    }
                  );
                  
                  if (createResponse.ok) {
                    console.log('[NexosAuth] ✅ Usuário registrado no SharePoint!');
                    
                    if (!isAdmin) {
                      window.NexosUI?.showToast(
                        '⏳ Seu acesso está pendente de aprovação pelo administrador',
                        'warning',
                        5000
                      );
                    }
                  } else {
                    const errorText = await createResponse.text();
                    console.error('[NexosAuth] ❌ Erro ao criar usuário:', errorText);
                  }
                } else {
                  // Usuário existe - atualizar último acesso
                  const userId = checkData.value[0].id;
                  const userFields = checkData.value[0].fields;
                  
                  console.log('[NexosAuth] 📊 Usuário existente, status:', userFields.Status);
                  
                  await fetch(
                    `${graphUrl}/sites/${siteId}/lists/${listId}/items/${userId}`,
                    {
                      method: 'PATCH',
                      headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                      },
                      body: JSON.stringify({
                        fields: {
                          UltimaAtualizacao: new Date().toISOString()
                        }
                      })
                    }
                  );
                  
                  // Verificar acesso
                  if (userFields.Status === 'pendente') {
                    window.NexosUI?.showToast(
                      '⏳ Seu acesso está pendente de aprovação pelo administrador',
                      'warning',
                      5000
                    );
                  } else if (userFields.Status === 'rejeitado') {
                    window.NexosUI?.showToast(
                      '❌ Seu acesso foi negado. Entre em contato com o administrador',
                      'error',
                      5000
                    );
                  }
                }
              }
            }
          } catch (error) {
            console.error('[NexosAuth] ❌ Erro ao registrar usuário:', error);
            console.error('[NexosAuth] 📍 Detalhes:', error.message);
            // Não bloqueia o login, apenas registra o erro
          }
          
          // Toast removido - já temos tela de boas-vindas
          setTimeout(() => {
            if (backdrop) backdrop.remove();
            if (overlay && overlay.parentNode) overlay.remove();
            loginOverlayOpen = false;
            currentLoginElements = null;
            resolve(result.user);
          }, 1000);
        } else if (result.aborted) {
          // Login abortado - restaurar botão
          console.log('[NexosAuth] 🔄 Login abortado, restaurando botão...');
          loginBtn.disabled = false;
          loginBtn.textContent = '🔐 Entrar com Conta Corporativa';
          
          if (window.NexosUI?.showToast) {
            window.NexosUI.showToast('Login cancelado', 'warning', 3000);
          }
          
          // NÃO fecha overlay, permite tentar novamente
        } else {
          loginBtn.disabled = false;
          loginBtn.textContent = '🔐 Entrar com Conta Corporativa';
          if (window.NexosUI?.showToast) {
            window.NexosUI.showToast(result.error || 'Erro ao fazer login', 'error');
          }
        }
      }, { once: false }); // Não usar once: true porque pode haver retry
      
      contentContainer.appendChild(loginBtn);
      overlay.appendChild(contentContainer);

      // Adiciona ao DOM
      if (container) {
        // Limpa container e adiciona login inline
        console.log('[NexosAuth] 📦 Renderizando login INLINE no container');
        container.innerHTML = '';
        container.appendChild(overlay);
        console.log('[NexosAuth] ✅ Login inline adicionado ao DOM');
      } else {
        // Adiciona backdrop global
        console.log('[NexosAuth] 🖼️ Renderizando login MODAL com backdrop');
        backdrop.appendChild(overlay);
        document.body.appendChild(backdrop);
        console.log('[NexosAuth] ✅ Login modal adicionado ao DOM');
      }
      
      // Armazena elementos para poder fechar depois
      currentLoginElements = { backdrop, overlay, container };
      console.log('[NexosAuth] 💾 Elementos salvos:', {
        hasBackdrop: !!backdrop,
        hasOverlay: !!overlay,
        hasContainer: !!container
      });
    });
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     REQUIRE AUTH
     ══════════════════════════════════════════════════════════════════════════ */

  async function requireAuth(options = {}) {
    const { silent = false, forceLogin = false, container = null } = options;
    
    // Se forceLogin=true, ignora sessão existente e força novo login
    if (forceLogin) {
      console.log('[NexosAuth] 🔄 forceLogin=true, forçando novo login...');
      return await showLoginOverlay({ container });
    }
    
    // IMPORTANTE: isAuthenticated() é assíncrono!
    const isAuth = await authManager.isAuthenticated();
    if (isAuth) {
      const currentUser = authManager.getCurrentUser();
      if (currentUser) {
        console.log('[NexosAuth] ✅ Usuário já autenticado:', currentUser.displayName || currentUser.name);
        return currentUser;
      }
    }

    if (silent) {
      console.log('[NexosAuth] Modo silencioso: usuário não autenticado');
      return null;
    }

    // ════════════════════════════════════════════════════════════════════════
    // CONTEXTO STANDALONE (sem chrome.runtime): usar MSAL popup diretamente
    // ════════════════════════════════════════════════════════════════════════
    const hasChrome = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL;

    if (!hasChrome) {
      console.log('[NexosAuth] 📄 Contexto standalone detectado — usando MSAL popup direto');
      return await requireAuthStandalone();
    }

    console.log('[NexosAuth] Usuário não autenticado, mostrando login...');
    console.log('[NexosAuth] 📦 Container fornecido:', !!container);
    return await showLoginOverlay({ container });
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     MSAL STANDALONE AUTH
     Login via MSAL popup para páginas abertas fora da extensão Chrome
     (ex: monitor-pedidos-armazenados.html aberto diretamente no browser)
     ══════════════════════════════════════════════════════════════════════════ */

  let _msalStandaloneInstance = null;

  async function getMsalInstance() {
    if (_msalStandaloneInstance) return _msalStandaloneInstance;

    if (typeof msal === 'undefined') {
      throw new Error('msal-browser.min.js não foi carregado. Adicione <script src="msal-browser.min.js"> antes do nexos-auth-system.js');
    }

    if (!window.AZURE_AD_CONFIG) {
      throw new Error('azure-ad-config.js não foi carregado. Adicione <script src="config/azure-ad-config.js"> antes do nexos-auth-system.js');
    }

    const cfg = window.AZURE_AD_CONFIG;
    const msalConfig = {
      auth: {
        clientId: cfg.clientId,
        authority: cfg.authority,
        redirectUri: cfg.redirectUri,
      },
      cache: {
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: false
      },
      system: {
        loggerOptions: {
          loggerCallback: (level, message, containsPii) => {
            if (!containsPii && cfg.debug) {
              console.log(`[MSAL] ${message}`);
            }
          }
        }
      }
    };

    const instance = new msal.PublicClientApplication(msalConfig);
    await instance.initialize();

    // Processar redirect response se houver (volta de redirect flow)
    try {
      const redirectResponse = await instance.handleRedirectPromise();
      if (redirectResponse) {
        console.log('[NexosAuth-Standalone] ✅ Redirect response processado');
      }
    } catch (e) {
      console.warn('[NexosAuth-Standalone] handleRedirectPromise error:', e.message);
    }

    _msalStandaloneInstance = instance;
    return instance;
  }

  /**
   * Obtém access token via MSAL (silent → popup fallback)
   * Usado no contexto standalone para preencher tokens automaticamente
   * @param {string[]} scopes - Scopes desejados (padrão: User.Read + Sites.ReadWrite.All)
   * @returns {Promise<string|null>} access token ou null
   */
  async function acquireTokenStandalone(scopes) {
    const targetScopes = scopes || ['User.Read', 'offline_access'];
    try {
      const instance = await getMsalInstance();
      const accounts = instance.getAllAccounts();

      if (accounts.length > 0) {
        try {
          const silentResult = await instance.acquireTokenSilent({
            scopes: targetScopes,
            account: accounts[0]
          });
          console.log('[NexosAuth-Standalone] ✅ Token obtido silenciosamente');
          return silentResult.accessToken;
        } catch (silentErr) {
          console.warn('[NexosAuth-Standalone] Silent falhou, tentando popup:', silentErr.message);
        }
      }

      // Popup interativo
      const popupResult = await instance.acquireTokenPopup({ scopes: targetScopes });
      console.log('[NexosAuth-Standalone] ✅ Token obtido via popup');
      return popupResult.accessToken;

    } catch (err) {
      console.error('[NexosAuth-Standalone] ❌ Falha ao obter token:', err.message);
      return null;
    }
  }

  async function requireAuthStandalone() {
    try {
      const instance = await getMsalInstance();
      const cfg = window.AZURE_AD_CONFIG;

      // Verificar contas já logadas (silent first)
      const accounts = instance.getAllAccounts();
      if (accounts.length > 0) {
        console.log('[NexosAuth-Standalone] Conta encontrada:', accounts[0].username);
        try {
          const silentResult = await instance.acquireTokenSilent({
            scopes: cfg.scopes || ['User.Read', 'offline_access'],
            account: accounts[0]
          });

          const user = await buildUserFromMsal(instance, silentResult);
          await authManager.saveSession(user);
          console.log('[NexosAuth-Standalone] ✅ Sessão restaurada silenciosamente:', user.displayName);
          return user;
        } catch (silentErr) {
          console.warn('[NexosAuth-Standalone] Silent falhou:', silentErr.message);
          // Cai no popup abaixo
        }
      }

      // Popup interativo
      console.log('[NexosAuth-Standalone] 🪟 Abrindo popup de login Microsoft...');
      const popupResult = await instance.acquireTokenPopup({
        scopes: cfg.scopes || ['User.Read', 'offline_access'],
        prompt: 'select_account'
      });

      const user = await buildUserFromMsal(instance, popupResult);
      await authManager.saveSession(user);
      authManager.triggerCallbacks('onLogin', user);
      console.log('[NexosAuth-Standalone] ✅ Login concluído:', user.displayName);
      return user;

    } catch (err) {
      if (err.errorCode === 'user_cancelled' || err.errorCode === 'popup_window_error') {
        console.warn('[NexosAuth-Standalone] Login cancelado pelo usuário');
        return null;
      }
      console.error('[NexosAuth-Standalone] ❌ Erro no login:', err);
      throw err;
    }
  }

  /**
   * Busca dados do usuário via Microsoft Graph e monta o objeto user padrão Nexos
   */
  async function buildUserFromMsal(msalInstance, tokenResponse) {
    const accessToken = tokenResponse.accessToken;

    let userData = {};
    let photoUrl = null;

    try {
      const meRes = await fetch('https://graph.microsoft.com/v1.0/me', {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      if (meRes.ok) {
        userData = await meRes.json();
      }
    } catch (e) {
      console.warn('[NexosAuth-Standalone] Falha ao buscar /me:', e.message);
    }

    try {
      const photoRes = await fetch('https://graph.microsoft.com/v1.0/me/photo/$value', {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      if (photoRes.ok) {
        const blob = await photoRes.blob();
        photoUrl = await new Promise(resolve => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result);
          reader.readAsDataURL(blob);
        });
      }
    } catch (e) {
      // foto opcional
    }

    const account = msalInstance.getAllAccounts()[0] || tokenResponse.account;

    return {
      id: userData.id || account?.homeAccountId || '',
      email: userData.mail || userData.userPrincipalName || account?.username || '',
      displayName: userData.displayName || account?.name || 'Usuário',
      name: userData.displayName || account?.name || 'Usuário',
      givenName: userData.givenName || '',
      surname: userData.surname || '',
      jobTitle: userData.jobTitle || 'Colaborador',
      department: userData.department || '',
      officeLocation: userData.officeLocation || '',
      photo: photoUrl,
      photoUrl: photoUrl,
      provider: 'microsoft',
      role: 'Operador',
      accessToken: accessToken,
      refreshToken: tokenResponse.refreshToken || null
    };
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     EXPORT API
     ══════════════════════════════════════════════════════════════════════════ */

  const authManager = new AuthManager();

  /* ═══════════════════════════════════════════════════════════════════════════
     REDIRECT HANDLER
     Processa retorno de autenticação via redirect
     ══════════════════════════════════════════════════════════════════════════ */

  async function handleRedirectCallback() {
    // Verificar se estávamos esperando um redirect
    const redirectPending = sessionStorage.getItem('nexos-auth-redirect-pending');
    if (!redirectPending) {
      return; // Não era um redirect de autenticação
    }

    console.log('[NexosAuth] 🔄 Processando retorno de redirect...');

    try {
      // Verificar se MSAL está disponível
      if (typeof msal === 'undefined' || !window.AZURE_AD_CONFIG) {
        console.warn('[NexosAuth] ⚠️ MSAL não disponível no retorno do redirect');
        sessionStorage.removeItem('nexos-auth-redirect-pending');
        return;
      }

      // Inicializar MSAL novamente
      const msalConfig = {
        auth: {
          clientId: window.AZURE_AD_CONFIG.clientId,
          authority: window.AZURE_AD_CONFIG.authority,
          redirectUri: window.AZURE_AD_CONFIG.redirectUri,
        },
        cache: window.AZURE_AD_CONFIG.cache,
      };

      const msalInstance = new msal.PublicClientApplication(msalConfig);
      await msalInstance.initialize();

      // Processar redirect
      const response = await msalInstance.handleRedirectPromise();
      
      if (response && response.account) {
        console.log('[NexosAuth] ✅ Redirect processado com sucesso!');
        
        // Buscar dados do usuário
        const graphClient = new window.AuthGraphClient(authManager.msalAuth);
        const userData = await graphClient.getUserProfile();
        const photoUrl = await graphClient.getUserPhoto();

        const user = {
          id: userData.id,
          email: userData.mail || userData.userPrincipalName,
          name: userData.displayName,
          firstName: userData.givenName || userData.displayName.split(' ')[0],
          lastName: userData.surname || userData.displayName.split(' ').slice(1).join(' '),
          photo: photoUrl,
          jobTitle: userData.jobTitle || 'Sem cargo definido',
          department: userData.department || 'Não especificado',
          officeLocation: userData.officeLocation || '',
          mobilePhone: userData.mobilePhone || '',
          businessPhones: userData.businessPhones || [],
          role: 'Operador',
          provider: 'microsoft',
          accessToken: response.accessToken
        };

        // Salvar sessão
        await authManager.saveSession(user);
        
        // Limpar flag
        sessionStorage.removeItem('nexos-auth-redirect-pending');
        
        console.log('[NexosAuth] ✅ Usuário autenticado via redirect:', user.name);
        
        // Recarregar overlay se estava ativo
        if (window.__nexos_overlay_active && window.buildExtractionOverlayRefactored) {
          console.log('[NexosAuth] 🔄 Recriando overlay com usuário autenticado...');
          setTimeout(() => {
            window.buildExtractionOverlayRefactored();
          }, 500);
        }
      } else {
        console.log('[NexosAuth] ℹ️ Nenhuma resposta de redirect (página normal)');
        sessionStorage.removeItem('nexos-auth-redirect-pending');
      }
    } catch (error) {
      console.error('[NexosAuth] ❌ Erro ao processar redirect:', error);
      sessionStorage.removeItem('nexos-auth-redirect-pending');
    }
  }

  // Executar handler de redirect na inicialização
  handleRedirectCallback();

  window.NexosAuth = {
    authManager,           // ← EXPOSTO para acesso externo
    manager: authManager,  // ← Alias para compatibilidade
    requireAuth,
    showLoginOverlay,

    // Helpers (mantém assíncrono)
    isAuthenticated: async () => await authManager.isAuthenticated(),
    getCurrentUser: () => authManager.getCurrentUser(),
    logout: async () => await authManager.logout(),
    refreshToken: async () => await authManager.refreshToken(), // 🆕 V3.0: Auto-refresh de tokens
    on: (event, callback) => authManager.on(event, callback),
    off: (event, callback) => authManager.off(event, callback),

    // 🆕 V3.1: Obter access token diretamente
    getToken: async () => {
      const user = authManager.getCurrentUser();
      if (!user || !user.accessToken) {
        console.debug('[NexosAuth] ℹ️ Usuário ainda não autenticado (getToken retornou null)');
        return null;
      }
      return user.accessToken;
    },

    // 🆕 V3.2 STANDALONE: Obter token com scopes específicos via MSAL
    // Usado para preencher automaticamente sp-token e pk-token
    acquireToken: async (scopes) => {
      // Tenta pegar do usuário atual primeiro (mais rápido)
      const user = authManager.getCurrentUser();
      if (user && user.accessToken) {
        return user.accessToken;
      }
      // Fallback: usa MSAL standalone
      return await acquireTokenStandalone(scopes);
    },

    // 🆕 V3.2 STANDALONE: Login via MSAL para contexto standalone
    loginStandalone: async () => await requireAuthStandalone(),

    // 🆕 V3.2 STANDALONE: Verifica se está em contexto standalone (sem extensão)
    isStandaloneContext: () => {
      return !(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL);
    }
  };

  // Sistema de autenticação inicializado silenciosamente


})();
