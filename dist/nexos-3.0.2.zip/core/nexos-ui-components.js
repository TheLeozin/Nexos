/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - UI COMPONENTS
 * Sistema de componentes reutilizáveis para todos os overlays
 * Versão: 2.2.2
 * ═══════════════════════════════════════════════════════════════════════════
 */

(function() {
  'use strict';

  // Garantir que só inicialize uma vez
  if (window.NexosUI) {
    console.log('[NexosUI] Já inicializado');
    return;
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     UTILITIES
     ══════════════════════════════════════════════════════════════════════════ */

  const utils = {
    /**
     * Cria um elemento DOM com classes e atributos
     */
    createElement(tag, classes = [], attributes = {}) {
      const element = document.createElement(tag);
      if (classes.length) element.classList.add(...classes);
      Object.entries(attributes).forEach(([key, value]) => {
        if (key === 'dataset') {
          Object.entries(value).forEach(([dataKey, dataValue]) => {
            element.dataset[dataKey] = dataValue;
          });
        } else if (key === 'innerHTML' || key === 'textContent' || key === 'innerText') {
          // 🔥 FIX: innerHTML, textContent, innerText são PROPRIEDADES, não atributos
          element[key] = value;
        } else {
          element.setAttribute(key, value);
        }
      });
      return element;
    },

    /**
     * Gera ID único
     */
    generateId(prefix = 'nexos') {
      return `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    },

    /**
     * Sanitiza texto para exibição
     */
    sanitize(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    },

    /**
     * Formata data
     */
    formatDate(date, format = 'dd/MM/yyyy HH:mm') {
      const d = new Date(date);
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const year = d.getFullYear();
      const hours = String(d.getHours()).padStart(2, '0');
      const minutes = String(d.getMinutes()).padStart(2, '0');
      
      return format
        .replace('dd', day)
        .replace('MM', month)
        .replace('yyyy', year)
        .replace('HH', hours)
        .replace('mm', minutes);
    },

    /**
     * Debounce function
     */
    debounce(func, wait) {
      let timeout;
      return function executedFunction(...args) {
        const later = () => {
          clearTimeout(timeout);
          func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
      };
    }
  };

  /* ═══════════════════════════════════════════════════════════════════════════
     THEME MANAGER
     ══════════════════════════════════════════════════════════════════════════ */

  class ThemeManager {
    constructor() {
      this.storageKey = 'nexos-theme';
      this.currentTheme = this.loadTheme();
    }

    loadTheme() {
      return localStorage.getItem(this.storageKey) || 'light';
    }

    saveTheme(theme) {
      localStorage.setItem(this.storageKey, theme);
      this.currentTheme = theme;
    }

    applyTheme(overlay) {
      // Aplicar ao overlay
      if (overlay) {
        if (this.currentTheme === 'dark') {
          overlay.classList.add('dark-mode');
        } else {
          overlay.classList.remove('dark-mode');
        }
      }
      
      // Aplicar também ao body para CSS globais
      if (this.currentTheme === 'dark') {
        document.documentElement.classList.add('dark-mode');
        document.body.classList.add('dark-mode');
      } else {
        document.documentElement.classList.remove('dark-mode');
        document.body.classList.remove('dark-mode');
      }
    }

    toggle(overlay) {
      const newTheme = this.currentTheme === 'dark' ? 'light' : 'dark';
      this.saveTheme(newTheme);
      this.applyTheme(overlay);
      return newTheme;
    }
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     BUTTON COMPONENT
     ══════════════════════════════════════════════════════════════════════════ */

  function createButton(config) {
    const {
      text = '',
      icon = '',
      variant = 'primary',
      size = 'md',
      onClick = null,
      disabled = false,
      type = 'button',
      classList = []
    } = config;

    const classes = ['nexos-btn', `nexos-btn-${variant}`];
    if (size !== 'md') classes.push(`nexos-btn-${size}`);
    if (icon && !text) classes.push('nexos-btn-icon');
    classes.push(...classList);

    const button = utils.createElement('button', classes, { type, disabled });
    button.disabled = disabled;

    if (icon) {
      const iconSpan = utils.createElement('span', [], { innerHTML: icon });
      button.appendChild(iconSpan);
    }

    if (text) {
      const textNode = document.createTextNode(text);
      button.appendChild(textNode);
    }

    if (onClick) {
      button.addEventListener('click', onClick);
    }

    return button;
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     BADGE COMPONENT
     ══════════════════════════════════════════════════════════════════════════ */

  function createBadge(text, variant = 'primary') {
    const badge = utils.createElement('span', ['nexos-badge', `nexos-badge-${variant}`]);
    badge.textContent = text;
    return badge;
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     CARD COMPONENT
     ══════════════════════════════════════════════════════════════════════════ */

  function createCard(config) {
    const {
      title = '',
      body = '',
      footer = null,
      classList = []
    } = config;

    const card = utils.createElement('div', ['nexos-card', ...classList]);

    if (title) {
      const header = utils.createElement('div', ['nexos-card-header']);
      const titleEl = utils.createElement('h3', ['nexos-card-title']);
      titleEl.textContent = title;
      header.appendChild(titleEl);
      card.appendChild(header);
    }

    if (body) {
      const bodyEl = utils.createElement('div', ['nexos-card-body']);
      if (typeof body === 'string') {
        bodyEl.innerHTML = body;
      } else {
        bodyEl.appendChild(body);
      }
      card.appendChild(bodyEl);
    }

    if (footer) {
      const footerEl = utils.createElement('div', ['nexos-card-footer']);
      if (Array.isArray(footer)) {
        footer.forEach(item => footerEl.appendChild(item));
      } else {
        footerEl.appendChild(footer);
      }
      card.appendChild(footerEl);
    }

    return card;
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     USER AVATAR COMPONENT
     ══════════════════════════════════════════════════════════════════════════ */

  function createUserAvatar(config) {
    const {
      name = 'Usuário',
      role = '',
      photo = null,
      menuItems = []
    } = config;

    const container = utils.createElement('div', ['nexos-user-avatar']);

    // Avatar image or placeholder
    if (photo) {
      const img = utils.createElement('img', ['nexos-avatar-image'], {
        src: photo,
        alt: name
      });
      container.appendChild(img);
    } else {
      const initials = name.split(' ').map(n => n[0]).join('').toUpperCase().substr(0, 2);
      const placeholder = utils.createElement('div', ['nexos-avatar-placeholder']);
      placeholder.textContent = initials;
      container.appendChild(placeholder);
    }

    // User info
    const info = utils.createElement('div', ['nexos-user-info']);
    const nameEl = utils.createElement('div', ['nexos-user-name']);
    nameEl.textContent = name;
    info.appendChild(nameEl);

    if (role) {
      const roleEl = utils.createElement('div', ['nexos-user-role']);
      roleEl.textContent = role;
      info.appendChild(roleEl);
    }

    container.appendChild(info);

    // Dropdown menu
    if (menuItems.length) {
      const menu = utils.createElement('div', ['nexos-user-menu']);

      menuItems.forEach((item, index) => {
        if (item.divider) {
          menu.appendChild(utils.createElement('div', ['nexos-user-menu-divider']));
        } else {
          const menuItem = utils.createElement('div', ['nexos-user-menu-item']);
          
          if (item.icon) {
            const icon = utils.createElement('span', [], { innerHTML: item.icon });
            menuItem.appendChild(icon);
          }
          
          const text = utils.createElement('span');
          text.textContent = item.text;
          menuItem.appendChild(text);

          if (item.onClick) {
            menuItem.addEventListener('click', (e) => {
              e.stopPropagation();
              item.onClick();
              container.classList.remove('active');
            });
          }

          menu.appendChild(menuItem);
        }
      });

      container.appendChild(menu);

      // Toggle menu on click
      container.addEventListener('click', (e) => {
        e.stopPropagation();
        container.classList.toggle('active');
      });

      // Close menu when clicking outside
      document.addEventListener('click', () => {
        container.classList.remove('active');
      });
    }

    return container;
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     HEADER COMPONENT
     ══════════════════════════════════════════════════════════════════════════ */

  function createHeader(config) {
    const {
      title = 'Nexos Torre',
      subtitle = '',
      logoUrl = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) 
        ? chrome.runtime.getURL('images/logo.png') 
        : 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48"><circle cx="24" cy="24" r="20" fill="%234CAF50"/></svg>',
      actions = [],
      userConfig = null
    } = config;

    const header = utils.createElement('header', ['nexos-header']);

    // Left side
    const left = utils.createElement('div', ['nexos-header-left']);
    
    const logo = utils.createElement('img', ['nexos-header-logo'], {
      src: logoUrl,
      alt: 'Nexos Torre'
    });
    left.appendChild(logo);

    const titleContainer = utils.createElement('div', ['nexos-header-title']);
    const h1 = utils.createElement('h1');
    h1.textContent = title;
    titleContainer.appendChild(h1);

    if (subtitle) {
      const sub = utils.createElement('div', ['subtitle']);
      sub.textContent = subtitle;
      titleContainer.appendChild(sub);
    }

    left.appendChild(titleContainer);
    header.appendChild(left);

    // Right side
    const right = utils.createElement('div', ['nexos-header-right']);

    actions.forEach(action => {
      right.appendChild(action);
    });

    if (userConfig) {
      const avatar = createUserAvatar(userConfig);
      right.appendChild(avatar);
    }

    header.appendChild(right);

    return header;
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     INPUT COMPONENT
     ══════════════════════════════════════════════════════════════════════════ */

  function createInput(config) {
    const {
      type = 'text',
      placeholder = '',
      value = '',
      onChange = null,
      classList = []
    } = config;

    const input = utils.createElement('input', ['nexos-input', ...classList], {
      type,
      placeholder,
      value
    });

    if (onChange) {
      input.addEventListener('input', (e) => onChange(e.target.value));
    }

    return input;
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     TOAST NOTIFICATION
     ══════════════════════════════════════════════════════════════════════════ */

  const toastContainer = (() => {
    let container = null;
    
    return () => {
      if (!container) {
        container = utils.createElement('div', ['nexos-toast-container'], {
          style: `
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 2147483720 !important;
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-width: 400px;
            pointer-events: none;
          `
        });
        document.body.appendChild(container);
      }
      return container;
    };
  })();

  function showToast(message, type = 'info', duration = 3000) {
    const container = toastContainer();
    
    const icons = {
      success: '✅',
      error: '❌',
      warning: '⚠️',
      info: 'ℹ️'
    };

    const toast = utils.createElement('div', ['nexos-card'], {
      style: `
        padding: 16px;
        background: #ffffff !important;
        border: 1px solid #E5E7EB;
        border-left: 4px solid var(--nexos-${type === 'error' ? 'error' : type === 'warning' ? 'warning' : type === 'success' ? 'success' : 'info'});
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        animation: nexosSlideInRight 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        display: flex;
        align-items: center;
        gap: 12px;
        opacity: 1 !important;
        pointer-events: auto;
        min-width: 300px;
      `
    });

    const icon = utils.createElement('span', [], {
      style: 'font-size: 20px;'
    });
    icon.textContent = icons[type] || icons.info;
    toast.appendChild(icon);

    const text = utils.createElement('span', [], {
      style: 'flex: 1; color: var(--nexos-text-primary);'
    });
    text.textContent = message;
    toast.appendChild(text);

    container.appendChild(toast);

    // Auto remove com animação suave
    setTimeout(() => {
      toast.style.animation = 'nexosSlideOutRight 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
      setTimeout(() => {
        if (container.contains(toast)) {
          container.removeChild(toast);
        }
      }, 300);
    }, duration);

    return toast;
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     MODAL COMPONENT
     ══════════════════════════════════════════════════════════════════════════ */

  function createModal(config) {
    const {
      title = '',
      body = '',
      footer = null,
      onClose = null,
      size = 'md'
    } = config;

    // Backdrop - começa invisível
    const backdrop = utils.createElement('div', ['nexos-modal-backdrop']);

    // Modal container with size class
    const modal = utils.createElement('div', ['nexos-card', 'nexos-modal-container', `nexos-modal-${size}`]);

    // Header
    if (title) {
      const header = utils.createElement('div', ['nexos-card-header', 'nexos-modal-header']);
      
      const titleEl = utils.createElement('h3', ['nexos-card-title']);
      titleEl.textContent = title;
      header.appendChild(titleEl);

      const closeBtn = createButton({
        icon: '✕',
        variant: 'ghost',
        onClick: () => {
          backdrop.remove();
          if (onClose) onClose();
        }
      });
      header.appendChild(closeBtn);

      modal.appendChild(header);
    }

    // Body
    const bodyEl = utils.createElement('div', ['nexos-card-body']);
    if (typeof body === 'string') {
      bodyEl.innerHTML = body;
    } else {
      bodyEl.appendChild(body);
    }
    modal.appendChild(bodyEl);

    if (footer) {
      const footerEl = utils.createElement('div', ['nexos-card-footer']);
      if (Array.isArray(footer)) {
        footer.forEach(item => {
          if (item && typeof item === 'object' && !item.nodeType) {
            const btn = createButton({
              text: item.text || '',
              variant: item.variant || 'primary',
              disabled: item.disabled || false,
              onClick: (event) => {
                if (typeof item.onClick === 'function') {
                  const closeModal = () => backdrop.remove();
                  item.onClick(closeModal, event);
                }
              }
            });
            footerEl.appendChild(btn);
          } else {
            footerEl.appendChild(item);
          }
        });
      } else if (typeof footer === 'object' && !footer.nodeType) {
        const btn = createButton({
          text: footer.text || '',
          variant: footer.variant || 'primary',
          disabled: footer.disabled || false,
          onClick: (event) => {
            if (typeof footer.onClick === 'function') {
              const closeModal = () => backdrop.remove();
              footer.onClick(closeModal, event);
            }
          }
        });
        footerEl.appendChild(btn);
      } else {
        footerEl.appendChild(footer);
      }
      modal.appendChild(footerEl);
    }

    backdrop.appendChild(modal);

    // Close on backdrop click
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        backdrop.remove();
        if (onClose) onClose();
      }
    });

    document.body.appendChild(backdrop);
    
    // Aplicar classe de visibilidade após pequeno delay (para animação funcionar)
    setTimeout(() => {
      backdrop.classList.add('nexos-modal-visible');
    }, 10);

    // ✅ Retornar objeto com método close()
    return { 
      backdrop, 
      modal, 
      close: () => {
        backdrop.remove();
        if (onClose) onClose();
      }
    };
  }

  /**
   * Exibe modal de confirmação customizado
   */
  function showConfirm(options = {}) {
    return new Promise((resolve) => {
      const {
        title = 'Confirmar',
        message = 'Tem certeza?',
        confirmText = 'Confirmar',
        cancelText = 'Cancelar',
        type = 'warning' // 'warning', 'error', 'info', 'success'
      } = options;

      // Cores por tipo
      const colors = {
        warning: { bg: '#FEF3C7', border: '#F59E0B', text: '#92400E', confirmBg: '#F59E0B', confirmText: '#FFFFFF' },
        error: { bg: '#FEE2E2', border: '#EF4444', text: '#991B1B', confirmBg: '#EF4444', confirmText: '#FFFFFF' },
        info: { bg: '#DBEAFE', border: '#3B82F6', text: '#1E40AF', confirmBg: '#3B82F6', confirmText: '#FFFFFF' },
        success: { bg: '#D1FAE5', border: '#10B981', text: '#065F46', confirmBg: '#10B981', confirmText: '#FFFFFF' }
      };

      const scheme = colors[type] || colors.warning;

      // Backdrop
      const backdrop = document.createElement('div');
      backdrop.style.cssText = `
        position: fixed !important;
        inset: 0 !important;
        background: rgba(17, 24, 39, 0.75) !important;
        backdrop-filter: blur(8px);
        display: flex !important;
        justify-content: center !important;
        align-items: center !important;
        z-index: var(--nexos-z-modal, 2147483647) !important;
        animation: fadeIn 0.2s ease;
        pointer-events: auto !important;
        opacity: 1 !important;
      `;

      // Modal
      const modal = document.createElement('div');
      modal.style.cssText = `
        background: #FFFFFF;
        border-radius: 16px;
        border: 2px solid ${scheme.border};
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        max-width: 400px;
        width: 90%;
        padding: 24px;
        animation: scaleIn 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      `;

      // Header com ícone
      const header = document.createElement('div');
      header.style.cssText = 'display: flex; align-items: center; gap: 12px; margin-bottom: 16px;';
      
      const icon = document.createElement('div');
      icon.style.cssText = `
        width: 48px;
        height: 48px;
        border-radius: 12px;
        background: ${scheme.bg};
        border: 2px solid ${scheme.border};
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        flex-shrink: 0;
      `;
      icon.textContent = type === 'warning' ? '⚠️' : type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️';

      const titleEl = document.createElement('h3');
      titleEl.style.cssText = `
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: ${scheme.text};
      `;
      titleEl.textContent = title;

      header.appendChild(icon);
      header.appendChild(titleEl);

      // Message
      const messageEl = document.createElement('p');
      messageEl.style.cssText = `
        margin: 0 0 24px 0;
        font-size: 14px;
        line-height: 1.5;
        color: #6B7280;
      `;
      messageEl.textContent = message;

      // Buttons
      const buttonsContainer = document.createElement('div');
      buttonsContainer.style.cssText = 'display: flex; gap: 12px; justify-content: flex-end;';

      const cancelBtn = document.createElement('button');
      cancelBtn.textContent = cancelText;
      cancelBtn.type = 'button';
      cancelBtn.disabled = false;
      cancelBtn.style.cssText = `
        padding: 10px 20px;
        border: 1px solid #E5E7EB;
        background: #F9FAFB;
        border-radius: 8px;
        cursor: pointer !important;
        font-weight: 600;
        font-size: 14px;
        color: #6B7280;
        transition: all 0.2s;
        pointer-events: auto !important;
      `;
      cancelBtn.addEventListener('mouseenter', () => {
        cancelBtn.style.background = '#F3F4F6';
        cancelBtn.style.borderColor = '#D1D5DB';
      });
      cancelBtn.addEventListener('mouseleave', () => {
        cancelBtn.style.background = '#F9FAFB';
        cancelBtn.style.borderColor = '#E5E7EB';
      });
      cancelBtn.addEventListener('click', () => {
        backdrop.remove();
        resolve(false);
      });

      const confirmBtn = document.createElement('button');
      confirmBtn.textContent = confirmText;
      confirmBtn.type = 'button';
      confirmBtn.disabled = false;
      confirmBtn.style.cssText = `
        padding: 10px 20px;
        border: 2px solid ${scheme.border};
        background: ${scheme.confirmBg};
        border-radius: 8px;
        cursor: pointer !important;
        font-weight: 700;
        font-size: 14px;
        color: ${scheme.confirmText};
        transition: all 0.2s;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        pointer-events: auto !important;
      `;
      confirmBtn.addEventListener('mouseenter', () => {
        confirmBtn.style.transform = 'translateY(-2px) scale(1.02)';
        confirmBtn.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.15)';
      });
      confirmBtn.addEventListener('mouseleave', () => {
        confirmBtn.style.transform = 'translateY(0) scale(1)';
        confirmBtn.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.1)';
      });
      confirmBtn.addEventListener('click', () => {
        backdrop.remove();
        resolve(true);
      });

      buttonsContainer.appendChild(cancelBtn);
      buttonsContainer.appendChild(confirmBtn);

      modal.appendChild(header);
      modal.appendChild(messageEl);
      modal.appendChild(buttonsContainer);
      backdrop.appendChild(modal);

      // Close on backdrop click
      backdrop.addEventListener('click', (e) => {
        if (e.target === backdrop) {
          backdrop.remove();
          resolve(false);
        }
      });

      // Keyboard shortcuts
      const handleKeydown = (e) => {
        if (e.key === 'Escape') {
          backdrop.remove();
          resolve(false);
          document.removeEventListener('keydown', handleKeydown);
        } else if (e.key === 'Enter') {
          backdrop.remove();
          resolve(true);
          document.removeEventListener('keydown', handleKeydown);
        }
      };
      document.addEventListener('keydown', handleKeydown);

      document.body.appendChild(backdrop);
    });
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     LOADING OVERLAY COMPONENT
     ══════════════════════════════════════════════════════════════════════════ */

  /**
   * Exibir overlay de loading (spinner)
   * @param {string} message - Mensagem a ser exibida
   * @param {string} subtitle - Subtítulo opcional
   * @returns {Object} - Objeto com função hide() para remover o loading
   */
  function showLoadingOverlay(message = 'Carregando...', subtitle = '') {
    const overlay = utils.createElement('div', ['nexos-loading-overlay'], {
      style: `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(4px);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 999999;
        animation: fadeIn 0.2s ease;
      `
    });

    const container = utils.createElement('div', ['nexos-card'], {
      style: `
        background: #ffffff;
        border-radius: 16px;
        padding: 32px;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
        text-align: center;
        max-width: 400px;
        min-width: 300px;
        animation: scaleIn 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      `
    });

    // Spinner
    const spinner = utils.createElement('div', ['nexos-spinner'], {
      style: `
        width: 48px;
        height: 48px;
        border: 4px solid #E5E7EB;
        border-top-color: var(--nexos-info);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
        margin: 0 auto 24px;
      `
    });
    container.appendChild(spinner);

    // Message
    const messageEl = utils.createElement('div', [], {
      style: `
        font-size: 18px;
        font-weight: 600;
        color: var(--nexos-text-primary);
        margin-bottom: ${subtitle ? '8px' : '0'};
      `,
      textContent: message
    });
    container.appendChild(messageEl);

    // Subtitle (optional)
    let subtitleEl = null;
    if (subtitle) {
      subtitleEl = utils.createElement('div', [], {
        style: `
          font-size: 14px;
          color: var(--nexos-text-secondary);
        `,
        textContent: subtitle
      });
      subtitleEl.dataset.subtitle = 'true';
      container.appendChild(subtitleEl);
    }

    overlay.appendChild(container);
    document.body.appendChild(overlay);

    // Return object with hide function
    return {
      hide: () => {
        overlay.style.animation = 'fadeOut 0.2s ease';
        setTimeout(() => {
          if (document.body.contains(overlay)) {
            document.body.removeChild(overlay);
          }
        }, 200);
      },
      updateMessage: (newMessage, newSubtitle = '') => {
        messageEl.textContent = newMessage;
        if (newSubtitle && subtitleEl) {
          subtitleEl.textContent = newSubtitle;
        }
      }
    };
  }

  /* ═══════════════════════════════════════════════════════════════════════════
     EXPORT API
     ══════════════════════════════════════════════════════════════════════════ */

  window.NexosUI = {
    // Utilities
    utils,
    
    // Theme
    ThemeManager,
    
    // Components
    createButton,
    createBadge,
    createCard,
    createUserAvatar,
    createHeader,
    createInput,
    showToast,
    createModal,
    showConfirm,
    showLoadingOverlay
  };

  // Inject CSS animations and variables
  const style = document.createElement('style');
  style.textContent = `
    :root {
      --nexos-success: #10B981;
      --nexos-error: #EF4444;
      --nexos-warning: #F59E0B;
      --nexos-info: #3B82F6;
      --nexos-text-primary: #111827;
      --nexos-text-secondary: #6B7280;
      --nexos-border: #E5E7EB;
      --nexos-bg-primary: #FFFFFF;
      --nexos-bg-secondary: #F9FAFB;
    }

    @keyframes nexosSlideInRight {
      from {
        opacity: 0;
        transform: translateX(100px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }

    @keyframes nexosSlideOutRight {
      from {
        opacity: 1;
        transform: translateX(0);
      }
      to {
        opacity: 0;
        transform: translateX(100px);
      }
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }

    @keyframes scaleIn {
      from {
        opacity: 0;
        transform: scale(0.9);
      }
      to {
        opacity: 1;
        transform: scale(1);
      }
    }

    @keyframes spin {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }
  `;
  document.head.appendChild(style);

  // Sistema de componentes inicializado silenciosamente

})();
