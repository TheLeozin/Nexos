// ===================================================================
// NEXOS - Sistema de Permissões e Roles (RBAC)
// Role-Based Access Control com hierarquia de cargos
// ===================================================================

/**
 * Estrutura de permissões disponíveis no sistema
 */
const PERMISSIONS = {
  // Dashboard & Visualização
  VIEW_DASHBOARD: 'view_dashboard',
  VIEW_LOGS: 'view_logs',
  VIEW_STATISTICS: 'view_statistics',
  VIEW_USERS: 'view_users',
  VIEW_ALERTS: 'view_alerts',
  
  // Ações de Operação
  EXTRACT_ORDERS: 'extract_orders',
  POST_COMMENTS: 'post_comments',
  AUTO_FILL_FORMS: 'auto_fill_forms',
  MANAGE_STORES: 'manage_stores',
  MANAGE_TREES: 'manage_trees',
  
  // Exportação & Relatórios
  EXPORT_LOGS: 'export_logs',
  EXPORT_REPORTS: 'export_reports',
  GENERATE_STATISTICS: 'generate_statistics',
  
  // Administração
  MANAGE_USERS: 'manage_users',
  MANAGE_ROLES: 'manage_roles',
  MANAGE_PERMISSIONS: 'manage_permissions',
  DELETE_LOGS: 'delete_logs',
  CLEAR_STORAGE: 'clear_storage',
  CHANGE_SETTINGS: 'change_settings',
  
  // Supervisão e Aprovação
  SUPERVISE_USERS: 'supervise_users',
  APPROVE_ACTIONS: 'approve_actions',
  ASSIGN_SUPERVISORS: 'assign_supervisors',
  VIEW_APPROVAL_HISTORY: 'view_approval_history',
  
  // Notificações
  RECEIVE_CRITICAL_ALERTS: 'receive_critical_alerts',
  RECEIVE_ALL_USER_ALERTS: 'receive_all_user_alerts',
  SEND_NOTIFICATIONS: 'send_notifications',
  
  // Configurações Avançadas
  MODIFY_AUTO_REFRESH: 'modify_auto_refresh',
  ACCESS_DEBUG_MODE: 'access_debug_mode',
  FORCE_UPDATE: 'force_update'
};

/**
 * Definição de Roles (Cargos) com suas permissões
 * Hierarquia: Master > Admin > Gestão > Encarregados > Torre (4 níveis)
 */
const ROLES = {
  // ============ NÍVEL 1: ADMINISTRAÇÃO MÁXIMA ============
  ADMIN_MASTER: {
    id: 'admin_master',
    name: 'Administrador Master',
    description: 'Acesso total ao sistema, controle de todos usuários e configurações',
    color: '#8B0000', // Vermelho escuro
    hierarchy: 100,
    permissions: Object.values(PERMISSIONS) // TODAS as permissões
  },
  
  // ============ NÍVEL 2: ADMINISTRAÇÃO ============
  ADMIN: {
    id: 'admin',
    name: 'Administrador',
    description: 'Gerencia usuários, configurações e operações do sistema',
    color: '#DC143C', // Vermelho
    hierarchy: 90,
    permissions: [
      PERMISSIONS.VIEW_DASHBOARD,
      PERMISSIONS.VIEW_LOGS,
      PERMISSIONS.VIEW_STATISTICS,
      PERMISSIONS.VIEW_USERS,
      PERMISSIONS.VIEW_ALERTS,
      PERMISSIONS.EXTRACT_ORDERS,
      PERMISSIONS.POST_COMMENTS,
      PERMISSIONS.AUTO_FILL_FORMS,
      PERMISSIONS.MANAGE_STORES,
      PERMISSIONS.MANAGE_TREES,
      PERMISSIONS.EXPORT_LOGS,
      PERMISSIONS.EXPORT_REPORTS,
      PERMISSIONS.GENERATE_STATISTICS,
      PERMISSIONS.MANAGE_USERS,
      PERMISSIONS.DELETE_LOGS,
      PERMISSIONS.CHANGE_SETTINGS,
      PERMISSIONS.SUPERVISE_USERS,
      PERMISSIONS.APPROVE_ACTIONS,
      PERMISSIONS.ASSIGN_SUPERVISORS,
      PERMISSIONS.VIEW_APPROVAL_HISTORY,
      PERMISSIONS.RECEIVE_CRITICAL_ALERTS,
      PERMISSIONS.RECEIVE_ALL_USER_ALERTS,
      PERMISSIONS.SEND_NOTIFICATIONS,
      PERMISSIONS.MODIFY_AUTO_REFRESH,
      PERMISSIONS.ACCESS_DEBUG_MODE
    ]
  },
  
  // ============ NÍVEL 3: GESTÃO ============
  GESTAO: {
    id: 'gestao',
    name: 'Gestão',
    description: 'Supervisiona operações, gera relatórios e monitora equipes',
    color: '#FF8C00', // Laranja escuro
    hierarchy: 80,
    permissions: [
      PERMISSIONS.VIEW_DASHBOARD,
      PERMISSIONS.VIEW_LOGS,
      PERMISSIONS.VIEW_STATISTICS,
      PERMISSIONS.VIEW_USERS,
      PERMISSIONS.VIEW_ALERTS,
      PERMISSIONS.EXTRACT_ORDERS,
      PERMISSIONS.POST_COMMENTS,
      PERMISSIONS.AUTO_FILL_FORMS,
      PERMISSIONS.EXPORT_LOGS,
      PERMISSIONS.EXPORT_REPORTS,
      PERMISSIONS.GENERATE_STATISTICS,
      PERMISSIONS.SUPERVISE_USERS,
      PERMISSIONS.APPROVE_ACTIONS,
      PERMISSIONS.ASSIGN_SUPERVISORS,
      PERMISSIONS.VIEW_APPROVAL_HISTORY,
      PERMISSIONS.RECEIVE_CRITICAL_ALERTS,
      PERMISSIONS.SEND_NOTIFICATIONS,
      PERMISSIONS.CHANGE_SETTINGS
    ]
  },
  
  // ============ NÍVEL 4: ENCARREGADOS ============
  ENCARREGADO_TORRE: {
    id: 'encarregado_torre',
    name: 'Encarregado Torre',
    description: 'Coordena operações da Torre de Controle',
    color: '#FFD700', // Dourado
    hierarchy: 70,
    permissions: [
      PERMISSIONS.VIEW_DASHBOARD,
      PERMISSIONS.VIEW_LOGS,
      PERMISSIONS.VIEW_STATISTICS,
      PERMISSIONS.VIEW_USERS,
      PERMISSIONS.VIEW_ALERTS,
      PERMISSIONS.EXTRACT_ORDERS,
      PERMISSIONS.POST_COMMENTS,
      PERMISSIONS.AUTO_FILL_FORMS,
      PERMISSIONS.EXPORT_LOGS,
      PERMISSIONS.EXPORT_REPORTS,
      PERMISSIONS.SUPERVISE_USERS,
      PERMISSIONS.APPROVE_ACTIONS,
      PERMISSIONS.VIEW_APPROVAL_HISTORY,
      PERMISSIONS.RECEIVE_CRITICAL_ALERTS,
      PERMISSIONS.SEND_NOTIFICATIONS
    ]
  },
  
  ENCARREGADO_FROTA: {
    id: 'encarregado_frota',
    name: 'Encarregado Frota',
    description: 'Gerencia operações de frota e entregas',
    color: '#4682B4', // Azul aço
    hierarchy: 70,
    permissions: [
      PERMISSIONS.VIEW_DASHBOARD,
      PERMISSIONS.VIEW_LOGS,
      PERMISSIONS.VIEW_STATISTICS,
      PERMISSIONS.EXTRACT_ORDERS,
      PERMISSIONS.POST_COMMENTS,
      PERMISSIONS.AUTO_FILL_FORMS,
      PERMISSIONS.EXPORT_LOGS,
      PERMISSIONS.SUPERVISE_USERS,
      PERMISSIONS.APPROVE_ACTIONS,
      PERMISSIONS.VIEW_APPROVAL_HISTORY,
      PERMISSIONS.RECEIVE_CRITICAL_ALERTS
    ]
  },
  
  ENCARREGADO_OCORRENCIA: {
    id: 'encarregado_ocorrencia',
    name: 'Encarregado Ocorrência',
    description: 'Gerencia ocorrências e problemas operacionais',
    color: '#8B4513', // Marrom
    hierarchy: 70,
    permissions: [
      PERMISSIONS.VIEW_DASHBOARD,
      PERMISSIONS.VIEW_LOGS,
      PERMISSIONS.VIEW_ALERTS,
      PERMISSIONS.POST_COMMENTS,
      PERMISSIONS.EXPORT_LOGS,
      PERMISSIONS.SUPERVISE_USERS,
      PERMISSIONS.APPROVE_ACTIONS,
      PERMISSIONS.VIEW_APPROVAL_HISTORY,
      PERMISSIONS.RECEIVE_CRITICAL_ALERTS,
      PERMISSIONS.SEND_NOTIFICATIONS
    ]
  },
  
  // ============ NÍVEL 5: TORRE DE CONTROLE (4 SUBNÍVEIS) ============
  TORRE_ASSISTENTE_II: {
    id: 'torre_assistente_ii',
    name: 'Torre - Assistente II',
    description: 'Assistente sênior da Torre, operações avançadas',
    color: '#32CD32', // Verde lima
    hierarchy: 60,
    permissions: [
      PERMISSIONS.VIEW_DASHBOARD,
      PERMISSIONS.VIEW_LOGS,
      PERMISSIONS.VIEW_STATISTICS,
      PERMISSIONS.EXTRACT_ORDERS,
      PERMISSIONS.POST_COMMENTS,
      PERMISSIONS.AUTO_FILL_FORMS,
      PERMISSIONS.MANAGE_STORES,
      PERMISSIONS.EXPORT_LOGS,
      PERMISSIONS.APPROVE_ACTIONS,
      PERMISSIONS.VIEW_APPROVAL_HISTORY,
      PERMISSIONS.RECEIVE_CRITICAL_ALERTS
    ]
  },
  
  TORRE_ASSISTENTE_I: {
    id: 'torre_assistente_i',
    name: 'Torre - Assistente I',
    description: 'Assistente da Torre, operações completas',
    color: '#228B22', // Verde floresta
    hierarchy: 50,
    permissions: [
      PERMISSIONS.VIEW_DASHBOARD,
      PERMISSIONS.VIEW_LOGS,
      PERMISSIONS.VIEW_STATISTICS,
      PERMISSIONS.EXTRACT_ORDERS,
      PERMISSIONS.POST_COMMENTS,
      PERMISSIONS.AUTO_FILL_FORMS,
      PERMISSIONS.EXPORT_LOGS
    ]
  },
  
  TORRE_AUXILIAR: {
    id: 'torre_auxiliar',
    name: 'Torre - Auxiliar',
    description: 'Auxiliar da Torre, operações básicas supervisionadas',
    color: '#3CB371', // Verde médio
    hierarchy: 40,
    permissions: [
      PERMISSIONS.VIEW_DASHBOARD,
      PERMISSIONS.VIEW_LOGS,
      PERMISSIONS.EXTRACT_ORDERS,
      PERMISSIONS.POST_COMMENTS,
      PERMISSIONS.AUTO_FILL_FORMS
    ]
  },
  
  TORRE_APRENDIZ: {
    id: 'torre_aprendiz',
    name: 'Torre - Aprendiz',
    description: 'Aprendiz da Torre, acesso limitado para treinamento',
    color: '#90EE90', // Verde claro
    hierarchy: 30,
    permissions: [
      PERMISSIONS.VIEW_DASHBOARD,
      PERMISSIONS.VIEW_LOGS,
      PERMISSIONS.EXTRACT_ORDERS
    ]
  },
  
  // ============ NÍVEL 6: OPERACIONAL ============
  FROTA: {
    id: 'frota',
    name: 'Frota',
    description: 'Operador de frota, foco em entregas',
    color: '#1E90FF', // Azul dodger
    hierarchy: 35,
    permissions: [
      PERMISSIONS.VIEW_DASHBOARD,
      PERMISSIONS.EXTRACT_ORDERS,
      PERMISSIONS.POST_COMMENTS,
      PERMISSIONS.AUTO_FILL_FORMS
    ]
  },
  
  OCORRENCIA: {
    id: 'ocorrencia',
    name: 'Ocorrência',
    description: 'Operador de ocorrências, tratamento de problemas',
    color: '#FF6347', // Tomate
    hierarchy: 35,
    permissions: [
      PERMISSIONS.VIEW_DASHBOARD,
      PERMISSIONS.VIEW_LOGS,
      PERMISSIONS.VIEW_ALERTS,
      PERMISSIONS.POST_COMMENTS
    ]
  }
};

/**
 * Classe para gerenciamento de permissões
 */
class PermissionManager {
  constructor() {
    this.storageKey = '__nexos_user_permissions';
    this.currentUser = null;
    this.initialized = false;
  }
  
  /**
   * Inicializa o sistema de permissões
   */
  async initialize() {
    if (this.initialized) return;
    
    try {
      // Carregar usuário atual
      const userData = await this._getFromStorage(this.storageKey);
      if (userData) {
        this.currentUser = userData;
        console.log('[PermissionManager] Usuário carregado:', this.currentUser.email, '| Role:', this.currentUser.role);
      }
      // Silencioso se não houver usuário (normal antes do login)
      
      this.initialized = true;
    } catch (error) {
      console.error('[PermissionManager] Erro ao inicializar:', error);
    }
  }
  
  /**
   * Define o usuário atual e seu role
   */
  async setCurrentUser(email, roleId) {
    const role = ROLES[roleId.toUpperCase()];
    
    if (!role) {
      throw new Error(`Role inválido: ${roleId}`);
    }
    
    this.currentUser = {
      email: email,
      role: role.id,
      roleName: role.name,
      permissions: role.permissions,
      hierarchy: role.hierarchy,
      loginTime: new Date().toISOString()
    };
    
    await this._saveToStorage(this.storageKey, this.currentUser);
    console.log('[PermissionManager] ✅ Usuário definido:', email, '| Role:', role.name);
    
    return this.currentUser;
  }
  
  /**
   * Verifica se o usuário atual tem uma permissão específica
   */
  hasPermission(permission) {
    if (!this.currentUser) {
      // Silencioso: é normal não ter usuário antes do login
      return false;
    }
    
    const has = this.currentUser.permissions.includes(permission);
    // console.log(`[PermissionManager] hasPermission("${permission}"): ${has}`);
    return has;
  }
  
  /**
   * Verifica múltiplas permissões (requer TODAS)
   */
  hasAllPermissions(permissions) {
    return permissions.every(perm => this.hasPermission(perm));
  }
  
  /**
   * Verifica múltiplas permissões (requer QUALQUER UMA)
   */
  hasAnyPermission(permissions) {
    return permissions.some(perm => this.hasPermission(perm));
  }
  
  /**
   * Verifica se o usuário tem hierarquia maior ou igual
   */
  hasMinimumHierarchy(minimumLevel) {
    if (!this.currentUser) return false;
    return this.currentUser.hierarchy >= minimumLevel;
  }
  
  /**
   * Retorna informações do role atual
   */
  getCurrentRole() {
    if (!this.currentUser) return null;
    return ROLES[this.currentUser.role.toUpperCase()];
  }
  
  /**
   * Retorna todos os roles disponíveis
   */
  getAllRoles() {
    return Object.values(ROLES).sort((a, b) => b.hierarchy - a.hierarchy);
  }
  
  /**
   * Mostra modal de acesso negado
   */
  showAccessDenied(action) {
    const role = this.getCurrentRole();
    const message = `⛔ Acesso Negado\n\n` +
      `Você não tem permissão para: ${action}\n\n` +
      `Seu cargo: ${role ? role.name : 'Não autenticado'}\n` +
      `Contate um administrador para solicitar acesso.`;
    
    alert(message);
    console.warn(`[PermissionManager] Acesso negado: ${action}`);
  }
  
  /**
   * Remove usuário atual
   */
  async clearCurrentUser() {
    this.currentUser = null;
    await chrome.storage.local.remove(this.storageKey);
    console.log('[PermissionManager] Usuário removido');
  }
  
  // ===================================================================
  // HELPERS DE STORAGE
  // ===================================================================
  
  async _getFromStorage(key) {
    try {
      const result = await chrome.storage.local.get(key);
      return result[key] || null;
    } catch (error) {
      console.error('[PermissionManager] Erro ao ler storage:', error);
      return null;
    }
  }
  
  async _saveToStorage(key, value) {
    try {
      await chrome.storage.local.set({ [key]: value });
    } catch (error) {
      console.error('[PermissionManager] Erro ao salvar no storage:', error);
    }
  }
}

// ===================================================================
// EXPORT
// ===================================================================

if (typeof window !== 'undefined') {
  window.PERMISSIONS = PERMISSIONS;
  window.ROLES = ROLES;
  window.PermissionManager = PermissionManager;
  console.log('[PermissionManager] ✅ Exportado para window');
}

if (typeof globalThis !== 'undefined') {
  globalThis.PERMISSIONS = PERMISSIONS;
  globalThis.ROLES = ROLES;
  globalThis.PermissionManager = PermissionManager;
}
