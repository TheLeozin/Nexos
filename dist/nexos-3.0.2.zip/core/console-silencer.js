/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - CONSOLE SILENCER
 * Reduz verbosidade de logs mantendo mensagens críticas
 * ═══════════════════════════════════════════════════════════════════════════
 */

(() => {
  'use strict';
  
  // Evitar instalar múltiplas vezes
  if (window.__nexosConsoleSilencerInstalled) {
    return;
  }
  
  // Backup das funções originais
  const original = {
    log: console.log.bind(console),
    info: console.info.bind(console),
    debug: console.debug ? console.debug.bind(console) : console.log.bind(console),
    warn: console.warn.bind(console),
    error: console.error.bind(console)
  };
  
  // Regex para mensagens importantes que sempre devem aparecer
  const importantRegex = /❌|⚠️|erro|error|fail|falha|token.*manager|auth.*token|sharepoint.*token|graph.*erro|msal.*erro|oauth.*erro|storage.*falha|picking.*erro/i;
  
  /**
   * Decide se uma mensagem deve ser exibida
   */
  const shouldLog = (level, args) => {
    // ✅ CONSOLE SILENCER AGORA ATIVO (desativa com window.NEXOS_VERBOSE_LOGS = true)
    // Modo silencioso por padrão
    if (window.NEXOS_VERBOSE_LOGS === true) {
      return true;
    }
    
    // Sempre mostra warn e error
    if (level === 'warn' || level === 'error') {
      return true;
    }
    
    // Para log/info/debug: só mostra se contém palavra-chave crítica
    const text = args.map(a => {
      if (typeof a === 'string') return a;
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a);
        } catch {
          return String(a);
        }
      }
      return String(a);
    }).join(' ');
    
    return importantRegex.test(text);
  };
  
  // Substituir console.log/info/debug com filtro
  ['log', 'info', 'debug'].forEach(level => {
    console[level] = (...args) => {
      if (shouldLog(level, args)) {
        original[level](...args);
      }
    };
  });
  
  // Manter warn/error intactos (sem filtro)
  console.warn = original.warn;
  console.error = original.error;
  
  // Marcar como instalado
  window.__nexosConsoleSilencerInstalled = true;
  
  // Aviso único
  // console.log('[NEXOS] ✅ Console silencer ativo (window.NEXOS_VERBOSE_LOGS = true para desabilitar)');
  
  // Expor helper para restaurar console original
  window.NEXOS_RESTORE_CONSOLE = () => {
    Object.assign(console, original);
    console.log('[NEXOS] 🔊 Console original restaurado');
    window.__nexosConsoleSilencerInstalled = false;
  };
})();
