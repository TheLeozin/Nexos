// --- Melhorias para o mapa James Delivery ---
(function tryInjectJamesMapImprovements(attempt = 1) {
  if (!(window.L && window.L.tileLayer && window.L.map && window.map)) {
    if (attempt < 30) return setTimeout(() => tryInjectJamesMapImprovements(attempt + 1), 2000);
    return console.error('[NEXOS] Falha ao injetar melhorias: Leaflet/map não disponível após 30 tentativas.');
  }
  try {
    const darkLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
    });
    window.map.eachLayer(function(layer) { window.map.removeLayer(layer); });
    darkLayer.addTo(window.map);
    console.log('[NEXOS] Tile layer escuro injetado com sucesso!');
  } catch (e) {
    console.error('[NEXOS] Erro ao injetar tile layer escuro:', e);
  }
  try {
    const style = document.createElement('style');
    style.textContent = '.custom-div-icon { box-shadow: 0 2px 8px rgba(0,0,0,0.5)!important; border: 2px solid #FFF!important; }';
    document.head.appendChild(style);
    console.log('[NEXOS] Estilo de destaque aplicado aos marcadores.');
  } catch (e) {
    console.error('[NEXOS] Erro ao destacar marcadores:', e);
  }
  try {
    const legend = document.getElementById('map-legend-wrapper');
    if (legend && !document.getElementById('nexos-courier-filter')) {
      const input = document.createElement('input');
      input.id = 'nexos-courier-filter';
      input.type = 'text';
      input.placeholder = 'Filtrar entregador...';
      input.style.cssText = 'width:100%;margin-bottom:8px;padding:6px;border-radius:6px;border:1px solid #004B6B;font-size:14px;';
        // Restaurar valor do filtro salvo
        const savedFilter = localStorage.getItem('nexos-courier-filter') || '';
        input.value = savedFilter;
      legend.prepend(input);
        function applyFilter(val) {
          document.querySelectorAll('#map-legend-list .map-li').forEach(li => {
            li.style.display = li.textContent.toLowerCase().includes(val) ? '' : 'none';
          });
        }
        // Aplica filtro ao inicializar
        applyFilter(savedFilter.toLowerCase());
        input.addEventListener('input', function() {
          const val = input.value.toLowerCase();
          localStorage.setItem('nexos-courier-filter', input.value); // Salva filtro
          applyFilter(val);
        }, { passive: true });
        // ...removido filtro de pedidos...
      console.log('[NEXOS] Campo de filtro de entregadores injetado.');
    }
  } catch (e) {
    console.error('[NEXOS] Erro ao injetar filtro de entregadores:', e);
  }
  try {
    document.querySelectorAll('#map-legend-list .map-li').forEach(li => {
      if (!li.querySelector('.nexos-locate-btn')) {
        const btn = document.createElement('button');
        btn.textContent = 'Localizar';
        btn.className = 'nexos-locate-btn';
        btn.style.cssText = 'margin-left:8px;padding:2px 8px;border-radius:4px;border:0;background:#00C2FF;color:#fff;font-size:12px;cursor:pointer;';
        console.log('[NEXOS] Botão Localizar criado para:', li.textContent);
        btn.addEventListener('click', function(e) {
          console.log('[NEXOS] Clique no botão Localizar:', li.textContent);
          e.stopPropagation();
          li.click();
          // Destaca o path SVG do entregador correspondente
          const courierColor = li.style.color;
          window.nexosCourierFocusIdx = Array.from(li.parentNode.children).indexOf(li);
          localStorage.setItem('nexos-courier-focus-color', courierColor);
          function rgbToHex(rgb) {
            if (!rgb) return '';
            const result = rgb.match(/\d+/g);
            if (!result) return '';
            return '#' + result.slice(0,3).map(x => (+x).toString(16).padStart(2, '0')).join('');
          }
          const legendColor = courierColor ? rgbToHex(courierColor) : '';
          console.log('[NEXOS] Cor do entregador na legenda:', legendColor);
          const allPaths = document.querySelectorAll('#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-overlay-pane > svg > g > path');
          allPaths.forEach((path, idx) => {
            console.log(`[NEXOS] Path ${idx}: fill=${path.getAttribute('fill')}, fill-opacity=${path.getAttribute('fill-opacity')}`);
          });
          // Limpa destaque anterior
          document.querySelectorAll('path.leaflet-interactive').forEach(path => {
            path.setAttribute('stroke', '#444444');
            path.setAttribute('stroke-width', '2');
            path.setAttribute('fill-opacity', path.getAttribute('fill-opacity') || '1');
          });
          // Limpa todos para fill-opacity 0.2
          allPaths.forEach(path => {
            path.setAttribute('fill-opacity', '0.2');
          });
          // Aplica destaque no path do entregador selecionado
          let found = false;
          allPaths.forEach((path, idx) => {
            // Compara HEX, RGB e cor original
            const pathFill = path.getAttribute('fill');
            if (
              legendColor && (
                pathFill === legendColor ||
                pathFill?.toLowerCase() === li.style.color?.toLowerCase() ||
                pathFill === li.style.color ||
                pathFill === rgbToHex(li.style.color)
              )
            ) {
              path.setAttribute('fill', '#002147'); // azul escuro
              path.setAttribute('fill-opacity', '1');
              path.setAttribute('stroke', '#FFD700'); // borda amarela
              path.setAttribute('stroke-width', '7');
              found = true;
              console.log(`[NEXOS] Path destacado: idx=${idx}, fill=${pathFill}`);
            }
          });
          if (!found) {
            // Tenta destacar pelo index do entregador na lista
            const liIdx = Array.from(li.parentNode.children).indexOf(li);
            const fallbackPath = allPaths[liIdx];
            if (fallbackPath) {
              fallbackPath.setAttribute('fill', '#002147');
              fallbackPath.setAttribute('fill-opacity', '1');
              fallbackPath.setAttribute('stroke', '#FFD700');
              fallbackPath.setAttribute('stroke-width', '7');
              console.log(`[NEXOS] Path destacado por index: idx=${liIdx}`);
              found = true;
            } else {
              console.log('[NEXOS] Nenhum path destacado! Verifique se a cor bate ou se há correspondência por index.');
            }
          }
          // Guarda o índice do entregador em foco
          window.nexosCourierFocusIdx = Array.from(li.parentNode.children).indexOf(li);
          // Função para alterar cor das linhas do entregador para amarelo
          function highlightCourierLines(courierColor) {
            const allLines = document.querySelectorAll('#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-overlay-pane > svg > g > path.leaflet-interactive');
            allLines.forEach(line => {
              const stroke = line.getAttribute('stroke');
              if (stroke && (stroke.toLowerCase() === courierColor.toLowerCase() || stroke === rgbToHex(courierColor))) {
                line.setAttribute('stroke', '#FFD700'); // amarelo
                line.setAttribute('stroke-width', '5');
                line.setAttribute('stroke-dasharray', '8, 4'); // linha tracejada
                console.log('[NEXOS] Linha do entregador alterada para amarelo:', line);
              }
            });
          }
          highlightCourierLines(li.style.color);
          // Função para destacar todos os elementos do entregador em foco
          function highlightCourierElements(courierColor) {
            // Linhas (paths) com stroke igual à cor do entregador
            const allLines = document.querySelectorAll('#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-overlay-pane > svg > g > path.leaflet-interactive');
            allLines.forEach(line => {
              const stroke = line.getAttribute('stroke');
              if (stroke && (stroke.toLowerCase() === courierColor.toLowerCase() || stroke === rgbToHex(courierColor))) {
                line.setAttribute('stroke', '#FFD700'); // amarelo
                line.setAttribute('stroke-width', '5');
                line.setAttribute('stroke-dasharray', '8, 4'); // linha tracejada
                console.log('[NEXOS] Linha do entregador alterada para amarelo:', line);
              }
            });
            // Clientes com background igual à cor do entregador
            document.querySelectorAll('#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-marker-pane > div').forEach(div => {
              const bg = div.style.backgroundColor;
              if (bg && (bg.toLowerCase() === courierColor.toLowerCase() || bg === rgbToHex(courierColor))) {
                div.style.backgroundColor = '#FFD700'; // amarelo
                div.style.border = '2px solid #FFD700';
                console.log('[NEXOS] Cliente alterado para amarelo:', div);
              }
            });
          }
          highlightCourierElements(li.style.color);
          // Função para destacar clientes com a cor do entregador
          function highlightClientsWithCourierColor(courierColor) {
            document.querySelectorAll('#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-marker-pane > div > div').forEach(div => {
              div.style.backgroundColor = courierColor;
              div.style.border = `2px solid ${courierColor}`;
              console.log('[NEXOS] Cliente alterado para cor do entregador:', courierColor, div);
            });
          }
          highlightClientsWithCourierColor(li.style.color);
          // Função para identificar clientes pelo stroke das linhas do entregador
          function highlightCourierClientsByStroke(courierColor) {
            // Busca todos os paths de linha do entregador
            const courierLines = Array.from(document.querySelectorAll('#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-overlay-pane > svg > g > path.leaflet-interactive'));
            const clientIndexes = courierLines
              .map((line, idx) => line.getAttribute('stroke')?.toLowerCase() === courierColor.toLowerCase() ? idx : null)
              .filter(idx => idx !== null);
            // Para cada índice, altera o cliente correspondente
            clientIndexes.forEach(idx => {
              const clientDiv = document.querySelector(`#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-marker-pane > div:nth-child(${idx + 1}) > div`);
              if (clientDiv) {
                clientDiv.style.backgroundColor = courierColor;
                clientDiv.style.border = `2px solid ${courierColor}`;
                console.log('[NEXOS] Cliente do entregador alterado por stroke:', courierColor, clientDiv);
              }
            });
          }
          highlightCourierClientsByStroke(li.style.color);
        }, { passive: true });
        li.appendChild(btn);
      }
        // Automatiza extração dos pedidos: simula mouseover em todos os marcadores para abrir popups
        if (!window.nexosPedidosExtraidos) {
          window.nexosPedidosExtraidos = {};
          const markerIcons = document.querySelectorAll('.leaflet-marker-icon.custom-div-icon');
          markerIcons.forEach(icon => {
            icon.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
          });
          setTimeout(() => {
            document.querySelectorAll('.map-courier-html, .map-order-html').forEach(el => {
              const courierMatch = el.textContent.match(/Entregador:\s*([^\n]+)/);
              const pedidoMatch = el.textContent.match(/#(\d+)/);
              const clienteMatch = el.textContent.match(/Cliente:\s*([^\n]+)/);
              if (courierMatch && pedidoMatch) {
                const courierName = courierMatch[1].trim();
                if (!window.nexosPedidosExtraidos[courierName]) window.nexosPedidosExtraidos[courierName] = [];
                window.nexosPedidosExtraidos[courierName].push({ id: pedidoMatch[1], cliente: clienteMatch ? clienteMatch[1].trim() : '' });
                console.log(`[NEXOS] Pedido extraído: ${courierName} - #${pedidoMatch[1]} - ${clienteMatch ? clienteMatch[1].trim() : ''}`);
              }
            });
            // Fecha todos os popups abertos
            markerIcons.forEach(icon => {
              icon.dispatchEvent(new MouseEvent('mouseout', { bubbles: true }));
            });
            // Adiciona lista de pedidos na legenda
            document.querySelectorAll('#map-legend-list .map-li').forEach(li => {
              const courierName = li.textContent.split(' - ')[0].replace(/^[^\w\s]+\s*/, '').trim();
              if (!li.querySelector('.nexos-orders-list') && window.nexosPedidosExtraidos[courierName]) {
                const pedidos = window.nexosPedidosExtraidos[courierName];
                const ul = document.createElement('ul');
                ul.className = 'nexos-orders-list';
                ul.style.cssText = 'margin:4px 0 0 0;padding:0 0 0 16px;font-size:12px;color:#fff;list-style:disc inside;';
                pedidos.forEach(order => {
                  const liOrder = document.createElement('li');
                  liOrder.textContent = `#${order.id} - ${order.cliente}`;
                  ul.appendChild(liOrder);
                });
                li.appendChild(ul);
              }
            });
          }, 800);
        }
        // Adiciona lista de pedidos ativos abaixo do nome do entregador, extraindo do DOM, com logs
        if (!li.querySelector('.nexos-orders-list')) {
          const courierName = li.textContent.split(' - ')[0].replace(/^[^\w\s]+\s*/, '').trim();
          let pedidos = [];
          document.querySelectorAll('.map-courier-html, .map-order-html').forEach(el => {
            if (el.textContent.includes(courierName)) {
              const match = el.textContent.match(/#(\d+)/);
              const clienteMatch = el.textContent.match(/Cliente:\s*([^\n]+)/);
              if (match) {
                pedidos.push({ id: match[1], cliente: clienteMatch ? clienteMatch[1].trim() : '' });
                console.log(`[NEXOS] Pedido encontrado para ${courierName}: #${match[1]} - ${clienteMatch ? clienteMatch[1].trim() : ''}`);
              }
            }
          });
          if (pedidos.length > 0) {
            console.log(`[NEXOS] Pedidos para ${courierName}:`, pedidos);
            const ul = document.createElement('ul');
            ul.className = 'nexos-orders-list';
            ul.style.cssText = 'margin:4px 0 0 0;padding:0 0 0 16px;font-size:12px;color:#fff;list-style:disc inside;';
            pedidos.forEach(order => {
              const liOrder = document.createElement('li');
              liOrder.textContent = `#${order.id} - ${order.cliente}`;
              ul.appendChild(liOrder);
            });
            li.appendChild(ul);
          } else {
            console.log(`[NEXOS] Nenhum pedido encontrado para ${courierName}`);
          }
        }
        // Adiciona lista de pedidos ativos abaixo do nome do entregador, extraindo do DOM
        if (!li.querySelector('.nexos-orders-list')) {
          const courierName = li.textContent.split(' - ')[0].replace(/^[^\w\s]+\s*/, '').trim();
          // Busca pedidos no DOM: procura popups ou elementos que contenham o nome do entregador
          let pedidos = [];
          document.querySelectorAll('.map-courier-html, .map-order-html').forEach(el => {
            if (el.textContent.includes(courierName)) {
              const match = el.textContent.match(/#(\d+)/);
              const clienteMatch = el.textContent.match(/Cliente:\s*([^\n]+)/);
              if (match) {
                pedidos.push({ id: match[1], cliente: clienteMatch ? clienteMatch[1].trim() : '' });
              }
            }
          });
          if (pedidos.length > 0) {
            const ul = document.createElement('ul');
            ul.className = 'nexos-orders-list';
            ul.style.cssText = 'margin:4px 0 0 0;padding:0 0 0 16px;font-size:12px;color:#fff;list-style:disc inside;';
            pedidos.forEach(order => {
              const liOrder = document.createElement('li');
              liOrder.textContent = `#${order.id} - ${order.cliente}`;
              ul.appendChild(liOrder);
            });
            li.appendChild(ul);
          }
        }
        // Adiciona lista de pedidos ativos abaixo do nome do entregador
        if (!li.querySelector('.nexos-orders-list')) {
          const courierName = li.textContent.split(' - ')[0].replace(/^[^\w\s]+\s*/, '').trim();
          // Busca pedidos do entregador no stores.json (ou fonte de dados disponível)
          // Exemplo: window.nexosCourierOrders[courierName] = [{id: 123, cliente: 'João'}, ...]
          if (window.nexosCourierOrders && window.nexosCourierOrders[courierName]) {
            const orders = window.nexosCourierOrders[courierName];
            const ul = document.createElement('ul');
            ul.className = 'nexos-orders-list';
            ul.style.cssText = 'margin:4px 0 0 0;padding:0 0 0 16px;font-size:12px;color:#fff;list-style:disc inside;';
            orders.forEach(order => {
              const liOrder = document.createElement('li');
              liOrder.textContent = `#${order.id} - ${order.cliente}`;
              ul.appendChild(liOrder);
            });
            li.appendChild(ul);
          }
        }
      if (li.textContent.includes(' - 0')) {
        li.style.background = '#222';
      } else {
        li.style.background = '#004B6B';
        li.style.color = '#fff';
      }
    });
    console.log('[NEXOS] Botão localizar e agrupamento visual aplicados.');
  } catch (e) {
    console.error('[NEXOS] Erro ao injetar botão localizar/agrupamento:', e);
  }
  try {
    const legendList = document.getElementById('map-legend-list');
    if (legendList) {
      const observer = new MutationObserver(() => {
        try {
          document.querySelectorAll('#map-legend-list .map-li').forEach((li, idx) => {
            if (!li.querySelector('.nexos-locate-btn')) {
              const btn = document.createElement('button');
              btn.textContent = 'Localizar';
              btn.className = 'nexos-locate-btn';
              btn.style.cssText = 'margin-left:8px;padding:2px 8px;border-radius:4px;border:0;background:#00C2FF;color:#fff;font-size:12px;cursor:pointer;';
              // console.log('[NEXOS] [Observer] Botão Localizar criado para:', li.textContent);
              btn.addEventListener('click', function(e) {
                console.log('[NEXOS] [Observer] Clique no botão Localizar:', li.textContent);
                e.stopPropagation();
                li.click();
                // Destaca o path SVG do entregador correspondente
                const courierColor = li.style.color;
                function rgbToHex(rgb) {
                  if (!rgb) return '';
                  const result = rgb.match(/\d+/g);
                  if (!result) return '';
                  return '#' + result.slice(0,3).map(x => (+x).toString(16).padStart(2, '0')).join('');
                }
                const legendColor = courierColor ? rgbToHex(courierColor) : '';
                console.log('[NEXOS] [Observer] Cor do entregador na legenda:', legendColor);
                const allPaths = document.querySelectorAll('#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-overlay-pane > svg > g > path');
                allPaths.forEach((path, idx) => {
                  console.log(`[NEXOS] [Observer] Path ${idx}: fill=${path.getAttribute('fill')}, fill-opacity=${path.getAttribute('fill-opacity')}`);
                });
                // Limpa destaque anterior
                document.querySelectorAll('path.leaflet-interactive').forEach(path => {
                  path.setAttribute('stroke', '#444444');
                  path.setAttribute('stroke-width', '2');
                  path.setAttribute('fill-opacity', path.getAttribute('fill-opacity') || '1');
                });
                // Limpa todos para fill-opacity 0.2
                allPaths.forEach(path => {
                  path.setAttribute('fill-opacity', '0.2');
                });
                // Aplica destaque no path do entregador selecionado
                let found = false;
                allPaths.forEach((path, idx) => {
                  // Compara HEX, RGB e cor original
                  const pathFill = path.getAttribute('fill');
                  if (
                    legendColor && (
                      pathFill === legendColor ||
                      pathFill?.toLowerCase() === li.style.color?.toLowerCase() ||
                      pathFill === li.style.color ||
                      pathFill === rgbToHex(li.style.color)
                    )
                  ) {
                    path.setAttribute('fill', '#002147'); // azul escuro
                    path.setAttribute('fill-opacity', '1');
                    path.setAttribute('stroke', '#FFD700'); // borda amarela
                    path.setAttribute('stroke-width', '7');
                    found = true;
                    console.log(`[NEXOS] [Observer] Path destacado: idx=${idx}, fill=${pathFill}`);
                  }
                });
                if (!found) {
                  // Tenta destacar pelo index do entregador na lista
                  const liIdx = Array.from(li.parentNode.children).indexOf(li);
                  const fallbackPath = allPaths[liIdx];
                  if (fallbackPath) {
                    // Se o path tem fill=none, aplica cor e borda
                    fallbackPath.setAttribute('fill', '#002147');
                    fallbackPath.setAttribute('fill-opacity', '1');
                    fallbackPath.setAttribute('stroke', '#FFD700');
                    fallbackPath.setAttribute('stroke-width', '7');
                    console.log(`[NEXOS] [Observer] Path destacado por index: idx=${liIdx}, fill=${fallbackPath.getAttribute('fill')}`);
                    found = true;
                  } else {
                    console.log('[NEXOS] [Observer] Nenhum path destacado! Verifique se a cor bate ou se há correspondência por index.');
                  }
                }
              }, { passive: true });
              li.appendChild(btn);
            }
            if (li.textContent.includes(' - 0')) {
              li.style.background = '#222';
            } else {
              li.style.background = '#004B6B';
              li.style.color = '#fff';
            }
            // Se o entregador está em foco, reaplica destaque
            if (window.nexosCourierFocusIdx === idx) {
              const allPaths = document.querySelectorAll('#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-overlay-pane > svg > g > path');
              const path = allPaths[idx];
              if (path) {
                path.setAttribute('fill', '#002147');
                path.setAttribute('fill-opacity', '1');
                path.setAttribute('stroke', '#FFD700');
                path.setAttribute('stroke-width', '7');
                console.log(`[NEXOS] [Observer] Path mantido em foco: idx=${idx}`);
              }
            }
          });
            // Reaplica filtro salvo após atualização da lista
            const savedFilter = localStorage.getItem('nexos-courier-filter') || '';
            document.getElementById('nexos-courier-filter')?.dispatchEvent(new Event('input'));
        } catch (e) {
          console.error('[NEXOS] Erro no observer de mutação:', e);
        }
      });
      observer.observe(legendList, { childList: true, subtree: true });
      console.log('[NEXOS] Observador de mutação ativado para a legenda.');
      restoreCourierFocus();
    }
  } catch (e) {
    console.error('[NEXOS] Erro ao ativar observer de mutação:', e);
  }
  console.log('[NEXOS] Injeção de melhorias finalizada.');
})(1);
// Função para manter linhas do entregador em foco sempre amarelas
function keepCourierLinesYellow() {
  if (window.nexosCourierFocusIdx !== null) {
    const legendLis = document.querySelectorAll('#map-legend-list .map-li');
    const li = legendLis[window.nexosCourierFocusIdx];
    if (li) {
      highlightCourierElements(li.style.color);
    }
  }
}
// Observa mudanças no SVG para manter linhas amarelas
const svgOverlay = document.querySelector('#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-overlay-pane > svg > g');
if (svgOverlay) {
  const svgObserver = new MutationObserver(() => {
    keepCourierLinesYellow();
    restoreCourierFocus();
  });
  svgObserver.observe(svgOverlay, { childList: true, subtree: true });
  console.log('[NEXOS] Observador de mutação ativado para o SVG dos paths.');
}
// Restaura o foco do entregador após qualquer atualização dinâmica
function restoreCourierFocus() {
  const savedColor = localStorage.getItem('nexos-courier-focus-color');
  if (savedColor) {
    document.querySelectorAll('#map-legend-list .map-li').forEach((li, idx) => {
      if (li.style.color === savedColor || rgbToHex(li.style.color) === savedColor) {
        window.nexosCourierFocusIdx = idx;
        highlightCourierElements(savedColor);
        console.log('[NEXOS] Foco do entregador restaurado:', li.textContent);
      }
    });
  }
}
// Aguarda carregamento completo do mapa antes de restaurar o foco
function waitAndRestoreCourierFocus(attempt = 1) {
  const legendReady = document.querySelectorAll('#map-legend-list .map-li').length > 0;
  const svgReady = document.querySelector('#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-overlay-pane > svg > g');
  if (legendReady && svgReady) {
    restoreCourierFocus();
  } else if (attempt < 30) {
    setTimeout(() => waitAndRestoreCourierFocus(attempt + 1), 500);
  } else {
    console.warn('[NEXOS] Não foi possível restaurar o foco do entregador: elementos não carregaram.');
  }
}
window.addEventListener('DOMContentLoaded', () => waitAndRestoreCourierFocus());
// Função para destacar apenas os clientes do entregador em foco
function highlightOnlyCourierClients(courierColor) {
  document.querySelectorAll('#map > div.leaflet-pane.leaflet-map-pane > div.leaflet-pane.leaflet-marker-pane > div > div').forEach(div => {
    // Só altera se o background original for igual à cor do entregador
    const bg = div.style.backgroundColor;
    if (bg && (bg.toLowerCase() === courierColor.toLowerCase() || bg === rgbToHex(courierColor))) {
      div.style.backgroundColor = courierColor;
      div.style.border = `2px solid ${courierColor}`;
      console.log('[NEXOS] Cliente do entregador alterado:', courierColor, div);
    }
  });
}
