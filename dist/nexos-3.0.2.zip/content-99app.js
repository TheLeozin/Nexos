/**
 * content-99app.js
 * Roda em entrega.99app.com
 * Lê o parâmetro ?nexos_order=XXXX da URL e preenche automaticamente
 * o campo "ID do pedido externo" (#external_order_id) com React-compatible events.
 */
(function () {
  'use strict';

  // ── Ler o ID do pedido passado pelo monitor ──────────────────────────────
  const params   = new URLSearchParams(location.search);
  const orderId  = params.get('nexos_order');
  if (!orderId) return; // não foi aberto pelo monitor → nada a fazer

  // ── Esperar o input aparecer no DOM (a página é SPA) ────────────────────
  let attempts = 0;
  const MAX    = 60; // até ~6 s

  const timer = setInterval(() => {
    attempts++;

    const input = document.getElementById('external_order_id')
               || document.querySelector('input[placeholder*="pedido externo" i]')
               || document.querySelector('input[id*="external"][id*="order"]');

    if (input) {
      clearInterval(timer);
      fillInput(input, orderId);
      return;
    }

    if (attempts >= MAX) {
      clearInterval(timer);
      console.warn('[Nexos 99] Campo external_order_id não encontrado após', MAX * 100, 'ms');
    }
  }, 100);

  /**
   * Preenche o input de forma compatível com React 16/17/18.
   * React mantém um setter nativo sobre value; precisamos dispará-lo
   * via Object.getOwnPropertyDescriptor para contornar o controle do framework.
   */
  function fillInput(input, value) {
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype, 'value'
    )?.set;

    if (nativeInputValueSetter) {
      nativeInputValueSetter.call(input, value);
    } else {
      input.value = value;
    }

    // Disparar eventos que o React escuta para atualizar o estado interno
    input.dispatchEvent(new Event('input',  { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));

    // Focar e posicionar cursor no final
    input.focus();
    input.setSelectionRange(value.length, value.length);

    // Pressionar Enter para disparar a pesquisa (se houver formulário)
    setTimeout(() => {
      input.dispatchEvent(new KeyboardEvent('keydown',  { key: 'Enter', bubbles: true }));
      input.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', bubbles: true }));
      input.dispatchEvent(new KeyboardEvent('keyup',    { key: 'Enter', bubbles: true }));

      // Tentar clicar no botão Pesquisar
      const btn = document.querySelector('button[type="submit"]')
               || [...document.querySelectorAll('button')].find(b =>
                    b.textContent.trim().toLowerCase().includes('pesquis'));
      if (btn) btn.click();
    }, 300);
  }
})();
