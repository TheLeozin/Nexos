// ============================================================================
// PHASE 3 - LOGMANAGER E NOTIFICATIONMANAGER INITIALIZATION (SERVICE WORKER)
// ============================================================================
let logManager = null;
let notificationManager = null;

// Rastrear abas de plataforma abertas pelo Picking (para detectar fechamento)
const _nexosPlatformTabIds = new Set();

try {
  importScripts(
    'core/logging/log-manager.js',
    'core/permissions/roles.js',
    'core/notifications/notification-manager.js'
  );
  
  // Inicializar LogManager
  if (typeof LogManager !== 'function' && typeof self.LogManager !== 'function') {
    throw new Error('LogManager não foi carregado corretamente');
  }
  
  const LogManagerClass = typeof LogManager !== 'undefined' ? LogManager : self.LogManager;
  logManager = new LogManagerClass();
  logManager.initialize().then(() => {
    console.log('[NEXOS-BG] ✅ LogManager inicializado');
  }).catch(err => {
    console.error('[NEXOS-BG] ❌ Erro ao inicializar LogManager:', err);
  });
  
  // Inicializar NotificationManager
  const NotificationManagerClass = typeof NotificationManager !== 'undefined' ? NotificationManager : self.NotificationManager;
  const PermissionManagerClass = typeof PermissionManager !== 'undefined' ? PermissionManager : self.PermissionManager;
  
  if (NotificationManagerClass) {
    notificationManager = new NotificationManagerClass();
    // PermissionManager será inicializado quando usuário fizer login no admin
    notificationManager.initialize(null, logManager).then(() => {
      console.log('[NEXOS-BG] ✅ NotificationManager inicializado');
    }).catch(err => {
      console.error('[NEXOS-BG] ❌ Erro ao inicializar NotificationManager:', err);
    });
  }
  
} catch (err) {
  console.error('[NEXOS-BG] ❌ Erro ao carregar managers:', err);
  // Fallback: mock para não quebrar a extensão
  logManager = {
    log: async (...args) => console.log('[LOG-FALLBACK]', ...args),
    warn: async (...args) => console.warn('[LOG-FALLBACK]', ...args),
    error: async (...args) => console.error('[LOG-FALLBACK]', ...args),
    initialize: async () => {}
  };
  notificationManager = {
    notifyCriticalError: async (...args) => console.error('[NOTIF-FALLBACK]', ...args),
    notifyUserError: async (...args) => console.warn('[NOTIF-FALLBACK]', ...args)
  };
}

/**
 * Helper para enviar notificação de erro crítico (visível apenas para admins)
 */
async function notifyCriticalErrorToAdmins(title, message, errorDetails) {
  try {
    // Verificar se há usuário admin logado no dashboard
    const session = await chrome.storage.local.get('__nexos_user_permissions');
    const userPermissions = session.__nexos_user_permissions;
    
    if (userPermissions && userPermissions.permissions.includes('receive_critical_alerts')) {
      // Usuário tem permissão, enviar notificação
      if (notificationManager) {
        await notificationManager.notifyCriticalError(title, message, errorDetails);
        console.log('[NEXOS-BG] 🔔 Notificação crítica enviada:', title);
      }
    } else {
      console.log('[NEXOS-BG] Nenhum admin logado para receber notificação');
    }
  } catch (error) {
    console.error('[NEXOS-BG] Erro ao enviar notificação:', error);
  }
}

// ============================================================================
// PHASE 3 - STORAGE ADAPTER INITIALIZATION (SERVICE WORKER)
// ============================================================================
// Service workers podem usar importScripts() - sem restrições de CSP

// Importar módulos necessários
try {
  importScripts(
    'core/auth/oauth-client.js',
    'core/auth/token-manager.js',
    'core/auth/auth-helper.js',
    'core/sharepoint/graph-client.js',
    'core/storage/storage-adapter.js'
  );
  console.log('[NEXOS-BG] ✅ Módulos carregados via importScripts');
} catch (importErr) {
  console.error('[NEXOS-BG] ❌ Erro ao importar módulos:', importErr);
  console.warn('[NEXOS-BG] Fallback: usando chrome.storage.local direto');
}

// ============================================================================
// NEXOS AUTH CONFIGURATION
// ============================================================================
const NEXOS_AUTH_CONFIG = {
  clientId: '8f673d6e-b976-4d54-a83d-a8618973c963', // Azure AD App Registration ID
  tenantId: '1a53e6b6-7562-4b9f-83d0-e71a8891667e', // GPA Tenant ID
  authority: 'https://login.microsoftonline.com/1a53e6b6-7562-4b9f-83d0-e71a8891667e',
  redirectUri: null, // Será gerado dinamicamente pelo OAuthClient
  scopes: [
    'openid',
    'profile',
    'email',
    'User.Read',
    'User.ReadBasic.All'
  ]
};

// Inicializar StorageAdapter com backend híbrido
let storageAdapter = null;

async function initStorageAdapter() {
  if (storageAdapter) {
    return storageAdapter;
  }

  try {
    console.log('[NEXOS-BG] Inicializando StorageAdapter (chrome-only)...');

    // Verificar se StorageAdapter está disponível
    if (typeof StorageAdapter === 'undefined') {
      throw new Error('StorageAdapter não disponível após importScripts');
    }

    // 🔧 TEMPORÁRIO: chrome-only (sem AuthHelper/GraphClient)
    // Para ativar SharePoint sync no futuro, descomentar bloco abaixo:
    /*
    // Configuração SharePoint
    const sharepointConfig = {
      auth: {
        clientId: 'obodcljemkajclohcfjhmommhfpklojo',
        authority: 'https://login.microsoftonline.com/consumers',
        redirectUri: chrome.identity.getRedirectURL(),
        scopes: [
          'openid',
          'profile',
          'email',
          'Files.ReadWrite.All',
          'Sites.ReadWrite.All',
          'User.Read'
        ]
      },
      sharepoint: {
        siteUrl: 'https://gpabr.sharepoint.com/sites/Nexos',
        driveType: 'documentLibrary',
        driveName: 'Documentos Compartilhados'
      }
    };

    const authHelper = new AuthHelper(sharepointConfig.auth);
    const graphClient = new GraphClient({
      siteUrl: sharepointConfig.sharepoint.siteUrl,
      driveType: sharepointConfig.sharepoint.driveType,
      driveName: sharepointConfig.sharepoint.driveName,
      authHelper: authHelper
    });

    storageAdapter = new StorageAdapter({
      backend: 'hybrid',
      graphClient: graphClient,
      authHelper: authHelper,
      syncInterval: 60000,
      maxRetries: 3
    });
    */

    // Criar StorageAdapter chrome-only (sem SharePoint)
    storageAdapter = new StorageAdapter({
      backend: 'chrome'
    });

    console.log('[NEXOS-BG] ✅ StorageAdapter inicializado (chrome-only)');
    
    return storageAdapter;
  } catch (error) {
    console.error('[NEXOS-BG] ❌ Erro ao inicializar StorageAdapter:', error);
    console.warn('[NEXOS-BG] Fallback: usando chrome.storage.local direto');
    
    // Notificar erro crítico para admins
    await notifyCriticalErrorToAdmins(
      '❌ Erro no StorageAdapter',
      'Falha ao inicializar StorageAdapter. Usando fallback local.',
      {
        error: error.message,
        stack: error.stack,
        timestamp: Date.now()
      }
    );
    
    // Criar adapter fallback (chrome-only inline)
    storageAdapter = {
      async get(key) {
        const result = await chrome.storage.local.get([key]);
        return result[key] || null;
      },
      async set(key, value) {
        await chrome.storage.local.set({ [key]: value });
        return true;
      },
      async remove(key) {
        await chrome.storage.local.remove([key]);
        return true;
      }
    };
    
    return storageAdapter;
  }
}

// Inicializar em background (não bloqueia)
initStorageAdapter().catch(err => {
  console.error('[NEXOS-BG] Falha crítica ao inicializar StorageAdapter:', err);
});

// Helper para garantir adapter está pronto
async function ensureStorageAdapter() {
  if (!storageAdapter) {
    return await initStorageAdapter();
  }
  return storageAdapter;
}

/**
 * Wrappers compatíveis com chrome.storage.local
 * Usam StorageAdapter quando disponível, fallback para chrome.storage direto
 */
async function bgStorageGet(keys) {
  const adapter = await ensureStorageAdapter();
  
  if (adapter && adapter !== chrome.storage.local) {
    // Usar StorageAdapter
    const keyArray = Array.isArray(keys) ? keys : [keys];
    const result = {};
    
    for (const key of keyArray) {
      const value = await adapter.get(key);
      if (value !== null) {
        result[key] = value;
      }
    }
    
    console.log('[NEXOS-BG] Dados carregados via StorageAdapter:', Object.keys(result));
    return result;
  }
  
  // Fallback direto
  return await chrome.storage.local.get(keys);
}

async function bgStorageSet(items) {
  const adapter = await ensureStorageAdapter();
  
  if (adapter && adapter !== chrome.storage.local) {
    // Usar StorageAdapter
    for (const [key, value] of Object.entries(items)) {
      await adapter.set(key, value);
    }
    console.log('[NEXOS-BG] Dados salvos via StorageAdapter:', Object.keys(items));
    return;
  }
  
  // Fallback direto
  await chrome.storage.local.set(items);
}

async function bgStorageRemove(keys) {
  const adapter = await ensureStorageAdapter();
  
  if (adapter && adapter !== chrome.storage.local) {
    // Usar StorageAdapter
    const keyArray = Array.isArray(keys) ? keys : [keys];
    
    for (const key of keyArray) {
      await adapter.remove(key);
    }
    console.log('[NEXOS-BG] Dados removidos via StorageAdapter:', keys);
    return;
  }
  
  // Fallback direto
  await chrome.storage.local.remove(keys);
}

// ============================================================================
// END STORAGE ADAPTER INITIALIZATION
// ============================================================================

// --- Auto-update leve usando manifest remoto ---
// latest.json é a fonte primária (contém versão + url + notes inline).
// REMOTE_MANIFEST_URL é mantido como fallback (compatibilidade).
const LATEST_JSON_URL = 'https://raw.githubusercontent.com/TheLeozin/Nexos/main/latest.json';
const REMOTE_MANIFEST_URL = 'https://raw.githubusercontent.com/TheLeozin/Nexos/main/manifest.json';
const REMOTE_UPDATE_NOTES_URL = 'https://raw.githubusercontent.com/TheLeozin/Nexos/main/update_notes.json';
// Tempo de espera antes de auto-reload (ms) — dá tempo ao PowerShell updater
// de concluir a substituição dos arquivos locais antes de recarregar a extensão.
const UPDATER_WAIT_MS = 5 * 60 * 1000; // 5 minutos
const LOCAL_UPDATE_NOTES = {
  '1.1.0': [
    'Adiconado overlay de picking redesenhado com filtros Pendentes/Solicitado/Cancelado e exclusao direta.',
    'Adiconado gerador de comentarios Orkestra com arvores condicionais, validacao de campos e envio assistido.',
    'Adiconado botao flutuante reutilizavel, alerts/toasts acessiveis e restauro completo de foco.',
    'Adiconado fluxo Lalamove restabelecido com selecao manual de veiculo, captura de tracking e sessao protegida.',
    'Adiconado autofill aprimorado para Uber, Lalamove e 99 com prompts contextuais e salvamento de links.',
    'Adiconado auto-update remoto com notificacao piscante, banner de release notes e recarregamento guiado.',
    'Adiconado script de mapa escuro personalizado no James Delivery com Leaflet e retry dedicado.'
  ]
};
const UPDATE_ALARM_NAME = 'nexos-auto-update-check';
const UPDATE_INTERVAL_MINUTES = 5; // 5 min — alinhado com o polling do PowerShell updater

// Keepalive: impede que o SW MV3 durma durante o polling do monitor (3 s)
// Chrome acorda o SW quando o alarm dispara, mantendo-o aquecido
const SW_KEEPALIVE_ALARM = 'nexos-sw-keepalive';
const SW_KEEPALIVE_INTERVAL_MINUTES = 0.4; // ~24 s (abaixo do timeout de suspensão do Chrome)
const RELOAD_STATE_KEY = '__nexos_auto_update_last_remote_version';
const RELOAD_STATE_TS_KEY = '__nexos_auto_update_last_reload_ts';
const PENDING_UPDATE_KEY = '__nexos_update_pending_version';
const UPDATE_NOTIFICATION_ID = 'nexos-update-alert';
const PENDING_NOTES_KEY = '__nexos_update_pending_notes';
const POST_UPDATE_KEY = '__nexos_update_post_install_payload';

let pendingRemoteVersion = null;
let pendingReleaseNotes = null;
let updateNotificationBlinkInterval = null;
let updateNotificationBlinkState = false;
// Timestamp da primeira deteção da nova versão — usado para calcular autoReloadAt
let _updateDetectedAt = null;

async function loadUpdateNotes(version) {
  if (!version) return null;
  try {
    const response = await fetch(REMOTE_UPDATE_NOTES_URL, { cache: 'no-store' });
    if (response && response.ok) {
      const payload = await response.json();
      if (Array.isArray(payload)) {
        return payload;
      }
      if (payload && Object.prototype.hasOwnProperty.call(payload, version)) {
        const candidate = payload[version];
        if (Array.isArray(candidate)) {
          return candidate;
        }
      }
    } else if (response) {
      console.warn('[NEXOS][AutoUpdate] update_notes remoto respondeu', response.status, response.statusText);
    }
  } catch (err) {
    console.warn('[NEXOS][AutoUpdate] Falha ao buscar update_notes remoto:', err);
  }

  if (Object.prototype.hasOwnProperty.call(LOCAL_UPDATE_NOTES, version)) {
    return LOCAL_UPDATE_NOTES[version];
  }

  return null;
}

// ═══════════════════════════════════════════════════════════════════════════
// PROXY DE FETCH — Contorna CSP de páginas hospedeiras (Uber, Lalamove, etc.)
// Content scripts em páginas de terceiros têm a CSP delas aplicada, o que
// bloqueia conexões para graph.microsoft.com. O background service worker
// não está sujeito a essa CSP e pode fazer fetch livremente.
// ═══════════════════════════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // ── Retornar hora UTC real do servidor Graph (para corrigir relógio local) ──
  if (request?.action === 'nexos_get_server_time') {
    fetch('https://graph.microsoft.com/v1.0/', { method: 'HEAD' })
      .then(res => {
        const dateHeader = res.headers.get('Date') || res.headers.get('date');
        const serverMs = dateHeader ? new Date(dateHeader).getTime() : Date.now();
        sendResponse({ ok: true, serverMs, localMs: Date.now() });
      })
      .catch(() => {
        // Fallback: sem acesso à internet, usa hora local
        sendResponse({ ok: false, serverMs: Date.now(), localMs: Date.now() });
      });
    return true; // resposta assíncrona
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request?.action === 'nexos_fetch') {
    const { url, options = {} } = request;
    // Compatibilidade com formato antigo (method/headers/body direto) e novo (options)
    const method  = options.method  || request.method  || 'GET';
    const headers = options.headers || request.headers || {};
    const body    = options.body    || request.body;
    const init = { method, headers };
    if (body) init.body = body;

    // ── Keepalive: evita que o service worker MV3 seja suspenso antes de responder ──
    // Padrão: ping via setInterval para manter o SW ativo durante fetches longos.
    const keepAliveInterval = setInterval(() => {
      try { chrome.runtime.getPlatformInfo(() => {}); } catch (_) {}
    }, 20000);

    fetch(url, init)
      .then(async (res) => {
        const contentType = res.headers.get('content-type') || '';
        const isBinary = contentType.startsWith('image/') ||
                         contentType.startsWith('application/octet') ||
                         contentType.startsWith('audio/') ||
                         contentType.startsWith('video/');
        if (isBinary) {
          const buf = await res.arrayBuffer();
          // Converter ArrayBuffer para base64
          const bytes = new Uint8Array(buf);
          let bin = '';
          for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
          const b64 = btoa(bin);
          sendResponse({ ok: res.ok, status: res.status, body: b64, isBase64: true, contentType });
        } else {
          const text = await res.text();
          sendResponse({ ok: res.ok, status: res.status, body: text });
        }
      })
      .catch((err) => {
        sendResponse({ ok: false, status: 0, error: err.message });
      })
      .finally(() => {
        clearInterval(keepAliveInterval);
      });
    return true; // resposta assíncrona
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Filtrar mensagens de token Instaleap fora de contexto (evitar flood de logs)
  if (request?.type === 'IL_TOKEN_CAPTURED') {
    if (!self._ilAuthPending) {
      // Sem login Instaleap pendente — responder "ignored" para o content script resetar tokenSent
      sendResponse({ ignored: true });
      return false;
    }
    // Há login pendente — deixar o messageListener específico do IL_AUTH_REQUEST tratar
    return false;
  }

  // Abrir aba em grupo "Nexos Torre" (content scripts não têm acesso a chrome.tabs.group)
  if (request?.action === 'openTabInNexosGroup') {
    const { url } = request;
    const GROUP_TITLE = 'Nexos Torre';
    const GROUP_COLOR = 'blue';
    (async () => {
      try {
        const newTab = await chrome.tabs.create({ url, active: false });
        // Rastrear aba de plataforma para detectar fechamento
        _nexosPlatformTabIds.add(newTab.id);
        let nexosGroupId = null;
        if (chrome.tabGroups?.query) {
          const groups = await chrome.tabGroups.query({ windowId: newTab.windowId });
          const existing = groups.find(g => g.title === GROUP_TITLE);
          if (existing) nexosGroupId = existing.id;
        }
        if (chrome.tabs.group) {
          const groupOptions = { tabIds: [newTab.id] };
          if (nexosGroupId !== null) groupOptions.groupId = nexosGroupId;
          else groupOptions.createProperties = { windowId: newTab.windowId };
          const assignedGroupId = await chrome.tabs.group(groupOptions);
          if (nexosGroupId === null && chrome.tabGroups?.update) {
            await chrome.tabGroups.update(assignedGroupId, { title: GROUP_TITLE, color: GROUP_COLOR, collapsed: false });
          }
        }
        // Não ativa a aba: foco permanece no Picking. O preenchimento roda em background.
        sendResponse({ ok: true, tabId: newTab.id });
      } catch (err) {
        console.warn('[NEXOS-BG] Falha ao abrir aba em grupo:', err);
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true; // resposta assíncrona
  }

  // Focar aba pelo tabId (content scripts não têm chrome.tabs.update)
  if (request?.action === 'focusTab') {
    const { tabId } = request;
    if (tabId) {
      chrome.tabs.update(tabId, { active: true }, (tab) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          // Focar também a janela
          if (tab?.windowId) chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
          sendResponse({ ok: true });
        }
      });
      return true;
    }
    sendResponse({ ok: false, error: 'tabId não fornecido' });
    return false;
  }

  // Renomear aba de plataforma (content scripts não têm chrome.scripting)
  if (request?.action === 'renameTab') {
    const { tabId, title } = request;
    if (tabId && title) {
      chrome.scripting.executeScript({
        target: { tabId },
        func: (t) => { try { document.title = t; } catch (_) {} },
        args: [title]
      }).catch(e => console.warn('[NEXOS-BG] renameTab falhou:', e));
    }
    return false;
  }

  // Retornar tabId da aba que enviou a mensagem (content scripts não têm chrome.tabs.getCurrent)
  if (request?.action === 'getCurrentTabId') {
    sendResponse({ tabId: sender?.tab?.id || null });
    return false;
  }

  // Focar aba de plataforma pelo URL pattern (fallback quando tabId não disponível)
  if (request?.action === 'focusPlatformTab') {
    const { platform } = request;
    const urlPatterns = {
      uber: 'direct.uber.com',
      lalamove: 'web.lalamove.com',
      '99': '99app.com'
    };
    const pattern = platform ? urlPatterns[platform] : null;
    (async () => {
      try {
        const tabs = await chrome.tabs.query({});
        const match = tabs.find(t => t.url && (
          pattern ? t.url.includes(pattern)
            : (t.url.includes('direct.uber.com') || t.url.includes('lalamove.com') || t.url.includes('99app.com'))
        ));
        if (match) {
          await chrome.tabs.update(match.id, { active: true });
          if (match.windowId) chrome.windows.update(match.windowId, { focused: true }).catch(() => {});
          sendResponse({ ok: true, tabId: match.id });
        } else {
          sendResponse({ ok: false, error: 'Aba da plataforma não encontrada' });
        }
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true;
  }

  // Log todas as mensagens recebidas para debug
  console.log('[NEXOS-BG] 📨 Mensagem recebida:', request);
  
  if (!request) {
    console.warn('[NEXOS-BG] ⚠️ Mensagem vazia recebida');
    return;
  }

  if (request.action === 'confirmUpdateReload') {
    (async () => {
      let versionForPostUpdate = pendingRemoteVersion;
      let notesForPostUpdate = pendingReleaseNotes;
      stopBlinkingNotification();
      try {
        if (chrome.storage && chrome.storage.local) {
          try {
            // PHASE 3: Usar bgStorageGet()
            const stored = await bgStorageGet([PENDING_UPDATE_KEY, PENDING_NOTES_KEY]);
            if (!versionForPostUpdate && stored && stored[PENDING_UPDATE_KEY]) {
              versionForPostUpdate = stored[PENDING_UPDATE_KEY];
            }
            if (!notesForPostUpdate && stored && Object.prototype.hasOwnProperty.call(stored, PENDING_NOTES_KEY)) {
              notesForPostUpdate = stored[PENDING_NOTES_KEY];
            }
          } catch (readErr) {
            console.warn('[NEXOS][AutoUpdate] Falha ao recuperar dados pendentes antes do reload:', readErr);
          }

          if (versionForPostUpdate) {
            try {
              // PHASE 3: Usar bgStorageSet()
              await bgStorageSet({
                [POST_UPDATE_KEY]: {
                  version: versionForPostUpdate,
                  notes: notesForPostUpdate || null,
                  ts: Date.now(),
                  acknowledged: false
                }
              });
            } catch (setErr) {
              console.warn('[NEXOS][AutoUpdate] Falha ao registrar banner pós-atualização:', setErr);
            }
          } else {
            try {
              // PHASE 3: Usar bgStorageRemove()
              await bgStorageRemove([POST_UPDATE_KEY]);
            } catch (clearErr) {
              console.warn('[NEXOS][AutoUpdate] Falha ao limpar banner pós-atualização anterior:', clearErr);
            }
          }

          try {
            // PHASE 3: Usar bgStorageRemove()
            await bgStorageRemove([PENDING_UPDATE_KEY, PENDING_NOTES_KEY]);
          } catch (removeErr) {
            console.warn('[NEXOS][AutoUpdate] Falha ao apagar estado pendente após confirmação:', removeErr);
          }
        }
      } catch (e) {
        console.warn('[NEXOS][AutoUpdate] Erro ao processar confirmação de atualização:', e);
      } finally {
        pendingRemoteVersion = null;
        pendingReleaseNotes = null;
        broadcastClearUpdatePrompt();
        sendResponse({ ok: true });
        setTimeout(() => {
          try {
            chrome.runtime.reload();
          } catch (err) {
            console.warn('[NEXOS][AutoUpdate] Erro ao recarregar após confirmação:', err);
          }
        }, 500);
      }
    })();
    return true;
  }

  if (request.action === '__nexos_heartbeat') {
    try {
      sendResponse({ ok: true });
    } catch (err) {
      console.warn('[NEXOS][AutoUpdate] Falha ao responder heartbeat:', err);
    }
    return false;
  }

  if (request.action === 'acknowledgePostUpdate') {
    (async () => {
      try {
        if (chrome.storage && chrome.storage.local) {
          // PHASE 3: Usar bgStorageRemove()
          await bgStorageRemove([POST_UPDATE_KEY]);
        }
      } catch (err) {
        console.warn('[NEXOS][AutoUpdate] Erro ao registrar confirmação do banner pós-atualização:', err);
      } finally {
        broadcastClearUpdatePrompt();
        sendResponse({ ok: true });
      }
    })();
    return true;
  }

  if (request.action === 'notify') {
    try {
      const options = {
        type: 'basic',
        iconUrl: 'images/logo.png',
        title: request.title || 'Nexos',
        message: request.message || ''
      };
      chrome.notifications.create('', options, () => {
        if (chrome.runtime.lastError) {
          console.warn('[NEXOS] Erro ao criar notificação:', chrome.runtime.lastError);
        }
      });
      sendResponse({ ok: true });
    } catch (e) {
      console.error('Erro ao criar notificação:', e);
      sendResponse({ ok: false, error: e && e.message });
    }
    return true;
  }
  
  // ═════════════════════════════════════════════════════════════════════════
  // MICROSOFT AUTHENTICATION HANDLERS
  // ═════════════════════════════════════════════════════════════════════════
  
  // Handler 1: Retorna URL de autenticação para iframe embutido
  if (request.type === 'GET_AUTH_URL') {
    console.log('[NEXOS-BG] 🔗 Gerando URL de autenticação para iframe...');
    
    try {
      const clientId = '8f673d6e-b976-4d54-a83d-a8618973c963';
      const tenantId = '1a53e6b6-7562-4b9f-83d0-e71a8891667e';
      const redirectUri = chrome.identity.getRedirectURL();
      
      const authUrl = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/authorize?` +
        `client_id=${clientId}` +
        `&response_type=token` +
        `&redirect_uri=${encodeURIComponent(redirectUri)}` +
        `&scope=${encodeURIComponent('User.Read openid profile email Sites.ReadWrite.All')}` +
        `&prompt=select_account`;
      
      console.log('[NEXOS-BG] ✅ URL gerada:', authUrl.substring(0, 100) + '...');
      
      sendResponse({
        success: true,
        url: authUrl,
        redirectUri: redirectUri
      });
    } catch (error) {
      console.error('[NEXOS-BG] ❌ Erro ao gerar URL:', error);
      sendResponse({
        success: false,
        error: error.message
      });
    }
    
    return true; // Mantém canal aberto
  }
  
  // Handler 2: Processa redirect capturado do iframe
  if (request.type === 'PROCESS_AUTH_REDIRECT') {
    console.log('[NEXOS-BG] 🔄 Processando redirect do iframe...');
    
    (async () => {
      try {
        const responseUrl = request.url;
        
        if (!responseUrl) {
          throw new Error('URL de redirect não fornecida');
        }
        
        console.log('[NEXOS-BG] 📥 URL de redirect recebida');
        
        // Extrair access token da URL
        const hashPart = responseUrl.split('#')[1];
        if (!hashPart) {
          throw new Error('URL sem fragmento hash');
        }
        
        const params = new URLSearchParams(hashPart);
        const accessToken = params.get('access_token');
        
        if (!accessToken) {
          throw new Error('Token de acesso não encontrado');
        }
        
        console.log('[NEXOS-BG] ✅ Token extraído com sucesso');
        
        // Buscar dados do usuário no Microsoft Graph
        const graphResponse = await fetch('https://graph.microsoft.com/v1.0/me', {
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        });
        
        if (!graphResponse.ok) {
          throw new Error(`Graph API retornou ${graphResponse.status}`);
        }
        
        const userData = await graphResponse.json();
        console.log('[NEXOS-BG] ✅ Dados do usuário obtidos:', userData.displayName);
        
        const user = {
          id: userData.id,
          email: userData.mail || userData.userPrincipalName,
          displayName: userData.displayName,
          givenName: userData.givenName,
          surname: userData.surname,
          jobTitle: userData.jobTitle || 'Colaborador',
          department: userData.department || 'Geral'
        };
        
        sendResponse({
          success: true,
          user: user,
          token: accessToken
        });
        
      } catch (error) {
        console.error('[NEXOS-BG] ❌ Erro ao processar redirect:', error);
        sendResponse({
          success: false,
          error: error.message
        });
      }
    })();
    
    return true; // Mantém canal aberto para async
  }
  
  // Handler 3: Popup tradicional (fallback)
  if (request.type === 'MS_AUTH_REQUEST') {
    console.log('[NEXOS-BG] 🔐 Microsoft Auth Request recebido (popup tradicional)');
    
    // Configuração do Azure AD
    const clientId = '8f673d6e-b976-4d54-a83d-a8618973c963';
    const tenantId = '1a53e6b6-7562-4b9f-83d0-e71a8891667e';
    const redirectUri = chrome.identity.getRedirectURL();
    
    // Construir URL de autenticação
    const authUrl = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/authorize?` +
      `client_id=${clientId}` +
      `&response_type=token` +
      `&redirect_uri=${encodeURIComponent(redirectUri)}` +
      `&scope=${encodeURIComponent('User.Read openid profile email Sites.ReadWrite.All')}` +
      `&prompt=select_account`;
    
    console.log('[NEXOS-BG] 📡 Iniciando launchWebAuthFlow...');
    console.log('[NEXOS-BG] 📍 Redirect URI:', redirectUri);
    
    // Iniciar fluxo OAuth (síncrono, não precisa async wrapper)
    chrome.identity.launchWebAuthFlow(
      {
        url: authUrl,
        interactive: true
      },
      async (responseUrl) => {
        try {
          if (chrome.runtime.lastError) {
            console.error('[NEXOS-BG] ❌ Erro no OAuth:', chrome.runtime.lastError);
            sendResponse({
              success: false,
              error: chrome.runtime.lastError.message
            });
            return;
          }
          
          if (!responseUrl) {
            console.error('[NEXOS-BG] ❌ Nenhuma URL de resposta');
            sendResponse({
              success: false,
              error: 'Nenhuma resposta do servidor OAuth'
            });
            return;
          }
          
          console.log('[NEXOS-BG] 📥 Resposta OAuth recebida');
          
          // Extrair access token da URL
          const hashPart = responseUrl.split('#')[1];
          if (!hashPart) {
            console.error('[NEXOS-BG] ❌ URL sem fragmento hash');
            sendResponse({
              success: false,
              error: 'Formato de resposta inválido'
            });
            return;
          }
          
          const params = new URLSearchParams(hashPart);
          const accessToken = params.get('access_token');
          
          if (!accessToken) {
            console.error('[NEXOS-BG] ❌ Token não encontrado na resposta');
            sendResponse({
              success: false,
              error: 'Token de acesso não encontrado'
            });
            return;
          }
          
          console.log('[NEXOS-BG] ✅ Token obtido, buscando perfil...');
          
          // Buscar dados do usuário
          const userResponse = await fetch('https://graph.microsoft.com/v1.0/me', {
            headers: { 'Authorization': `Bearer ${accessToken}` }
          });
          
          if (!userResponse.ok) {
            console.error('[NEXOS-BG] ❌ Falha ao buscar perfil:', userResponse.status);
            sendResponse({
              success: false,
              error: `Erro ${userResponse.status} ao buscar perfil`
            });
            return;
          }
          
          const userData = await userResponse.json();
          console.log('[NEXOS-BG] 👤 Perfil obtido:', userData.displayName);
          
          // Buscar foto do usuário (opcional - não bloqueia login)
          let photoUrl = null;
          try {
            const photoResponse = await fetch('https://graph.microsoft.com/v1.0/me/photo/$value', {
              headers: { 'Authorization': `Bearer ${accessToken}` }
            });
            if (photoResponse.ok) {
              const photoBlob = await photoResponse.blob();
              
              // Converter blob para base64 (funciona entre contextos)
              const reader = new FileReader();
              photoUrl = await new Promise((resolve) => {
                reader.onloadend = () => resolve(reader.result);
                reader.readAsDataURL(photoBlob);
              });
              
              console.log('[NEXOS-BG] 📷 Foto do usuário obtida e convertida para base64');
            }
          } catch (photoErr) {
            console.warn('[NEXOS-BG] ⚠️ Não foi possível obter foto:', photoErr.message);
          }
          
          const user = {
            id: userData.id,
            email: userData.mail || userData.userPrincipalName,
            displayName: userData.displayName,
            givenName: userData.givenName,
            surname: userData.surname,
            jobTitle: userData.jobTitle || 'Sem cargo',
            department: userData.department || 'Não especificado',
            photo: photoUrl,  // ← Agora é base64 (data:image/jpeg;base64,...)
            provider: 'microsoft',
            accessToken: accessToken
          };
          
          console.log('[NEXOS-BG] ✅ Login bem-sucedido:', user.displayName);
          
          sendResponse({
            success: true,
            user: user
          });
          
        } catch (error) {
          console.error('[NEXOS-BG] ❌ Erro ao processar auth:', error);
          sendResponse({
            success: false,
            error: error.message || 'Erro desconhecido'
          });
        }
      }
    );
    
    return true; // Keep message channel open for async response
  }
  
  // ═════════════════════════════════════════════════════════════════════════
  // PICKING ADMIN AUTHENTICATION HANDLER
  // 1. Verifica abas já abertas e extrai token via executeScript
  // 2. Se não encontrar, abre popup + polling via executeScript
  // ═════════════════════════════════════════════════════════════════════════
  if (request.type === 'PK_AUTH_REQUEST') {
    if (self._pkAuthPending) {
      console.warn('[NEXOS-BG] ⚠ PK_AUTH_REQUEST ignorado — já existe login Picking Admin em andamento');
      sendResponse({ success: false, error: 'Login Picking Admin já em andamento. Aguarde.' });
      return false;
    }
    self._pkAuthPending = true;

    // Helper: lê token do localStorage['user'].token da aba picking-admin
    async function tryExtractPkToken(tabId) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId },
          world: 'MAIN',
          func: () => {
            try {
              const raw = localStorage.getItem('user');
              if (!raw) return null;
              const obj = JSON.parse(raw);
              const token = obj?.token || obj?.accessToken || obj?.access_token || null;
              if (token && typeof token === 'string' && token.startsWith('ey') && token.split('.').length === 3 && token.length > 50) return token;
            } catch (_) {}
            return null;
          }
        });
        return results?.[0]?.result || null;
      } catch (e) {
        console.warn('[NEXOS-BG] executeScript falhou na aba', tabId, ':', e.message);
        return null;
      }
    }

    (async () => {
      // ── Etapa 1: verificar abas picking-admin já abertas ──────────────────
      // Lê __nexos_pk_bearer__ (salvo pelo interceptor a partir de fetch/XHR reais)
      let existingTabId = null;
      try {
        const existingTabs = await chrome.tabs.query({ url: '*://picking-admin.backoffice.gpa.digital/*' });
        // Primeiro: checar se alguma aba já tem o token guardado pelo interceptor
        for (const tab of existingTabs) {
          if (tab.status !== 'complete') continue;
          const token = await tryExtractPkToken(tab.id);
          if (token) {
            console.log('[NEXOS-BG] ✅ Token Picking Admin lido de __nexos_pk_bearer__ (tab', tab.id, ')');
            await chrome.storage.local.set({ 'nexos-gpa-api-token': token });
            self._pkAuthPending = false;
            sendResponse({ success: true, token });
            return;
          }
          if (!existingTabId && tab.status === 'complete') existingTabId = tab.id;
        }
        // Segundo: se há aba aberta mas sem token guardado, recarregar para
        // o interceptor capturar o token nas chamadas iniciais da SPA
        if (existingTabId) {
          console.log('[NEXOS-BG] Aba existente sem __nexos_pk_bearer__ — recarregando tab', existingTabId);
          chrome.tabs.reload(existingTabId, { bypassCache: false });
          // Aguardar interceptor enviar PK_TOKEN_CAPTURED após reload
          // (o fluxo continua no listener de mensagens + polling abaixo)
        } else {
          console.log('[NEXOS-BG] Nenhuma aba picking-admin aberta — abrindo popup de login');
        }
      } catch (e) {
        console.warn('[NEXOS-BG] Erro ao verificar abas existentes:', e.message);
      }

      // ── Etapa 2: abrir popup + polling via executeScript ──────────────────
      let loginWindowId = null;
      let pollInterval = null;
      let messageListener = null;
      let timeoutId = null;
      let responded = false;

      function respond(payload) {
        if (responded) return;
        responded = true;
        if (timeoutId) clearTimeout(timeoutId);
        if (pollInterval) clearInterval(pollInterval);
        if (messageListener) chrome.runtime.onMessage.removeListener(messageListener);
        if (loginWindowId) {
          chrome.windows.remove(loginWindowId, () => { if (chrome.runtime.lastError) {} });
          loginWindowId = null;
        }
        self._pkAuthPending = false;
        sendResponse(payload);
      }

      // Listener de mensagens (interceptor envia PK_TOKEN_CAPTURED via fetch/XHR override)
      messageListener = function (msg, sender) {
        if (msg.type !== 'PK_TOKEN_CAPTURED') return;
        const senderUrl = sender?.tab?.url || sender?.url || '';
        if (!senderUrl.includes('picking-admin.backoffice.gpa.digital')) return;
        const token = msg.token;
        if (!token) return;
        console.log('[NEXOS-BG] ✅ Token Picking Admin capturado via interceptor (mensagem)');
        chrome.storage.local.set({ 'nexos-gpa-api-token': token });
        respond({ success: true, token });
      };
      chrome.runtime.onMessage.addListener(messageListener);

      timeoutId = setTimeout(() => {
        console.warn('[NEXOS-BG] ⏱ Timeout ao aguardar login Picking Admin');
        respond({ success: false, error: 'Tempo esgotado. Tente novamente.' });
      }, 5 * 60 * 1000);

      // Se já havia aba existente sendo recarregada, não abrir popup
      if (existingTabId) {
        // Polling via executeScript na aba recarregada
        const startReloadPolling = () => {
          pollInterval = setInterval(async () => {
            if (responded) { clearInterval(pollInterval); return; }
            const token = await tryExtractPkToken(existingTabId);
            if (token) {
              console.log('[NEXOS-BG] ✅ Token Picking Admin capturado após reload (tab', existingTabId, ')');
              chrome.storage.local.set({ 'nexos-gpa-api-token': token });
              respond({ success: true, token });
            }
          }, 2000);
        };
        // Aguardar aba carregar completamente antes de iniciar polling
        const onTabUpdated = (tabId, info) => {
          if (tabId !== existingTabId || info.status !== 'complete') return;
          chrome.tabs.onUpdated.removeListener(onTabUpdated);
          startReloadPolling();
        };
        chrome.tabs.onUpdated.addListener(onTabUpdated);
        return;
      }

      chrome.windows.create({
        url: 'https://picking-admin.backoffice.gpa.digital/',
        type: 'popup',
        width: 520,
        height: 700,
        focused: true
      }, (win) => {
        if (chrome.runtime.lastError || !win) {
          console.error('[NEXOS-BG] ❌ Erro ao abrir janela Picking Admin:', chrome.runtime.lastError);
          respond({ success: false, error: 'Não foi possível abrir a janela de login.' });
          return;
        }
        loginWindowId = win.id;
        console.log('[NEXOS-BG] 🪟 Janela Picking Admin aberta — id:', loginWindowId);

        // Iniciar polling via executeScript na aba do popup
        const startPolling = (tabId) => {
          pollInterval = setInterval(async () => {
            if (responded) { clearInterval(pollInterval); return; }
            const token = await tryExtractPkToken(tabId);
            if (token) {
              console.log('[NEXOS-BG] ✅ Token Picking Admin capturado via polling (executeScript)');
              chrome.storage.local.set({ 'nexos-gpa-api-token': token });
              respond({ success: true, token });
            }
          }, 2000);
        };

        // Obter tabId da aba do popup para polling
        chrome.tabs.query({ windowId: win.id }, (tabs) => {
          if (tabs?.[0]?.id) {
            startPolling(tabs[0].id);
          }
        });

        // Detectar fechamento manual
        chrome.windows.onRemoved.addListener(function onWinRemoved(wid) {
          if (wid !== loginWindowId) return;
          chrome.windows.onRemoved.removeListener(onWinRemoved);
          loginWindowId = null;
          respond({ success: false, error: 'Login cancelado pelo usuário.' });
        });
      });
    })();

    return true;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // PK_TOKEN_CAPTURED — content script enviou token (sem login pendente)
  // Salva no storage para uso futuro pelo monitor
  // ─────────────────────────────────────────────────────────────────────────
  if (request.type === 'PK_TOKEN_CAPTURED') {
    const token = request.token;
    if (token) {
      chrome.storage.local.set({ 'nexos-gpa-api-token': token }, () => {
        console.log('[NEXOS-BG] ✅ nexos-gpa-api-token atualizado automaticamente');
      });
    }
    sendResponse({ ignored: true });
    return false;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // PK_TOKEN_EXPIRED — token picking expirou (401 detectado pelo interceptor)
  // ─────────────────────────────────────────────────────────────────────────
  if (request.type === 'PK_TOKEN_EXPIRED') {
    chrome.storage.local.remove('nexos-gpa-api-token', () => {
      console.log('[NEXOS-BG] 🔓 nexos-gpa-api-token removido (expirado)');
    });
    // Notificar monitor para exibir overlay de re-auth
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, { type: 'PK_TOKEN_EXPIRED' }).catch(() => {});
      });
    });
    sendResponse({ success: true });
    return false;
  }

  // ═════════════════════════════════════════════════════════════════════════
  // INSTALEAP AUTHENTICATION HANDLER
  // Abre janela de login do Instaleap e captura o token via content script
  // ═════════════════════════════════════════════════════════════════════════
  if (request.type === 'IL_AUTH_REQUEST') {
    // Guard: prevenir múltiplas janelas simultâneas
    if (self._ilAuthPending) {
      console.warn('[NEXOS-BG] ⚠ IL_AUTH_REQUEST ignorado — já existe login Instaleap em andamento');
      sendResponse({ success: false, error: 'Login Instaleap já em andamento. Aguarde.' });
      return false;
    }
    self._ilAuthPending = true;

    console.log('[NEXOS-BG] 🔐 Instaleap Auth Request recebido');

    const ilEmail = request.email || null;

    // Salvar email para pré-preenchimento pelo content script
    if (ilEmail) {
      chrome.storage.local.set({ 'nexos-il-prefill-email': ilEmail });
    }

    let loginWindowId = null;
    let messageListener = null;
    let timeoutId = null;

    // Limpar tudo ao finalizar (sucesso ou erro)
    function cleanup() {
      if (timeoutId) clearTimeout(timeoutId);
      if (messageListener) chrome.runtime.onMessage.removeListener(messageListener);
      if (loginWindowId) {
        chrome.windows.remove(loginWindowId, () => {
          if (chrome.runtime.lastError) {
            // Janela já foi fechada pelo usuário — ignorar
          }
        });
        loginWindowId = null;
      }
      self._ilAuthPending = false;
      chrome.storage.local.remove('nexos-il-prefill-email');
    }

    // Listener que aguarda o content script enviar o token
    messageListener = function (msg, sender) {
      if (msg.type !== 'IL_TOKEN_CAPTURED') return;

      // Aceitar token de qualquer aba do control.instaleap.io enquanto o login está pendente
      // (o windowId pode diferir se a página fizer redirect interno)
      const senderUrl = sender?.tab?.url || sender?.url || '';
      const isInstaleapTab = senderUrl.includes('control.instaleap.io') ||
                             senderUrl.includes('instaleap.io');
      const isFromLoginWindow = sender?.tab?.windowId === loginWindowId;

      if (!isInstaleapTab && !isFromLoginWindow) {
        console.warn('[NEXOS-BG] IL_TOKEN_CAPTURED ignorado — remetente inesperado:', senderUrl);
        return;
      }

      const token = msg.token;
      if (!token) return;

      console.log('[NEXOS-BG] ✅ Token Instaleap capturado com sucesso');
      cleanup();

      sendResponse({ success: true, token: token });
    };

    chrome.runtime.onMessage.addListener(messageListener);

    // Timeout de 5 minutos (o usuário pode demorar para logar)
    timeoutId = setTimeout(() => {
      console.warn('[NEXOS-BG] ⏱ Timeout ao aguardar login Instaleap');
      cleanup();
      sendResponse({ success: false, error: 'Tempo esgotado. Tente novamente.' });
    }, 5 * 60 * 1000);

    // Abrir janela de login do Instaleap
    chrome.windows.create({
      url: 'https://control.instaleap.io/',
      type: 'popup',
      width: 500,
      height: 680,
      focused: true
    }, (win) => {
      if (chrome.runtime.lastError || !win) {
        console.error('[NEXOS-BG] ❌ Erro ao abrir janela Instaleap:', chrome.runtime.lastError);
        cleanup();
        sendResponse({ success: false, error: 'Não foi possível abrir a janela de login.' });
        return;
      }

      loginWindowId = win.id;
      console.log('[NEXOS-BG] 🪟 Janela Instaleap aberta — id:', loginWindowId);

      // Detectar se o usuário fecha a janela manualmente
      chrome.windows.onRemoved.addListener(function onWinRemoved(wid) {
        if (wid !== loginWindowId) return;
        chrome.windows.onRemoved.removeListener(onWinRemoved);
        if (loginWindowId !== null) {
          // Janela fechada antes do token ser capturado
          console.log('[NEXOS-BG] 🚪 Janela Instaleap fechada pelo usuário');
          loginWindowId = null;
          cleanup();
          sendResponse({ success: false, error: 'Login cancelado pelo usuário.' });
        }
      });
    });

    return true; // Manter canal de mensagem aberto para resposta assíncrona
  }

  // ─────────────────────────────────────────────────────────────────────────
  // INSTALEAP TOKEN REVOKED — detectado pelo content script (logout na página)
  // ─────────────────────────────────────────────────────────────────────────
  if (request.type === 'IL_TOKEN_REVOKED') {
    console.log('[NEXOS-BG] 🔓 Instaleap logout detectado — limpando token');
    chrome.storage.local.get(['nexos-secure-tokens'], (result) => {
      const tokens = result['nexos-secure-tokens'] || {};
      tokens['il-token'] = '';
      chrome.storage.local.set({ 'nexos-secure-tokens': tokens }, () => {
        console.log('[NEXOS-BG] ✅ Token Instaleap removido do storage');
      });
    });
    sendResponse({ success: true });
    return false;
  }
  // STORES DATA HANDLER (AI Assistant)
  // ═════════════════════════════════════════════════════════════════════════
  
  // GET stores.json data
  if (request.type === 'GET_STORES_DATA') {
    console.log('[NEXOS-BG] 📡 Solicitação para carregar stores.json...');
    
    (async () => {
      try {
        // Tentar carregar de storage primeiro
        const stored = await chrome.storage.local.get('nexos-stores-data');
        if (stored && stored['nexos-stores-data']) {
          console.log('[NEXOS-BG] ✅ Retornando dados do storage');
          sendResponse({
            success: true,
            data: stored['nexos-stores-data']
          });
          return;
        }
        
        // Se não tem no storage, carregar do arquivo
        const storesUrl = chrome.runtime.getURL('stores.json');
        const response = await fetch(storesUrl);
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        
        // Salvar no storage para próxima vez
        await chrome.storage.local.set({ 'nexos-stores-data': data });
        
        console.log('[NEXOS-BG] ✅ Dados carregados do stores.json:', data.stores.length - 1, 'lojas');
        sendResponse({
          success: true,
          data: data
        });
        
      } catch (error) {
        console.error('[NEXOS-BG] ❌ Erro ao carregar stores.json:', error);
        sendResponse({
          success: false,
          error: error.message
        });
      }
    })();
    
    return true; // Keep channel open for async response
  }
  
  // SAVE stores data
  if (request.type === 'SAVE_STORES_DATA') {
    console.log('[NEXOS-BG] 💾 Salvando dados de lojas...');
    
    try {
      // Salvar no chrome.storage.local
      chrome.storage.local.set({ 'nexos-stores-data': request.data }, () => {
        if (chrome.runtime.lastError) {
          console.error('[NEXOS-BG] ❌ Erro ao salvar stores:', chrome.runtime.lastError);
          sendResponse({
            success: false,
            error: chrome.runtime.lastError.message
          });
        } else {
          console.log('[NEXOS-BG] ✅ Stores salvos em storage.local');
          sendResponse({ success: true });
        }
      });
    } catch (error) {
      console.error('[NEXOS-BG] ❌ Erro ao processar save stores:', error);
      sendResponse({
        success: false,
        error: error.message
      });
    }
    
    return true;
  }
  
  // ═════════════════════════════════════════════════════════════════════════
  // AUTHENTICATION HANDLERS (LEGACY - AuthHelper)
  // ═════════════════════════════════════════════════════════════════════════
  
  if (request.action === 'startLogin') {
    (async () => {
      try {
        console.log('[NEXOS-BG] 🔐 Iniciando login via OAuthClient (service worker)...');

        const OAuthClientClass = (typeof OAuthClient !== 'undefined' ? OAuthClient : self.OAuthClient);
        if (!OAuthClientClass) {
          throw new Error('OAuthClient não disponível no service worker');
        }

        const oauthClient = new OAuthClientClass(NEXOS_AUTH_CONFIG);
        const { tokens, user } = await oauthClient.login();

        // Buscar foto de perfil via Graph API
        let photoUrl = null;
        try {
          const photoResp = await fetch('https://graph.microsoft.com/v1.0/me/photo/$value', {
            headers: { Authorization: `Bearer ${tokens.access_token}` }
          });
          if (photoResp.ok) {
            const blob = await photoResp.blob();
            photoUrl = await new Promise(resolve => {
              const reader = new FileReader();
              reader.onloadend = () => resolve(reader.result);
              reader.readAsDataURL(blob);
            });
          }
        } catch (_) { /* foto opcional */ }

        // Incluir accessToken no user para que NexosAuth.getToken() funcione nos content scripts
        const userWithPhoto = { ...user, photo: photoUrl, accessToken: tokens.access_token };

        // Salvar sessão no storage (popup e content scripts leem daqui)
        // ⚠️ NOTA: NÃO salvar 'nexos-tokens' aqui — essa chave é gerenciada pelo TokenManager
        //   que salva dados criptografados via crypto.subtle. Sobrescrever com objeto bruto
        //   faz o TokenManager detectar "cache corrompido" e fazer logout.
        // 'nexos-user-session' é lido pelo NexosAuth (picking + monitor) via storage.onChanged.
        const sessionForNexosAuth = { user: userWithPhoto, expiresAt: Date.now() + 24 * 60 * 60 * 1000 };
        await chrome.storage.local.set({
          'nexos_current_user': userWithPhoto,
          'nexos-user-session': sessionForNexosAuth
        });
        // Limpar flag de SP expirado (reconexão bem-sucedida)
        chrome.storage.local.remove(['nexos-sp-token-expired']);

        // Notificar todos os content scripts ativos
        try {
          const tabs = await chrome.tabs.query({});
          for (const tab of tabs) {
            chrome.tabs.sendMessage(tab.id, {
              action: 'onLoginSuccess',
              user: userWithPhoto,
              tokens
            }).catch(() => {});
          }
        } catch (_) {}

        console.log('[NEXOS-BG] ✅ Login concluído:', user.displayName || user.userPrincipalName);
        sendResponse({ success: true, user: userWithPhoto });

      } catch (error) {
        console.error('[NEXOS-BG] ❌ Login falhou:', error);
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true;
  }

  // CONTENT SCRIPT LOGIN (mantido para compatibilidade com fluxos legados)
  if (request.action === 'contentLogin') {
    (async () => {
      try {
        // Redirecionar para o novo fluxo centralizado no service worker
        console.log('[NEXOS-BG] contentLogin redirecionado para startLogin (service worker)');
        sendResponse({ success: true, message: 'Use startLogin para acionar o fluxo OAuth no service worker' });
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true;
  }
  
  if (request.action === 'logout') {
    (async () => {
      try {
        console.log('[NEXOS-BG] Starting logout...');
        
        // Enviar logout para content script
        try {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          
          if (tab) {
            chrome.tabs.sendMessage(tab.id, { action: 'contentLogout' }, (response) => {
              if (chrome.runtime.lastError) {
                console.error('[NEXOS-BG] Erro ao enviar logout:', chrome.runtime.lastError);
              }
            });
          }
        } catch (e) {
          console.warn('[NEXOS-BG] Falha ao delegar logout:', e);
        }
        
        // Limpar dados do usuário localmente (ambos os formatos de sessão)
        await chrome.storage.local.remove(['nexos_current_user', 'nexos-tokens', 'nexos-user-session']);
        console.log('[NEXOS-BG] ✅ Logout successful');
        
        sendResponse({ success: true });
        
      } catch (error) {
        console.error('[NEXOS-BG] ❌ Logout failed:', error);
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true;
  }

  // ⚠️ REMOVIDO: Handler duplicado de logout foi consolidado acima
  // O logout agora é delegado para content script e limpa storage localmente

  // ═════════════════════════════════════════════════════════════════════════
  // SP APP TOKEN — Client Credentials Flow (app-only, sem contexto de usuário)
  // O client_secret fica APENAS no service worker, nunca exposto ao DOM.
  // A página envia { type: 'SP_APP_TOKEN' } e recebe { token, expiresAt }.
  // ═════════════════════════════════════════════════════════════════════════
  if (request.type === 'SP_APP_TOKEN') {
    (async () => {
      try {
        const SP_CLIENT_ID     = '8f673d6e-b976-4d54-a83d-a8618973c963';
        const SP_TENANT_ID     = '1a53e6b6-7562-4b9f-83d0-e71a8891667e';
        const SP_CLIENT_SECRET = 'e038Q~9yUNcYxcwdb5RZnsLdJVTAnrSb2JrPtbx0';
        const SP_SCOPE         = 'https://graph.microsoft.com/.default';
        const CACHE_KEY        = 'nexos-sp-app-token-cache';

        // Verificar cache
        const stored = await chrome.storage.local.get(CACHE_KEY);
        const cached = stored[CACHE_KEY];
        if (cached && cached.expiresAt > Date.now() + 60000) {
          // Token ainda válido por mais de 1 minuto
          sendResponse({ success: true, token: cached.token, expiresAt: cached.expiresAt });
          return;
        }

        // Adquirir novo token via client credentials
        const params = new URLSearchParams({
          grant_type:    'client_credentials',
          client_id:     SP_CLIENT_ID,
          client_secret: SP_CLIENT_SECRET,
          scope:         SP_SCOPE,
        });

        const resp = await fetch(
          `https://login.microsoftonline.com/${SP_TENANT_ID}/oauth2/v2.0/token`,
          { method: 'POST', body: params }
        );

        if (!resp.ok) {
          const err = await resp.text().catch(() => '');
          throw new Error(`token endpoint ${resp.status}: ${err.slice(0, 200)}`);
        }

        const data = await resp.json();
        const expiresAt = Date.now() + (data.expires_in - 120) * 1000; // margem 2 min

        // Guardar no cache do service worker
        await chrome.storage.local.set({ [CACHE_KEY]: { token: data.access_token, expiresAt } });

        console.log('[NEXOS-BG] ✅ SP app token adquirido (client_credentials)');
        sendResponse({ success: true, token: data.access_token, expiresAt });
      } catch (e) {
        console.error('[NEXOS-BG] ❌ SP_APP_TOKEN falhou:', e.message);
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true; // canal assíncrono
  }

});

// ═════════════════════════════════════════════════════════════════════════
// FUNÇÕES AUXILIARES
// ═════════════════════════════════════════════════════════════════════════

async function canReloadForVersion(remoteVersion) {
  return !!remoteVersion;
}

function startBlinkingNotification(version, releaseNotes) {
  if (!chrome.notifications) return;
  const iconUrl = chrome.runtime.getURL('images/logo.png');
  const joinedNotes = Array.isArray(releaseNotes) ? releaseNotes.join('\n') : (typeof releaseNotes === 'string' ? releaseNotes : '');
  const trimmedNotes = joinedNotes && joinedNotes.length > 260 ? `${joinedNotes.slice(0, 257).trim()}…` : joinedNotes;
  const versionLine = version ? `\nUma nova versão v${version} está disponível.` : '';
  const detailsLine = trimmedNotes ? `\n${trimmedNotes}` : '';
  const baseMessage = `Nova atualização disponível!${versionLine}${detailsLine}`;

  chrome.notifications.clear(UPDATE_NOTIFICATION_ID, () => {
    if (chrome.runtime.lastError) {
      console.warn('[NEXOS][AutoUpdate] Erro ao limpar notificação anterior:', chrome.runtime.lastError);
    }
  });

  chrome.notifications.create(UPDATE_NOTIFICATION_ID, {
    type: 'basic',
    iconUrl,
    title: 'Nexos',
    message: baseMessage,
    requireInteraction: true
  }, () => {
    if (chrome.runtime.lastError) {
      console.warn('[NEXOS][AutoUpdate] Erro ao exibir notificação de atualização:', chrome.runtime.lastError);
    }
  });

  if (updateNotificationBlinkInterval) {
    clearInterval(updateNotificationBlinkInterval);
  }
  updateNotificationBlinkState = false;
  updateNotificationBlinkInterval = setInterval(() => {
    updateNotificationBlinkState = !updateNotificationBlinkState;
    const blinkMessage = (updateNotificationBlinkState ? '⚠️ ' : '') + baseMessage;
    chrome.notifications.update(UPDATE_NOTIFICATION_ID, { message: blinkMessage }, () => {
      if (chrome.runtime.lastError) {
        console.warn('[NEXOS][AutoUpdate] Erro ao atualizar notificação piscante:', chrome.runtime.lastError);
      }
    });
  }, 800);
}

function stopBlinkingNotification() {
  if (updateNotificationBlinkInterval) {
    clearInterval(updateNotificationBlinkInterval);
    updateNotificationBlinkInterval = null;
    updateNotificationBlinkState = false;
  }
  if (chrome.notifications) {
    chrome.notifications.clear(UPDATE_NOTIFICATION_ID, () => {
      if (chrome.runtime.lastError) {
        console.warn('[NEXOS][AutoUpdate] Erro ao limpar notificação de atualização:', chrome.runtime.lastError);
      }
    });
  }
}

function broadcastUpdatePrompt(version, releaseNotes, opts) {
  const autoReloadAt = (opts && opts.autoReloadAt) ? opts.autoReloadAt : null;
  if (!chrome.tabs || !chrome.tabs.query) return;
  chrome.tabs.query({}, tabs => {
    if (chrome.runtime.lastError) {
      console.warn('[NEXOS][AutoUpdate] Erro ao consultar abas para broadcast:', chrome.runtime.lastError);
      return;
    }
    tabs.forEach(tab => {
      if (!tab || typeof tab.id !== 'number') return;
      if (tab.url && tab.url.startsWith('chrome://')) return;
      try {
        chrome.tabs.sendMessage(tab.id, { action: 'showUpdatePrompt', version, releaseNotes, autoReloadAt }, () => {
          const err = chrome.runtime.lastError;
          if (err && !/Receiving end does not exist/i.test(err.message || '') && !/message port closed/i.test(err.message || '')) {
            console.warn('[NEXOS][AutoUpdate] Erro ao enviar prompt de atualização para aba:', tab.id, err);
          }
        });
      } catch (errSend) {
        console.warn('[NEXOS][AutoUpdate] Exceção ao enviar prompt para aba:', tab.id, errSend);
      }
    });
  });
}

function broadcastClearUpdatePrompt() {
  if (!chrome.tabs || !chrome.tabs.query) return;
  chrome.tabs.query({}, tabs => {
    if (chrome.runtime.lastError) {
      console.warn('[NEXOS][AutoUpdate] Erro ao consultar abas para limpar prompt:', chrome.runtime.lastError);
      return;
    }
    tabs.forEach(tab => {
      if (!tab || typeof tab.id !== 'number') return;
      if (tab.url && tab.url.startsWith('chrome://')) return;
      try {
        chrome.tabs.sendMessage(tab.id, { action: 'clearUpdatePrompt' }, () => {
          const err = chrome.runtime.lastError;
          if (err && !/Receiving end does not exist/i.test(err.message || '') && !/message port closed/i.test(err.message || '')) {
            console.warn('[NEXOS][AutoUpdate] Erro ao limpar prompt na aba:', tab.id, err);
          }
        });
      } catch (errSend) {
        console.warn('[NEXOS][AutoUpdate] Exceção ao limpar prompt na aba:', tab.id, errSend);
      }
    });
  });
}

async function clearUpdateState() {
  pendingRemoteVersion = null;
  pendingReleaseNotes = null;
  stopBlinkingNotification();
  let skipBannerClear = false;
  if (chrome.storage && chrome.storage.local) {
    try {
      // PHASE 3: Usar bgStorageGet()
      const snapshot = await bgStorageGet([POST_UPDATE_KEY]);
      const storedPostUpdate = snapshot && snapshot[POST_UPDATE_KEY];
      if (storedPostUpdate && storedPostUpdate.version && storedPostUpdate.acknowledged === false) {
        skipBannerClear = true;
      }
    } catch (snapshotErr) {
      console.warn('[NEXOS][AutoUpdate] Falha ao inspecionar estado pós-atualização antes de limpar prompt:', snapshotErr);
    }
  }

  if (!skipBannerClear) {
    broadcastClearUpdatePrompt();
  }

  if (chrome.storage && chrome.storage.local) {
    try {
      // PHASE 3: Usar bgStorageRemove()
      await bgStorageRemove([PENDING_UPDATE_KEY, PENDING_NOTES_KEY, RELOAD_STATE_KEY, RELOAD_STATE_TS_KEY]);
    } catch (e) {
      console.warn('[NEXOS][AutoUpdate] Falha ao limpar estado de atualização:', e);
    }
  }
}

/**
 * Compara versões no formato semântico (X.Y.Z)
 * @returns {number} -1 se v1 < v2, 0 se iguais, 1 se v1 > v2
 */
function compareVersions(v1, v2) {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  
  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const p1 = parts1[i] || 0;
    const p2 = parts2[i] || 0;
    if (p1 < p2) return -1;
    if (p1 > p2) return 1;
  }
  return 0;
}

async function checkForUpdates() {
  const localVersion = chrome.runtime.getManifest().version;

  // ── Extensões unpacked (installType === 'development') também devem verificar
  // atualizações — o PowerShell updater substitui os arquivos locais e background.js
  // dispara o reload. Não pulamos mais o check em modo desenvolvedor.
  
  try {
    // Tentar latest.json primeiro (contém url + notes inline).
    // Fallback para manifest.json (compatibilidade com versões anteriores).
    let remoteManifest = null;
    for (const url of [LATEST_JSON_URL, REMOTE_MANIFEST_URL]) {
      try {
        const resp = await fetch(url, { cache: 'no-store' });
        if (resp.ok) { remoteManifest = await resp.json(); break; }
        console.warn('[NEXOS][AutoUpdate] Fonte não disponível:', url, resp.status);
      } catch (fetchErr) {
        console.warn('[NEXOS][AutoUpdate] Falha ao buscar:', url, fetchErr.message);
      }
    }

    if (!remoteManifest) { return; }

    const remoteVersion = remoteManifest.version;
    if (!remoteVersion) {
      console.warn('[NEXOS][AutoUpdate] Manifest remoto sem campo version.');
      return;
    }

    // Comparar versões: só notificar se remota for MAIOR
    const versionComparison = compareVersions(remoteVersion, localVersion);
    
    console.log(`[NEXOS][AutoUpdate] 🔍 Comparação de versões:`);
    console.log(`[NEXOS][AutoUpdate]   Local: ${localVersion}`);
    console.log(`[NEXOS][AutoUpdate]   Remota: ${remoteVersion}`);
    console.log(`[NEXOS][AutoUpdate]   Resultado: ${versionComparison} (${versionComparison > 0 ? 'REMOTA MAIOR' : versionComparison === 0 ? 'IGUAIS' : 'LOCAL MAIOR'})`);
    
    if (versionComparison > 0) {
      // Versão remota é MAIOR que a local
      console.log(`[NEXOS][AutoUpdate] ⬆️ Nova versão detectada: local=${localVersion} remoto=${remoteVersion}`);
      
      if (logManager) {
        await logManager.log('INFO', 'Background', 'update_available', 
          `Nova versão disponível: ${remoteVersion}`, 
          { local: localVersion, remote: remoteVersion }
        );
      }

      // Notas: preferir inline no latest.json, senão buscar update_notes.json
      const inlineNotes = Array.isArray(remoteManifest.notes) ? remoteManifest.notes : null;
      const releaseNotes = inlineNotes || (await loadUpdateNotes(remoteVersion));

      const allowReload = await canReloadForVersion(remoteVersion);
      if (!allowReload) { return; }

      // Registrar timestamp da primeira detecção (para calcular autoReloadAt)
      if (!_updateDetectedAt) {
        _updateDetectedAt = Date.now();
        console.log('[NEXOS][AutoUpdate] ⏱ Countdown de auto-reload iniciado (', UPDATER_WAIT_MS / 60000, 'min)');
      }

      // autoReloadAt: quando o PowerShell já deve ter atualizado os arquivos
      const autoReloadAt = _updateDetectedAt + UPDATER_WAIT_MS;

      pendingRemoteVersion = remoteVersion;
      pendingReleaseNotes = releaseNotes;
      try {
        if (chrome.storage && chrome.storage.local) {
          await bgStorageSet({ [PENDING_UPDATE_KEY]: remoteVersion, [PENDING_NOTES_KEY]: releaseNotes });
        }
      } catch (e) {
        console.warn('[NEXOS][AutoUpdate] Falha ao registrar versão pendente:', e);
      }

      startBlinkingNotification(remoteVersion, releaseNotes);
      broadcastUpdatePrompt(remoteVersion, releaseNotes, { autoReloadAt });

      // Auto-reload silencioso quando o countdown expira
      // (background.js verifica a cada UPDATE_INTERVAL_MINUTES — quando essa condição
      //  for verdadeira, os arquivos já foram substituídos pelo PowerShell updater)
      if (Date.now() >= autoReloadAt) {
        console.log('[NEXOS][AutoUpdate] ⏱ Auto-reload disparado após espera do updater.');
        let versionForPost = remoteVersion;
        let notesForPost   = releaseNotes;
        try {
          await bgStorageSet({
            [POST_UPDATE_KEY]: { version: versionForPost, notes: notesForPost || null, ts: Date.now(), acknowledged: false }
          });
          await bgStorageRemove([PENDING_UPDATE_KEY, PENDING_NOTES_KEY]);
        } catch (_) {}
        broadcastClearUpdatePrompt();
        _updateDetectedAt = null;
        setTimeout(() => { try { chrome.runtime.reload(); } catch (_) {} }, 800);
        return;
      }

    } else if (versionComparison === 0) {
      console.log('[NEXOS][AutoUpdate] ✅ Versão atual já está atualizada.');
      _updateDetectedAt = null;
      await clearUpdateState();
    } else {
      console.log(`[NEXOS][AutoUpdate] ℹ️ Versão local (${localVersion}) > remota (${remoteVersion}) — dev/teste.`);
      _updateDetectedAt = null;
      await clearUpdateState();
    }
  } catch (error) {
    console.warn('[NEXOS][AutoUpdate] Não foi possível verificar atualização (fetch/CORS?):', error);
  }
}

function scheduleUpdateAlarm() {
  if (!chrome.alarms || !chrome.alarms.create) {
    console.warn('[NEXOS][AutoUpdate] API chrome.alarms indisponível. Verifique permissões.');
    return;
  }
  try {
    chrome.alarms.create(UPDATE_ALARM_NAME, { periodInMinutes: UPDATE_INTERVAL_MINUTES });
  } catch (e) {
    console.warn('[NEXOS][AutoUpdate] Não foi possível agendar alarme:', e);
  }
}

chrome.runtime.onInstalled.addListener(() => {
  scheduleUpdateAlarm();
  chrome.alarms.create(SW_KEEPALIVE_ALARM, { periodInMinutes: SW_KEEPALIVE_INTERVAL_MINUTES });
  checkForUpdates();
});

if (chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(() => {
    scheduleUpdateAlarm();
    chrome.alarms.create(SW_KEEPALIVE_ALARM, { periodInMinutes: SW_KEEPALIVE_INTERVAL_MINUTES });
    checkForUpdates();
  });
}

if (chrome.alarms && chrome.alarms.onAlarm) {
  chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm && alarm.name === UPDATE_ALARM_NAME) {
      checkForUpdates();
    }
    // 🆕 V3.0: Auto-refresh de tokens
    if (alarm && alarm.name === 'token-refresh') {
      checkAndRefreshTokens();
    }
    // Keepalive: acorda o SW periodicamente para evitar suspensão durante polling do monitor
    if (alarm && alarm.name === SW_KEEPALIVE_ALARM) {
      // No-op intencional — o simples fato de acordar o SW já resolve o status 0
    }
  });
}

scheduleUpdateAlarm();
// Registrar keepalive imediatamente (para quando o SW é carregado pela primeira vez sem onInstalled)
try { chrome.alarms.create(SW_KEEPALIVE_ALARM, { periodInMinutes: SW_KEEPALIVE_INTERVAL_MINUTES }); } catch (_) {}
checkForUpdates();

// ═══════════════════════════════════════════════════════════════════════════
// 🆕 V3.0: AUTO-REFRESH DE TOKENS
// Verifica e renova tokens próximos de expirar a cada 5 minutos
// ═══════════════════════════════════════════════════════════════════════════

const TOKEN_REFRESH_ALARM_NAME = 'token-refresh';
const TOKEN_REFRESH_INTERVAL_MINUTES = 5;

/**
 * Verifica e renova tokens próximos de expirar
 */
async function checkAndRefreshTokens() {
  try {
    console.log('[NEXOS][TokenRefresh] 🔄 Verificando tokens...');
    
    // Buscar sessão atual do storage
    const result = await chrome.storage.local.get(['nexos-user-session']);
    if (!result || !result['nexos-user-session']) {
      console.log('[NEXOS][TokenRefresh] ℹ️ Nenhuma sessão encontrada');
      return;
    }
    
    const session = result['nexos-user-session'];
    const now = Date.now();
    const expiresAt = session.expiresAt;
    
    if (!expiresAt) {
      console.log('[NEXOS][TokenRefresh] ⚠️ Sessão sem expiresAt');
      return;
    }
    
    const timeRemaining = expiresAt - now;
    const minutesRemaining = Math.floor(timeRemaining / 60000);
    
    console.log(`[NEXOS][TokenRefresh] ⏱️ Token expira em ${minutesRemaining} minutos`);
    
    // Se falta menos de 10 minutos, renovar
    if (timeRemaining < 10 * 60 * 1000 && timeRemaining > 0) {
      console.log('[NEXOS][TokenRefresh] 🔄 Token próximo de expirar, enviando mensagem para content scripts...');
      
      // Enviar mensagem para todos os content scripts renovarem o token
      const tabs = await chrome.tabs.query({});
      for (const tab of tabs) {
        if (tab.id && tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
          try {
            await chrome.tabs.sendMessage(tab.id, {
              type: 'REFRESH_TOKEN',
              reason: 'Token próximo de expirar'
            });
          } catch (err) {
            // Ignorar erros (tab pode não ter content script)
          }
        }
      }
      
      console.log('[NEXOS][TokenRefresh] ✅ Mensagens enviadas para content scripts');
    } else if (timeRemaining <= 0) {
      console.log('[NEXOS][TokenRefresh] ⚠️ Token expirado! Usuário precisará fazer login novamente');
    }
    
  } catch (error) {
    console.error('[NEXOS][TokenRefresh] ❌ Erro ao verificar tokens:', error);
  }
}

/**
 * Agenda alarme de refresh de tokens
 */
function scheduleTokenRefreshAlarm() {
  if (!chrome.alarms || !chrome.alarms.create) {
    console.warn('[NEXOS][TokenRefresh] API chrome.alarms indisponível');
    return;
  }
  try {
    chrome.alarms.create(TOKEN_REFRESH_ALARM_NAME, { periodInMinutes: TOKEN_REFRESH_INTERVAL_MINUTES });
    console.log(`[NEXOS][TokenRefresh] ✅ Alarme agendado (${TOKEN_REFRESH_INTERVAL_MINUTES} min)`);
  } catch (e) {
    console.warn('[NEXOS][TokenRefresh] Não foi possível agendar alarme:', e);
  }
}

// Inicializar refresh de tokens
chrome.runtime.onInstalled.addListener(() => {
  scheduleTokenRefreshAlarm();
});

if (chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(() => {
    scheduleTokenRefreshAlarm();
  });
}

scheduleTokenRefreshAlarm();

// ─── Detectar fechamento de aba de plataforma (Uber/Lalamove/99) ──────────────
// Quando o usuário fecha a aba antes de confirmar o pedido, emite 'tab_closed'
// para que o overlay de Picking possa atualizar o job correspondente.
chrome.tabs.onRemoved.addListener((tabId) => {
  if (!_nexosPlatformTabIds.has(tabId)) return;
  _nexosPlatformTabIds.delete(tabId);
  try {
    const key = 'nexos_platform_events';
    chrome.storage.local.get([key], (result) => {
      try {
        const existing = Array.isArray(result[key]) ? result[key].slice(-50) : [];
        existing.push({ type: 'tab_closed', tabId, ts: Date.now() });
        chrome.storage.local.set({ [key]: existing });
      } catch (e) {}
    });
  } catch (e) {}
});
