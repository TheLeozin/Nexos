/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - SHAREPOINT CONFIGURATION
 * Configuração centralizada de caminhos e URLs do SharePoint
 * ═══════════════════════════════════════════════════════════════════════════
 */

const SHAREPOINT_CONFIG = {
  // ═══════════════════════════════════════════════════════════════════════════
  // URLS BASE
  // ═══════════════════════════════════════════════════════════════════════════
  
  // URL principal do site SharePoint (para Graph API)
  siteUrl: 'https://gpabr.sharepoint.com/sites/Nexos',
  
  // URL com MCAS (Microsoft Cloud App Security) - usada para acesso direto browser
  // MCAS fornece segurança adicional e monitoramento de atividades
  // Use esta URL para testes manuais no navegador
  siteUrlMCAS: 'https://gpabr.sharepoint.com.mcas.ms/sites/Nexos?McasTsid=20892&McasCtx=4',
  
  // Graph API endpoint
  graphApiUrl: 'https://graph.microsoft.com/v1.0',
  
  // ═══════════════════════════════════════════════════════════════════════════
  // AZURE AD / OAUTH
  // ═══════════════════════════════════════════════════════════════════════════
  
  auth: {
    // ═══════════════════════════════════════════════════════════════════════════
    // DELEGATED AUTHENTICATION (On behalf of user)
    // Usado quando usuário está logado - para ações interativas
    // ═══════════════════════════════════════════════════════════════════════════
    
    // App Registration configurado no Azure AD com Redirect URIs corretos
    clientId: '8f673d6e-b976-4d54-a83d-a8618973c963', 
    tenantId: '1a53e6b6-7562-4b9f-83d0-e71a8891667e',
    // redirectUri com Extension ID FIXO (mesmo em todas as máquinas - modo unpacked)
    // Gerado via manifest.json "key" (chave pública do .pem)
    redirectUri: 'https://obodcljemkajclohcfjhmommhfpklojo.chromiumapp.org/',
    
    scopes: [
      'User.Read',           // Apenas leitura do perfil (não precisa aprovação)
      'offline_access'       // Refresh token (não precisa aprovação)
    ],
    
    // Scopes completos para produção (requerem aprovação admin):
    // 'Sites.Selected', 'Files.ReadWrite.All'
    
    authority: 'https://login.microsoftonline.com',
    
    // ═══════════════════════════════════════════════════════════════════════════
    // APPLICATION AUTHENTICATION (App-only, no user context)
    // Usado para background tasks que rodam 24/7 sem usuário logado
    // ═══════════════════════════════════════════════════════════════════════════
    
    app: {
      // Mesmos IDs do Azure AD App Registration
      clientId: '8f673d6e-b976-4d54-a83d-a8618973c963',
      tenantId: '1a53e6b6-7562-4b9f-83d0-e71a8891667e',
      
      // 🔐 CLIENT SECRET - Criado em Azure Portal → Certificates & secrets
      // ⚠️ NUNCA commitar este valor em repositórios públicos
      // ⚠️ Este secret NÃO é mais usado diretamente (Azure Function o usa)
      // Expires: 11/19/2027 (24 meses)
      clientSecret: 'e038Q~9yUNcYxcwdb5RZnsLdJVTAnrSb2JrPtbx0',
      
      // Authority para app-only auth (tenant-specific, não /common)
      authority: 'https://login.microsoftonline.com/1a53e6b6-7562-4b9f-83d0-e71a8891667e',
      
      // Token endpoint para Client Credentials Flow (Azure Function usa isto)
      tokenEndpoint: 'https://login.microsoftonline.com/1a53e6b6-7562-4b9f-83d0-e71a8891667e/oauth2/v2.0/token',
      
      // Scopes para Application Permissions (formato .default)
      scope: 'https://graph.microsoft.com/.default',
      
      // ═══════════════════════════════════════════════════════════════════════
      // AZURE FUNCTION PROXY (para obter tokens sem expor Client Secret)
      // ═══════════════════════════════════════════════════════════════════════
      
      // URL da Azure Function que atua como proxy
      // Desenvolvimento local: http://localhost:7071/api/token
      // Produção: https://nexos-torre-proxy.azurewebsites.net/api/token
      azureFunctionUrl: 'http://localhost:7071/api/token',
      
      // Permissões configuradas no Azure AD (Application, não Delegated):
      // - Sites.Selected (Microsoft Graph)
      // - Sites.Selected (SharePoint)
      permissions: [
        'Sites.Selected'
      ]
    }
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // SHAREPOINT LISTS
  // ═══════════════════════════════════════════════════════════════════════════
  
  lists: {
    statusPedidos: {
      name: 'Nexos_StatusPedidos',
      displayName: 'Nexos - Status dos Pedidos',
      description: 'Controle central de status de pedidos para múltiplos usuários',
      fields: [
        'PedidoID',
        'Loja',
        'NumeroPedido',
        'Status',
        'Plataforma',
        'OrderUUID',
        'ValorSolicitacao',
        'NomeCliente',
        'EnderecoCompleto',
        'TelefoneCliente',
        'TrackingLink',
        'Usuario',
        'DataCriacao',
        'DataAtualizacao',
        'Bloqueado',
        'BloqueadoPor',
        'Observacoes'
      ]
    },
    
    notificacoes: {
      name: 'Nexos_Notificacoes',
      displayName: 'Nexos - Notificações',
      description: 'Hub central de notificações para todos os usuários',
      fields: [
        'NotificacaoID',
        'Tipo',
        'Mensagem',
        'UsuarioDestino',
        'Lida',
        'DataCriacao',
        'DataLeitura',
        'Dados'
      ]
    },
    
    auditLog: {
      name: 'Nexos_AuditLog',
      displayName: 'Nexos - Log de Auditoria',
      description: 'Registro completo de ações dos usuários',
      fields: [
        'Acao',
        'Usuario',
        'Detalhes',
        'Timestamp',
        'IPAddress',
        'UserAgent',
        'Resultado'
      ]
    },
    
    logs: {
      name: 'Nexos_Logs',
      displayName: 'Nexos - Logs Gerais',
      description: 'Logs gerais da aplicação (substitui Google Sheets)',
      fields: [
        'TipoLog',
        'Mensagem',
        'Dados',
        'Usuario',
        'Timestamp'
      ]
    },
    
    configuracoes: {
      name: 'Nexos_Configuracoes',
      displayName: 'Nexos - Configurações',
      description: 'Configurações dinâmicas da aplicação',
      fields: [
        'Chave',
        'Valor',
        'Tipo',
        'Descricao',
        'DataAtualizacao',
        'AtualizadoPor'
      ]
    },
    
    // ═══════════════════════════════════════════════════════════════════════════
    // NOVA LISTA: PEDIDOS CONCLUÍDOS (Para Dashboard Financeiro)
    // ═══════════════════════════════════════════════════════════════════════════
    
    pedidosConcluidos: {
      name: 'Nexos_PedidosConcluidos',
      displayName: 'Nexos - Pedidos Concluídos',
      description: 'Histórico completo de pedidos concluídos para análise financeira e relatórios',
      
      fields: [
        // ═══════════════════════════════════════════════════════════════
        // IDENTIFICAÇÃO
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'PedidoID',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'ID único do pedido (formato: #PLATAFORMA-NUMERO)',
          example: '#UBER-12345'
        },
        {
          name: 'OrderUUID',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'UUID original da plataforma (se disponível)',
          example: 'abc123-def456-ghi789'
        },
        {
          name: 'NumeroPedido',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Número do pedido interno da loja',
          example: '54321'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // PLATAFORMA E LOJA
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'Plataforma',
          type: 'Choice',
          required: true,
          indexed: true,
          choices: ['Uber', '99app', 'Lalamove', 'Picking', 'Orkestra'],
          description: 'Plataforma de entrega utilizada'
        },
        {
          name: 'Loja',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Nome da loja que solicitou a entrega',
          example: 'Torre 1'
        },
        {
          name: 'CodigoLoja',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Código único da loja (de stores.json)',
          example: 'torre1'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // FINANCEIRO (CRÍTICO PARA DASHBOARD)
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'CustoEntrega',
          type: 'Currency',
          required: true,
          indexed: true,
          description: 'Custo total da entrega (cobrado pela plataforma)',
          example: 125.50,
          note: '⚠️ CAMPO CRÍTICO - Necessário para análises financeiras'
        },
        {
          name: 'ValorPedido',
          type: 'Currency',
          required: false,
          indexed: false,
          description: 'Valor total do pedido (produtos + entrega)',
          example: 250.00
        },
        {
          name: 'TaxaServico',
          type: 'Currency',
          required: false,
          indexed: false,
          description: 'Taxa de serviço da plataforma (se aplicável)',
          example: 12.50
        },
        {
          name: 'Desconto',
          type: 'Currency',
          required: false,
          indexed: false,
          description: 'Desconto aplicado ao custo de entrega',
          example: 10.00
        },
        {
          name: 'CustoFinal',
          type: 'Calculated',
          formula: '=[CustoEntrega]+[TaxaServico]-[Desconto]',
          returnType: 'Currency',
          description: 'Custo final calculado (CustoEntrega + TaxaServico - Desconto)'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // DATAS E TIMESTAMPS
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'DataSolicitacao',
          type: 'DateTime',
          required: true,
          indexed: true,
          format: 'DateOnly',
          description: 'Data em que a entrega foi solicitada',
          example: '2025-11-27'
        },
        {
          name: 'HoraSolicitacao',
          type: 'DateTime',
          required: true,
          indexed: true,
          format: 'TimeOnly',
          description: 'Hora em que a entrega foi solicitada',
          example: '14:30:00'
        },
        {
          name: 'DataConclusao',
          type: 'DateTime',
          required: true,
          indexed: true,
          format: 'DateOnly',
          description: 'Data em que a entrega foi concluída',
          example: '2025-11-27'
        },
        {
          name: 'HoraConclusao',
          type: 'DateTime',
          required: true,
          indexed: true,
          format: 'TimeOnly',
          description: 'Hora em que a entrega foi concluída',
          example: '15:45:00'
        },
        {
          name: 'TempoConclusao',
          type: 'Number',
          required: false,
          indexed: false,
          description: 'Tempo total de conclusão em minutos',
          example: 75
        },
        
        // ═══════════════════════════════════════════════════════════════
        // OPERADOR E RESPONSÁVEL
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'OperadorEmail',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Email do operador que solicitou a entrega',
          example: 'leonardo.miguel@gpabr.com'
        },
        {
          name: 'OperadorNome',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Nome completo do operador',
          example: 'Leonardo Miguel da Silva Araujo'
        },
        {
          name: 'OperadorCargo',
          type: 'Choice',
          required: false,
          indexed: true,
          choices: ['Admin', 'Gerente', 'Coordenador', 'Operador'],
          description: 'Cargo do operador'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // STATUS E FLUXO
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'StatusFinal',
          type: 'Choice',
          required: true,
          indexed: true,
          choices: ['Concluído', 'Cancelado', 'Falhou'],
          default: 'Concluído',
          description: 'Status final do pedido'
        },
        {
          name: 'StatusPicking',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Status do picking capturado no momento da extração (texto exato da tela)',
          example: 'Aguardando Transporte',
          note: '⚠️ IMPORTANTE - Captura o valor exato da UI do picking sem validação'
        },
        {
          name: 'MotivoCancelamento',
          type: 'Text',
          required: false,
          indexed: false,
          description: 'Motivo do cancelamento (se StatusFinal = Cancelado)'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // RASTREAMENTO E LINKS
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'TrackingLink',
          type: 'Hyperlink',
          required: false,
          indexed: false,
          description: 'Link de rastreamento da entrega',
          example: 'https://uber.com/track/abc123'
        },
        {
          name: 'ComprovanteFoto',
          type: 'Hyperlink',
          required: false,
          indexed: false,
          description: 'Link para foto do comprovante de entrega'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // CLIENTE (OPCIONAL)
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'NomeCliente',
          type: 'Text',
          required: false,
          indexed: false,
          description: 'Nome do cliente destinatário'
        },
        {
          name: 'EnderecoCompleto',
          type: 'Note',
          required: false,
          indexed: false,
          description: 'Endereço completo de entrega'
        },
        {
          name: 'Bairro',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Bairro do endereço de entrega'
        },
        {
          name: 'Cidade',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Cidade do endereço de entrega'
        },
        {
          name: 'DistanciaKm',
          type: 'Number',
          required: false,
          indexed: false,
          description: 'Distância percorrida em KM',
          example: 5.2
        },
        
        // ═══════════════════════════════════════════════════════════════
        // ENTREGADOR
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'NomeEntregador',
          type: 'Text',
          required: false,
          indexed: false,
          description: 'Nome do entregador (se disponível)'
        },
        {
          name: 'VeiculoTipo',
          type: 'Choice',
          required: false,
          indexed: true,
          choices: ['Moto', 'Carro', 'Bicicleta', 'Caminhão', 'A pé'],
          description: 'Tipo de veículo usado na entrega'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // OBSERVAÇÕES E METADADOS
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'Observacoes',
          type: 'Note',
          required: false,
          indexed: false,
          description: 'Observações gerais sobre o pedido'
        },
        {
          name: 'Tags',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Tags separadas por vírgula para categorização',
          example: 'urgente,vip,primeiro_pedido'
        },
        {
          name: 'AvaliacaoCliente',
          type: 'Number',
          required: false,
          indexed: true,
          description: 'Avaliação do cliente (1-5 estrelas)'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // AUDITORIA
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'CriadoPor',
          type: 'User',
          required: false,
          indexed: false,
          description: 'Usuário que criou o registro'
        },
        {
          name: 'DataCriacao',
          type: 'DateTime',
          required: true,
          indexed: true,
          default: 'Now',
          description: 'Data/hora de criação do registro no SharePoint'
        },
        {
          name: 'ModificadoPor',
          type: 'User',
          required: false,
          indexed: false,
          description: 'Último usuário que modificou o registro'
        },
        {
          name: 'DataModificacao',
          type: 'DateTime',
          required: true,
          indexed: true,
          default: 'Now',
          description: 'Data/hora da última modificação'
        }
      ],
      
      // Índices para performance de queries
      indexes: [
        { columns: ['Plataforma', 'DataSolicitacao'], name: 'IX_Platform_Date' },
        { columns: ['Loja', 'DataSolicitacao'], name: 'IX_Store_Date' },
        { columns: ['OperadorEmail', 'DataSolicitacao'], name: 'IX_Operator_Date' },
        { columns: ['StatusFinal', 'DataConclusao'], name: 'IX_Status_Date' },
        { columns: ['CustoEntrega'], name: 'IX_Cost' }
      ],
      
      // Views padrão para facilitar queries
      views: [
        {
          name: 'Todos_Concluidos',
          query: "StatusFinal eq 'Concluído'",
          orderBy: 'DataConclusao desc',
          fields: ['PedidoID', 'Plataforma', 'Loja', 'CustoEntrega', 'DataConclusao', 'OperadorNome']
        },
        {
          name: 'Ultimos_30_Dias',
          query: "DataConclusao ge datetime'{lastMonth}'",
          orderBy: 'DataConclusao desc',
          fields: ['PedidoID', 'Plataforma', 'Loja', 'CustoEntrega', 'DataConclusao']
        },
        {
          name: 'Por_Plataforma',
          query: null,
          orderBy: 'Plataforma, DataConclusao desc',
          fields: ['Plataforma', 'PedidoID', 'Loja', 'CustoEntrega', 'DataConclusao'],
          groupBy: 'Plataforma'
        },
        {
          name: 'Por_Loja',
          query: null,
          orderBy: 'Loja, DataConclusao desc',
          fields: ['Loja', 'PedidoID', 'Plataforma', 'CustoEntrega', 'DataConclusao'],
          groupBy: 'Loja'
        },
        {
          name: 'Custos_Altos',
          query: 'CustoEntrega ge 100',
          orderBy: 'CustoEntrega desc',
          fields: ['PedidoID', 'Plataforma', 'Loja', 'CustoEntrega', 'DataConclusao', 'OperadorNome']
        }
      ]
    },
    
    // ═══════════════════════════════════════════════════════════════════════════
    // NOVA LISTA: PEDIDOS EXTRAÍDOS DO PICKING COM TRAVAMENTO
    // ═══════════════════════════════════════════════════════════════════════════
    
    pedidosExtraidos: {
      name: 'Nexos_PedidosExtraidos',
      displayName: 'Nexos - Pedidos Extraídos (Picking)',
      description: 'Pedidos extraídos do sistema de Picking com sistema de travamento para evitar duplicação',
      
      fields: [
        // ═══════════════════════════════════════════════════════════════
        // IDENTIFICAÇÃO ÚNICA
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'PedidoID',
          type: 'Text',
          required: true,
          indexed: true,
          unique: true,
          description: 'ID único do pedido (formato: PICKING-NUMERO)',
          example: 'PICKING-54321'
        },
        {
          name: 'NumeroPedido',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Número do pedido no sistema de picking',
          example: '54321'
        },
        {
          name: 'OrderUUID',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'UUID do pedido (se disponível)',
          example: 'abc-123-def-456'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // SISTEMA DE TRAVAMENTO (CRITICAL)
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'Bloqueado',
          type: 'Boolean',
          required: true,
          indexed: true,
          default: false,
          description: '⚠️ CRÍTICO - Indica se o pedido está bloqueado para edição'
        },
        {
          name: 'BloqueadoPor',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Email do usuário que bloqueou o pedido',
          example: 'leonardo.miguel@gpabr.com'
        },
        {
          name: 'BloqueadoEm',
          type: 'DateTime',
          required: false,
          indexed: true,
          description: 'Data/hora do bloqueio'
        },
        {
          name: 'TokenBloqueio',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Token único para validar bloqueio e liberar',
          example: 'uuid-v4-random-token'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // DADOS DO CLIENTE
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'NomeCliente',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Nome completo do cliente'
        },
        {
          name: 'TelefoneCliente',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Telefone do cliente (formato capturado)'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // ENDEREÇO COMPLETO
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'Endereco',
          type: 'Text',
          required: true,
          indexed: false,
          description: 'Logradouro (rua/avenida)'
        },
        {
          name: 'Numero',
          type: 'Text',
          required: true,
          indexed: false,
          description: 'Número do endereço'
        },
        {
          name: 'Complemento',
          type: 'Text',
          required: false,
          indexed: false,
          description: 'Complemento do endereço (apto, bloco, etc)'
        },
        {
          name: 'Bairro',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Bairro'
        },
        {
          name: 'Cidade',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Cidade'
        },
        {
          name: 'UF',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Estado (UF)'
        },
        {
          name: 'EnderecoCompleto',
          type: 'Note',
          required: false,
          indexed: false,
          description: 'Endereço formatado completo (gerado)'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // VALORES
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'ValorPedido',
          type: 'Currency',
          required: false,
          indexed: true,
          description: 'Valor total do pedido'
        },
        {
          name: 'ValorEntrega',
          type: 'Currency',
          required: false,
          indexed: true,
          description: 'Valor da entrega (se separado)'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // STATUS E PLATAFORMA
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'StatusPicking',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Status capturado do sistema de picking',
          example: 'Aguardando Transporte'
        },
        {
          name: 'Bandeira',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Bandeira/canal do pedido (Rappi, Uber, etc)'
        },
        {
          name: 'Formato',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Formato do pedido (se disponível)'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // LOJA
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'Loja',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Nome da loja',
          example: 'Torre 1'
        },
        {
          name: 'CodigoLoja',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Código da loja (de stores.json)',
          example: 'torre1'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // OPERADOR E AUDITORIA
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'ExtraidoPor',
          type: 'Text',
          required: true,
          indexed: true,
          description: 'Email do operador que extraiu o pedido',
          example: 'leonardo.miguel@gpabr.com'
        },
        {
          name: 'ExtraidoEm',
          type: 'DateTime',
          required: true,
          indexed: true,
          default: 'Now',
          description: 'Data/hora da extração'
        },
        {
          name: 'ProcessadoPor',
          type: 'Text',
          required: false,
          indexed: true,
          description: 'Email do operador que processou/enviou o pedido'
        },
        {
          name: 'ProcessadoEm',
          type: 'DateTime',
          required: false,
          indexed: true,
          description: 'Data/hora do processamento/envio'
        },
        {
          name: 'PlataformaEnvio',
          type: 'Choice',
          required: false,
          indexed: true,
          choices: ['Uber', '99app', 'Lalamove', 'Outro'],
          description: 'Plataforma usada para enviar o pedido'
        },
        
        // ═══════════════════════════════════════════════════════════════
        // METADADOS
        // ═══════════════════════════════════════════════════════════════
        {
          name: 'DadosCompletos',
          type: 'Note',
          required: false,
          indexed: false,
          description: 'JSON completo dos dados extraídos (backup)'
        },
        {
          name: 'Observacoes',
          type: 'Note',
          required: false,
          indexed: false,
          description: 'Observações adicionais'
        },
        {
          name: 'DataCriacao',
          type: 'DateTime',
          required: true,
          indexed: true,
          default: 'Now',
          description: 'Data/hora de criação do registro'
        },
        {
          name: 'DataModificacao',
          type: 'DateTime',
          required: true,
          indexed: true,
          default: 'Now',
          description: 'Data/hora da última modificação'
        }
      ],
      
      // Índices para performance
      indexes: [
        { columns: ['PedidoID'], name: 'IX_PedidoID_Unique', unique: true },
        { columns: ['Bloqueado', 'BloqueadoPor'], name: 'IX_Lock_Status' },
        { columns: ['ExtraidoPor', 'ExtraidoEm'], name: 'IX_Extractor_Date' },
        { columns: ['StatusPicking', 'ExtraidoEm'], name: 'IX_Status_Date' },
        { columns: ['Loja', 'ExtraidoEm'], name: 'IX_Store_Date' }
      ],
      
      // Views padrão
      views: [
        {
          name: 'Pedidos_Ativos',
          query: "Bloqueado eq false",
          orderBy: 'ExtraidoEm desc',
          fields: ['PedidoID', 'NomeCliente', 'StatusPicking', 'Loja', 'ExtraidoPor', 'ExtraidoEm']
        },
        {
          name: 'Pedidos_Bloqueados',
          query: "Bloqueado eq true",
          orderBy: 'BloqueadoEm desc',
          fields: ['PedidoID', 'NomeCliente', 'BloqueadoPor', 'BloqueadoEm', 'StatusPicking']
        },
        {
          name: 'Meus_Pedidos',
          query: "ExtraidoPor eq '{currentUser}'",
          orderBy: 'ExtraidoEm desc',
          fields: ['PedidoID', 'NomeCliente', 'StatusPicking', 'Bloqueado', 'ExtraidoEm']
        },
        {
          name: 'Aguardando_Processamento',
          query: "ProcessadoPor eq null and Bloqueado eq false",
          orderBy: 'ExtraidoEm asc',
          fields: ['PedidoID', 'NomeCliente', 'StatusPicking', 'Loja', 'ExtraidoPor', 'ExtraidoEm']
        }
      ]
    }
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // DOCUMENT LIBRARY (para arquivos da extensão)
  // ═══════════════════════════════════════════════════════════════════════════
  
  documentLibrary: {
    name: 'Nexos_Files',
    displayName: 'Nexos - Arquivos da Extensão',
    description: 'Biblioteca de documentos para arquivos JS/CSS/JSON da extensão',
    
    folders: {
      core: '/core',           // Módulos principais (auth, graph, loader, etc)
      modules: '/modules',     // Módulos específicos (picking, orkestra, uber, etc)
      templates: '/templates', // Templates HTML
      styles: '/styles',       // Arquivos CSS
      config: '/config',       // Arquivos de configuração
      data: '/data',          // Dados estáticos (stores.json, trees.json)
      scripts: '/scripts'      // Scripts PowerShell e utilitários
    },
    
    criticalFiles: [
      '/config/version.json',
      '/core/loader.js',
      '/core/graph-client.js',
      '/core/update-engine.js',
      '/data/stores.json',
      '/data/trees.json'
    ]
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CACHE E PERFORMANCE
  // ═══════════════════════════════════════════════════════════════════════════
  
  cache: {
    defaultTTL: 300000,        // 5 minutos
    listsTTL: 60000,           // 1 minuto para listas
    filesTTL: 3600000,         // 1 hora para arquivos
    configTTL: 600000,         // 10 minutos para configs
    userProfileTTL: 3600000    // 1 hora para perfil do usuário
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // RETRY E RATE LIMITING
  // ═══════════════════════════════════════════════════════════════════════════
  
  retry: {
    maxRetries: 3,
    initialDelay: 1000,
    maxDelay: 30000,
    backoffMultiplier: 2
  },
  
  rateLimit: {
    maxRequestsPerMinute: 1000,
    maxConcurrentRequests: 5
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // ATUALIZAÇÃO AUTOMÁTICA
  // ═══════════════════════════════════════════════════════════════════════════
  
  autoUpdate: {
    enabled: true,
    checkInterval: 1800000,      // 30 minutos
    versionFilePath: '/config/version.json',
    autoApplyUpdates: true,
    requiresUserConfirmation: false,
    
    fallbackUrls: [
      'https://gpabr.sharepoint.com/sites/Nexos',
      'https://raw.githubusercontent.com/TheLeozin/Nexos/main'
    ]
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // MIGRAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  
  migration: {
    enabled: true,
    batchSize: 20,
    validateBeforeMigration: true,
    skipDuplicates: true,
    generateReport: true,
    backupBeforeMigration: true
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // MULTI-USUÁRIO
  // ═══════════════════════════════════════════════════════════════════════════
  
  multiUser: {
    enabled: false, // Por enquanto desabilitado, será ativado na fase 2
    lockTimeout: 300000, // 5 minutos
    heartbeatInterval: 30000, // 30 segundos
    conflictResolution: 'last-write-wins' // ou 'manual'
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // LOGGING E AUDITORIA
  // ═══════════════════════════════════════════════════════════════════════════
  
  logging: {
    enabled: true,
    level: 'info', // debug, info, warn, error
    sendToSharePoint: true,
    batchSize: 50,
    flushInterval: 60000 // 1 minuto
  },
  
  audit: {
    enabled: true,
    trackActions: [
      'pedido_criado',
      'pedido_atualizado',
      'status_alterado',
      'solicitacao_enviada',
      'entrega_confirmada',
      'pedido_cancelado',
      'login',
      'logout',
      'configuracao_alterada'
    ]
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // NOTIFICAÇÕES
  // ═══════════════════════════════════════════════════════════════════════════
  
  notifications: {
    enabled: true,
    checkInterval: 30000, // 30 segundos
    showDesktopNotifications: true,
    playSound: false,
    maxUnreadNotifications: 10
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // FALLBACK E OFFLINE
  // ═══════════════════════════════════════════════════════════════════════════
  
  offline: {
    enabled: true,
    queueOperations: true,
    maxQueueSize: 1000,
    syncOnReconnect: true
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // SEGURANÇA
  // ═══════════════════════════════════════════════════════════════════════════
  
  security: {
    encryptTokens: true,
    encryptionAlgorithm: 'AES-GCM',
    tokenExpiryBuffer: 300000, // 5 minutos antes de expirar, renovar
    maxTokenAge: 3600000, // 1 hora
    requireHTTPS: true
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // FEATURES FLAGS (para controle gradual de funcionalidades)
  // ═══════════════════════════════════════════════════════════════════════════
  
  features: {
    autoMigration: true,
    autoUpdate: true,
    multiUser: false,          // Fase 2
    realTimeSync: false,       // Fase 2
    conflictResolution: false, // Fase 2
    advancedAnalytics: false,  // Fase 3
    aiSuggestions: false,      // Fase 3
    mobileSupport: false       // Fase 3
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // DEBUG E DESENVOLVIMENTO
  // ═══════════════════════════════════════════════════════════════════════════
  
  debug: {
    enabled: false, // Ativar apenas em desenvolvimento
    verboseLogging: false,
    mockData: false,
    skipAuthentication: false,
    useLocalFiles: false
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Gera URL completa do Graph API para um endpoint
 */
function getGraphApiUrl(endpoint) {
  return `${SHAREPOINT_CONFIG.graphApiUrl}${endpoint}`;
}

/**
 * Gera URL completa do SharePoint
 */
function getSharePointUrl(path = '') {
  return `${SHAREPOINT_CONFIG.siteUrl}${path}`;
}

/**
 * Retorna configuração de uma lista pelo nome
 */
function getListConfig(listName) {
  for (const key in SHAREPOINT_CONFIG.lists) {
    if (SHAREPOINT_CONFIG.lists[key].name === listName) {
      return SHAREPOINT_CONFIG.lists[key];
    }
  }
  return null;
}

/**
 * Retorna caminho completo de um arquivo na biblioteca
 */
function getLibraryFilePath(file) {
  if (file.startsWith('/')) {
    return file;
  }
  
  // Tentar detectar pasta automaticamente
  for (const folderName in SHAREPOINT_CONFIG.documentLibrary.folders) {
    const folderPath = SHAREPOINT_CONFIG.documentLibrary.folders[folderName];
    if (file.includes(folderName)) {
      return `${folderPath}/${file}`;
    }
  }
  
  return `/${file}`;
}

/**
 * Valida se a configuração está completa
 */
function validateConfig() {
  const errors = [];
  
  if (SHAREPOINT_CONFIG.auth.clientId === 'SEU_CLIENT_ID_AQUI') {
    errors.push('Client ID do Azure AD não configurado');
  }
  
  if (!SHAREPOINT_CONFIG.siteUrl) {
    errors.push('URL do SharePoint não configurada');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════════════════════════════════════

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    SHAREPOINT_CONFIG,
    getGraphApiUrl,
    getSharePointUrl,
    getListConfig,
    getLibraryFilePath,
    validateConfig
  };
}

// Expor globalmente (Service Worker usa 'self', DOM usa 'window')
if (typeof self !== 'undefined') {
  self.SHAREPOINT_CONFIG = SHAREPOINT_CONFIG;
  self.SharePointConfigHelpers = {
    getGraphApiUrl,
    getSharePointUrl,
    getListConfig,
    getLibraryFilePath,
    validateConfig
  };
}
