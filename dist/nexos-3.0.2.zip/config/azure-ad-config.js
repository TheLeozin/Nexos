// ===================================================================
// NEXOS - Configuração Microsoft Azure AD (Entra ID)
// OAuth 2.0 + Microsoft Identity Platform
// ===================================================================

/**
 * Configuração do Azure AD para autenticação corporativa
 * 
 * INSTRUÇÕES DE CONFIGURAÇÃO:
 * 
 * 1. Acesse: https://portal.azure.com
 * 2. Azure Active Directory → App registrations → New registration
 * 3. Nome: "Nexos Torre Extension"
 * 4. Supported account types: "Accounts in this organizational directory only (GPA only)"
 * 5. Redirect URI: 
 *    - Platform: Single-page application (SPA)
 *    - URI: https://<extension-id>.chromiumapp.org/admin/admin.html
 *           (substitua <extension-id> pelo ID real da extensão)
 * 
 * 6. API permissions → Add permission → Microsoft Graph → Delegated:
 *    - User.Read (Obrigatório - ler perfil básico)
 *    - User.ReadBasic.All (Opcional - ler outros usuários)
 *    - Group.Read.All (Obrigatório - ler grupos do usuário)
 *    - offline_access (Obrigatório - refresh token)
 * 
 * 7. Grant admin consent para todas as permissões
 * 
 * 8. Copie:
 *    - Application (client) ID → AZURE_AD_CONFIG.clientId
 *    - Directory (tenant) ID → AZURE_AD_CONFIG.tenantId
 * 
 * 9. Atualizar este arquivo com valores corretos
 */

const AZURE_AD_CONFIG = {
  // ===================================
  // CONFIGURAÇÃO OBRIGATÓRIA
  // ===================================
  
  /**
   * Application (client) ID do Azure AD
   * @example "12345678-1234-1234-1234-123456789012"
   */
  clientId: '8f673d6e-b976-4d54-a83d-a8618973c963',
  
  /**
   * Directory (tenant) ID do Azure AD
   * @example "87654321-4321-4321-4321-210987654321"
   */
  tenantId: '1a53e6b6-7562-4b9f-83d0-e71a8891667e',
  
  /**
   * Redirect URI configurado no Azure AD
   * 
   * ⚠️ DINÂMICO: Detecta automaticamente baseado na página atual
   * 
   * Páginas suportadas:
   * - Extensão Chrome (chrome-extension://): usa chrome.identity.getRedirectURL() ou chromiumapp.org
   * - Picking Admin (picking-admin.backoffice.gpa.digital): usa URL da página atual
   * - Testes standalone (file:// ou localhost): usa http://localhost
   * - James Delivery (mapa.james.delivery): usa https://mapa.james.delivery/map
   * 
   * Configure TODOS no Azure AD Portal:
   * Platform: Single-page application (SPA)
   * Redirect URIs:
   *   1. https://obodcljemkajclohcfjhmommhfpklojo.chromiumapp.org/  (extensão)
   *   2. https://picking-admin.backoffice.gpa.digital/dashboard/gerencial  (picking admin)
   *   3. https://mapa.james.delivery/map  (james delivery)
   *   4. http://localhost  (testes locais)
   */
  get redirectUri() {
    // Detectar contexto atual
    let currentUrl;
    try {
      currentUrl = window.location.href;
    } catch (e) {
      // Se não conseguir acessar window.location, tentar via chrome.runtime
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
        console.warn('[AZURE_AD_CONFIG] ⚠️ window.location inacessível, usando chrome.runtime.id');
        return `https://${chrome.runtime.id}.chromiumapp.org/`;
      }
      // Fallback final
      console.warn('[AZURE_AD_CONFIG] ⚠️ Não conseguiu acessar window.location, usando fallback');
      return 'https://mapa.james.delivery/map';
    }
    
    // ✅ PRIORIDADE 1: Extensão Chrome (chrome-extension://)
    if (currentUrl.startsWith('chrome-extension://')) {
      // Usar chrome.identity.getRedirectURL() se disponível
      if (typeof chrome !== 'undefined' && chrome.identity && typeof chrome.identity.getRedirectURL === 'function') {
        try {
          const identityUrl = chrome.identity.getRedirectURL();
          console.log('[AZURE_AD_CONFIG] 📍 Detectado extensão Chrome, usando chrome.identity:', identityUrl);
          return identityUrl;
        } catch (error) {
          console.warn('[AZURE_AD_CONFIG] ⚠️ Erro ao obter chrome.identity.getRedirectURL:', error);
        }
      }
      
      // Fallback: gerar URL baseado no runtime.id
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
        const chromiumAppUrl = `https://${chrome.runtime.id}.chromiumapp.org/`;
        console.log('[AZURE_AD_CONFIG] 📍 Usando chromiumapp.org (runtime.id):', chromiumAppUrl);
        return chromiumAppUrl;
      }
    }
    
    // ✅ PRIORIDADE 2: Picking Admin (picking-admin.backoffice.gpa.digital)
    if (currentUrl.includes('picking-admin.backoffice.gpa.digital') || currentUrl.includes('backoffice.gpa.digital')) {
      console.log('[AZURE_AD_CONFIG] 📍 Detectado Picking Admin (backoffice.gpa.digital), usando URL atual');
      // Usar a URL da página hospedeira como redirect
      const baseUrl = currentUrl.split('?')[0].split('#')[0]; // Remove query params e hash
      return baseUrl;
    }
    
    // ✅ PRIORIDADE 3: Testes standalone (file:// ou localhost sem chrome-extension)
    if (currentUrl.startsWith('file://') || (currentUrl.includes('localhost') && !currentUrl.startsWith('chrome-extension://'))) {
      const testRedirect = 'http://localhost';
      console.log('[AZURE_AD_CONFIG] 📍 Detectado ambiente de teste standalone, usando:', testRedirect);
      console.log('[AZURE_AD_CONFIG] ⚠️ IMPORTANTE: Adicione esta URL no Azure AD Portal:');
      console.log('[AZURE_AD_CONFIG]    1. Vá para: https://portal.azure.com');
      console.log('[AZURE_AD_CONFIG]    2. Azure AD > App registrations > Nexos Torre');
      console.log('[AZURE_AD_CONFIG]    3. Authentication > Platform configurations > Add a platform > Single-page application');
      console.log('[AZURE_AD_CONFIG]    4. Redirect URIs: adicione "http://localhost"');
      console.log('[AZURE_AD_CONFIG]    5. Salve as alterações');
      return testRedirect;
    }
    
    // ✅ PRIORIDADE 4: James Delivery (content script)
    if (currentUrl.includes('mapa.james.delivery')) {
      console.log('[AZURE_AD_CONFIG] 📍 Detectado James Delivery, usando: https://mapa.james.delivery/map');
      return 'https://mapa.james.delivery/map';
    }
    
    // ✅ PRIORIDADE 5: Plataformas conhecidas (content script em páginas de entrega)
    const knownPlatforms = ['direct.uber.com', 'web.lalamove.com', 'entrega.99app.com', 'james-orkestra', 'instaleap'];
    if (knownPlatforms.some(p => currentUrl.includes(p))) {
      // Tenta identity API primeiro (mais confiável)
      if (typeof chrome !== 'undefined' && chrome.identity && typeof chrome.identity.getRedirectURL === 'function') {
        try {
          const identityUrl = chrome.identity.getRedirectURL();
          if (identityUrl) {
            console.log('[AZURE_AD_CONFIG] 📍 Plataforma de entrega detectada, usando identity:', identityUrl);
            return identityUrl;
          }
        } catch (_) {}
      }
      // Tenta chromiumapp.org via runtime.id
      try {
        const runtimeId = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id;
        if (runtimeId) {
          const chromiumAppUrl = `https://${runtimeId}.chromiumapp.org/`;
          console.log('[AZURE_AD_CONFIG] 📍 Plataforma de entrega detectada, usando chromiumapp.org:', chromiumAppUrl);
          return chromiumAppUrl;
        }
      } catch (_) {}
      // Fallback seguro: usar URL de base sem query params (evita redirect inválido)
      const platformBase = currentUrl.split('?')[0].split('#')[0];
      console.log('[AZURE_AD_CONFIG] 📍 Plataforma de entrega detectada, usando URL base:', platformBase);
      return platformBase;
    }

    // ✅ PRIORIDADE 6: Qualquer contexto de extensão (chrome.runtime disponível)
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      try {
        if (chrome.identity && typeof chrome.identity.getRedirectURL === 'function') {
          const url = chrome.identity.getRedirectURL();
          if (url) { console.log('[AZURE_AD_CONFIG] 📍 Extensão detectada via identity:', url); return url; }
        }
      } catch (_) {}
      try {
        if (chrome.runtime.id) {
          const url = `https://${chrome.runtime.id}.chromiumapp.org/`;
          console.log('[AZURE_AD_CONFIG] 📍 Extensão detectada via runtime.id:', url);
          return url;
        }
      } catch (_) {}
    }

    // ⚠️ Último fallback (nunca deve chegar aqui em produção)
    console.warn('[AZURE_AD_CONFIG] ⚠️ Não conseguiu detectar contexto conhecido');
    console.warn('[AZURE_AD_CONFIG] 📍 URL atual:', currentUrl);
    const baseUrl = currentUrl.split('?')[0].split('#')[0];
    return baseUrl || 'https://mapa.james.delivery/map';
  },
  
  // ===================================
  // SCOPES (Permissões Microsoft Graph)
  // ===================================
  
  /**
   * Scopes solicitados durante autenticação
   *
   * - User.Read: Ler perfil do usuário logado (nome, email, foto, cargo, departamento)
   * - User.ReadBasic.All: Ler perfil básico de outros usuários (opcional)
   * - offline_access: Obter refresh token (renovação automática)
   * - Sites.ReadWrite.All: Ler e escrever no SharePoint (tratativas)
   *
   * ⚠️ IMPORTANTE: Sites.ReadWrite.All deve ter admin consent concedido no Azure AD Portal:
   *   Azure AD → App registrations → Nexos Torre → API permissions → Grant admin consent
   */
  scopes: [
    'User.Read',
    'User.ReadBasic.All',
    'offline_access',
    'Sites.ReadWrite.All'
  ],
  
  // ===================================
  // ENDPOINTS
  // ===================================
  
  /**
   * Authority URL (endpoint de autenticação)
   * Formato: https://login.microsoftonline.com/<tenant-id>
   */
  get authority() {
    return `https://login.microsoftonline.com/${this.tenantId}`;
  },
  
  /**
   * Microsoft Graph API base URL
   */
  graphApiEndpoint: 'https://graph.microsoft.com/v1.0',
  
  // ===================================
  // MAPEAMENTO AZURE AD → NEXOS ROLES
  // ===================================
  
  /**
   * Mapeia grupos do Azure AD para roles do Nexos
   * 
   * INSTRUÇÕES:
   * 1. Criar grupos no Azure AD:
   *    - Azure Active Directory → Groups → New group
   *    - Group type: Security
   *    - Group name: Exatamente como abaixo
   *    - Members: Adicionar usuários apropriados
   * 
   * 2. Sincronizar nomes dos grupos aqui
   * 
   * IMPORTANTE: 
   * - Nomes devem ser EXATAMENTE iguais (case-sensitive)
   * - Ordem importa: primeiro match ganha (Admin Master tem prioridade)
   * - Se usuário não estiver em nenhum grupo, usa defaultRole
   */
  roleMapping: {
    // Administração
    'Nexos - Admin Master': 'admin_master',
    'Nexos - Administrador': 'admin',
    'Nexos - Gestão': 'gestao',
    
    // Encarregados
    'Nexos - Encarregado Torre': 'encarregado_torre',
    'Nexos - Encarregado Frota': 'encarregado_frota',
    'Nexos - Encarregado Ocorrência': 'encarregado_ocorrencia',
    
    // Torre
    'Nexos - Torre Assistente II': 'torre_assistente_ii',
    'Nexos - Torre Assistente I': 'torre_assistente_i',
    'Nexos - Torre Auxiliar': 'torre_auxiliar',
    'Nexos - Torre Aprendiz': 'torre_aprendiz',
    
    // Outros departamentos
    'Nexos - Frota': 'frota',
    'Nexos - Ocorrência': 'ocorrencia'
  },
  
  /**
   * Role padrão para usuários sem grupo definido
   * Recomendado: role com menos permissões
   */
  defaultRole: 'torre_aprendiz',
  
  /**
   * Domínios de email permitidos
   * Apenas usuários com estes domínios podem fazer login
   */
  allowedDomains: ['gpa.com.br', 'gpabr.onmicrosoft.com'],
  
  // ===================================
  // CONFIGURAÇÕES DE CACHE
  // ===================================
  
  /**
   * Configurações de cache do MSAL
   */
  cache: {
    cacheLocation: 'localStorage', // ou 'sessionStorage'
    storeAuthStateInCookie: false
  },
  
  /**
   * Tempo de vida do token (em segundos)
   * Padrão Microsoft: 3600 (1 hora)
   * Renovação automática ocorre 5 min antes de expirar
   */
  tokenLifetime: 3600,
  tokenRenewalOffset: 300, // 5 minutos antes
  
  // ===================================
  // CONFIGURAÇÕES DE UI
  // ===================================
  
  /**
   * Tipo de popup para login
   * - 'popup': Abre popup para login (recomendado para extensões)
   * - 'redirect': Redireciona página inteira (não funciona bem em extensões)
   */
  loginType: 'popup',
  
  /**
   * Configurações do popup de login
   */
  popupConfig: {
    width: 600,
    height: 700
  },
  
  // ===================================
  // MODO DEBUG
  // ===================================
  
  /**
   * Ativa logs detalhados do MSAL
   * ATENÇÃO: Desativar em produção (expõe tokens no console)
   */
  debug: true,
  
  /**
   * Bypass de autenticação para desenvolvimento
   * ATENÇÃO: DEVE SER FALSE EM PRODUÇÃO
   */
  bypassAuth: false
};

// ===================================
// VALIDAÇÃO DE CONFIGURAÇÃO
// ===================================

/**
 * Valida se a configuração está completa
 * @returns {Object} { valid: boolean, errors: string[] }
 */
function validateAzureAdConfig() {
  const errors = [];
  
  if (AZURE_AD_CONFIG.clientId === 'YOUR_CLIENT_ID_HERE') {
    errors.push('❌ Client ID não foi configurado. Atualize AZURE_AD_CONFIG.clientId');
  }
  
  if (AZURE_AD_CONFIG.tenantId === 'YOUR_TENANT_ID_HERE') {
    errors.push('❌ Tenant ID não foi configurado. Atualize AZURE_AD_CONFIG.tenantId');
  }
  
  if (AZURE_AD_CONFIG.redirectUri.includes('YOUR_EXTENSION_ID')) {
    errors.push('❌ Redirect URI não foi configurado. Atualize AZURE_AD_CONFIG.redirectUri com o ID da extensão');
  }
  
  // Validar formato de GUID
  const guidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  
  if (!guidRegex.test(AZURE_AD_CONFIG.clientId) && AZURE_AD_CONFIG.clientId !== 'YOUR_CLIENT_ID_HERE') {
    errors.push('⚠️ Client ID não parece ser um GUID válido');
  }
  
  if (!guidRegex.test(AZURE_AD_CONFIG.tenantId) && AZURE_AD_CONFIG.tenantId !== 'YOUR_TENANT_ID_HERE') {
    errors.push('⚠️ Tenant ID não parece ser um GUID válido');
  }
  
  // Validar redirect URI
  if (!AZURE_AD_CONFIG.redirectUri.startsWith('https://') && !AZURE_AD_CONFIG.redirectUri.includes('YOUR_EXTENSION_ID')) {
    errors.push('⚠️ Redirect URI deve começar com https://');
  }
  
  // Validar scopes
  if (AZURE_AD_CONFIG.scopes.length === 0) {
    errors.push('❌ Pelo menos um scope é necessário');
  }
  
  const valid = errors.length === 0;
  
  if (valid) {
    console.log('[AzureAD Config] ✅ Configuração válida');
  } else {
    console.error('[AzureAD Config] ❌ Erros na configuração:', errors);
  }
  
  return { valid, errors };
}

// ===================================
// HELPER FUNCTIONS
// ===================================

/**
 * Verifica se email é de domínio permitido
 * @param {string} email 
 * @returns {boolean}
 */
function isEmailAllowed(email) {
  if (!email) return false;
  
  const domain = email.split('@')[1]?.toLowerCase();
  return AZURE_AD_CONFIG.allowedDomains.some(d => domain === d.toLowerCase());
}

/**
 * Mapeia grupo do Azure AD para role do Nexos
 * @param {Array<string>} groups - Nomes dos grupos do usuário
 * @returns {string} roleId do Nexos
 */
function mapGroupsToRole(groups) {
  if (!groups || groups.length === 0) {
    console.log('[AzureAD Config] ⚠️ Usuário sem grupos, usando defaultRole:', AZURE_AD_CONFIG.defaultRole);
    return AZURE_AD_CONFIG.defaultRole;
  }
  
  // Procurar primeiro match (ordem importa)
  for (const [groupName, roleId] of Object.entries(AZURE_AD_CONFIG.roleMapping)) {
    if (groups.includes(groupName)) {
      console.log(`[AzureAD Config] ✅ Grupo encontrado: "${groupName}" → role: ${roleId}`);
      return roleId;
    }
  }
  
  console.log('[AzureAD Config] ⚠️ Nenhum grupo mapeado encontrado, usando defaultRole:', AZURE_AD_CONFIG.defaultRole);
  return AZURE_AD_CONFIG.defaultRole;
}

/**
 * Obtém URL completa do Graph API para um endpoint
 * @param {string} endpoint - Caminho relativo (ex: '/me', '/me/photo/$value')
 * @returns {string} URL completa
 */
function getGraphApiUrl(endpoint) {
  return `${AZURE_AD_CONFIG.graphApiEndpoint}${endpoint}`;
}

// ===================================
// EXPORTAÇÃO
// ===================================

if (typeof window !== 'undefined') {
  window.AZURE_AD_CONFIG = AZURE_AD_CONFIG;
  window.validateAzureAdConfig = validateAzureAdConfig;
  window.isEmailAllowed = isEmailAllowed;
  window.mapGroupsToRole = mapGroupsToRole;
  window.getGraphApiUrl = getGraphApiUrl;
  
  console.log('[AzureAD Config] ✅ Configuração exportada para window');
  
  // Validar automaticamente ao carregar
  const validation = validateAzureAdConfig();
  if (!validation.valid) {
    console.warn('[AzureAD Config] ⚠️ Configuração incompleta. Siga as instruções no arquivo.');
  }
}

