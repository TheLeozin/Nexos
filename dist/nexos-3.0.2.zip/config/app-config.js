/**
 * Nexos Torre - Configuração Enterprise
 * Versão: 2.0.0
 * 
 * INSTRUÇÕES DE CONFIGURAÇÃO:
 * 1. Registre um app no Azure Portal (Azure AD > App registrations)
 * 2. Configure Redirect URI: chrome-extension://<EXTENSION_ID>/
 * 3. Adicione permissões: User.Read, Sites.ReadWrite.All, offline_access
 * 4. Copie Client ID e Tenant ID para esta configuração
 * 5. Configure URLs do SharePoint para seu tenant
 */

const NEXOS_CONFIG = {
  // ========================================
  // AZURE AD / MICROSOFT ENTRA ID
  // ========================================
  auth: {
    // Client ID do app registrado no Azure Portal
    clientId: '8f673d6e-b976-4d54-a83d-a8618973c963', // Ex: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890'
    
    // Tenant ID (ou usar 'common' para multi-tenant)
    tenantId: '1a53e6b6-7562-4b9f-83d0-e71a8891667e', // Ex: '12345678-90ab-cdef-1234-567890abcdef'
    
    // Redirect URI (será gerado automaticamente pela extensão)
    redirectUri: '', // Será preenchido automaticamente: chrome-extension://<ID>/
    
    // Scopes necessários (delegated permissions)
    scopes: [
      'User.Read',              // Ler perfil do usuário
      'Sites.ReadWrite.All',    // Ler/escrever em SharePoint
      'offline_access'          // Refresh tokens
    ],
    
    // Endpoints (não alterar a menos que use sovereign cloud)
    authority: 'https://login.microsoftonline.com',
    
    // Configurações de token
    tokenExpiry: 3600,          // 1 hora (padrão do Azure AD)
    refreshThreshold: 300       // Renovar token 5 min antes de expirar
  },
  
  // ========================================
  // SHAREPOINT ONLINE
  // ========================================
  sharepoint: {
    // URL do site SharePoint (altere para seu tenant)
    siteUrl: 'https://gpabr.sharepoint.com/sites/NexosTorre',
    
    // Nomes das Lists (devem corresponder aos nomes criados no SharePoint)
    lists: {
      statusPedidos: 'Nexos_StatusPedidos',
      notificacoes: 'Nexos_Notificacoes',
      auditLog: 'Nexos_AuditLog',
      configuracoes: 'Nexos_Configuracoes',
      logs: 'Nexos_Logs'
    },
    
    // Document Library para atualizações
    updateLibrary: 'Nexos_Updates',
    
    // Configurações de cache
    cache: {
      enabled: true,
      defaultTTL: 300000,       // 5 minutos
      maxSize: 50,              // Máximo de 50 itens em cache
      strategies: {
        statusPedidos: 60000,   // 1 minuto (dados frequentes)
        notificacoes: 30000,    // 30 segundos (tempo real)
        configuracoes: 600000   // 10 minutos (dados estáticos)
      }
    },
    
    // Configurações de retry
    retry: {
      maxAttempts: 3,
      baseDelay: 1000,          // 1 segundo
      maxDelay: 30000,          // 30 segundos
      backoffMultiplier: 2      // Exponencial: 1s, 2s, 4s, 8s...
    },
    
    // Throttling (429 Too Many Requests)
    throttling: {
      enabled: true,
      respectRetryAfter: true,
      defaultWaitTime: 60       // 60 segundos se Retry-After não fornecido
    }
  },
  
  // ========================================
  // NOTIFICAÇÕES
  // ========================================
  notifications: {
    // Polling interval (em milissegundos)
    polling: {
      enabled: true,
      interval: 30000,          // 30 segundos
      adaptiveInterval: true,   // Ajustar baseado em atividade
      minInterval: 10000,       // Mínimo: 10 segundos
      maxInterval: 120000       // Máximo: 2 minutos
    },
    
    // Badge de notificações não lidas
    badge: {
      enabled: true,
      maxCount: 99              // Mostrar "99+" se passar
    },
    
    // Sons de notificação (opcional)
    sounds: {
      enabled: false,
      critica: 'sounds/critical.mp3',
      alta: 'sounds/high.mp3'
    },
    
    // Integração com Microsoft Teams (opcional)
    teams: {
      enabled: false,
      webhookUrl: '',           // Webhook do canal do Teams
      notifyOnPriority: ['Crítica', 'Alta']
    },
    
    // Power Automate (opcional)
    powerAutomate: {
      enabled: false,
      flowUrl: ''               // URL do flow HTTP trigger
    }
  },
  
  // ========================================
  // SISTEMA MULTIUSUÁRIO
  // ========================================
  multiuser: {
    // Lock distribuído
    lock: {
      enabled: true,
      defaultTimeout: 300000,   // 5 minutos
      autoRenew: true,
      renewInterval: 120000,    // Renovar a cada 2 minutos
      conflictResolution: 'optimistic' // 'optimistic' ou 'pessimistic'
    },
    
    // Sincronização de status
    statusSync: {
      enabled: true,
      interval: 15000,          // 15 segundos
      conflictStrategy: 'last-write-wins' // ou 'manual-merge'
    },
    
    // Presença de usuários (opcional)
    presence: {
      enabled: false,
      heartbeatInterval: 30000, // 30 segundos
      offlineThreshold: 90000   // Marcar offline após 90s sem heartbeat
    }
  },
  
  // ========================================
  // ATUALIZAÇÃO AUTOMÁTICA
  // ========================================
  updates: {
    // Verificação de updates
    check: {
      enabled: true,
      interval: 1800000,        // 30 minutos
      sources: ['sharepoint', 'github'], // Ordem de prioridade
      autoDownload: false       // Solicitar confirmação antes de baixar
    },
    
    // SharePoint source
    sharepoint: {
      manifestPath: '/Shared%20Documents/Nexos_Updates/manifest.json',
      updatesPath: '/Shared%20Documents/Nexos_Updates/updates/'
    },
    
    // GitHub fallback
    github: {
      repo: 'TheLeozin/Nexos',
      branch: 'main',
      manifestUrl: 'https://raw.githubusercontent.com/TheLeozin/Nexos/main/manifest.json'
    },
    
    // Validação de checksums
    validation: {
      enabled: true,
      algorithm: 'SHA-256'
    },
    
    // Backup antes de atualizar
    backup: {
      enabled: true,
      keepLastN: 2              // Manter últimas 2 versões
    }
  },
  
  // ========================================
  // ARMAZENAMENTO LOCAL
  // ========================================
  storage: {
    // IndexedDB
    indexedDB: {
      name: 'NexosTorreDB',
      version: 2,
      stores: ['tokens', 'cache', 'queue', 'config', 'audit']
    },
    
    // Sincronização híbrida
    sync: {
      enabled: true,
      strategy: 'background',   // 'immediate' ou 'background'
      queueSize: 100,           // Máximo de operações em fila
      retryFailed: true,
      retryInterval: 60000      // Tentar novamente a cada 1 minuto
    },
    
    // Limpeza automática
    cleanup: {
      enabled: true,
      interval: 86400000,       // 24 horas
      maxAge: 2592000000        // 30 dias
    }
  },
  
  // ========================================
  // PLATAFORMAS DE ENTREGA
  // ========================================
  platforms: {
    uber: {
      enabled: true,
      accountId: '740e6e18-263c-4f1a-8ee6-a8a706696e89',
      baseUrl: 'https://direct.uber.com',
      defaultVehicle: 'moto',
      timeout: 30000            // 30 segundos
    },
    
    lalamove: {
      enabled: true,
      baseUrl: 'https://web.lalamove.com',
      region: 'BR_SAO',
      timeout: 30000
    },
    
    nineNine: {
      enabled: true,
      baseUrl: 'https://entrega.99app.com',
      timeout: 30000
    }
  },
  
  // ========================================
  // PERMISSÕES E ROLES
  // ========================================
  permissions: {
    // Mapeamento de grupos do Azure AD para roles
    roles: {
      'TORRE_OPERADOR': {
        canCreateOrders: true,
        canCancelOrders: true,
        canViewAll: true,
        canManageNotifications: false,
        canAccessAdmin: false
      },
      'TORRE_GESTOR': {
        canCreateOrders: true,
        canCancelOrders: true,
        canViewAll: true,
        canManageNotifications: true,
        canAccessAdmin: true
      },
      'OCORRENCIA': {
        canCreateOrders: false,
        canCancelOrders: false,
        canViewAll: true,
        canManageNotifications: true,
        canAccessAdmin: false
      },
      'FROTA': {
        canCreateOrders: false,
        canCancelOrders: false,
        canViewAll: true,
        canManageNotifications: true,
        canAccessAdmin: false
      }
    },
    
    // Role padrão para usuários não mapeados
    defaultRole: 'TORRE_OPERADOR'
  },
  
  // ========================================
  // UI / DESIGN SYSTEM
  // ========================================
  ui: {
    theme: {
      mode: 'dark',             // 'light' ou 'dark'
      allowUserToggle: true
    },
    
    animations: {
      enabled: true,
      duration: 200             // ms
    },
    
    toast: {
      duration: 4000,           // 4 segundos
      position: 'bottom-right'  // 'top-left', 'top-right', 'bottom-left', 'bottom-right'
    },
    
    modal: {
      backdrop: true,
      closeOnBackdrop: true,
      closeOnEscape: true
    }
  },
  
  // ========================================
  // LOGGING E DEBUG
  // ========================================
  logging: {
    level: 'info',              // 'debug', 'info', 'warn', 'error'
    console: true,
    sharepoint: true,           // Enviar logs para SharePoint
    maxLogSize: 1000,           // Máximo de logs locais
    
    // Categorias de log
    categories: {
      auth: true,
      api: true,
      storage: true,
      sync: true,
      ui: false                 // Desabilitado por padrão (verbose)
    }
  },
  
  // ========================================
  // RECURSOS EXPERIMENTAIS
  // ========================================
  experimental: {
    // GraphQL para queries complexas (futuro)
    graphql: {
      enabled: false
    },
    
    // Offline mode (PWA-like)
    offline: {
      enabled: false,
      cacheAssets: true
    },
    
    // AI-powered suggestions (futuro)
    ai: {
      enabled: false
    }
  },
  
  // ========================================
  // METADADOS
  // ========================================
  meta: {
    version: '2.0.0',
    buildDate: '2025-11-16',
    environment: 'production',  // 'development', 'staging', 'production'
    features: [
      'multi-user',
      'notifications',
      'auto-update',
      'sharepoint-sync',
      'oauth'
    ]
  }
};

// ========================================
// VALIDAÇÃO DE CONFIGURAÇÃO
// ========================================
function validateConfig() {
  const errors = [];
  
  // Validar Auth
  if (!NEXOS_CONFIG.auth.clientId || NEXOS_CONFIG.auth.clientId === 'SEU_CLIENT_ID_AQUI') {
    errors.push('❌ Azure AD Client ID não configurado');
  }
  
  if (!NEXOS_CONFIG.auth.tenantId || NEXOS_CONFIG.auth.tenantId === 'SEU_TENANT_ID_AQUI') {
    errors.push('❌ Azure AD Tenant ID não configurado');
  }
  
  // Validar SharePoint
  if (!NEXOS_CONFIG.sharepoint.siteUrl || NEXOS_CONFIG.sharepoint.siteUrl.includes('exemplo')) {
    errors.push('⚠️ SharePoint Site URL pode estar incorreto');
  }
  
  if (errors.length > 0) {
    console.warn('[NEXOS CONFIG] Avisos de configuração:', errors);
    return false;
  }
  
  console.log('✅ Configuração validada com sucesso');
  return true;
}

// ========================================
// GETTERS ÚTEIS
// ========================================
const NexosConfig = {
  get(path) {
    return path.split('.').reduce((obj, key) => obj?.[key], NEXOS_CONFIG);
  },
  
  getAuthority() {
    return `${NEXOS_CONFIG.auth.authority}/${NEXOS_CONFIG.auth.tenantId}`;
  },
  
  getSharePointApiUrl() {
    return `${NEXOS_CONFIG.sharepoint.siteUrl}/_api/web`;
  },
  
  getGraphApiUrl() {
    return 'https://graph.microsoft.com/v1.0';
  },
  
  isFeatureEnabled(feature) {
    return NEXOS_CONFIG.meta.features.includes(feature);
  },
  
  getUserRole(userGroups = []) {
    for (const group of userGroups) {
      if (NEXOS_CONFIG.permissions.roles[group]) {
        return group;
      }
    }
    return NEXOS_CONFIG.permissions.defaultRole;
  },
  
  hasPermission(role, permission) {
    const roleConfig = NEXOS_CONFIG.permissions.roles[role];
    return roleConfig ? roleConfig[permission] === true : false;
  }
};

// ========================================
// EXPORTAR
// ========================================
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { NEXOS_CONFIG, NexosConfig, validateConfig };
}

// Validar ao carregar (somente em desenvolvimento)
if (NEXOS_CONFIG.meta.environment === 'development') {
  validateConfig();
}
