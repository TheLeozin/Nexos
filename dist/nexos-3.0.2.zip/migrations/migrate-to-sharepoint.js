/**
 * ═══════════════════════════════════════════════════════════════════════════
 * NEXOS TORRE - MIGRATION SCRIPT v2.x → v3.0.0
 * Migra tokens do chrome.storage.local para SharePoint Nexos_TokenVault
 * 
 * EXECUÇÃO:
 * - Automática ao detectar atualização de v2.x para v3.0.0
 * - Manual via console: runMigrationToSharePoint()
 * 
 * FLUXO:
 * 1. Verificar se já migrou (flag 'nexos-migration-v3-done')
 * 2. Ler tokens antigos de chrome.storage.local (chave 'nexos-tokens')
 * 3. Fazer login via UnifiedAuthService (Chrome Identity API)
 * 4. Salvar tokens no SharePoint via AuthTokenServiceV2
 * 5. Limpar storage antigo
 * 6. Marcar migração como concluída
 * ═══════════════════════════════════════════════════════════════════════════
 */

class SharePointMigration {
  constructor() {
    this.migrationKey = 'nexos-migration-v3-done';
    this.oldTokenKey = 'nexos-tokens';
    this.oldVersionKey = 'nexos-extension-version';
    this.migrationInProgress = false;
  }

  /**
   * Verifica se precisa executar migração
   * @returns {Promise<boolean>}
   */
  async needsMigration() {
    try {
      // Verificar se chrome.storage está disponível (content script context)
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
        console.log('[Migration] ℹ️ chrome.storage não disponível (contexto de página), pulando migração');
        return false;
      }

      // Verificar se já migrou
      const result = await chrome.storage.local.get([this.migrationKey]);
      if (result[this.migrationKey]) {
        console.log('[Migration] ✅ Migração já executada');
        return false;
      }

      // Verificar se há tokens antigos
      const oldTokens = await chrome.storage.local.get([this.oldTokenKey]);
      if (!oldTokens[this.oldTokenKey]) {
        console.log('[Migration] ℹ️ Sem tokens antigos para migrar');
        return false;
      }

      console.log('[Migration] ⚠️ Migração necessária (tokens antigos encontrados)');
      return true;

    } catch (error) {
      console.error('[Migration] ❌ Erro ao verificar necessidade de migração:', error);
      return false;
    }
  }

  /**
   * Executa migração completa
   * @returns {Promise<object>} { success, message, details }
   */
  async migrate() {
    if (this.migrationInProgress) {
      return {
        success: false,
        message: 'Migração já em andamento',
        details: null
      };
    }

    this.migrationInProgress = true;

    try {
      console.log('[Migration] 🚀 Iniciando migração para SharePoint...');

      // Etapa 1: Verificar dependências
      await this._waitForDependencies();

      // Etapa 2: Fazer login via UnifiedAuthService
      console.log('[Migration] 🔐 Etapa 1/4: Autenticando usuário...');
      const loginResult = await this._loginUser();
      
      if (!loginResult.success) {
        throw new Error(`Falha no login: ${loginResult.error}`);
      }

      console.log('[Migration] ✅ Usuário autenticado:', loginResult.user.username);

      // Etapa 3: Salvar tokens no SharePoint
      console.log('[Migration] 💾 Etapa 2/4: Salvando tokens no SharePoint...');
      const saveResult = await this._saveToSharePoint(loginResult.tokens);

      if (!saveResult.success) {
        throw new Error(`Falha ao salvar: ${saveResult.error}`);
      }

      console.log('[Migration] ✅ Tokens salvos no SharePoint (Item ID:', saveResult.itemId, ')');

      // Etapa 4: Limpar storage antigo
      console.log('[Migration] 🧹 Etapa 3/4: Limpando storage antigo...');
      await this._cleanOldStorage();
      console.log('[Migration] ✅ Storage antigo limpo');

      // Etapa 5: Marcar como concluído
      console.log('[Migration] ✓ Etapa 4/4: Marcando migração como concluída...');
      await chrome.storage.local.set({ [this.migrationKey]: true });
      console.log('[Migration] ✅ Migração concluída!');

      return {
        success: true,
        message: 'Migração concluída com sucesso',
        details: {
          user: loginResult.user.username,
          itemId: saveResult.itemId
        }
      };

    } catch (error) {
      console.error('[Migration] ❌ Erro na migração:', error);
      
      return {
        success: false,
        message: error.message,
        details: { error: error.stack }
      };

    } finally {
      this.migrationInProgress = false;
    }
  }

  /**
   * Aguarda dependências estarem disponíveis
   * @private
   */
  async _waitForDependencies() {
    console.log('[Migration] ⏳ Aguardando dependências...');

    let attempts = 0;
    const maxAttempts = 100; // 10 segundos (100 * 100ms)

    while (attempts < maxAttempts) {
      if (
        window.unifiedAuth &&
        window.authTokenService &&
        window.msalAuth
      ) {
        console.log('[Migration] ✅ Dependências disponíveis');
        return;
      }

      await new Promise(resolve => setTimeout(resolve, 100));
      attempts++;
    }

    throw new Error('Timeout: dependências não carregadas (unifiedAuth, authTokenService, msalAuth)');
  }

  /**
   * Faz login do usuário via UnifiedAuthService
   * @private
   */
  async _loginUser() {
    try {
      // Verificar se já está logado
      if (window.unifiedAuth.isAuthenticated()) {
        const user = window.unifiedAuth.getCurrentUser();
        const accessToken = await window.unifiedAuth.getAccessToken();

        return {
          success: true,
          user: user,
          tokens: {
            accessToken: accessToken,
            refreshToken: 'N/A', // Chrome Identity não retorna refresh token
            expiresIn: 3600 // 1 hora (padrão)
          }
        };
      }

      // Fazer login popup-free com Chrome Identity API
      console.log('[Migration] 🔐 Iniciando login via Chrome Identity API...');
      const loginResult = await window.unifiedAuth.login({ interactive: true });

      if (!loginResult.success) {
        throw new Error(loginResult.error || 'Login falhou');
      }

      const user = window.unifiedAuth.getCurrentUser();
      const accessToken = await window.unifiedAuth.getAccessToken();

      return {
        success: true,
        user: user,
        tokens: {
          accessToken: accessToken,
          refreshToken: 'N/A',
          expiresIn: loginResult.expiresIn || 3600
        }
      };

    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Salva tokens no SharePoint via AuthTokenServiceV2
   * @private
   */
  async _saveToSharePoint(tokens) {
    try {
      // AuthTokenServiceV2 salva automaticamente ao obter token pela primeira vez
      // Vamos apenas garantir que está salvo
      const saveResult = await window.authTokenService.saveToken(
        tokens.accessToken,
        tokens.refreshToken,
        tokens.expiresIn
      );

      return {
        success: saveResult.success,
        itemId: saveResult.itemId,
        error: saveResult.error
      };

    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Limpa storage antigo (chrome.storage.local)
   * @private
   */
  async _cleanOldStorage() {
    try {
      // Listar chaves a serem removidas
      const keysToRemove = [
        this.oldTokenKey,
        '__nexos_token_vault_cache',
        '__nexos_msal_cache',
        '__nexos_oauth_tokens'
      ];

      // Remover do chrome.storage.local
      await chrome.storage.local.remove(keysToRemove);

      console.log('[Migration] 🧹 Chaves removidas:', keysToRemove.join(', '));

      // Limpar localStorage também (se houver tokens lá)
      try {
        if (typeof localStorage !== 'undefined') {
          localStorage.removeItem('nexos-tokens');
          localStorage.removeItem('__nexos_token_vault');
          console.log('[Migration] 🧹 localStorage limpo');
        }
      } catch (lsError) {
        console.warn('[Migration] ⚠️ Erro ao limpar localStorage:', lsError);
      }

    } catch (error) {
      console.error('[Migration] ❌ Erro ao limpar storage:', error);
      throw error;
    }
  }

  /**
   * Exibe modal de progresso da migração
   * @private
   */
  _showMigrationProgress(message, type = 'info') {
    // Usar showAlert se disponível
    if (typeof showAlert === 'function') {
      showAlert(message, type, 5000);
    } else {
      console.log(`[Migration] ${type.toUpperCase()}: ${message}`);
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// AUTO-EXECUTION & GLOBAL EXPORT
// ═══════════════════════════════════════════════════════════════════════════

// Criar instância singleton
const migrationService = new SharePointMigration();

/**
 * Executa migração (função pública para uso manual)
 * @returns {Promise<object>}
 */
async function runMigrationToSharePoint() {
  try {
    const needsMigration = await migrationService.needsMigration();
    
    if (!needsMigration) {
      console.log('[Migration] ℹ️ Migração não necessária');
      return {
        success: true,
        message: 'Migração não necessária',
        details: { reason: 'Já migrado ou sem dados antigos' }
      };
    }

    return await migrationService.migrate();

  } catch (error) {
    console.error('[Migration] ❌ Erro ao executar migração:', error);
    return {
      success: false,
      message: error.message,
      details: { error: error.stack }
    };
  }
}

/**
 * Verifica e executa migração automaticamente (se necessário)
 * Chamado no carregamento da extensão
 */
async function autoMigrationCheck() {
  try {
    console.log('[Migration] 🔍 Verificando necessidade de migração automática...');

    const needsMigration = await migrationService.needsMigration();
    
    if (needsMigration) {
      console.log('[Migration] ⚠️ Migração necessária! Executando automaticamente...');
      
      // Mostrar notificação ao usuário
      if (typeof showAlert === 'function') {
        showAlert('Migração para SharePoint em andamento...', 'info', 0);
      }

      const result = await migrationService.migrate();

      if (result.success) {
        if (typeof showAlert === 'function') {
          showAlert('✅ Migração concluída com sucesso!', 'success', 5000);
        }
        console.log('[Migration] ✅ Migração automática concluída');
      } else {
        if (typeof showAlert === 'function') {
          showAlert(`❌ Erro na migração: ${result.message}`, 'error', 10000);
        }
        console.error('[Migration] ❌ Migração automática falhou:', result.message);
      }

      return result;
    }

    console.log('[Migration] ✅ Sem necessidade de migração');
    return { success: true, message: 'Sem necessidade de migração' };

  } catch (error) {
    console.error('[Migration] ❌ Erro na verificação automática:', error);
    return { success: false, message: error.message };
  }
}

// Exportar para window (global)
if (typeof window !== 'undefined') {
  window.runMigrationToSharePoint = runMigrationToSharePoint;
  window.autoMigrationCheck = autoMigrationCheck;
  window.migrationService = migrationService;
  console.log('[Migration] ✅ Script de migração carregado');
}

// Auto-executar verificação após 5 segundos do carregamento
setTimeout(() => {
  autoMigrationCheck().catch(err => {
    console.error('[Migration] ❌ Erro na verificação automática:', err);
  });
}, 5000);
