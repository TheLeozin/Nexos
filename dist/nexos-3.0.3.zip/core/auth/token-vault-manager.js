/**
 * ═══════════════════════════════════════════════════════════════════════════
 * TOKEN VAULT MANAGER - CRUD COMPLETO
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * 🎯 Gerenciamento completo de tokens no SharePoint
 * 
 * 📋 Operações disponíveis:
 *   1. CREATE  - Criar novo token
 *   2. READ    - Buscar token do usuário
 *   3. UPDATE  - Atualizar token existente
 *   4. DELETE  - Invalidar token
 *   5. REFRESH - Renovar token expirado
 *   6. LIST    - Listar todos os tokens (admin)
 * 
 * 🚀 COMO USAR:
 * 
 * // Criar instância
 * const tokenVault = new TokenVaultManager();
 * await tokenVault.initialize();
 * 
 * // Criar token
 * await tokenVault.createToken({
 *   userId: 'user@domain.com',
 *   accessToken: 'eyJ...',
 *   refreshToken: 'eyJ...',
 *   expiresAt: new Date(Date.now() + 3600000)
 * });
 * 
 * // Buscar token
 * const token = await tokenVault.getToken('user@domain.com');
 * 
 * // Atualizar token
 * await tokenVault.updateToken('user@domain.com', {
 *   accessToken: 'novo_token',
 *   expiresAt: new Date()
 * });
 * 
 * // Invalidar token
 * await tokenVault.deleteToken('user@domain.com');
 * 
 * // Renovar token
 * await tokenVault.refreshToken('user@domain.com');
 */

class TokenVaultManager {
  constructor() {
    this.siteId = null;
    this.listId = null;
    this.graphUrl = 'https://graph.microsoft.com/v1.0';
    this.initialized = false;
    this.listName = 'Nexos_TokenVault';
    this.externalToken = null; // Token fornecido externamente
  }

  _isThirdPartyContext() {
    try {
      const host = window.location.hostname;
      return host !== 'picking-admin.backoffice.gpa.digital' &&
             !host.endsWith('.chromiumapp.org') &&
             !window.location.protocol.startsWith('chrome-extension');
    } catch (_) {
      return false;
    }
  }

  async _tryRefreshAuthToken(currentToken) {
    try {
      // 1) NexosAuth (fluxo principal em páginas terceiras)
      if (window.NexosAuth?.getToken) {
        if (window.NexosAuth?.refreshToken) {
          await window.NexosAuth.refreshToken().catch(() => false);
        }
        const t = await window.NexosAuth.getToken();
        if (t && t !== currentToken) {
          this.externalToken = t;
          return t;
        }
      }
    } catch (_) {}

    try {
      // 2) MSAL (fallback para páginas de extensão/admin)
      if (window.msalAuth?.msalInstance) {
        const accounts = window.msalAuth.msalInstance.getAllAccounts();
        if (accounts.length > 0) {
          const response = await window.msalAuth.msalInstance.acquireTokenSilent({
            scopes: ['https://graph.microsoft.com/.default'],
            account: accounts[0],
            forceRefresh: true
          });
          if (response?.accessToken && response.accessToken !== currentToken) {
            this.externalToken = response.accessToken;
            return response.accessToken;
          }
        }
      }
    } catch (_) {}

    return null;
  }

  /**
   * Proxy de fetch para contornar CSP de páginas hospedeiras (Uber/Lalamove/etc.)
   * e retry automático em 401 por token expirado.
   */
  async _fetch(url, options = {}) {
    const internalRetryFlag = options.__retriedAuth === true;
    const fetchOptions = { ...options };
    delete fetchOptions.__retriedAuth;

    const authHeader = fetchOptions.headers?.Authorization || fetchOptions.headers?.authorization || '';
    const currentToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

    const sendViaBackground = this._isThirdPartyContext() && typeof chrome !== 'undefined' && chrome.runtime?.sendMessage;

    const sendViaBridge = this._isThirdPartyContext() && (!sendViaBackground) && typeof document !== 'undefined';

    const fetchViaBridge = async () => {
      const requestId = `nexos-fetch-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          document.removeEventListener('nexos-response', onResponse);
          reject(new Error('Timeout aguardando PROXY_FETCH_RESPONSE'));
        }, 20000);

        const onResponse = (ev) => {
          const detail = ev?.detail || {};
          if (detail.type !== 'PROXY_FETCH_RESPONSE' || detail.requestId !== requestId) return;
          clearTimeout(timeout);
          document.removeEventListener('nexos-response', onResponse);

          if (!detail.success || !detail.data) {
            reject(new Error(detail.error || 'Proxy fetch falhou'));
            return;
          }

          const response = detail.data;
          resolve({
            ok: response.ok,
            status: response.status,
            text: () => Promise.resolve(response.body || ''),
            json: () => {
              try { return Promise.resolve(JSON.parse(response.body || '{}')); }
              catch (e) { return Promise.reject(new Error('JSON inválido: ' + response.body)); }
            }
          });
        };

        document.addEventListener('nexos-response', onResponse);
        document.dispatchEvent(new CustomEvent('nexos-request', {
          detail: {
            type: 'PROXY_FETCH',
            timestamp: Date.now(),
            payload: {
              requestId,
              url,
              options: fetchOptions
            }
          }
        }));
      });
    };

    const performRequest = async () => {
      if (sendViaBackground) {
        return new Promise((resolve, reject) => {
          try {
            chrome.runtime.sendMessage({
              action: 'nexos_fetch',
              url,
              method: fetchOptions.method || 'GET',
              headers: fetchOptions.headers || {},
              body: fetchOptions.body || undefined
            }, (response) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
                return;
              }
              if (!response) {
                reject(new Error('Sem resposta do background (proxy fetch)'));
                return;
              }
              resolve({
                ok: response.ok,
                status: response.status,
                text: () => Promise.resolve(response.body || ''),
                json: () => {
                  try { return Promise.resolve(JSON.parse(response.body || '{}')); }
                  catch (e) { return Promise.reject(new Error('JSON inválido: ' + response.body)); }
                }
              });
            });
          } catch (_e) {
            reject(new Error('Extension context invalidated'));
          }
        });
      }

      if (sendViaBridge) {
        return fetchViaBridge();
      }

      return fetch(url, fetchOptions);
    };

    const response = await performRequest();

    // Retry automático em 401 por token expirado
    if (response.status === 401 && !internalRetryFlag && currentToken) {
      const refreshedToken = await this._tryRefreshAuthToken(currentToken);
      if (refreshedToken && refreshedToken !== currentToken) {
        const retryHeaders = { ...(fetchOptions.headers || {}), Authorization: `Bearer ${refreshedToken}` };
        return this._fetch(url, { ...fetchOptions, headers: retryHeaders, __retriedAuth: true });
      }
    }

    return response;
  }

  /**
   * Inicializa o manager com um token externo (sem depender de MSAL)
   * 
   * @param {string} accessToken - Access token obtido externamente (ex: via Chrome Identity)
   * @returns {Promise<{success: boolean, siteId?: string, listId?: string, error?: string}>}
   */
  async initializeWithToken(accessToken) {
    console.log('%c🔐 TOKEN VAULT MANAGER (Token Externo)', 'color: #0078d4; font-weight: bold; font-size: 14px');
    console.log('%c─'.repeat(80), 'color: #0078d4');

    try {
      if (!accessToken) {
        throw new Error('Access token não fornecido');
      }

      // Armazenar token externo
      this.externalToken = accessToken;
      console.log('✅ Token externo configurado');

      // Obter Site ID
      const siteResponse = await this._fetch(
        `${this.graphUrl}/sites/gpabr.sharepoint.com:/sites/Nexos`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (!siteResponse.ok) {
        const errorText = await siteResponse.text();
        throw new Error(`Erro ao acessar site: HTTP ${siteResponse.status} - ${errorText}`);
      }

      const siteData = await siteResponse.json();
      this.siteId = siteData.id;
      console.log('✅ Site ID obtido:', this.siteId);

      // Obter List ID
      const listResponse = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists?$filter=displayName eq '${this.listName}'`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (!listResponse.ok) {
        const errorText = await listResponse.text();
        throw new Error(`Erro ao buscar lista: HTTP ${listResponse.status} - ${errorText}`);
      }

      const listData = await listResponse.json();
      
      if (!listData.value || listData.value.length === 0) {
        throw new Error(`Lista ${this.listName} não encontrada! Execute o setup primeiro.`);
      }

      this.listId = listData.value[0].id;
      console.log('✅ List ID obtido:', this.listId);

      this.initialized = true;
      console.log('%c─'.repeat(80), 'color: #0078d4');
      console.log('%c✅ INICIALIZAÇÃO COMPLETA (Token Externo)', 'color: #00ff00; font-weight: bold');
      console.log('%c─'.repeat(80), 'color: #0078d4');

      return {
        success: true,
        siteId: this.siteId,
        listId: this.listId
      };

    } catch (error) {
      const msg = String(error?.message || error || '');
      const isExpectedAuthIssue = msg.includes('401') || msg.toLowerCase().includes('token is expired') || msg.includes('InvalidAuthenticationToken');
      if (isExpectedAuthIssue) {
        console.info('[TokenVault] ⏸️ Inicialização pendente de token válido (401/expirado).');
      } else {
        console.error('❌ %c❌ Erro na inicialização:', 'color: #d13438; font-weight: bold');
        console.error('❌', error);
      }
      this.initialized = false;
      
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Inicializa o manager obtendo IDs do site e lista (via MSAL)
   * 
   * @param {string} [accessToken] - Token opcional (se não fornecido, busca via MSAL)
   */
  async initialize(accessToken = null) {
    // Se token foi fornecido, usar initializeWithToken
    if (accessToken) {
      return this.initializeWithToken(accessToken);
    }
    console.log('%c🔐 TOKEN VAULT MANAGER', 'color: #0078d4; font-weight: bold; font-size: 14px');
    console.log('%c─'.repeat(80), 'color: #0078d4');

    try {
      // Verificar MSAL
      if (!window.msalAuth || !window.msalAuth.msalInstance) {
        throw new Error('MSAL não disponível! Recarregue a página');
      }

      const accounts = window.msalAuth.msalInstance.getAllAccounts();
      if (accounts.length === 0) {
        throw new Error('Nenhuma conta logada! Execute: window.unifiedAuth.loginRedirect()');
      }

      console.log('✅ Conta:', accounts[0].username);

      // Obter token
      const accessToken = await this._getAccessToken();
      console.log('✅ Token obtido');

      // Obter Site ID
      const siteResponse = await this._fetch(
        `${this.graphUrl}/sites/gpabr.sharepoint.com:/sites/Nexos`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (!siteResponse.ok) {
        throw new Error(`Erro ao acessar site: HTTP ${siteResponse.status}`);
      }

      const siteData = await siteResponse.json();
      this.siteId = siteData.id;
      console.log('✅ Site ID obtido');

      // Obter List ID
      const listResponse = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists?$filter=displayName eq '${this.listName}'`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (!listResponse.ok) {
        throw new Error(`Erro ao buscar lista: HTTP ${listResponse.status}`);
      }

      const listData = await listResponse.json();
      
      if (!listData.value || listData.value.length === 0) {
        throw new Error(`Lista ${this.listName} não encontrada!`);
      }

      this.listId = listData.value[0].id;
      console.log('✅ Lista ID obtido');
      console.log('%c─'.repeat(80), 'color: #0078d4');
      console.log('%c✅ Manager inicializado com sucesso!', 'color: #107c10; font-weight: bold');
      console.log('');

      this.initialized = true;
      return true;

    } catch (error) {
      // ✅ Erro esperado quando usuário não está autenticado
      if (error.message && error.message.includes('Nenhuma conta logada')) {
        console.log('[TokenVault] ⏸️ Usuário não autenticado - aguardando login');
      } else {
        console.error('%c❌ Erro na inicialização:', 'color: #d13438; font-weight: bold');
        console.error(error);
      }
      throw error;
    }
  }

  /**
   * Helper: Obter Access Token do MSAL
   */
  /**
   * Obtém access token (usa token externo se disponível, senão MSAL)
   * @private
   */
  async _getAccessToken() {
    // Se há token externo, usar ele
    if (this.externalToken) {
      return this.externalToken;
    }

    // Fallback: buscar via MSAL
    if (!window.msalAuth || !window.msalAuth.msalInstance) {
      throw new Error('Nenhum token disponível (nem externo, nem MSAL)');
    }

    const accounts = window.msalAuth.msalInstance.getAllAccounts();
    if (accounts.length === 0) {
      throw new Error('Nenhuma conta logada no MSAL');
    }

    const tokenRequest = {
      scopes: ['https://graph.microsoft.com/.default'],
      account: accounts[0],
      forceRefresh: false
    };

    try {
      const response = await window.msalAuth.msalInstance.acquireTokenSilent(tokenRequest);
      return response.accessToken;
    } catch (error) {
      const response = await window.msalAuth.msalInstance.acquireTokenPopup(tokenRequest);
      return response.accessToken;
    }
  }

  /**
   * Helper: Validar inicialização
   */
  _ensureInitialized() {
    if (!this.initialized) {
      throw new Error('Manager não inicializado! Execute: await tokenVault.initialize()');
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 1️⃣ CREATE - Criar novo token
  // ═══════════════════════════════════════════════════════════════════════════
  
  async createToken(tokenData) {
    this._ensureInitialized();

    console.log('%c1️⃣ CREATE TOKEN', 'color: #107c10; font-weight: bold');
    console.log('─'.repeat(80));

    // Validar dados obrigatórios
    const required = ['userId', 'accessToken', 'refreshToken', 'expiresAt'];
    for (const field of required) {
      if (!tokenData[field]) {
        throw new Error(`Campo obrigatório ausente: ${field}`);
      }
    }

    const now = new Date().toISOString();
    const expiresAt = tokenData.expiresAt instanceof Date 
      ? tokenData.expiresAt.toISOString() 
      : tokenData.expiresAt;

    const item = {
      fields: {
        Title: `Token - ${tokenData.userId}`,
        UserID: tokenData.userId,
        AccessToken: tokenData.accessToken.substring(0, 100) + '...', // Preview
        RefreshToken: tokenData.refreshToken.substring(0, 50) + '...',
        ExpiresAt: expiresAt,
        IsValid: true,
        CreatedAt: now,
        UpdatedAt: now,
        LastUsedAt: now,
        DeviceID: tokenData.deviceId || 'N/A',
        Scopes: tokenData.scopes || 'https://graph.microsoft.com/.default'
      }
    };

    console.log('📝 Criando token para:', tokenData.userId);
    console.log('🔍 DEBUG - Campos sendo enviados:', item.fields);

    const accessToken = await this._getAccessToken();
    const response = await this._fetch(
      `${this.graphUrl}/sites/${this.siteId}/lists/${this.listId}/items`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(item)
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const created = await response.json();
    console.log('✅ Token criado! ID:', created.id);
    console.log('🔍 DEBUG - Campos retornados após criação:');
    console.log(Object.keys(created.fields || {}));
    console.log('');

    return created;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 2️⃣ READ - Buscar token do usuário
  // ═══════════════════════════════════════════════════════════════════════════
  
  async getToken(userId, options = {}) {
    this._ensureInitialized();

    const maxRetries = options.maxRetries || 3;
    const retryDelay = options.retryDelay || 1000; // 1 segundo inicial

    console.log('%c2️⃣ GET TOKEN', 'color: #107c10; font-weight: bold');
    console.log('─'.repeat(80));
    console.log('🔍 Buscando token para:', userId);
    console.log('🔄 Retries configurados:', maxRetries);

    const accessToken = await this._getAccessToken();
    
    // Função interna para buscar
    const fetchToken = async () => {
      // 🔧 SOLUÇÃO: Buscar APENAS por UserID (indexado)
      // Filtrar IsValid manualmente no JavaScript (SharePoint tem delay de indexação em filtros compostos)
      const url = `${this.graphUrl}/sites/${this.siteId}/lists/${this.listId}/items?$expand=fields&$filter=fields/UserID eq '${userId}'`;
      
      const response = await this._fetch(url, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      
      // Filtrar IsValid=true MANUALMENTE no JavaScript
      if (data.value && data.value.length > 0) {
        data.value = data.value.filter(t => t.fields.IsValid === true);
      }
      
      return data;
    };

    // Retry loop com delay exponencial
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const data = await fetchToken();
        
        if (data.value && data.value.length > 0) {
          // Como cada usuário tem apenas 1 token válido, pegamos o primeiro
          const token = data.value[0];
          
          console.log('✅ Token encontrado na tentativa', attempt);
          console.log('✅ Token ID:', token.id);
          console.log('📅 Criado em:', new Date(token.fields.CreatedAt).toLocaleString('pt-BR'));
          console.log('✅ IsValid:', token.fields.IsValid);
          console.log('');
          
          return token;
        }
        
        // Não encontrou - fazer retry
        if (attempt < maxRetries) {
          const waitTime = retryDelay * Math.pow(2, attempt - 1); // Exponencial: 1s, 2s, 4s
          console.log(`⏳ Token não encontrado. Tentativa ${attempt}/${maxRetries}. Aguardando ${waitTime}ms...`);
          await new Promise(resolve => setTimeout(resolve, waitTime));
        }
        
      } catch (error) {
        if (attempt === maxRetries) {
          throw error; // Última tentativa, propaga o erro
        }
        console.log(`❌ Erro na tentativa ${attempt}:`, error.message);
        const waitTime = retryDelay * Math.pow(2, attempt - 1);
        console.log(`⏳ Aguardando ${waitTime}ms antes de retry...`);
        await new Promise(resolve => setTimeout(resolve, waitTime));
      }
    }
    
    console.log('⚠️ Token não encontrado para:', userId);
    console.log('');
    
    return null;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 3️⃣ UPDATE - Atualizar token existente
  // ═══════════════════════════════════════════════════════════════════════════
  
  async updateToken(userId, updates) {
    this._ensureInitialized();

    console.log('%c3️⃣ UPDATE TOKEN', 'color: #107c10; font-weight: bold');
    console.log('─'.repeat(80));

    // Buscar token existente
    const existing = await this.getToken(userId);
    if (!existing) {
      throw new Error(`Token não encontrado para: ${userId}`);
    }

    const now = new Date().toISOString();
    const fields = {
      UpdatedAt: now
    };

    // Atualizar campos fornecidos
    if (updates.accessToken) {
      fields.AccessToken = updates.accessToken.substring(0, 100) + '...';
    }
    if (updates.refreshToken) {
      fields.RefreshToken = updates.refreshToken.substring(0, 50) + '...';
    }
    if (updates.expiresAt) {
      fields.ExpiresAt = updates.expiresAt instanceof Date 
        ? updates.expiresAt.toISOString() 
        : updates.expiresAt;
    }
    if (updates.isValid !== undefined) {
      fields.IsValid = updates.isValid;
    }
    if (updates.lastUsedAt) {
      fields.LastUsedAt = updates.lastUsedAt instanceof Date 
        ? updates.lastUsedAt.toISOString() 
        : updates.lastUsedAt;
    }
    if (updates.renewedAt) {
      fields.RenewedAt = now;
    }

    console.log('📝 Atualizando token ID:', existing.id);

    const accessToken = await this._getAccessToken();
    const response = await this._fetch(
      `${this.graphUrl}/sites/${this.siteId}/lists/${this.listId}/items/${existing.id}/fields`,
      {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(fields)
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const updated = await response.json();
    console.log('✅ Token atualizado com sucesso!');
    console.log('');

    return updated;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 4️⃣ DELETE - Invalidar token
  // ═══════════════════════════════════════════════════════════════════════════
  
  async deleteToken(userId, permanentDelete = false) {
    this._ensureInitialized();

    console.log('%c4️⃣ DELETE TOKEN', 'color: #d13438; font-weight: bold');
    console.log('─'.repeat(80));

    // Buscar token existente
    const existing = await this.getToken(userId);
    if (!existing) {
      throw new Error(`Token não encontrado para: ${userId}`);
    }

    const accessToken = await this._getAccessToken();

    if (permanentDelete) {
      // Exclusão permanente
      console.log('🗑️ Excluindo permanentemente token ID:', existing.id);

      const response = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listId}/items/${existing.id}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      if (!response.ok && response.status !== 204) {
        throw new Error(`HTTP ${response.status}`);
      }

      console.log('✅ Token excluído permanentemente!');
    } else {
      // Apenas invalidar (soft delete)
      console.log('❌ Invalidando token ID:', existing.id);

      const response = await this._fetch(
        `${this.graphUrl}/sites/${this.siteId}/lists/${this.listId}/items/${existing.id}/fields`,
        {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            IsValid: false,
            UpdatedAt: new Date().toISOString()
          })
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${await response.text()}`);
      }

      console.log('✅ Token invalidado com sucesso!');
    }

    console.log('');
    return true;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 5️⃣ REFRESH - Renovar token expirado
  // ═══════════════════════════════════════════════════════════════════════════
  
  async refreshToken(userId) {
    this._ensureInitialized();

    console.log('%c5️⃣ REFRESH TOKEN', 'color: #107c10; font-weight: bold');
    console.log('─'.repeat(80));

    // Buscar token existente
    const existing = await this.getToken(userId);
    if (!existing) {
      throw new Error(`Token não encontrado para: ${userId}`);
    }

    // Verificar se está expirado
    const expiresAt = new Date(existing.fields.ExpiresAt);
    const now = new Date();
    
    if (expiresAt > now) {
      console.log('ℹ️ Token ainda válido, não precisa renovar');
      console.log('⏰ Expira em:', expiresAt.toLocaleString('pt-BR'));
      return existing;
    }

    console.log('🔄 Token expirado, renovando...');

    // Aqui você implementaria a lógica de renovação real usando o refreshToken
    // Por enquanto, vamos simular obtendo um novo token do MSAL
    const accounts = window.msalAuth.msalInstance.getAllAccounts();
    const tokenRequest = {
      scopes: ['https://graph.microsoft.com/.default'],
      account: accounts[0],
      forceRefresh: true // Força renovação
    };

    const tokenResponse = await window.msalAuth.msalInstance.acquireTokenSilent(tokenRequest);

    // Atualizar token no SharePoint
    await this.updateToken(userId, {
      accessToken: tokenResponse.accessToken,
      expiresAt: tokenResponse.expiresOn,
      renewedAt: true,
      lastUsedAt: new Date()
    });

    console.log('✅ Token renovado com sucesso!');
    console.log('⏰ Nova expiração:', new Date(tokenResponse.expiresOn).toLocaleString('pt-BR'));
    console.log('');

    return await this.getToken(userId);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 6️⃣ LIST - Listar todos os tokens (admin)
  // ═══════════════════════════════════════════════════════════════════════════
  
  async listAllTokens(options = {}) {
    this._ensureInitialized();

    console.log('%c6️⃣ LIST ALL TOKENS', 'color: #107c10; font-weight: bold');
    console.log('─'.repeat(80));

    const top = options.top || 10;
    const onlyValid = options.onlyValid !== false; // Default true

    let filter = '';
    if (onlyValid) {
      filter = '&$filter=fields/IsValid eq true';
    }

    const accessToken = await this._getAccessToken();
    
    // 🔧 SEM $orderby: Campo CreatedAt não está indexado, causando erro
    // Usamos Created (campo system) que não precisa de índice
    const response = await this._fetch(
      `${this.graphUrl}/sites/${this.siteId}/lists/${this.listId}/items?$expand=fields&$top=${top}${filter}`,
      {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly' // Permite queries sem índice
        }
      }
    );

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${await response.text()}`);
    }

    const data = await response.json();
    let tokens = data.value || [];

    // Ordenar manualmente por CreatedAt (decrescente)
    tokens.sort((a, b) => {
      const dateA = new Date(a.fields.CreatedAt || 0);
      const dateB = new Date(b.fields.CreatedAt || 0);
      return dateB - dateA; // Decrescente (mais recente primeiro)
    });

    console.log(`📋 Encontrados ${tokens.length} tokens`);
    console.log('📊 Ordenados manualmente por CreatedAt (mais recente primeiro)');
    console.log('');

    if (tokens.length > 0) {
      console.table(tokens.slice(0, 10).map(t => ({ // Mostrar apenas primeiros 10
        'ID': t.id,
        'UserID': t.fields.UserID,
        'IsValid': t.fields.IsValid ? '✓' : '✗',
        'ExpiresAt': new Date(t.fields.ExpiresAt).toLocaleString('pt-BR'),
        'CreatedAt': new Date(t.fields.CreatedAt).toLocaleString('pt-BR')
      })));
    }

    return tokens;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 🔧 UTILS - Verificar status do token
  // ═══════════════════════════════════════════════════════════════════════════
  
  async checkTokenStatus(userId) {
    const token = await this.getToken(userId);
    if (!token) {
      return {
        exists: false,
        valid: false,
        expired: null
      };
    }

    const expiresAt = new Date(token.fields.ExpiresAt);
    const now = new Date();
    const expired = expiresAt < now;

    return {
      exists: true,
      valid: token.fields.IsValid && !expired,
      expired: expired,
      expiresAt: expiresAt,
      token: token
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORTAR GLOBALMENTE
// ═══════════════════════════════════════════════════════════════════════════

window.TokenVaultManager = TokenVaultManager;

console.log('%c✅ TokenVaultManager carregado!', 'color: #107c10; font-weight: bold');
console.log('');
console.log('%c💡 Como usar:', 'color: #0078d4; font-weight: bold');
console.log('');
console.log('// Criar instância');
console.log('const tokenVault = new TokenVaultManager();');
console.log('await tokenVault.initialize();');
console.log('');
console.log('// Criar token');
console.log('await tokenVault.createToken({ userId, accessToken, refreshToken, expiresAt });');
console.log('');
console.log('// Buscar token');
console.log('await tokenVault.getToken(userId);');
console.log('');
console.log('// Atualizar token');
console.log('await tokenVault.updateToken(userId, { accessToken, expiresAt });');
console.log('');
console.log('// Invalidar token');
console.log('await tokenVault.deleteToken(userId);');
console.log('');
console.log('// Renovar token');
console.log('await tokenVault.refreshToken(userId);');
console.log('');
console.log('// Listar tokens');
console.log('await tokenVault.listAllTokens();');
console.log('');
